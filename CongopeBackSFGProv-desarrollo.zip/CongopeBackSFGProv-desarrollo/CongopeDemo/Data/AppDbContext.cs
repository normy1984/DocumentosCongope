﻿using Congope.Empresas.Models.Bpm;
using Congope.Empresas.Models.Genericas;
using Microsoft.EntityFrameworkCore;


namespace Congope.Empresas.Data
{

    /**
     * Con esto hacemos ingenieria inversa
     * dotnet ef dbcontext scaffold "Host=localhost;Port=5432;Database=contabilidad_act;Username=postgres;Password=edjavi1981" Npgsql.EntityFrameworkCore.PostgreSQL --output-dir ModelsTemp --context TempDbContext --schema public
     * dotnet ef dbcontext scaffold "Host=localhost;Port=5432;Database=contabilidad_act;Username=postgres;Password=edjavi1981" Npgsql.EntityFrameworkCore.PostgreSQL --output-dir ModelsTemp --context TempDbContext --schema public --table clientes

     */

    public class AppDbContext : DbContext
    {
        public DbSet<DocumentoBpmMo> documentoproceso { get; set; }
        public DbSet<Attlog> Attlog { get; set; }
        public DbSet<Userinfo> Userinfo { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Attlog>().HasNoKey();
            modelBuilder.HasDefaultSchema("public");
        }
    }
}
