﻿using System.Text;
using Newtonsoft.Json;

namespace Congope.Empresas.Data
{
    public class CamundaBpm
    {
        private readonly HttpClient _http;

        public CamundaBpm()
        {
            _http = new HttpClient();
            _http.BaseAddress = new Uri(Conexion.CamundaBpm);
        }

        // 1️⃣ Iniciar proceso
        public async Task<string> StartProcessAsync(string processKey, object variables)
        {
            var payload = new { variables = variables };
            var json = JsonConvert.SerializeObject(payload);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.PostAsync($"process-definition/key/{processKey}/start", content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 2️⃣ Completar tarea enviando variables
        public async Task CompleteTaskAsync(string taskId, object variables)
        {
            var payload = new { variables = variables };
            var json = JsonConvert.SerializeObject(payload);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.PostAsync($"task/{taskId}/complete", content);
            response.EnsureSuccessStatusCode();

        }

        // Funcion para validar si el proceso ya termino
        public async Task<bool> ProcesoFinalizadoAsync(string processInstanceId)
        {
            var response = await _http.GetAsync($"process-instance/{processInstanceId}");

            // Si devuelve 404 => proceso no existe => ya terminó
            return response.StatusCode == System.Net.HttpStatusCode.NotFound;
        }

        // 3️⃣ Obtener lista de tareas (filtradas por query)
        public async Task<string> GetTasksAsync(object query)
        {
            var json = JsonConvert.SerializeObject(query);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _http.PostAsync("task", content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 4️⃣ Obtener tareas activas por instancia de proceso
        public async Task<string> GetActiveTasksByProcessAsync(string processInstanceId)
        {
            var response = await _http.GetAsync($"task?processInstanceId={processInstanceId}");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 5️⃣ Obtener detalle de una tarea específica
        public async Task<string> GetTaskDetailAsync(string taskId)
        {
            var response = await _http.GetAsync($"task/{taskId}");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 6️⃣ Obtener historial de actividades de un proceso
        public async Task<string> GetHistoryAsync(string processInstanceId)
        {
            var response = await _http.GetAsync($"history/activity-instance?processInstanceId={processInstanceId}");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 7️⃣ Obtener variables de una instancia (ej: para saber info del documento asociado)
        public async Task<string> GetProcessVariablesAsync(string processInstanceId)
        {
            var response = await _http.GetAsync($"process-instance/{processInstanceId}/variables");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }

        // 8️⃣ Cancelar/Anular un proceso
        public async Task CancelProcessAsync(string processInstanceId, string reason = "Anulado por usuario")
        {
            var requestUri = $"process-instance/{processInstanceId}";
            var request = new HttpRequestMessage(HttpMethod.Delete, requestUri)
            {
                Content = new StringContent(
                    JsonConvert.SerializeObject(new
                    {
                        skipCustomListeners = true,
                        skipSubprocesses = true
                    }),
                    Encoding.UTF8,
                    "application/json"
                )
            };

            request.Headers.Add("X-Cancellation-Reason", reason);

            var response = await _http.SendAsync(request);
            response.EnsureSuccessStatusCode();
        }
    }
}
