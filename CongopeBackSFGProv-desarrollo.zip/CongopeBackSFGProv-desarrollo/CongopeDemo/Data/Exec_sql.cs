﻿using Congope.Empresas.BussinessLogic.Genericas;
using MongoDB.Driver;
using MongoDB.Bson;
using Newtonsoft.Json;
using Npgsql;
using System.Data;
using System.Reflection;
using System.Text.Json;
using Congope.Empresas.Models;
using System.Diagnostics;
using System.Runtime.ConstrainedExecution;
using System;


namespace Congope.Empresas.Data
{
    public class Exec_sql
    {
        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato Model de acuerdo a una declaracion de un modelo
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosModel<ModelClass>(NpgsqlCommand Command)
        {
            try
            {
                List<ModelClass> listaGenerica = new List<ModelClass>();

                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();

                    using (NpgsqlDataReader dr = Command.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            listaGenerica = DataReaderMapToList<ModelClass>(dr);
                        }
                        else
                        {
                            return new
                            {
                                success = false,
                                message = "No existen registros",
                                result = ""
                            };
                        }
                    }
                }

                return new
                {
                    success = true,
                    message = "Success",
                    result = listaGenerica
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato JSON
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosJson(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();

                    DataTable listaGenerica = new DataTable();

                    using (NpgsqlDataReader dr = Command.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            listaGenerica.Load(dr);
                        }
                        else
                        {
                            return new
                            {
                                success = false,
                                message = "No existen registros",
                                result = JsonConvert.SerializeObject(new object[0])
                            };
                        }
                    }

                    return new
                    {
                        success = true,
                        message = "Success",
                        result = JsonConvert.SerializeObject(listaGenerica)
                    };
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuery(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();
                    int rowsAffected = Command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return new
                        {
                            success = true,
                            message = "Se guardaron correctamente " + rowsAffected + " registros.",
                            result = ""
                        };
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: La actualización no afectó ninguna fila.",
                            result = ""
                        };
                    }
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }


        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuerySP(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.CommandType = CommandType.StoredProcedure;
                    Command.Connection = oConexion;
                    oConexion.Open();
                    int rowsAffected = Command.ExecuteNonQuery();

                    if (rowsAffected != 0)
                    {
                        return new
                        {
                            success = true,
                            message = "El comando se ejecutó en el servidor.",
                            result = ""
                        };
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: El comando no se ejecutó en el servidor.",
                            result = ""
                        };
                    }
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que permite la eliminacion de un registro en el servidor
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQueryDelete(NpgsqlCommand Command)
        {
            try
            {
                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.Connection = oConexion;
                oConexion.Open();

                bool deleted = (bool)Command.ExecuteScalar();

                oConexion.Close();

                return new
                {
                    success = deleted,
                    message = deleted ? "Registro eliminado exitosamente" : "No se pudo eliminar el registro"
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message
                };
            }
        }

        /// <summary>
        /// Funcion que convierte un modelo de datos en un modelo declarado previamente
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static List<ModelClass> DataReaderMapToList<ModelClass>(IDataReader dr)
        {
            List<ModelClass> list = new List<ModelClass>();
            ModelClass obj = default(ModelClass);

            // Obtener los nombres de las columnas y convertirlos a minúsculas
            List<string> columnNames = Enumerable.Range(0, dr.FieldCount)
                                                 .Select(i => dr.GetName(i).ToLower())
                                                 .ToList();

            // Obtener los tipos de datos de las propiedades del modelo
            PropertyInfo[] props = typeof(ModelClass).GetProperties();

            while (dr.Read())
            {
                obj = Activator.CreateInstance<ModelClass>();

                foreach (PropertyInfo prop in props)
                {
                    string propName = prop.Name.ToLower();

                    if (columnNames.Contains(propName) && !dr.IsDBNull(columnNames.IndexOf(propName)))
                    {
                        object value = dr.GetValue(columnNames.IndexOf(propName));

                        if (value != DBNull.Value)
                        {
                            // Convertir el valor según el tipo de la propiedad
                            if (prop.PropertyType == typeof(string))
                            {
                                prop.SetValue(obj, Convert.ToString(value).Trim(), null);
                            }
                            else if (prop.PropertyType == typeof(int))
                            {
                                prop.SetValue(obj, Convert.ToInt32(value), null);
                            }
                            else if (prop.PropertyType == typeof(float))
                            {
                                prop.SetValue(obj, Convert.ToSingle(value), null);
                            }
                            // Añadir aquí más conversiones según necesidad (por ejemplo, para tipos DateTime, double, etc.)
                            else
                            {
                                prop.SetValue(obj, value, null);
                            }
                        }
                    }
                    else
                    {
                        // Asignar valor nulo si la columna no está presente en el resultado
                        prop.SetValue(obj, null);
                    }
                }

                list.Add(obj);
            }

            return list;
        }

        /// <summary>
        /// La función ObtenerDatosMongo está diseñada para realizar una consulta en una colección de MongoDB utilizando un filtro dinámico y, 
        /// opcionalmente, ordenando los resultados en función de un campo especificado.
        /// </summary>
        /// <param name="coleccion"></param>
        /// <param name="filtro"></param>
        /// <param name="sortField"></param>
        /// <returns></returns>

        public static dynamic ObtenerDatosMongo(string coleccion, Dictionary<string, object> filtro, string? sortField = null)
        {
            try
            {

                var filterList = new List<FilterDefinition<BsonDocument>>();

                foreach (var item in filtro)
                {
                    // Verificar el tipo de cada valor
                    if (item.Value is JsonElement jsonElement)
                    {
                        // Si el valor es un JsonElement, extraemos el valor real de acuerdo con su ValueKind
                        switch (jsonElement.ValueKind)
                        {
                            case JsonValueKind.String:
                                filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, jsonElement.GetString()));
                                break;

                            case JsonValueKind.Number:
                                filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, jsonElement.GetDecimal()));
                                break;

                            case JsonValueKind.True:
                            case JsonValueKind.False:
                                filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, jsonElement.GetBoolean()));
                                break;

                            case JsonValueKind.Object:
                            case JsonValueKind.Array:
                                // Manejo de objetos o arreglos (puedes agregar más lógica si lo necesitas)
                                filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, jsonElement.ToString()));
                                break;

                            default:
                                filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, item.Value));
                                break;
                        }
                    }
                    else
                    {
                        // Si el valor no es un JsonElement, simplemente lo agregamos al filtro
                        filterList.Add(Builders<BsonDocument>.Filter.Eq(item.Key, item.Value));
                    }
                }

                // Combinar todos los filtros con 'And' para que todos los criterios sean cumplidos
                var filtroBson = Builders<BsonDocument>.Filter.And(filterList);

                //var filtro = JsonConvert.DeserializeObject<Dictionary<string, object>>(filtroJSON);

                // Obtener la base de datos y colección
                IMongoClient oConexion = new MongoClient(Conexion.cadenaMongo); // Cambia según tu cadena de conexión
                IMongoDatabase db = oConexion.GetDatabase(Conexion.DBMongo); // No pasamos la base de datos aquí

                var collection = db.GetCollection<BsonDocument>(coleccion);

                // Crear un filtro dinámico utilizando los valores del diccionario
                // var filtroBson = Builders<BsonDocument>.Filter.And(
                //    filtro.Select(item => Builders<BsonDocument>.Filter.Eq(item.Key, item.Value)).ToArray()
                //);

                // Buscar los documentos que coincidan con el filtro
                var documentos = collection.Find(filtroBson).ToList();

                if (!string.IsNullOrEmpty(sortField))
                {
                    documentos = collection.Find(filtroBson)
                          .Sort(Builders<BsonDocument>.Sort.Ascending(sortField)) // Ordenar por 'FechaSubida' descendente
                          .ToList();
                }

                if (documentos.Count > 0)
                {
                    // Convertir cada documento a JSON utilizando ToJson
                    var jsonDocumentos = documentos.Select(doc => doc.ToJson()).ToList();
                    return new
                    {
                        success = true,
                        message = "Registros encontrados",
                        result = jsonDocumentos
                    };
                }
                else
                {
                    throw new Exception("No se encontraron registros");
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }


        /// <summary>
        /// La función EjecutarComandoMongo es una función que maneja operaciones de base de datos en MongoDB, 
        /// específicamente insertar, actualizar, eliminar y consultar múltiples documentos. 
        /// Esta función toma diferentes parámetros, ejecuta la operación correspondiente según el valor de operacion, 
        /// y devuelve un objeto que indica el resultado de la operación (ya sea éxito o error).
        /// </summary>
        /// <param name="coleccion"></param>
        /// <param name="operacion"></param>
        /// <param name="filtro"></param>
        /// <param name="datos"></param>
        /// <param name="documentos"></param>
        /// <returns></returns>

        public static dynamic EjecutarComandoMongo(string coleccion, string operacion, Dictionary<string, object> filtro, object? datos = null, List<BsonDocument>? documentos = null)
        {
            var resultado = new ApiResultMo<string>();

            try
            {
                // Obtener la base de datos y colección
                IMongoClient oConexion = new MongoClient(Conexion.cadenaMongo); // Cambia según tu cadena de conexión
                IMongoDatabase db = oConexion.GetDatabase(Conexion.DBMongo); // No pasamos la base de datos aquí
                var collection = db.GetCollection<BsonDocument>(coleccion);

                // Comprobar si el filtro es nulo o vacío, en caso de serlo asignar un filtro vacío
                var filtroBson = Builders<BsonDocument>.Filter.Empty;

                if (filtro != null && filtro.Count > 0)
                {
                    // Crear un filtro dinámico utilizando los valores del diccionario
                    filtroBson = Builders<BsonDocument>.Filter.And(
                        filtro.Select(item => Builders<BsonDocument>.Filter.Eq(item.Key, item.Value)).ToArray()
                    );
                }

                // Resultado de la operación
                switch (operacion.ToLower())
                {
                    case "insert":
                        // INSERT: Insertar un nuevo documento
                        collection.InsertOne(datos.ToBsonDocument());
                        resultado.message = "Documento insertado exitosamente";
                        resultado.success = true;
                        break;

                    case "update":
                        // UPDATE: Actualizar un documento existente
                        var updateResult = collection.UpdateOne(
                            filtroBson,  // Filtro de búsqueda
                            Builders<BsonDocument>.Update.Set("campo", "valorNuevo") // Cambia este update según el campo y valor
                        );

                        if (updateResult.ModifiedCount > 0)
                        {
                            resultado.message = "Documento actualizado exitosamente";
                            resultado.success = true;
                        }
                        else
                        {
                            throw new Exception("No se encontraron documentos para actualizar");
                        }
                        break;

                    case "delete":
                        // DELETE: Eliminar un documento
                        var deleteResult = collection.DeleteOne(filtroBson);

                        if (deleteResult.DeletedCount > 0)
                        {
                            resultado.message = "Documento eliminado exitosamente";
                            resultado.success = true;
                        }
                        else
                        {
                            throw new Exception("No se encontraron documentos para eliminar");
                        }
                        break;

                    case "deletemany":
                        // DELETE MANY: Eliminar muchos documentos
                        var deleteManyResult = collection.DeleteMany(filtroBson);
                        resultado.message = "Documentos eliminados exitosamente";
                        resultado.success = true;
                        break;

                    case "insertmany":
                        // INSERT MANY: Guardar muchos documentos
                        if (documentos == null || !documentos.Any())
                        {
                            throw new Exception("No se proporcionaron documentos para insertar");
                        }
                        collection.InsertMany(documentos);
                        resultado.message = "Documentos insertados exitosamente";
                        resultado.success = true;
                        break;

                    case "insertdelete":
                        // DELETE y luego INSERT
                        var deleteInsertResult = collection.DeleteOne(filtroBson);
                        collection.InsertOne(datos.ToBsonDocument());

                        if (deleteInsertResult.DeletedCount > 0)
                        {
                            resultado.message = "Documento eliminado y luego insertado exitosamente";
                            resultado.success = true;
                        }
                        else
                        {
                            throw new Exception("No se encontraron documentos para eliminar");
                        }
                        break;

                    default:
                        throw new Exception("Operación no válida");
                }


            }
            catch (Exception e)
            {
                // Manejo de errores
                resultado.message = e.Message;
            }

            return resultado;
        }


    }
}
