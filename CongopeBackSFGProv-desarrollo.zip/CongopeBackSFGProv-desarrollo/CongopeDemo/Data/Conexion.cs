﻿namespace Congope.Empresas.Data
{
    /// <summary>
    /// CLASE QUE CONTIENE LAS REFERENCIAS PARA LA CONEXION A LOS DIFERENTES SERVICIOS
    /// </summary>
    public class Conexion
    {
        private static IConfiguration Configuration { get; }

        static Conexion()
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
        }

        // Verifica si se usa una base de datos mongo para los archivos
        public static bool GuardaArchivosRepositorio => bool.Parse(Configuration["GuardaArchivosRepositorio"] ?? "");
        public static bool GuardaArchivosMongo => bool.Parse(Configuration["GuardaArchivosMongo"] ?? "");
        // RUTA DONDE SE GUARDAN LOS ARCHIVOS
        public static string RutaDocumentos => Configuration["RutaDocumentos"] ?? "DocumentosSFGProv";

        // CONFIGURACIÓN DE LA CARPETA DE FOTOS
        public static string RutaFotos => Path.Combine(RutaDocumentos, Configuration["RutaFotos"] ?? "FotoSFGProv");

        // NOMBRE DEL SISTEMA
        public static string NombreSistema => Configuration["NombreSistema"] ?? "Sistema Financiero de Gobiernos Provinciales";

        // VARIABLE DE AMBIENTE
        public static string VariableAmbiente => Configuration["VariableAmbiente"] ?? "Desarrollo";

        // RUTA ARCHIVO ERRORES
        public static string ErrorlogFilePath => Configuration["ErrorlogFilePath"] ?? "error.log";

        // IMAGEN POR DEFECTO
        public static string ErrorImagen => Configuration["ErrorImagen"] ?? "error_imagen.png";
        public static string ErrorFoto => Configuration["ErrorFoto"] ?? "foto_generica.jpg";

        // CONFIGURACION DEL HUB PRA ENVIO DE MENSAJES web socket
        public static string? HubMensajes => Configuration["HubMensajes"];

        // CONFIGURACION DEL HUB PRA ENVIO DE MENSAJES web socket
        public static string? CamundaBpm => Configuration["CamundaBpm"];

        // TOKEN DE TELEGRAM
        public static string TokenTelegram => Configuration["TokenTelegram"] ?? "";

        // CONFIGURACIÓN DE CORREO

        public static CorreoConfiguracionOptions CorreoConfiguracion => Configuration.GetSection("CorreoConfiguracion").Get<CorreoConfiguracionOptions>();

        // CONFIGURACIÓN JWT
        public static JwtConfiguracionOptions JwtConfiguracion => Configuration.GetSection("JwtConfiguracion").Get<JwtConfiguracionOptions>();

        // CONFIGURACIÓN DE BASE DE DATOS
        public static string cadena => $"server={Configuration.GetSection("PgSqlConfiguracion")["Servidor"]};port={Configuration.GetSection("PgSqlConfiguracion")["Port"]};user id={Configuration.GetSection("PgSqlConfiguracion")["UserId"]};password={Configuration.GetSection("PgSqlConfiguracion")["Password"]};database={Configuration.GetSection("PgSqlConfiguracion")["Database"]};";


        // CONFIGURACION DE CONEXION PARA EL MONGODB
        public static string cadenaMongo => $"mongodb://{Configuration.GetSection("MongoDbConfiguracion")["UserId"]}:{Configuration.GetSection("MongoDbConfiguracion")["Password"]}@{Configuration.GetSection("MongoDbConfiguracion")["Servidor"]}:{Configuration.GetSection("MongoDbConfiguracion")["Port"]}?authSource=admin";
        public static string? DBMongo => Configuration.GetSection("MongoDbConfiguracion")["Database"];


        // CONFIGURACIÓN LDAP
        public static LdapConfigOptions ldapConfig => Configuration.GetSection("ldapConfig").Get<LdapConfigOptions>();
        public static string TipoLogin => Configuration["TipoLogin"] ?? "local";
        public static bool ValidarLoginVb6 => bool.Parse(Configuration["ValidarLoginVb6"]);


        // CONFIGURACION PARA LA FIRMA ELECTRONICA
        public static FirmaConfigOptions firmaConfig => Configuration.GetSection("FirmaConfig").Get<FirmaConfigOptions>();

        // CONFGURACION PARA EL SHAREPOINT
        public static SharepointConfigOptions sharepointConfig => Configuration.GetSection("SharepointConfigOptions").Get<SharepointConfigOptions>();

        // CONFGURACION PARA EL OSTICKET
        public static OsticketConfigOptions OsticketConfig => Configuration.GetSection("OSTicketConfig").Get<OsticketConfigOptions>();


        // CONFGURACION PARA EL OPENAI
        public static OpenAIConfigOptions OpenAIConfig => Configuration.GetSection("OpenAIConfig").Get<OpenAIConfigOptions>();


    }

    /// <summary>
    /// ESTRUCTURA PARA JWT
    /// </summary>
    public class JwtConfiguracionOptions
    {
        public required string JwtAuthority { get; set; }
        public required string JwtKey { get; set; }
        public required string JwtIssuer { get; set; }
        public required string JwtAudience { get; set; }
        public required string JwtSubject { get; set; }
        public int JwtDuracionToken { get; set; }
        public int JwtTiempoMaximoRenovar { get; set; }
    }

    /// <summary>
    /// ESTRUCTURA DE CONEXION PARA EL LDAP
    /// </summary>
    public class LdapConfigOptions
    {
        public List<string>? DomainControllers { get; set; }
        public string? AccountSuffix { get; set; }
        public string? BaseDn { get; set; }
        public string? DefaultEmailDomain { get; set; }
        public bool SaveDatabase { get; set; }
    }

    /// <summary>
    /// ESTRUCTURA DE CONEXION PARA EL CORREO
    /// </summary>
    public class CorreoConfiguracionOptions
    {
        public string? MailstrHost { get; set; }
        public int Mailport { get; set; }
        public string? MailstrUserName { get; set; }
        public string? MailstrFromPass { get; set; }
        public string? MailFrom { get; set; }
        public string? MailNameFrom { get; set; }
        public bool MailEnableSsl { get; set; }
    }


    /// <summary>
    /// ESTRUCTURA DE CONEXION PARA LA FIRMA ELECTRÓNICA
    /// </summary>
    public class FirmaConfigOptions
    {
        public int TamanoDocumento { get; set; }
        public int TamanoNombreDocumento { get; set; }
        public string? ServidorDocumentos { get; set; }
        public string? ServidorApi { get; set; }
        public string? X_API_KEY { get; set; }
        public string? Sistema { get; set; }
        public int llx { get; set; }
        public int lly { get; set; }
        public int separacion_firmas { get; set; }
        public string? estampado { get; set; }
        public string? razon { get; set; }

    }

    public class SharepointConfigOptions
    {
        public string? Instance { get; set; }
        public string? TenantId { get; set; }
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public string? Domain { get; set; }
        public string? Graph { get; set; }
        public string? GraphVersion { get; set; }
        public string? SiteId { get; set; }
        public string? DriveId { get; set; }
    }

    /// <summary>
    /// ESTRUCTURA DE CONEXION PARA OSTICKET
    /// </summary>
    public class OsticketConfigOptions
    {
        public string? OSTicketHost { get; set; }
        public string? OSTicketToken { get; set; }
       }

    /// <summary>
    /// ESTRUCTURA DE CONEXION PARA OPENAI
    /// </summary>
    public class OpenAIConfigOptions
    {
        public string? OpenAIToken { get; set; }
        public string? OpenAIModel { get; set; }
    }


}
