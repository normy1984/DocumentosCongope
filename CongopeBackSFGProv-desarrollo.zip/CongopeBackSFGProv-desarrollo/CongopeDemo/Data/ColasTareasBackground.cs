﻿using Congope.Empresas.Models;
using System.Threading.Channels;

namespace Congope.Empresas.Data
{
    public class ColasTareasBackground : IColasTareasBackground
    {
        private readonly Channel<Func<CancellationToken, Task>> _queue;

        public ColasTareasBackground(int capacity = 100)
        {
            var options = new BoundedChannelOptions(capacity)
            {
                FullMode = BoundedChannelFullMode.Wait
            };
            _queue = Channel.CreateBounded<Func<CancellationToken, Task>>(options);
        }

        public void Enqueue(Func<CancellationToken, Task> workItem)
        {
            if (workItem == null) throw new ArgumentNullException(nameof(workItem));
            _queue.Writer.TryWrite(workItem);
        }

        public async Task<Func<CancellationToken, Task>> DequeueAsync(CancellationToken cancellationToken)
        {
            return await _queue.Reader.ReadAsync(cancellationToken);
        }
    }
}
