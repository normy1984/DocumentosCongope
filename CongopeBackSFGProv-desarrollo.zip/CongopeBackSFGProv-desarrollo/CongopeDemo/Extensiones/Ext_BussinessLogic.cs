﻿using Congope.Empresas.BussinessLogic.Bpm;
using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Microsoft.EntityFrameworkCore;
using System;

namespace Congope.Empresas.Extensiones
{
    public static class Ext_BussinessLogic
    {
        public static void AddApplicationServices(this IServiceCollection services)
        {
            var connectionString = Conexion.cadena;
            ///////////SERVICIO GENERICO//////////////
            services.AddDbContext<AppDbContext>(
                options => options.UseNpgsql(connectionString)
                );


            /////////// SERVICIOS CREADOS/////////////
            services.AddScoped<FirmaEcBL>();
            services.AddScoped<FirmaEcRecibeBL>();
            services.AddScoped<BpmBl>();
            services.AddScoped<DocumentoBpmBL>();
            services.AddScoped<TimbradasBL>();

        }
    }
}
