﻿using Microsoft.AspNetCore.SignalR;

namespace Congope.Empresas.Extensiones
{
    public class NotificacionesHub : Hub
    {
        /*
        public async Task EnviarMensaje(string documento)
        {
            // Broadcast a todos los clientes conectados
            var payload = new { documento = "123456" };

            // Enviar a todos los clientes conectados
            await Clients.All.SendAsync("RecibirMensaje", ApiResultMo<object>.Ok(payload));
        }

        public async Task DocumentoFirmado(string documentoId)
        {
            await Clients.All.SendAsync("DocumentoFirmado", documentoId);
        }*/
    }
}
