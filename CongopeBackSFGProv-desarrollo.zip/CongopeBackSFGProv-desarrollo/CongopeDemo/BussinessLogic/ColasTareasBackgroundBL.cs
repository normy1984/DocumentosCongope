﻿using Congope.Empresas.Models;

namespace Congope.Empresas.BussinessLogic
{
    public class ColasTareasBackgroundBL : BackgroundService
    {
        private readonly IColasTareasBackground _taskQueue;

        public ColasTareasBackgroundBL(IColasTareasBackground taskQueue)
        {
            _taskQueue = taskQueue;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var workItem = await _taskQueue.DequeueAsync(stoppingToken);

                try
                {
                    await workItem(stoppingToken);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[BackgroundTask] Error: {ex.Message}");
                }
            }
        }
    }
}
