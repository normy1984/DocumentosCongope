﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Microsoft.Identity.Client;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;
using System.Text.Json;
using Congope.Empresas.Models.Genericas;
using MongoDB.Bson;
using Org.BouncyCastle.Crypto;
using System;
using Congope.Empresas.General;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Immutable;
using Newtonsoft.Json.Linq;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class SharepointBL
    {
        private static IConfidentialClientApplication _app;
        private static SharepointConfigOptions _sharepointConfig;
     
        static SharepointBL()
        {
            //Obtenemos el servidor sharepoint del archivo de configuración.
            _sharepointConfig = Conexion.sharepointConfig;

            _app = ConfidentialClientApplicationBuilder.Create(_sharepointConfig.ClientId)
                .WithClientSecret(_sharepointConfig.ClientSecret)
                .WithAuthority($"{_sharepointConfig.Instance}{_sharepointConfig.TenantId}")
                .Build();

          
        }

        /// <summary>
        /// Sube un archivo al sistema de almacenamiento y lo registra en SharePoint
        /// </summary>
        /// <param name="file">Archivo a subir (IFormFile con datos del archivo)</param>
        /// <param name="uploadMo">Objeto con metadatos adicionales para el archivo</param>
        /// <returns>
        /// Resultado de la operación que contiene:
        /// - La URL/identificador del archivo en SharePoint si es exitoso
        /// - Mensaje de error si falla alguna operación
        /// </returns>
        /// <remarks>
        /// Flujo de ejecución:
        /// 1. Valida que el archivo no esté vacío
        /// 2. Determina la carpeta destino según el código de sistema (codsistema)
        /// 3. Guarda metadatos en la base de datos local
        /// 4. Sube el archivo a SharePoint en la carpeta correspondiente
        /// 
        /// Mapeo de códigos de sistema a carpetas:
        /// 1 → Contabilidad
        /// 2 → Presupuesto
        /// 3 → Inventarios
        /// 4 → Nomina
        /// 5 → ActivosFijos
        /// </remarks>
        /// <exception cref="Exception">
        /// Excepciones posibles:
        /// - "No se ha recibido ningún archivo" cuando el archivo está vacío
        /// - Errores de guardado en base de datos local
        /// - Errores de carga a SharePoint
        /// </exception>
        public static dynamic UploadFile(IFormFile file, UploadMo uploadMo)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    throw new Exception("No se ha recibido ningún archivo.");
                }

                // Diccionario para mapear los valores de codsistema con las colecciones
                var collectionMap = new Dictionary<int, string>
                    {
                        { 1, "Contabilidad" },
                        { 2, "Presupuesto" },
                        { 3, "Inventarios" },
                        { 4, "Nomina" },
                        { 5, "ActivosFijos" }
                    };

                // Asignar la colección usando el codsistema, o un valor predeterminado si no existe
                var Collection = collectionMap.ContainsKey(uploadMo.codsistema) ? collectionMap[uploadMo.codsistema] : "";

                var uploadsFolder = Path.Combine(Conexion.RutaDocumentos, Collection);

                var RespuestaNombreArchivo = UploadBL.GuardaBase(uploadMo, file.FileName, file.ContentType);

                if (RespuestaNombreArchivo.success)
                {
                    using var ms = new MemoryStream();
                    file.CopyTo(ms);
                    var fileBytes = ms.ToArray();

                    var NombreArchivo = JsonConvert.DeserializeObject(RespuestaNombreArchivo.result);
                    NombreArchivo = Convert.ToString(NombreArchivo[0]["nombrearchivo"]);

                    var CargarArchivo = CargarSharepoint(fileBytes, NombreArchivo, uploadsFolder);

                    if (CargarArchivo.success)
                    {
                        return ApiResultMo<string>.Ok(CargarArchivo.result);
                    }
                    else
                    {
                        throw new Exception(CargarArchivo.message);
                    }

                }
                else
                {
                    throw new Exception(RespuestaNombreArchivo.message);
                }

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return ApiResultMo<string>.Fail(ex.Message);

            }
        }
        /// <summary>
        /// Carga un archivo a SharePoint en la carpeta especificada, creando la carpeta si no existe
        /// </summary>
        /// <param name="fileBytes">Array de bytes con el contenido del archivo a subir</param>
        /// <param name="fileName">Nombre del archivo con extensión (ej: "documento.pdf")</param>
        /// <param name="nombreCarpeta">Nombre de la carpeta destino en SharePoint (se creará si no existe)</param>
        /// <returns>
        /// Resultado de la operación que contiene:
        /// - El ID del archivo en SharePoint si es exitoso
        /// - Mensaje de error si falla
        /// </returns>
        /// <remarks>
        /// Flujo de la función:
        /// 1. Obtiene token de acceso para Microsoft Graph API
        /// 2. Verifica/crea la carpeta destino
        /// 3. Sube el archivo mediante upload por contenido
        /// 4. Actualiza registros internos con la metadata del archivo
        /// </remarks>
        /// <exception cref="Exception">
        /// Puede lanzar excepciones cuando:
        /// - Fallan las operaciones con SharePoint
        /// - Hay errores al procesar la respuesta
        /// </exception>
        public static ApiResultMo<string> CargarSharepoint(byte[] fileBytes, string fileName, string nombreCarpeta)
        {
            try
            {
                var tokenResult = GetAccessToken();
                var _url = $"{_sharepointConfig.Graph}/{_sharepointConfig.GraphVersion}/sites/{_sharepointConfig.SiteId}/drives/{_sharepointConfig.DriveId}/root";

                if (!tokenResult.success)
                    return ApiResultMo<string>.Fail("Error al obtener el token: " + tokenResult.message);

                string token = tokenResult.result;

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                nombreCarpeta = Uri.EscapeDataString(nombreCarpeta);

                // Aseguramos que la carpeta exista
                var checkFolderUrl = $"{_url}:/{nombreCarpeta}";
                var folderResponse = client.GetAsync(checkFolderUrl).GetAwaiter().GetResult();

                if (!folderResponse.IsSuccessStatusCode)
                {
                    // Crear carpeta
                    var createFolderUrl = $"{_url}/children";
                    var createFolderBody = new
                    {
                        name = nombreCarpeta,
                        folder = new { },
                        @microsoft_graph_conflictBehavior = "rename"
                    };

                    var createContent = new StringContent(JsonConvert.SerializeObject(createFolderBody), Encoding.UTF8, "application/json");

                    var createResponse = client.PostAsync(createFolderUrl, createContent).GetAwaiter().GetResult();

                    if (!createResponse.IsSuccessStatusCode)
                        return ApiResultMo<string>.Fail($"Error al crear carpeta '{nombreCarpeta}': {createResponse.StatusCode}");
                }

                // Construimos la URL del endpoint para subir archivo
                var url = $"{_url}:/{nombreCarpeta}/{fileName}:/content";

                var content = new ByteArrayContent(fileBytes);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

                var response = client.PutAsync(url, content).GetAwaiter().GetResult();

                var respuesta = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                if (response.IsSuccessStatusCode)
                {

                    using var doc = JsonDocument.Parse(respuesta);
                    var root = doc.RootElement;

                    var id = root.GetProperty("id").GetString() ?? "";
                    var name = root.GetProperty("name").GetString() ?? "";

                    var cargar = ActualizarRegistro(name, id);

                    if (cargar.success)
                    {
                        return ApiResultMo<string>.Ok(cargar.result);
                    }
                    else {
                        throw new Exception(cargar.message);
                    }
                }
                else
                {
                    throw new Exception($"Error al subir archivo: {response.StatusCode} - {respuesta}");
                }
            }
            catch (Exception ex)
            {
                return ApiResultMo<string>.Fail("Excepción al subir archivo: " + ex.Message);
            }
        }

        /// <summary>
        /// Función para buscar archivos en SharePoint por contenido o nombre
        /// </summary>
        /// <param name="query">Texto a buscar en el contenido o nombre del archivo</param>
        /// <param name="nombreCarpeta">Opcional: filtrar por una carpeta específica</param>
        /// <returns>Resultado con la lista de archivos que coinciden</returns>
        public static ApiResultMo<List<FileSearchResult>> BuscarArchivosPorContenido(string query)
        {
            try
            {
                var tokenResult = GetAccessToken();
                if (!tokenResult.success)
                    return ApiResultMo<List<FileSearchResult>>.Fail("Error al obtener el token: " + tokenResult.message);

                string token = tokenResult.result;

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                // Se carga el valor de la carpeta donde se estan cargando los documentos, añadir filtro

                string nombreCarpeta = Conexion.RutaDocumentos;

                if (!string.IsNullOrEmpty(nombreCarpeta))
                {
                    nombreCarpeta = Uri.EscapeDataString(nombreCarpeta);
                    nombreCarpeta = $":/{nombreCarpeta}:";
                }

                var url = $"{_sharepointConfig.Graph}/{_sharepointConfig.GraphVersion}/sites/{_sharepointConfig.SiteId}/drive/root{nombreCarpeta}/search(q='{Uri.EscapeDataString(query)}')";

                var response = client.GetAsync(url).GetAwaiter().GetResult();
                var respuesta = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                if (response.IsSuccessStatusCode)
                {
                    var results = JsonConvert.DeserializeObject<GraphSearchResponse>(respuesta);
                    var fileResults = new List<FileSearchResult>();

                    foreach (var item in results.Value)
                    {
                        fileResults.Add(new FileSearchResult
                        {
                            Id = item.Id,
                            Name = item.Name,
                            WebUrl = item.WebUrl,
                            LastModified = item.LastModifiedDateTime,
                            Size = item.Size,
                            ContentType = item.File?.MimeType
                        });
                    }

                    return ApiResultMo<List<FileSearchResult>>.Ok(fileResults);
                }
                else
                {
                    return ApiResultMo<List<FileSearchResult>>.Fail($"Error en la búsqueda: {response.StatusCode} - {respuesta}");
                }
            }
            catch (Exception ex)
            {
                return ApiResultMo<List<FileSearchResult>>.Fail("Excepción al buscar archivos: " + ex.Message);
            }
        }

        /// <summary>
        /// Funcion que retorna el token para poder interactuar con el sharepoint
        /// </summary>
        /// <returns></returns>
        public static ApiResultMo<string> GetAccessToken()
        {
            try
            {
                var scopes = new[] { $"{_sharepointConfig.Graph}/.default" };

                var result = _app.AcquireTokenForClient(scopes)
                                 .ExecuteAsync()
                                 .GetAwaiter()
                                 .GetResult(); // Sincrónico

                return ApiResultMo<string>.Ok(result.AccessToken);
            }
            catch (Exception ex)
            {
                return ApiResultMo<string>.Fail($"Error al obtener el token: {ex.Message}");
            }
        }
        /// <summary>
        /// Funcion para obtener las imagenes desde el repositorio de sharepoint
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        public static ApiResultMo<string> DescargarDesdeSharepoint(UploadMo uploadMo)
        {
            try
            {
                var tokenResult = GetAccessToken();
                if (!tokenResult.success)
                    return ApiResultMo<string>.Fail("Error al obtener el token: " + tokenResult.message);

                string token = tokenResult.result;

                var IdArchivo = ObtenerIdItem(uploadMo.nombrearchivo);

                var DatosIdArchivo = JsonConvert.DeserializeObject(IdArchivo.result.ToString());
                var itemId = DatosIdArchivo[0]["observacion"].Value.ToString();

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var url = $"{_sharepointConfig.Graph}/{_sharepointConfig.GraphVersion}/sites/{_sharepointConfig.SiteId}/drives/{_sharepointConfig.DriveId}/items/{itemId}/content";

                var response = client.GetAsync(url).GetAwaiter().GetResult();

                if (!response.IsSuccessStatusCode)
                {
                    var error = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    return ApiResultMo<string>.Fail($"Error al descargar archivo: {response.StatusCode} - {error}");
                }

                var fileBytes = response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult();
                var base64 = Convert.ToBase64String(fileBytes);

                return ApiResultMo<string>.Ok(base64);
            }
            catch (Exception ex)
            {
                return ApiResultMo<string>.Fail("Excepción al descargar archivo: " + ex.Message);
            }
        }


        /// <summary>
        /// Funcion que actualiza el registro con el codigo de sharepoint para poder reconstruir el documento
        /// </summary>
        /// <param name="NombreArchivo"></param>
        /// <param name="CodigoSharepoint"></param>
        /// <returns></returns>
        public static dynamic ActualizarRegistro(string NombreArchivo, string CodigoSharepoint)
        {

            string sql = @" UPDATE 
                            public.codocaso
                            SET
                            observacion = @in_observacion
                            WHERE
                            dcm_archivo = @dcm_archivo;";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
 
            cmd.Parameters.AddWithValue("@dcm_archivo", NpgsqlDbType.Varchar, NombreArchivo);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, CodigoSharepoint);
            return Exec_sql.EjecutarQuery(cmd);
        }

        /// <summary>
        /// Funcion para obtener el id de el archivo
        /// </summary>
        /// <param name="NombreArchivo"></param>
        /// <returns></returns>
        public static dynamic ObtenerIdItem(string NombreArchivo)
        {

            string sql = @" SELECT
                            observacion
                            FROM
                            public.codocaso
                            WHERE
                            dcm_archivo = @dcm_archivo;";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@dcm_archivo", NpgsqlDbType.Varchar, NombreArchivo);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }  
}
