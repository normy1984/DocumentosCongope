﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using iText.Commons.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using MongoDB.Bson;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using System.Runtime.CompilerServices;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class UploadBL
    {
        /// <summary>
        /// Funcion que devuelve el numero total de registros eliminados de archivos
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        public static dynamic DeleteArchivosCargados(UploadMo uploadMo)
        {
            var cmd = new NpgsqlCommand();
            string codEmpresa = Constantes.General.Empresa;

            string sql = @"select 
                            count(out_dcm_archivo) as total_eliminados
                            from public.spd_codocaso
                            (
                            @in_codemp,
                            @in_anio,
                            @in_dcm_sig_tip,
                            @in_dcm_acu_tip,
                            @in_dcm_id,
                            @in_observacion
                            );";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, codEmpresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Numeric, uploadMo.anio);
            cmd.Parameters.AddWithValue("@in_dcm_sig_tip", NpgsqlDbType.Char, uploadMo.tipo_documento);
            cmd.Parameters.AddWithValue("@in_dcm_acu_tip", NpgsqlDbType.Numeric, uploadMo.codigo_documento);
            cmd.Parameters.AddWithValue("@in_dcm_id", NpgsqlDbType.Numeric, uploadMo.codsistema);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, uploadMo.descripcion);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion que devuelve el numero de archivos adjuntos a cualquier documento
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        public static dynamic ListArchivosCargados(UploadMo uploadMo)
        {
            var cmd = new NpgsqlCommand();
            string codEmpresa = Constantes.General.Empresa;

            string sql = @"select 
                            c.dcm_archivo_ori,
                            c.dcm_descripcion,
                            c.dcm_contenttype,
                            c.dcm_archivo,
                            c.dcm_modulo,
                            c.dcm_id
                            from codocaso c 
                            where 
                            c.estado = 1
                            AND c.anio = @anio 
                            and c.dcm_sig_tip  = @dcm_sig_tip
                            AND c.dcm_acu_tip = @dcm_acu_tip
                            AND c.codemp = @cod_emp;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@cod_emp", codEmpresa.ToString());
            cmd.Parameters.AddWithValue("@dcm_sig_tip", uploadMo.tipo_documento);
            cmd.Parameters.AddWithValue("@anio", uploadMo.anio);
            cmd.Parameters.AddWithValue("@dcm_acu_tip", uploadMo.codigo_documento);

            return Exec_sql.cargarDatosJson(cmd);
        }
        /// <summary>
        /// Funcion para subir archivos a un repositorio
        /// </summary>
        /// <param name="file"></param>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        public static dynamic UploadFile(IFormFile file, UploadMo uploadMo)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    throw new Exception("No se ha recibido ningún archivo.");
                }

                // Diccionario para mapear los valores de codsistema con las colecciones
                var collectionMap = new Dictionary<int, string>
                    {
                        { 1, "Contabilidad" },
                        { 2, "Presupuesto" },
                        { 3, "Inventarios" },
                        { 4, "Nomina" },
                        { 5, "ActivosFijos" }
                    };

                // Asignar la colección usando el codsistema, o un valor predeterminado si no existe
                var Collection = collectionMap.ContainsKey(uploadMo.codsistema) ? collectionMap[uploadMo.codsistema] : "";

                var uploadsFolder = Path.Combine(Conexion.RutaDocumentos, Collection);

                var RespuestaNombreArchivo = GuardaBase(uploadMo, file.FileName, file.ContentType);

                if (RespuestaNombreArchivo.success)
                {

                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var NombreArchivo = JsonConvert.DeserializeObject(RespuestaNombreArchivo.result);
                    NombreArchivo = Convert.ToString(NombreArchivo[0]["nombrearchivo"]);

                    var filePath = Path.Combine(uploadsFolder, NombreArchivo);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(fileStream);
                    }

                    /// A PARTIR DE AQUI GUARDAMOS EN LA BASE DE MONGO
                    /// 
                    if (Conexion.GuardaArchivosMongo)
                    {

                        using (var memoryStream = new MemoryStream())
                        {
                            // Copiar el archivo al MemoryStream
                            file.CopyTo(memoryStream);

                            // Convertir el contenido del MemoryStream a un arreglo de bytes
                            byte[] fileBytes = memoryStream.ToArray();

                            // Convertir el arreglo de bytes a Base64
                            BsonBinaryData binData = new BsonBinaryData(fileBytes);

                            var uploadData = new
                            {
                                NombreOriginal = file.FileName,
                                Tipo = file.ContentType,
                                Tamano = file.Length,
                                Nombre = NombreArchivo,
                                Codemp = "0004",
                                Sigtip = uploadMo.tipo_documento,
                                Acutip = uploadMo.codigo_documento,
                                Anio = uploadMo.anio,
                                FirmaEc = false,
                                FechaSubida = DateTime.Now,
                                FileBase64 = binData
                            };

                            // Llamar a la función de inserción con el archivo en Base64
                            var resultado = Exec_sql.EjecutarComandoMongo(Collection, "insert", null, uploadData);

                            if (resultado.success == false)
                            {
                                throw new Exception(resultado.message);
                            }
                        }

                    }

                    return new
                    {
                        success = true,
                        message = "Archivo cargado exitosamente",
                        result = ""
                    };
                }
                else
                {
                    return RespuestaNombreArchivo;
                }

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };

            }
        }

        /// <summary>
        /// Funcion que guarda en la base de datos el registro de insercion de un archivo
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <param name="NombreArchivo"></param>
        /// <param name="ContentType"></param>
        /// <returns></returns>
        public static dynamic GuardaBase(UploadMo DetalleMo, string NombreArchivo, string ContentType)
        {
            string codemp = Constantes.General.Empresa;
            string sql = @" SELECT 
                            trim(out_dcm_archivo) as NombreArchivo
                            from 
                            public.spiu_codocaso(
                            @in_codemp, 
                            @in_anio, 
                            @in_dcm_sig_tip, 
                            @in_dcm_acu_tip, 
                            @in_dcm_descripcion, 
                            @in_dcm_archivo_ori, 
                            @in_dcm_modulo,
                            @in_dcm_contenttype
                            );";


            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, codemp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Numeric, DetalleMo.anio);
            cmd.Parameters.AddWithValue("@in_dcm_sig_tip", NpgsqlDbType.Char, DetalleMo.tipo_documento);
            cmd.Parameters.AddWithValue("@in_dcm_acu_tip", NpgsqlDbType.Numeric, DetalleMo.codigo_documento);
            cmd.Parameters.AddWithValue("@in_dcm_descripcion", NpgsqlDbType.Varchar, DetalleMo.descripcion);
            cmd.Parameters.AddWithValue("@in_dcm_archivo_ori", NpgsqlDbType.Varchar, NombreArchivo);
            cmd.Parameters.AddWithValue("@in_dcm_modulo", NpgsqlDbType.Numeric, DetalleMo.codsistema);
            cmd.Parameters.AddWithValue("@in_dcm_contenttype", NpgsqlDbType.Varchar, ContentType);

            return Exec_sql.cargarDatosJson(cmd);
        }
        /// <summary>
        /// Funcion para cargar los archivos del repositorio en base64
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        public static dynamic VerArchivosRepositorio(UploadMo uploadMo)
        {
            try
            {
                var uploadsFolder = Conexion.RutaDocumentos;

                switch (uploadMo.codsistema)
                {
                    case 1:
                        uploadsFolder += "Contabilidad/";
                        break;
                    case 2:
                        uploadsFolder += "Presupuesto/";
                        break;
                    case 3:
                        uploadsFolder += "Inventarios/";
                        break;
                    case 4:
                        uploadsFolder += "Nomina/";
                        break;
                    case 5:
                        uploadsFolder += "Activos_Fijos/";
                        break;
                }
                // Combina la ruta del repositorio con el nombre del archivo
                string filePath = Path.Combine(uploadsFolder, uploadMo.nombrearchivo);

                // Verifica si el archivo existe
                if (File.Exists(filePath))
                {
                    // Lee el contenido del archivo como bytes
                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // Convierte los bytes a Base64
                    string base64String = Convert.ToBase64String(fileBytes);

                    return new
                    {
                        success = true,
                        message = "",
                        result = base64String
                    };
                }
                else
                {
                    return new
                    {
                        success = false,
                        message = "Error: " + $"El archivo {uploadMo.nombrearchivo} no existe en el repositorio.",
                        result = ""
                    };

                }
            }

            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };

            }


        }
    }
}
