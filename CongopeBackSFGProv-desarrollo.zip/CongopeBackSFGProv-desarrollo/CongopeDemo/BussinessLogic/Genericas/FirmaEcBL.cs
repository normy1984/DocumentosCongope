﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using MongoDB.Bson;
using System.Text;
using System.Web;
using Newtonsoft.Json;
using Microsoft.AspNetCore.SignalR;
using Congope.Empresas.Extensiones;
using Congope.Empresas.BussinessLogic.Bpm;


namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class FirmaEcBL
    {
        private readonly DocumentoBpmBL _DocumentoBl;
        private readonly BpmBl _BpmBl;
        private readonly CamundaBpm _camunda;

        // Constructor
        public FirmaEcBL(IHubContext<NotificacionesHub> hubContext,
             DocumentoBpmBL documentoBl,
              BpmBl bpmBl
            
            )
        {
            _camunda = new CamundaBpm();
            _BpmBl = bpmBl;
            _DocumentoBl = documentoBl;
        }
 
        /// <summary>
        /// Procesa la carga de archivos para firmarlos electrónicamente.
        /// Valida los datos, verifica los documentos en MongoDB y genera un enlace para realizar la firma.
        /// </summary>
        /// <param name="InformacionCargaArchivos">Datos en formato dinámico que contienen la información de usuario y documentos a firmar.</param>
        /// <returns>Un objeto que incluye el enlace para proceder con la firma o un mensaje de error en caso de fallo.</returns>
        public async Task<dynamic> CargarArchivoAsync(dynamic InformacionCargaArchivos)
        {
            // Inicializamos la respuesta con un objeto para almacenar el estado y resultado.
            var respuesta = new ApiResultMo<string>();

            try
            {
                // Deserializamos los datos recibidos en un objeto dinámico.
                var datosUsuario = JsonConvert.DeserializeObject<dynamic>(InformacionCargaArchivos.ToString());

                // Convertimos el filtro proporcionado en un diccionario de clave-valor.
                Dictionary<string, object> filtro = JsonConvert.DeserializeObject<Dictionary<string, object>>(datosUsuario.filtro.ToString());

                // Mapeamos la información de firma a un modelo específico para un manejo más estructurado.
                FirmaEcCargarArchivoMo request = JsonConvert.DeserializeObject<FirmaEcCargarArchivoMo>(datosUsuario.InformacionFirma.ToString());

                // Configuración: límites de tamaño para documentos y nombres.
                var sizeDocumento = Conexion.firmaConfig.TamanoDocumento;
                var sizeNombreDocumento = Conexion.firmaConfig.TamanoNombreDocumento;

                // Consultamos MongoDB para obtener los documentos a firmar usando el filtro proporcionado.
                var registros = Exec_sql.ObtenerDatosMongo("Firmas_Electronicas", filtro, "NumeroFirmas");

                if (!registros.success)
                    throw new FileNotFoundException("No existen archivos para firmar. Comuníquese con el administrador.");

                // Identificamos el número de firma inicial para posicionar correctamente el QR.
                var documento_0 = registros.result[0];
                BsonDocument bsonDocument_0 = BsonDocument.Parse(documento_0.ToString());
                int firma_0 = Convert.ToInt32(bsonDocument_0["NumeroFirmas"]) + 1;

                var documentos = new StringBuilder();

                // Iteramos sobre los documentos para construirlos y validarlos.
                for (var i = 0; i < registros.result.Count; i++)
                {
                    var documento = registros.result[i];
                    BsonDocument bsonDocument = BsonDocument.Parse(documento.ToString());

                    // Extraemos el contenido en Base64 y validamos el nombre del documento.
                    var fileBase64 = bsonDocument["FileBase64"].AsBsonBinaryData;
                    string base64String = Convert.ToBase64String(fileBase64.Bytes);
                    string nombreDocumento = bsonDocument["Nombre"].ToString();

                    if (nombreDocumento.Length > sizeNombreDocumento)
                        throw new ArgumentException($"El nombre del archivo {nombreDocumento} supera los {sizeNombreDocumento} caracteres permitidos.");

                    if (nombreDocumento.IndexOfAny(new[] { '!', '@', '#', '$', '%', '&', '/', '(', ')' }) >= 0)
                        throw new ArgumentException($"El nombre del archivo {nombreDocumento} contiene caracteres especiales no permitidos.");

                    // Agregamos el documento al cuerpo de la solicitud.
                    documentos.Append($@"
                    {{
                        ""nombre"": ""{i}-firmado-{bsonDocument["Nombre"]}.pdf"",
                        ""documento"": ""{base64String}""
                    }},");
                }

                // Construimos el cuerpo de la solicitud con los documentos listos.
                var body = $@"
                    {{
                        ""cedula"": ""{request.Cedula}"",
                        ""sistema"": ""{Conexion.firmaConfig.Sistema}"",
                        ""documentos"": [{documentos.ToString().TrimEnd(',')}]
                    }}";

                // Validamos el tamaño total del cuerpo para evitar exceder los límites.
                if (Encoding.UTF8.GetByteCount(body) > sizeDocumento)
                    throw new InvalidOperationException("El tamaño total del documento excede el permitido.");

                // Configuramos y enviamos la solicitud HTTP al servidor de firma electrónica.
                var content = new StringContent(body, Encoding.UTF8, "application/json");
                using var httpClient = new HttpClient();
                var httpRequest = new HttpRequestMessage(HttpMethod.Post, Conexion.firmaConfig.ServidorDocumentos)
                {
                    Content = content
                };
                httpRequest.Headers.Add("X-API-KEY", Conexion.firmaConfig.X_API_KEY);
                var response = await httpClient.SendAsync(httpRequest);
                response.EnsureSuccessStatusCode();

                // Procesamos la respuesta y construimos el enlace de firma.
                var token = await response.Content.ReadAsStringAsync();


                /*case 'token':
				$certificadoDigital = "&tipo_certificado=1";
                    break;
                case 'archivo':
				$certificadoDigital = "&tipo_certificado=2";
                    break;
                case 'error':
				$certificadoDigital = "error";
                    break;*/


                int tipo_certificado = 2;


                /// llamo a la funcion que me devuelve la posicion de las firmas
                int anio = Convert.ToInt32(bsonDocument_0["Anio"]);
                string DocumentoId = bsonDocument_0["Referencia"].ToString();

                PosicionesFirmaMo PosFirma = await GetPosicionesFirma(firma_0, DocumentoId, anio);


                var linkfirma = "firmaec://" + Conexion.firmaConfig.Sistema +
                "/firmar?token=" + token +
                "&tipo_certificado=" + tipo_certificado +
                "&llx=" + PosFirma.PosicionX +
                "&lly=" + PosFirma.PosicionY +
                "&estampado=" + Conexion.firmaConfig.estampado +
                "&razon=" + Conexion.firmaConfig.razon +
                "&pro=true" +
                "&url=" + HttpUtility.UrlEncode(Conexion.firmaConfig.ServidorApi);

                // Configuramos la respuesta exitosa.
                respuesta.success = true;
                respuesta.result = linkfirma;
            }
            catch (Exception ex)
            {
                // Capturamos y retornamos cualquier error.
                respuesta.message = ex.Message;
            }

            return respuesta;
        }


        /// <summary>
        /// Funcion que trae el primer valor de los documentos para mostrar en el sistema
        /// </summary>
        /// <param name="filtro"></param>
        /// <returns></returns>
        /// <summary>
        /// Obtiene un documento almacenado en una base de datos MongoDB en formato Base64.
        /// </summary>
        /// <param name="filtro">Diccionario con los filtros de búsqueda para los registros en MongoDB.</param>
        /// <returns>Un objeto que indica si la operación fue exitosa y, en caso positivo, devuelve los datos en formato Base64.</returns>
        public dynamic DocumentoBase64Firmas(Dictionary<string, object> filtro)
        {
            // Resultado que se retornará, inicializado como un objeto de tipo ApiResultMo.
            var resultado = new ApiResultMo<dynamic>();

            try
            {
                // Consulta a la base de datos MongoDB para obtener los datos según el filtro proporcionado.
                // 'Firmas_Electronicas' es el nombre de la colección, y 'NumeroFirmas' podría ser un índice o campo relevante.
                var registros = Exec_sql.ObtenerDatosMongo("Firmas_Electronicas", filtro, "NumeroFirmas");

                // Verifica si la consulta fue exitosa.
                if (registros.success)
                {
                    // Obtiene el primer documento del resultado de la consulta.
                    var documento = registros.result[0];

                    // Convierte el documento MongoDB (generalmente en formato JSON o Bson) a un objeto BsonDocument.
                    BsonDocument bsonDocument = BsonDocument.Parse(documento.ToString());

                    // Accede al campo específico 'FileBase64' dentro del documento.
                    var fileBase64 = bsonDocument["FileBase64"];

                    // Verifica si el campo 'FileBase64' existe y contiene datos válidos.
                    if (fileBase64 != null)
                    {
                        // Obtiene los datos binarios del campo 'FileBase64' como un BsonBinaryData.
                        var bsonBinaryData = fileBase64.AsBsonBinaryData;

                        // Convierte el arreglo de bytes a una cadena en formato Base64.
                        string base64String = Convert.ToBase64String(bsonBinaryData.Bytes);

                        // Crea un objeto con los datos relevantes: número total de documentos y el archivo en formato Base64.
                        var DatosBase64 = new
                        {
                            totalDocumentos = registros.result.Count, // Total de documentos encontrados en la consulta.
                            stringBase64 = base64String              // Representación Base64 del archivo.
                        };

                        // Marca la operación como exitosa y asigna los datos al resultado.
                        resultado.success = true;
                        resultado.result = DatosBase64;
                    }
                    else
                    {
                        // Lanza una excepción si el campo 'FileBase64' no está presente o está vacío.
                        throw new Exception("No existen documentos para visualizar");
                    }
                }
                else
                {
                    // Lanza una excepción si la consulta a MongoDB falló.
                    throw new Exception(registros.message);
                }
            }
            catch (Exception e)
            {
                // Maneja cualquier excepción y almacena el mensaje de error en el resultado.
                resultado.message = e.Message;
            }

            // Retorna el resultado de la operación.
            return resultado;
        }


        /// <summary>
        /// Calcula la posición (X, Y) en el documento donde se debe ubicar una firma electrónica,
        /// en base al total de firmas y al índice de la firma actual.
        /// </summary>
        /// <param name="TotalFirmas">
        /// Número total de firmas requeridas en el documento.
        /// - 1 → Se distribuye en 2 bloques (mitad).
        /// - 2 → Se distribuye en 4 bloques.
        /// - ≥3 → Se distribuye en 6 bloques.
        /// </param>
        /// <param name="FirmaActual">
        /// Índice de la firma a calcular (1-based).
        /// - Firma 1 o 4 → posición izquierda.
        /// - Firma 2 o 5 → posición centro.
        /// - Firma 3 o 6 → posición derecha.
        /// - Mayor a 6 → fallback al bloque 1 (izquierda).
        /// </param>
        /// <returns>
        /// Objeto <see cref="PosicionesFirmaMo"/> que contiene la coordenada X e Y
        /// donde debe colocarse la firma en el documento.
        /// </returns>
        public async Task<PosicionesFirmaMo> GetPosicionesFirma(int FirmaActual, string DocumentoId, int Anio)
        {

            var doc = await _DocumentoBl.ObtenerDocumentoPorIdAsync(DocumentoId, Anio);
            // Tamaño base de la celda de firma
            int ancho = (int)doc.AnchoFirma;
            int alto = (int)doc.AltoFirma;

            // Posición inicial en el eje Y
            int PosicionY_o = (int)doc.PosicionY;
            int TotalFirmas = (int)doc.TotalFirmas;

            // Objeto de retorno
            PosicionesFirmaMo _PosicionesFirma = new PosicionesFirmaMo();

            // Ajuste del ancho según la cantidad de firmas totales
            ancho = TotalFirmas switch
            {
                1 => ancho / 2,
                2 => ancho / 4,
                _ => ancho / 6
            };

            // Factor horizontal según la firma actual
            int factor = FirmaActual switch
            {
                1 or 4 => 1,   // primera columna
                2 or 5 => 3,   // segunda columna
                3 or 6 => 5,   // tercera columna
                _ => 1         // fallback: primera columna
            };

            // Si hay más de 3 firmas y se pasa a la "segunda fila",
            // la altura se reduce a la mitad para colocar las firmas más abajo
            alto = (TotalFirmas > 3 && FirmaActual > 3) ? (alto / 2) : alto;

            // Cálculo de coordenadas finales
            _PosicionesFirma.PosicionX = (ancho * factor) + Conexion.firmaConfig.llx - Conexion.firmaConfig.separacion_firmas;
            _PosicionesFirma.PosicionY = PosicionY_o - Conexion.firmaConfig.lly + alto;

            return _PosicionesFirma;
        }





    }
}