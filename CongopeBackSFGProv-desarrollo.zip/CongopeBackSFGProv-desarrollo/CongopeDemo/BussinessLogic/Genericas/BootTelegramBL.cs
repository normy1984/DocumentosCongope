﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using System.Collections.Concurrent;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using Npgsql;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Administracion;


namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class BootTelegramBL : IHostedService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ITelegramBotClient botClient;
        private readonly string botToken = Conexion.TokenTelegram; // Tu token desde la configuración

        // Usuarios ya registrados (persistencia real: BD)
        private static readonly ConcurrentDictionary<long, (string Cedula, string Trato, string Correo, string Token)> usuariosRegistrados
            = new();

        // Estado de conversación por chatId
        private static readonly ConcurrentDictionary<long, RegistrationStep> conversationState
            = new();

        // Temporal para guardar tempusuariosRegistrados
        private static readonly ConcurrentDictionary<long, (string Cedula, string Trato, string Correo, string Token)> tempusuariosRegistrados
            = new();
        private enum RegistrationStep
        {
            None,
            WaitingCedula,
            WaitingToken,
            Registered,
            WaitingTicketMessage
        }

        public BootTelegramBL(IServiceScopeFactory scopeFactory)
        {
            botClient = new TelegramBotClient(botToken);
            _scopeFactory = scopeFactory;
        }

        // Inicio del servicio
        public Task StartAsync(CancellationToken cancellationToken)
        {
            var receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = { } // Recibir todos los tipos de actualizaciones
            };

            botClient.StartReceiving(
                HandleUpdateAsync,
                HandleErrorAsync,
                receiverOptions,
                cancellationToken
            );

            Console.WriteLine("Bot Telegram iniciado...");
            return Task.CompletedTask;
        }

        // Stop del servicio
        public Task StopAsync(CancellationToken cancellationToken)
        {
            // StopReceiving se maneja automáticamente con el token
            return Task.CompletedTask;
        }

        // Manejo de mensajes entrantes
        private async Task HandleUpdateAsync(ITelegramBotClient bot, Update update, CancellationToken cancellationToken)
        {
            if (update.Type == UpdateType.Message && update.Message!.Type == MessageType.Text)
            {
                var chatId = update.Message.Chat.Id;
                var text = update.Message.Text ?? "".Trim();

                // Usuario NO registrado aún
                if (!usuariosRegistrados.ContainsKey(chatId))
                {
                    await ManejarFlujoNoRegistrado(chatId, text, cancellationToken);
                }
                else
                {
                    // Usuario ya registrado
                    await ManejarFlujoRegistrado(chatId, text, cancellationToken);
                }
            }
            else if (update.Type == UpdateType.CallbackQuery)
            {
                await ManejarCallback(update.CallbackQuery!, cancellationToken);
            }
        }




        // Manejo de errores
        private Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            Console.WriteLine($"[BOT ERROR]: {exception.Message}");
            return Task.CompletedTask;
        }

        // Método público opcional para enviar mensajes desde backend
        public async Task EnviarMensajeAsync(long chatId, string mensaje)
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: mensaje
            );


        }

        // 📌 Flujo para usuarios no registrados
        private async Task ManejarFlujoNoRegistrado(long chatId, string text, CancellationToken ct)
        {
            // Ver si el chat está en un paso intermedio
            if (conversationState.TryGetValue(chatId, out var step))
            {
                if (step == RegistrationStep.WaitingCedula)
                {
                    if (!IsValidCedula(text))
                    {
                        await botClient.SendMessage(
                            chatId,
                            "❌ Cédula inválida. Ingresa un número de 10 dígitos.",
                            cancellationToken: ct
                        );
                        return;
                    }

                    var Result = ObtenerDatosFuncionario(text);

                    if (!Result.success)
                    {
                        await botClient.SendMessage(
                            chatId,
                            "❌ La cédula ingresada no existe en nuestros registros.\n\n ✍️ Por favor ingresa una cédula válida.",
                            cancellationToken: ct
                        );
                        return;
                    }

                    var DatosFuncionario = Result.result;

                    // Guardar temporal y avanzar
                    var EnviarToken = GenerarTokenTelegram(DatosFuncionario.Descrip, DatosFuncionario.Correo_origen);

                    if (!EnviarToken.success)
                    {
                        await botClient.SendMessage(
                            chatId,
                            $"❌ Ocurrió el siguiente problema: {EnviarToken.message}. \n\n✍️ Por favor ingresa nuevamente tu cédula para enviar el token.",
                            cancellationToken: ct
                        );
                        return;
                    }

                    tempusuariosRegistrados[chatId] = (Cedula: DatosFuncionario.Cedruc, Trato: DatosFuncionario.Descrip, Correo: DatosFuncionario.Correo_origen, Token: EnviarToken.result);

                    conversationState[chatId] = RegistrationStep.WaitingToken;

                    await botClient.SendMessage(
                         chatId,
                         $"📧 Tu token de registro ha sido enviado a: {DatosFuncionario.Correo_origen}\n\n" +
                         "👉 Copia el código que recibiste por correo y escríbelo aquí para finalizar tu registro.",
                         cancellationToken: ct
                    );

                    return;
                }

                if (step == RegistrationStep.WaitingToken)
                {
                    var token = text.Trim();

                    if (token == "/salir")
                    {
                        conversationState[chatId] = RegistrationStep.None;
                        usuariosRegistrados.TryRemove(chatId, out _);
                        await botClient.SendMessage(chatId, "❌ No estas registrado aun para las notificaciones.\n\n.👋 Si deseas reiniciar el proceso de registro, escríbeme y te ayudaré con gusto.", cancellationToken: ct);
                        return;
                    }

                    if (!tempusuariosRegistrados.TryGetValue(chatId, out var datos))
                    {
                        // Si algo se perdió, reiniciamos
                        conversationState[chatId] = RegistrationStep.None;
                        await botClient.SendMessage(chatId, "⚠️ Algo salió mal. Por favor escribe /start para intentar de nuevo.", cancellationToken: ct);
                        return;
                    }

                    if (datos.Token == token)
                    {
                        usuariosRegistrados[chatId] = tempusuariosRegistrados[chatId];
                        conversationState[chatId] = RegistrationStep.Registered;
                        tempusuariosRegistrados.TryRemove(chatId, out _);
                        
                        await botClient.SendMessage(
                            chatId,
                            $"✅ Registro completado con éxito.\n\n🎉 Bienvenid@ {datos.Trato}.",
                            cancellationToken: ct
                        );

                        await MostrarMenuPrincipal(chatId, ct);
                        return;
                    }
                    else
                    {
                        await botClient.SendMessage(
                            chatId,
                            "⚠️ El token ingresado no es válido.\n\n🔁 Por favor intenta nuevamente escribiendo el token que recibiste en tu correo.\n\n❌ Si deseas cancelar el proceso, escribe /salir.",
                            cancellationToken: ct
                        );
                        return;
                    }
                }
            }


            var menu = new InlineKeyboardMarkup(new[]
            {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("✅ Sí Regístrame!", "registrar"),
                InlineKeyboardButton.WithCallbackData("❌ No gracias", "no_registro")
            }
        });

            await botClient.SendMessage(
                chatId,
                "👋 Hola, soy el asistente virtual del CONGOPE.\n\n" +
                "Para poder brindarte notificaciones personalizadas sobre tus trámites y tareas, necesitamos confirmar tu identidad una sola vez. 🔐\n\n" +
                "👉 Durante el registro te pediremos:\n" +
                "   • Tu número de cédula (10 dígitos).\n" +
                "   • Un dato adicional para validar que realmente eres tú.\n\n" +
                "📌 Esta información solo se usará para asociar tu chat con tu perfil interno en la institución y garantizar que recibas únicamente mensajes relevantes para ti.\n\n" +
                "⚠️ Importante: Si no estás en los registros institucionales, no podrás utilizar este chat.\n\n" +
                "¿Deseas continuar con el registro?",
                replyMarkup: menu,
                cancellationToken: ct
            );
        }



        // 📌 Flujo para usuarios registrados
        private async Task ManejarFlujoRegistrado(long chatId, string text, CancellationToken ct)
        {

            if (conversationState.TryGetValue(chatId, out var step))
            {

                var (_, trato, correo, _) = usuariosRegistrados[chatId];

                if (step == RegistrationStep.WaitingTicketMessage)
                {
                    conversationState[chatId] = RegistrationStep.Registered; // volvemos al flujo normal
                   
                    string userMessage = text;

                    // Generar el subject con OpenAI
                    string OpenAIKey = Conexion.OpenAIConfig.OpenAIToken ?? string.Empty;

                    string subject = await GenerateSubjectAsync(userMessage, OpenAIKey);

                    // Crear ticket en osTicket
                    string ticketResponse = await CreateOsTicketAsync(subject, userMessage, trato, correo);

                    // Enviar respuesta al usuario con número de ticket
                    await botClient.SendMessage(
                        chatId,
                        "🎫 Tu ticket ha sido creado con éxito. \n" +
                        $"🆔 Número de {ticketResponse} \n\n" +
                        "Nuestro equipo de soporte se comunicará contigo pronto.",
                        cancellationToken: ct
                    );

                    await MostrarMenuPrincipal(chatId, ct);
                    return;
                }

                if (text == "/menu")
                {
                    await MostrarMenuPrincipal(chatId, ct);
                    return;
                }

                // Si escribe cualquier cosa que no esté en el menú

                if (text.Contains("hola", StringComparison.OrdinalIgnoreCase))
                {
                    await botClient.SendMessage(
                        chatId,
                        $"👋 Hola {trato}, ¿en qué puedo ayudarte?\n",
                        cancellationToken: ct
                    );
                    await MostrarMenuPrincipal(chatId, ct);
                    return;
                }

                

                await botClient.SendMessage(
                    chatId,
                    $"🤔 No entendí tu mensaje, {trato}.",
                    cancellationToken: ct
                );
                await MostrarMenuPrincipal(chatId, ct);
            }
        }

        // 📌 Manejo de botones (CallbackQuery)
        private async Task ManejarCallback(CallbackQuery callback, CancellationToken ct)
        {
            var chatId = callback.Message!.Chat.Id;
            var data = callback.Data;

            switch (data)
            {
                case "registrar":
                    conversationState[chatId] = RegistrationStep.WaitingCedula;
                    await botClient.SendMessage(
                        chatId,
                        "✍️ Por favor, ingresa tu número de cédula (10 dígitos):",
                        cancellationToken: ct
                    );
                    break;

                case "no_registro":
                    await botClient.SendMessage(
                        chatId,
                        "👌 Entendido. No recibirás notificaciones de mi parte. " +
                        "Si cambias de opinión, escribeme y te ayudaré con gusto.",
                        cancellationToken: ct
                    );
                    break;

                case "menu_principal":
                    await MostrarMenuPrincipal(chatId, ct);
                    break;

                case "timbrada":
                    {
                        var usuario = GetUsuarioPorChatId(chatId);

                        if (usuario == null)
                        {
                            await botClient.SendMessage(
                                chatId,
                                "⚠️ No encuentro tu registro. Por favor escribe /start para registrarte.",
                                cancellationToken: ct
                            );
                            break;
                        }

                        var cedula = usuario.Value.Cedula;
                       
                        using var scope = _scopeFactory.CreateScope();
                        var _TimbradasBL = scope.ServiceProvider.GetRequiredService<TimbradasBL>();

                        var timbradas = await _TimbradasBL.ObtenerUltimasTimbradasAsync(cedula, ct);

                        var mensaje = "📋 *Tus últimas 5 timbradas*\n\n";
                        foreach (var t in timbradas)
                        {
                            var diaSemana = t.Fecha.ToString("dddd", new System.Globalization.CultureInfo("es-ES"));
                            var fechaFormateada = t.Fecha.ToString("dd/MM/yyyy");

                            // Redondear Entrada si los segundos son mayores a 30
                            string entrada;
                            if (t.Entrada.HasValue)
                            {
                                var ts = t.Entrada.Value;
                                if (ts.Seconds > 30) ts = ts.Add(TimeSpan.FromMinutes(1));
                                entrada = $"{ts.Hours:D2}:{ts.Minutes:D2}";
                            }
                            else
                            {
                                entrada = "--:--";
                            }

                            // Redondear Salida si los segundos son mayores a 30
                            string salida;
                            if (t.Salida.HasValue)
                            {
                                var ts = t.Salida.Value;
                                if (ts.Seconds > 30) ts = ts.Add(TimeSpan.FromMinutes(1));
                                salida = $"{ts.Hours:D2}:{ts.Minutes:D2}";
                            }
                            else
                            {
                                salida = "--:--";
                            }

                            mensaje += $"{diaSemana} ({fechaFormateada}): Entrada {entrada} - Salida {salida}\n";
                        }

                        mensaje += "\n⚠️ Nota importante:\n" +
                                   "- Solo se muestran las últimas 5 timbradas por motivos de privacidad y seguridad.\n" +
                                   "- Para un reporte completo y detallado, ingresa a tu portal institucional en el siguiente enlace:\n" +
                                   "https://sfgprov-web.congope.gob.ec/sfgprov\n" +
                                   "- Utiliza tus credenciales personales para acceder de manera segura.\n\n" +
                                   "Si deseas volver al menú principal, escribe /menu.";

                        await botClient.SendMessage(chatId, mensaje, cancellationToken: ct);
                    }
                    break;

                case "crear_ticket":
                    conversationState[chatId] = RegistrationStep.WaitingTicketMessage;
                    await botClient.SendMessage(
                        chatId,
                        "✍️ Por favor, escribe el incoveniente presentado para que sea resuelto por nuestro equipo de soporte:",
                        cancellationToken: ct
                    );
                    break;

                case "certificado":
                    await botClient.SendMessage(chatId, "🪪 Generando tu certificado laboral...", cancellationToken: ct);
                    break;

                case "tareas":
                    await botClient.SendMessage(chatId, "✅ Estas son tus tareas pendientes...", cancellationToken: ct);
                    break;

                case "desvincular":
                    usuariosRegistrados.TryRemove(chatId, out _);
                    await botClient.SendMessage(chatId, "❌ Te has desvinculado de las notificaciones.", cancellationToken: ct);
                    break;
            }

            await botClient.AnswerCallbackQuery(callback.Id, cancellationToken: ct);
        }

        // 📌 Menú principal después de registrarse
        private async Task MostrarMenuPrincipal(long chatId, CancellationToken ct)
        {
            var menu = new InlineKeyboardMarkup([
                [ InlineKeyboardButton.WithCallbackData("📋 Registro de Asistencia", "timbrada") ],
                [ InlineKeyboardButton.WithCallbackData("🎫 Crear Ticket de Soporte de TI", "crear_ticket") ],
                [ InlineKeyboardButton.WithCallbackData("🪪 Solicitar Certificado laboral", "certificado") ],
                [ InlineKeyboardButton.WithCallbackData("✅ Revisar tareas pendientes", "tareas") ],
                [ InlineKeyboardButton.WithCallbackData("❌ Desvincularme de notificaciones", "desvincular") ]
             ]);


            await botClient.SendMessage(
                chatId,
                $"🎯 Selecciona una opción del menu por favor:",
                replyMarkup: menu,
                cancellationToken: ct
            );
        }

        // FUNCIN QUE VALIDA SI EL REGISTRO DE LA CEDULA TIENE 10 DIGITOS VALIDOS
        private static bool IsValidCedula(string cedula)
        {
            return !string.IsNullOrWhiteSpace(cedula)
                   && cedula.Length == 10
                   && cedula.All(char.IsDigit);
        }

      
        private static (string Cedula, string Trato, string Correo, string Token)? GetUsuarioPorChatId(long chatId)
        {
            if (usuariosRegistrados.TryGetValue(chatId, out var datos))
            {
                return datos; // (Cedula, Trato)
            }
            return null; // No registrado
        }

        // FUNCION QUE CREA LOS ASUNTOS CON UN MENSAJE Y LA AYUDA DE IA
        private static async Task<string> GenerateSubjectAsync(string message, string openAiApiKey)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", openAiApiKey);

            var requestBody = new
            {
                model = Conexion.OpenAIConfig.OpenAIModel,
                messages = new[]
                {
            new { role = "system", content = "Eres un asistente que genera títulos breves de tickets." },
            new { role = "user", content = message }
        },
                max_tokens = 15
            };

            var content = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://api.openai.com/v1/chat/completions", content);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(json);
            var subject = doc.RootElement
                            .GetProperty("choices")[0]
                            .GetProperty("message")
                            .GetProperty("content")
                            .GetString();

            return subject?.Trim() ?? message;
        }

        // FUNCION QUE ME PERMITE CREAR TICKETS DE ATENCION A PARTIR DEL API DE OSTICKET
        private static async Task<string> CreateOsTicketAsync(string _subject, string _message, string trato, string correo)
        {
            string osTicketApiKey = Conexion.OsticketConfig.OSTicketToken ?? string.Empty;
            string osTicketUrl = Conexion.OsticketConfig.OSTicketHost + "api/http.php/tickets.json";

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-API-Key", osTicketApiKey);

            var ticket = new
            {
                alert = true,
                autorespond = true,
                source = "API",
                name = trato,
                email = correo,
                subject = _subject,
                message = _message
            };

            var content = new StringContent(JsonSerializer.Serialize(ticket), Encoding.UTF8, "application/json");
            var response = await client.PostAsync(osTicketUrl, content);
            var result = await response.Content.ReadAsStringAsync();

            return $" ticket #{result}";
        }


        //FUNCION PARA OBTENER LOS DATOS DE UN FUNCIONARIO BASADO EN EL NUMERO DE CEDULA

        private static ApiResultMo<InsertarUsuariosMo> ObtenerDatosFuncionario(string cedula)
        {
            using var cmd = new NpgsqlCommand();
            string sql = @"SELECT 
                            left(u.cedruc,10) as cedruc,
                            u.descrip,
		                    u.email1 as correo_origen
                            FROM rodatper  u
                            WHERE 
                            left(u.cedruc,10) = @usuario
                            and u.estado = 1
                            LIMIT 1;";
            cmd.Parameters.AddWithValue("@usuario", cedula);
            cmd.CommandText = sql;

            var result = Exec_sql.cargarDatosModel<InsertarUsuariosMo>(cmd);  // Retornar List<LoginMo>

            if (result.success)
            {
                return ApiResultMo<InsertarUsuariosMo>.Ok(result.result[0]);
            }
            else
            {
                return ApiResultMo<InsertarUsuariosMo>.Fail("Sin registros!!");
            }
        }


        /// <summary>
        /// GENERACION DE TOKEN PARA EL REGISTRO DE TELEGRAM
        /// </summary>
        /// <param name="iCodigoUsuario"></param>
        /// <returns></returns>
        public static ApiResultMo<string> GenerarTokenTelegram(string nombreUsuario, string correo)
        {
            try
            {
                var CorreoValido = SeguridadBL.IsValidEmail(correo);

                if (CorreoValido == true)
                {
                    // SI TIENE UN CORREO VALIDO PARA ACTUALIZAR REALIZO EL PROCESO DE ACTUALIZACION
                    string _html = string.Empty;

                    using (var cmd = new NpgsqlCommand())
                    {

                        var sql = @"select *
                                           from mensajes_html
                                           where men_codigo = @men_codigo;";
                        cmd.CommandText = sql;
                        cmd.Parameters.AddWithValue("@men_codigo", 27);

                        var respuesta = Exec_sql.cargarDatosJson(cmd);

                        respuesta = Newtonsoft.Json.JsonConvert.DeserializeObject(respuesta.result);

                        _html = respuesta[0]["men_html"];
                    }
                    var Token = new SeguridadBL().GeneraCodigo(6);

                    _html = _html.Replace("##USUARIO_NOMBRE##", nombreUsuario);
                    _html = _html.Replace("##TOKEN##", Token);


                    // ENVIAR CORREO PARA GENERACION DE TOKEN

                    CorreoMo oCorreo = new()
                    {
                        Para = [correo],
                        Asunto = "Registro de Telegram - SFGProv",
                        isHtml = true,
                        Body = _html
                    };

                    var oEnviarCorreo = new CorreoBL().Enviar(oCorreo);

                    if (oEnviarCorreo.success)
                    {
                        return ApiResultMo<string>.Ok(Token);
                    }
                    else
                    {
                        return ApiResultMo<string>.Fail("No se pudo enviar el token.");
                    }
                }
                else {
                    return ApiResultMo<string>.Fail("El correo electrónico no tiene un formato correcto.");
                }
            }

            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return ApiResultMo<string>.Fail("Error: " + e.Message);
            }

        }
    }
}
