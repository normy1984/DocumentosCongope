﻿using Congope.Empresas.BussinessLogic.Bpm;
using Congope.Empresas.Data;
using Congope.Empresas.Extensiones;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.SignalR;
using MongoDB.Bson;
using System.Text.RegularExpressions;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    /// <summary>
    /// Maneja la recepción de documentos firmados y su procesamiento en background.
    /// </summary>
    public class FirmaEcRecibeBL
    {
        private readonly IColasTareasBackground _colasTareasBackground;
        private readonly IServiceScopeFactory _scopeFactory;

        public FirmaEcRecibeBL(
            IColasTareasBackground colasTareasBackground,
            IServiceScopeFactory scopeFactory)
        {
           
            _colasTareasBackground = colasTareasBackground;
            _scopeFactory = scopeFactory;
        }

        /// <summary>
        /// Procesa un archivo firmado, lo valida y lo encola para que sea procesado en background.
        /// </summary>
        public async Task<string> RecibeFirmados(FirmaEcRecibeDocumentoMo request)
        {
            try
            {
                // Validar nombre con regex
                string pattern = @"^(\d+)-.*-([A-Za-z0-9_]+)_(\d{4})\.pdf$";
                var match = Regex.Match(request.NombreDocumento, pattern);

                if (!match.Success || string.IsNullOrWhiteSpace(request.Archivo))
                    throw new FormatException("El nombre del documento no cumple con el formato esperado o el archivo está vacío.");

                // Encolamos el trabajo pesado
                _colasTareasBackground.Enqueue(async token =>
                {
                    int secuencia = int.Parse(match.Groups[1].Value);
                    string referencia = match.Groups[2].Value;
                    int anio = int.Parse(match.Groups[3].Value);

                    var filtro1 = new Dictionary<string, object>
                    {
                        { "Referencia", referencia },
                        { "Anio", anio },
                        { "Nombre", $"{referencia}_{anio}" }
                    };

                    // Consultar en Mongo
                    var registros = Exec_sql.ObtenerDatosMongo("Firmas_Electronicas", filtro1, "NumeroFirmas");
                    var documento_0 = registros.result[0];
                    BsonDocument bsonDocument_0 = BsonDocument.Parse(documento_0.ToString());
                    int numeroFirmas = Convert.ToInt32(bsonDocument_0["NumeroFirmas"]);

                    // Decodificar Base64
                    byte[] decodedBytes = Convert.FromBase64String(request.Archivo);
                    BsonBinaryData binData = new BsonBinaryData(decodedBytes);

                    var DatosDocumento = new
                    {
                        Referencia = referencia,
                        Anio = anio,
                        Nombre = $"{referencia}_{anio}",
                        Tipo = "application/pdf",
                        NumeroFirmas = numeroFirmas + 1,
                        FechaSubida = DateTime.Now,
                        FileBase64 = binData
                    };

                    Exec_sql.EjecutarComandoMongo("Firmas_Electronicas", "insertdelete", filtro1, DatosDocumento);

                    // Nuevo scope para evitar DbContext disposed
                    using var scope = _scopeFactory.CreateScope();
                    var documentoBl = scope.ServiceProvider.GetRequiredService<DocumentoBpmBL>();
                    var bpmBl = scope.ServiceProvider.GetRequiredService<BpmBl>();

                    var doc = await documentoBl.ObtenerDocumentoPorIdAsync(referencia, anio);
                    var tasks = await bpmBl.GetTasksByDocumentoAsync(doc?.ProcessInstanceId);
                    var tareaActual = tasks?.FirstOrDefault();

                    if (tareaActual != null)
                    {
                        await bpmBl.CompleteTaskAsync(tareaActual.Id, tareaActual.ProcessInstanceId, true);
                    }
                });

                return "OK";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FirmaEcRecibeBL] Error: {ex.Message}");
                return "NO SE GUARDO EL DOCUMENTO";
            }
        }
    }
}
