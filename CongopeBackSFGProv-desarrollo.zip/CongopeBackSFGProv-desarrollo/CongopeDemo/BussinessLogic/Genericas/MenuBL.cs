﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Npgsql;
using NpgsqlTypes;


namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class MenuBL
    {
        /// <summary>
        /// Funcion que carga el menu lateral del sistema
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        protected static dynamic SqlMenuLateral(int codUsu, int nivel, string codigo )
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           select * from public.sps_generar_menu(
                            @codUsu, @nivel, @codigo);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Numeric, codUsu);
            cmd.Parameters.AddWithValue("@nivel", NpgsqlDbType.Numeric, nivel);
            cmd.Parameters.AddWithValue("@codigo", codigo);

            return Exec_sql.cargarDatosModel<MenuMO>(cmd);

        }

        /// <summary>
        /// Funcion que trae el ejercicio fiscal
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarEjercicioFiscal()
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           select anio, trim(codemp) as codemp, trim(des_eje) as des_eje  from coejefis c 
                           order by anio desc;";
            cmd.CommandText = sql;

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion que carga los iconos del menu principal
        /// </summary>
        /// <param name="iCodUsu"></param>
        /// <returns></returns>
        public static dynamic CargarMenuPrincipal(int iCodUsu)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           select * from  
                           public.sps_cargarmenuprincipal(@codusu);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codusu", iCodUsu);
            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion que trae el menu lateral de la aplicacion
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static dynamic CargarMenuLateral(int codUsu, int nivel, string codigo, string ip)


        {
            if (nivel == 1) {
                SqlAuditoriaAcceso(codUsu, Int32.Parse(codigo), ip);
            }

            var menu = new List<MenuMO>();
            var menuDatos = SqlMenuLateral(codUsu, nivel, codigo);

            if (menuDatos.success)
            {
                foreach (var item in menuDatos.result)
                {
                    if (item.Submenu == null)
                    {
                        item.Submenu = new List<MenuMO>(); // Inicializar Submenu si es null
                    }
                    item.GroupTitle = true;
                    item.Badge = "";
                    menu.Add(item); // Agregar cada ítem a la lista menu
                }
            }

            var subMenus = CargarMenuRecursivo(codUsu, nivel + 1, codigo);
            menu.AddRange(subMenus); // Agregar los submenús recursivos

            return new
            {
                success = true,
                message = "",
                result = menu
            };
        }


       
        /// <summary>
        /// Funcion recursiva que carga la informacion del menu lateral
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        private static List<MenuMO> CargarMenuRecursivo(int codUsu, int nivel, string codigo)
        {
            var menu = new List<MenuMO>();
            var respuesta = SqlMenuLateral(codUsu, nivel, codigo);

            if (respuesta.success)
            {
                var objetoMenu = respuesta.result; // Suponiendo que respuesta.result es de tipo List<MenuMO> o MenuMO[]
                foreach (var item in objetoMenu)
                {
                    if (nivel == 1 && Int32.Parse(item.Badge) > 0)
                    {
                        item.Submenu = CargarMenuRecursivo(codUsu, nivel + 1, item.Codigo); // Llamada recursiva para el siguiente nivel
                    }
                    else if (nivel == 2 && Int32.Parse(item.Badge) > 0)
                    {
                        item.Submenu = CargarMenuRecursivo(codUsu, nivel + 1, item.Codigo); // Llamada recursiva para el siguiente nivel
                    }
                    if (item.Submenu == null)
                    {
                        item.Submenu = new List<MenuMO>(); // Inicializar Submenu si es null
                    }
                    menu.Add(item); // Agregar cada ítem de objetoMenu a la lista menu
                }
            }
            return menu;
        }

        /// <summary>
        /// Funcion que carga las notificaciones del sistemas
        /// </summary>
        /// <param name="paramSession"></param>
        /// <returns></returns>
        protected static dynamic SqlCargarNotificaciones(ParamSessionMo paramSession)
        {

            var cmd = new NpgsqlCommand();
            var sql = @"
                    SELECT * from public.sps_cargarnotificaciones(
                    @codUsu, @Anio, @CodEmp);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", paramSession.codUsu);
            cmd.Parameters.AddWithValue("@CodEmp", paramSession.CodEmp);
            cmd.Parameters.AddWithValue("@Anio", paramSession.Anio);
            return Exec_sql.cargarDatosModel<NotificacionesMo>(cmd);
        }

        /// <summary>
        /// Funcion que carga las notificaciones del sistema
        /// </summary>
        /// <param name="paramSession"></param>
        /// <returns></returns>
        public static dynamic CargarNotificaciones(ParamSessionMo paramSession)
        {
            var respuesta = new ApiResultMo<List<NotificacionesMo>>();
            var varListaNotificaciones = new List<NotificacionesMo>();

            var informacionNotificacion = SqlCargarNotificaciones(paramSession);
            if (informacionNotificacion.success)
            {
                foreach (var item in informacionNotificacion.result)
                {
                    if (item.notificaciones > 0)
                    {
                        varListaNotificaciones.Add(item);
                    }
                }

                if (varListaNotificaciones.Count > 0)
                {

                    respuesta.success = true;
                    respuesta.message = "Tiene notificaciones";
                    respuesta.result = varListaNotificaciones;
                }
                else
                {
                    respuesta.message = "No tiene notificaciones";
                }

                return respuesta;

            }
            else
            {
                return informacionNotificacion;
            }

        }
        /// <summary>
        /// Funcion que verifica los permisos para visualizar notificaciones
        /// </summary>
        /// <param name="CodUsu"></param>
        /// <returns></returns>
        public static dynamic TienePermisosNotificaciones(int CodUsu)
        {

            var cmd = new NpgsqlCommand();
            var sql = @"
                    SELECT * from public.sps_TienePermisos(
                    @codUsu);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", CodUsu);

            return Exec_sql.cargarDatosJson(cmd);
        }


        /// <summary>
        /// Funcion que guarda en la base de datos la auditoria de acceso a las aplicaciones
        /// </summary>
        /// <param name="cod_usu"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        private static dynamic SqlAuditoriaAcceso(int cod_usu, int sistema , string ip)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"select * from public.spi_ingreso_a_sistemas(
                               @cod_usu, @sistema ,@ip
                                );";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@cod_usu", NpgsqlDbType.Integer, cod_usu);
                cmd.Parameters.AddWithValue("@sistema", NpgsqlDbType.Integer, sistema);
                cmd.Parameters.AddWithValue("@ip", NpgsqlDbType.Varchar, ip);

                return Exec_sql.cargarDatosJson(cmd);
            }
        }

    }
}
