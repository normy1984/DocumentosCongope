﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Microsoft.EntityFrameworkCore;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class TimbradasBL
    {
        private readonly AppDbContext _db;

        public TimbradasBL(AppDbContext db)
        {
            _db = db;
        }

        public async Task<List<TimbradaDto>> ObtenerUltimasTimbradasAsync(string cedula, CancellationToken ct)
        {
            var timbradas = await (
                 from u in _db.Userinfo
                 join a in _db.Attlog on u.Badgenumber equals a.Pin.ToString()
                 where u.Ssn == cedula
                 group a by a.Atttime.Date into g
                 orderby g.Key descending
                 select new TimbradaDto
                 {
                     Fecha = g.Key,
                     Entrada = g.Min(x => x.Atttime).TimeOfDay,
                     Salida = g.Min(x => x.Atttime) == g.Max(x => x.Atttime)
                         ? (TimeSpan?)null
                         : g.Max(x => x.Atttime).TimeOfDay
                 }
             )
             .Take(5)
             .ToListAsync(ct)
             .ConfigureAwait(false);

            // Reordenar cronológicamente de la más antigua a la más reciente
            return timbradas.OrderBy(t => t.Fecha).ToList();

        }
    }
}
