﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Npgsql;

namespace Congope.Empresas.BussinessLogic
{
    public class SaldosPorPeriodoBL
    {
        /// <summary>
        /// Función para Obtener Saldo por perìodo de una cuenta contable
        /// </summary>
        /// <param name="cuenta">Identificación de la cuenta</param>
        /// <returns>lista de Saldos de la cuenta</returns>
        public static dynamic ObtenerSaldoPorPeriodoCuentaContable(string cuenta)
        {
            string sql = "select * from sps_saldo_por_periodo('" + Constantes.General.Empresa + "',"
                + Constantes.General.anio + ",'" + Constantes.TipoCuenta.apertura + "','" + cuenta + "')";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            return Exec_sql.cargarDatosModel<SaldosPorPeriodoMO>(cmd);
        }
    }
}
