﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;

//using Congope.Empresas.Models.CuentasContables;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Data;

namespace Congope.Empresas.BussinessLogic
{
    public class CuentasContablesBL
    {

        /// <summary>
        /// Método para ver la lista de Cuentas Contables
        /// </summary>
        /// <returns>Lista de Empresas</returns>
        public static dynamic ListarCuentasContables(int pag, int reg)
        {
   
            ParamSessionMo parametros = new ParamSessionMo();
            string sql = "select * from sps_cuentas_contables(@codemp,@anio,@estado,@pag,@reg);";             
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Varchar, string.IsNullOrEmpty(parametros.CodEmp)?Constantes.General.Empresa:parametros.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, parametros.Anio>0 ?  parametros.Anio: DateTime.Now.Year);           
            cmd.Parameters.AddWithValue("@estado", NpgsqlDbType.Integer, Int32.Parse(Constantes.EstadosCuenta.activo));          
            cmd.Parameters.AddWithValue("@pag", NpgsqlDbType.Integer, pag);
            cmd.Parameters.AddWithValue("@reg", NpgsqlDbType.Integer, reg);

            return Exec_sql.cargarDatosModel<CuentasContableMO>(cmd);
        }

        /// <summary>
        /// Visualizar el detalle de cuentas contables
        /// </summary>
        /// <param name="cuenta">Identificacion de cuenta</param>
        /// <returns>Detalle de cuenta</returns>
        public static dynamic ObtenerDetalleCuentaContable(string cuenta)
        {
            ParamSessionMo parametros = new ParamSessionMo();
            string sql = "select * from sps_detalle_cuentas_contables(@in_codemp,@in_anio,@in_estado,@in_cuenta);";
      
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, string.IsNullOrEmpty(parametros.CodEmp) ? Constantes.General.Empresa : parametros.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, parametros.Anio > 0 ? parametros.Anio : DateTime.Now.Year);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, Int32.Parse(Constantes.EstadosCuenta.activo));
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Varchar,cuenta);
          
    

            return Exec_sql.cargarDatosModel<PlanCuentasMO>(cmd);
        }

        /// <summary>
        /// Modica el detalle de una Cuenta Contable
        /// </summary>
        /// <param name="cuenta"> Datos de la cuenta</param>
        /// <returns>bool  si se realizo la modificacion ominserción</returns>
        public static dynamic ModificarCuentaContable(PlanCuentasMO cuenta)
        {
            string sql = "spiu_detalle_cuentas_contables";
            NpgsqlCommand cmd = new NpgsqlCommand();

            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codigo", Int32.Parse(cuenta.codigo));
            cmd.Parameters.AddWithValue("@in_cuenta_p", cuenta.cuenta_p);
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_estado", Int32.Parse(Constantes.EstadosCuenta.activo));
            cmd.Parameters.AddWithValue("@in_cuenta", cuenta.cuenta);
            cmd.Parameters.AddWithValue("@in_nom_cue", cuenta.nom_cue);
            cmd.Parameters.AddWithValue("@in_ult_cue", cuenta.ult_cue);
            cmd.Parameters.AddWithValue("@in_niv_cue", Int32.Parse(cuenta.niv_cue));
            cmd.Parameters.AddWithValue("@in_aux_cue", cuenta.aux_cue);
            cmd.Parameters.AddWithValue("@in_ban_cue", cuenta.ban_cue);
            cmd.Parameters.AddWithValue("@in_nivbal", Int32.Parse(cuenta.nivbal));
            cmd.Parameters.AddWithValue("@in_tipocuec", Int32.Parse(cuenta.tipocuec));
            cmd.Parameters.AddWithValue("@in_por_iva", Int32.Parse(cuenta.por_iva));
            cmd.Parameters.AddWithValue("@in_por_ret", Int32.Parse(cuenta.por_ret));
            cmd.Parameters.AddWithValue("@in_renta", Int32.Parse(cuenta.renta));
            cmd.Parameters.AddWithValue("@in_ctapeaje", Int32.Parse(cuenta.ctapeaje));
            cmd.Parameters.AddWithValue("@in_ctatrans", Int32.Parse(cuenta.ctatrans));
            cmd.Parameters.AddWithValue("@in_ctapago", Int32.Parse(cuenta.ctapago));
            cmd.Parameters.AddWithValue("@in_cta_evol", Int32.Parse(cuenta.cta_evol));
            cmd.Parameters.AddWithValue("@in_ctapasateso", Int32.Parse(cuenta.ctapasateso));
            cmd.Parameters.AddWithValue("@in_cta_repcom", Int32.Parse(cuenta.cta_repcom));
            cmd.Parameters.AddWithValue("@in_cxc_iva_ret100_lrti", Int32.Parse(cuenta.cxc_iva_ret100_lrti));
            cmd.Parameters.AddWithValue("@in_cta_iess", Int32.Parse(cuenta.cta_iess));
            cmd.Parameters.AddWithValue("@in_sal_inic", Int32.Parse(cuenta.sal_inic));
            cmd.Parameters.AddWithValue("@in_sal_cre", Int32.Parse(cuenta.sal_cre));
            cmd.Parameters.AddWithValue("@in_sal_inid", Int32.Parse(cuenta.sal_inid));
            cmd.Parameters.AddWithValue("@in_sal_deb", Int32.Parse(cuenta.sal_deb));
            return Exec_sql.EjecutarQuerySP(cmd);
        }


        /// <summary>
        /// Funcion para inactivar una cuenta contable
        /// </summary>
        /// <param name="cuenta">Informaciòn de la cuenta</param>
        /// <returns></returns>
        public static dynamic EliminarDetalle(PlanCuentasMO cuenta)
        {
            string sql = "spd_detalle_cuentas_contables";

            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_cuenta", cuenta.cuenta);
            return Exec_sql.EjecutarQuerySP(cmd);
        }

        /// <summary>
        /// Método para ver la información para creacion de cuentas
        /// </summary>
        /// <returns>Lista de Empresas</returns>
        public static dynamic DesplegarInfoCreacionCuentasContables(string cuenta)
        {
            string sql = "select niv_est,descripcion,niv_digitos,nombre_cuenta from sps_creacion_cuentas_masivo(" +
                "@in_codemp,@in_anio,@in_cuenta);";   
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_cuenta", cuenta);
            return Exec_sql.cargarDatosModel<InformacionCuentasMO>(cmd);

        }
    }
}
