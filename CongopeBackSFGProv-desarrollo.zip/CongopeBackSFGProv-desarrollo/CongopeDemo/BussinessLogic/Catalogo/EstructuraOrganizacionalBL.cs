﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Catalogo
{
    public class EstructuraOrganizacionalBL
    {
        /// <summary>
        /// Funcion utilizada para obtener la lista de informacion de la Estructura Organizacional
        /// </summary>
        /// <returns></returns>
        public static dynamic Listar()
        {

            string sql = @"select 
                          trim(cuenta) as cuenta,
                          trim(nom_cue) as nom_cue
                          from roplacta r
                          where r.codemp = @codemp
                          and r.anio = @anio
                          order by 1;";


            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, Convert.ToInt32( Constantes.General.anio));
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
