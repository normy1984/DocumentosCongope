﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Catalogo;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;


namespace Congope.Empresas.BussinessLogic.Catalogo
{
    public class EmpleadosBL
    {
        /// <summary>
        /// Funcion que retorna el listado de empleados
        /// </summary>
        /// <returns></returns>
        public static dynamic EmpleadoLista()
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"select * from public.sps_empleado_lista();";
                cmd.CommandText = sql;
                return Exec_sql.cargarDatosJson(cmd);
            }
        }

        /// <summary>
        /// Funcion que obtiene los Datos por codigo del empleado
        /// </summary>
        /// <param name="empleadosPorCodigoMo"></param>
        /// <returns></returns>
        public static dynamic EmpleadoPersonalesPorCodigo(EmpleadosPorCodigoMo empleadosPorCodigoMo)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"select r.*,
                               sps_calcular_edad(r.fecnac) as edad
                               from public.rodatper r
                               where r.codemp = @codemp
                               and r.cedruc = @cedruc;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Varchar, empleadosPorCodigoMo.sessionMo.CodEmp);
                cmd.Parameters.AddWithValue("@cedruc", NpgsqlDbType.Varchar, empleadosPorCodigoMo.Cedruc);

                return Exec_sql.cargarDatosJson(cmd);
            }
        }
        /// <summary>
        /// Funcion que trae la informacion de las tablas generales por código
        /// </summary>
        /// <param name="tablasporCodigo"></param>
        /// <returns></returns>
        public static dynamic TablasGeneralesPorCodigo(EmpleadosPorCodigoMo tablasporCodigo)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"select *
                               from public.select_tablas_detalle
                               (@codemp,@codtab,0);";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Varchar, tablasporCodigo.sessionMo.CodEmp);
                cmd.Parameters.AddWithValue("@codtab", NpgsqlDbType.Integer, Int32.Parse(tablasporCodigo.Cedruc));
                return Exec_sql.cargarDatosJson(cmd);
            }
        }

        /// <summary>
        /// Funcion que trae la informacion demografica por codigo
        /// </summary>
        /// <param name="codigo_p"></param>
        /// <returns></returns>
        public static dynamic DatosDemograficos(string codigo_p)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"select codigo
                                    , nombre from public.siprocan s 
                                    where s.codigo_p = @codigo_p
                                    and s.activo = 1 order by 1;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@codigo_p", NpgsqlDbType.Varchar, codigo_p);
                return Exec_sql.cargarDatosJson(cmd);


            }
        }


        /// <summary>
        /// Funcion que se ejecuta para actualizar la informacion de la fotografia del empleado
        /// </summary>
        /// <param name="subirFotoMo"></param>
        /// <returns></returns>
        public static dynamic SubirFotoEmpleado(EmpleadosSubirFotoMo subirFotoMo)
        {
            var respuesta = new ApiResultMo<string>();

            try
            {
                if (subirFotoMo.uploadFile != null && subirFotoMo.uploadFile.Length != 0)
                {
                    // Ruta donde se guardarán las imágenes
                    var uploadsFolder = Path.Combine(Conexion.RutaDocumentos, "fotos");

                    // Crear el directorio si no existe
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    // Obtener el nombre del archivo
                    var fileName = Path.GetFileNameWithoutExtension(subirFotoMo.Cedruc) + ".jpg";

                    // Crear la ruta completa para guardar el archivo
                    var filePath = Path.Combine(uploadsFolder, fileName);

                    // Guardar el archivo
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        subirFotoMo.uploadFile.CopyTo(fileStream);
                    }

                }
                respuesta.success = true;

            }
            catch (Exception ex)
            {
                // Escribir el error en el log
                SeguridadBL.WriteErrorLog(ex);
                respuesta.message = ex.Message;

            }

            return respuesta;
        }

        /// <summary>
        /// Funcion que realiza un proceso de conversion de la imagen a un formato base64 para enviarlo al front
        /// </summary>
        /// <param name="pathArchivo"></param>
        /// <returns></returns>
        public static dynamic CargarFoto(string pathArchivo)
        {
            var respuesta = new ApiResultMo<string>();

            try
            {
                // Combina la ruta del repositorio con el nombre del archivo
                var filePath = Path.Combine(Conexion.RutaFotos, pathArchivo + ".jpg");

                if (!File.Exists(filePath))
                {
                    filePath = Path.Combine(Environment.CurrentDirectory, "assets/images/" + Conexion.ErrorFoto);
                }

                // Verifica si el archivo existe
                if (File.Exists(filePath))
                {
                    // Lee el contenido del archivo como bytes
                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // Convierte los bytes a Base64
                    string base64String = Convert.ToBase64String(fileBytes);

                    respuesta.success = true;
                    respuesta.result = base64String;

                }
                else
                {
                    throw new Exception("Fallo la carga de la foto del empleado.");

                }

                return respuesta;
            }

            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                respuesta.message = ex.Message;
                return respuesta;

            }


        }

        /// <summary>
        /// Funcion que permite insertar o actualizar los datos del Empleado
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        public static dynamic InsertarActualizarEmpleado(EmpleadosMo DetalleMo)
        {
            var respuesta = new ApiResultMo<string>();

            try
            {

                var validar_Cedula = ListaCiuBL.Validar_identificacion("C", DetalleMo.cedruc);
                validar_Cedula = JsonConvert.DeserializeObject(validar_Cedula.result);
                if (validar_Cedula[0].sp_validaidentificacion == 0)
                {
                    throw new Exception("El número de cédula es incorrecto favor verifique!!");
                }
                using (NpgsqlCommand cmd = new NpgsqlCommand())
                {
                    string sql = @"select * from
                               public.spiu_empleados
                               (
                                @in_codemp,
                                @in_cedruc,
                                @in_descrip,
                                @in_direcci,
                                @in_telefon1,
                                @in_telefon2,
                                @in_fax1,
                                @in_fax2,
                                @in_email1,
                                @in_email2,
                                @in_cre_por,
                                @in_fec_ini,
                                @in_fec_fin,
                                @in_cuenta,
                                @in_libretmi,
                                @in_afiiess,
                                @in_tiposan,
                                @in_instruc,
                                @in_sexo,
                                @in_tipocta,
                                @in_banco,
                                @in_rucoced,
                                @in_cuentaco,
                                @in_suelunif,
                                @in_suelante,
                                @in_sueliess,
                                @in_partida,
                                @in_fecnac,
                                @in_regimen,
                                @in_estciv,
                                @in_estado,
                                @in_cuentaaso,
                                @in_fondo_reser,
                                @in_extension,
                                @in_crg_id,
                                @in_cargas_famil,
                                @in_nombramiento,
                                @in_discapacitado,
                                @in_dias_lab,
                                @in_provincia,
                                @in_ciudad,
                                @in_nacionalidad,
                                @in_etnico,
                                @in_enf_catastrofico,
                                @in_enf_alergias,
                                @in_enf_otros,
                                @in_grupo,
                                @in_grado,
                                @in_duracion_cont,
                                @in_cambioad,
                                @in_declara_bien,
                                @in_clave,
                                @in_pago_decimos,
                                @in_pago_decimocuarto,
                                @in_th_perfil,
                                @in_image,
                                @in_code );";
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, DetalleMo.sessionMo.CodEmp);
                    cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, DetalleMo.cedruc);
                    cmd.Parameters.AddWithValue("@in_descrip", NpgsqlDbType.Char, DetalleMo.descrip);
                    cmd.Parameters.AddWithValue("@in_direcci", NpgsqlDbType.Char, DetalleMo.direcci);
                    cmd.Parameters.AddWithValue("@in_telefon1", NpgsqlDbType.Char, DetalleMo.telefon1);
                    cmd.Parameters.AddWithValue("@in_telefon2", NpgsqlDbType.Char, DetalleMo.telefon2);
                    cmd.Parameters.AddWithValue("@in_fax1", NpgsqlDbType.Char, DetalleMo.fax1);
                    cmd.Parameters.AddWithValue("@in_fax2", NpgsqlDbType.Char, DetalleMo.fax2);
                    cmd.Parameters.AddWithValue("@in_email1", NpgsqlDbType.Char, DetalleMo.email1);
                    cmd.Parameters.AddWithValue("@in_email2", NpgsqlDbType.Char, DetalleMo.email2);
                    cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, DetalleMo.sessionMo.codUsu.ToString());
                    cmd.Parameters.AddWithValue("@in_fec_ini", NpgsqlDbType.Char, DetalleMo.fec_ini);
                    cmd.Parameters.AddWithValue("@in_fec_fin", NpgsqlDbType.Char, DetalleMo.fec_fin);
                    cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, DetalleMo.cuenta);
                    cmd.Parameters.AddWithValue("@in_libretmi", NpgsqlDbType.Char, DetalleMo.libretmi);
                    cmd.Parameters.AddWithValue("@in_afiiess", NpgsqlDbType.Char, DetalleMo.afiiess);
                    cmd.Parameters.AddWithValue("@in_tiposan", NpgsqlDbType.Smallint, DetalleMo.tiposan);
                    cmd.Parameters.AddWithValue("@in_instruc", NpgsqlDbType.Smallint, DetalleMo.instruc);
                    cmd.Parameters.AddWithValue("@in_sexo", NpgsqlDbType.Smallint, DetalleMo.sexo);
                    cmd.Parameters.AddWithValue("@in_tipocta", NpgsqlDbType.Smallint, DetalleMo.tipocta);
                    cmd.Parameters.AddWithValue("@in_banco", NpgsqlDbType.Char, DetalleMo.banco);
                    cmd.Parameters.AddWithValue("@in_rucoced", NpgsqlDbType.Smallint, DetalleMo.rucoced);
                    cmd.Parameters.AddWithValue("@in_cuentaco", NpgsqlDbType.Char, DetalleMo.cuentaco);
                    cmd.Parameters.AddWithValue("@in_suelunif", NpgsqlDbType.Double, DetalleMo.suelunif);
                    cmd.Parameters.AddWithValue("@in_suelante", NpgsqlDbType.Double, DetalleMo.suelante);
                    cmd.Parameters.AddWithValue("@in_sueliess", NpgsqlDbType.Double, DetalleMo.sueliess);
                    cmd.Parameters.AddWithValue("@in_partida", NpgsqlDbType.Varchar, DetalleMo.partida);
                    cmd.Parameters.AddWithValue("@in_fecnac", NpgsqlDbType.Char, DetalleMo.fecnac);
                    cmd.Parameters.AddWithValue("@in_regimen", NpgsqlDbType.Smallint, DetalleMo.regimen);
                    cmd.Parameters.AddWithValue("@in_estciv", NpgsqlDbType.Smallint, DetalleMo.estciv);
                    cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, DetalleMo.estado);
                    cmd.Parameters.AddWithValue("@in_cuentaaso", NpgsqlDbType.Char, DetalleMo.cuentaaso);
                    cmd.Parameters.AddWithValue("@in_fondo_reser", NpgsqlDbType.Numeric, DetalleMo.fondo_reser);
                    cmd.Parameters.AddWithValue("@in_extension", NpgsqlDbType.Varchar, DetalleMo.extension);
                    cmd.Parameters.AddWithValue("@in_crg_id", NpgsqlDbType.Numeric, DetalleMo.crg_id);
                    cmd.Parameters.AddWithValue("@in_cargas_famil", NpgsqlDbType.Numeric, DetalleMo.cargas_famil);
                    cmd.Parameters.AddWithValue("@in_nombramiento", NpgsqlDbType.Integer, DetalleMo.nombramiento);
                    cmd.Parameters.AddWithValue("@in_discapacitado", NpgsqlDbType.Numeric, DetalleMo.discapacitado);
                    cmd.Parameters.AddWithValue("@in_dias_lab", NpgsqlDbType.Numeric, DetalleMo.dias_lab);
                    cmd.Parameters.AddWithValue("@in_provincia", NpgsqlDbType.Char, DetalleMo.provincia);
                    cmd.Parameters.AddWithValue("@in_ciudad", NpgsqlDbType.Char, DetalleMo.ciudad);
                    cmd.Parameters.AddWithValue("@in_nacionalidad", NpgsqlDbType.Numeric, DetalleMo.nacionalidad);
                    cmd.Parameters.AddWithValue("@in_etnico", NpgsqlDbType.Numeric, DetalleMo.etnico);
                    cmd.Parameters.AddWithValue("@in_enf_catastrofico", NpgsqlDbType.Numeric, DetalleMo.enf_catastrofico);
                    cmd.Parameters.AddWithValue("@in_enf_alergias", NpgsqlDbType.Numeric, DetalleMo.enf_alergias);
                    cmd.Parameters.AddWithValue("@in_enf_otros", NpgsqlDbType.Numeric, DetalleMo.enf_otros);
                    cmd.Parameters.AddWithValue("@in_grupo", NpgsqlDbType.Numeric, DetalleMo.grupo);
                    cmd.Parameters.AddWithValue("@in_grado", NpgsqlDbType.Numeric, DetalleMo.grado);
                    cmd.Parameters.AddWithValue("@in_duracion_cont", NpgsqlDbType.Numeric, DetalleMo.duracion_cont);
                    cmd.Parameters.AddWithValue("@in_cambioad", NpgsqlDbType.Numeric, DetalleMo.cambioad);
                    cmd.Parameters.AddWithValue("@in_declara_bien", NpgsqlDbType.Char, DetalleMo.declara_bien);
                    cmd.Parameters.AddWithValue("@in_clave", NpgsqlDbType.Varchar, DetalleMo.clave);
                    cmd.Parameters.AddWithValue("@in_pago_decimos", NpgsqlDbType.Numeric, DetalleMo.pago_decimos);
                    cmd.Parameters.AddWithValue("@in_pago_decimocuarto", NpgsqlDbType.Numeric, DetalleMo.pago_decimocuarto);
                    cmd.Parameters.AddWithValue("@in_th_perfil", NpgsqlDbType.Integer, DetalleMo.th_perfil);
                    cmd.Parameters.AddWithValue("@in_image", NpgsqlDbType.Varchar, DetalleMo.image);
                    cmd.Parameters.AddWithValue("@in_code", NpgsqlDbType.Varchar, DetalleMo.code);
                    var result = Exec_sql.cargarDatosJson(cmd);
                    respuesta.success = result.success;
                    respuesta.message = result.message;
                    respuesta.result = result.result;
                }
                return respuesta;

            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);

                respuesta.message = e.Message;
                return respuesta;

            }
        }

    }



}
