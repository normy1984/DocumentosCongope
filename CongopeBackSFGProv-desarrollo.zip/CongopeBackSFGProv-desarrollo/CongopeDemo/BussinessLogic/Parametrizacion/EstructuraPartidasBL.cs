﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Npgsql;
using NpgsqlTypes;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Parametrizacion
{
    public class EstructuraPartidasBL
    {
        /// <summary>
        /// FUNCION QUE LISTA LOS REGISTROS DE LA ESTRUCTURA EN EL LIST
        /// </summary>
        /// <param name="sel_Estructura"></param>
        /// <returns></returns>
        public static dynamic ListarEstructuraPartidas(Sel_EstructuraPartidaMo sel_Estructura)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"
                            SELECT * from 
                            public.sps_man_estructura_partida(@in_anio, @in_codemp, @in_sistema ,  @in_identifi);
                            ";
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@in_anio", sel_Estructura.sessionMo.Anio);
                cmd.Parameters.AddWithValue("@in_codemp", sel_Estructura.sessionMo.CodEmp);
                cmd.Parameters.AddWithValue("@in_identifi", sel_Estructura.identifi);
                cmd.Parameters.AddWithValue("@in_sistema", sel_Estructura.sessionMo.Sistema);
                return Exec_sql.cargarDatosJson(cmd);
            }

        }


        /// <summary>
        /// FUNCION SQL QUE ACTUALIZA O ELIMINA LOS REGISTROS
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>

        public static dynamic SQL_InsertarActualizar_EstructuraPartidas(Actualizar_EstructuraPartidaMo DetalleMo)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                string sql = @"
                            SELECT * from public.spi_tablas_estcta(@in_codemp, @in_anio, @in_niv_est, @in_identifi, 
                            @in_des_est, @in_lon_est, @in_cre_por, @in_con_est, 
                            @in_item_aso, @in_foce, @in_orienta_gas, @in_niv_ug, 
                            @in_niv_proy, @in_estado, @in_sistema);
                            ";
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, DetalleMo.paramSessionMo.CodEmp);
                cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, DetalleMo.paramSessionMo.Anio);
                cmd.Parameters.AddWithValue("@in_niv_est", NpgsqlDbType.Integer, DetalleMo.niv_est);
                cmd.Parameters.AddWithValue("@in_identifi", NpgsqlDbType.Smallint, DetalleMo.identifi);
                cmd.Parameters.AddWithValue("@in_ucodemp", NpgsqlDbType.Char, DetalleMo.paramSessionMo.CodEmp);
                cmd.Parameters.AddWithValue("@in_uanio", NpgsqlDbType.Integer, DetalleMo.paramSessionMo.Anio);
                cmd.Parameters.AddWithValue("@in_des_est", NpgsqlDbType.Char, DetalleMo.des_est);
                cmd.Parameters.AddWithValue("@in_lon_est", NpgsqlDbType.Integer, DetalleMo.lon_est);
                cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, DetalleMo.paramSessionMo.codUsu.ToString());
                cmd.Parameters.AddWithValue("@in_con_est", NpgsqlDbType.Integer, DetalleMo.con_est);
                cmd.Parameters.AddWithValue("@in_item_aso", NpgsqlDbType.Smallint, DetalleMo.item_aso);
                cmd.Parameters.AddWithValue("@in_foce", NpgsqlDbType.Numeric, DetalleMo.foce);
                cmd.Parameters.AddWithValue("@in_orienta_gas", NpgsqlDbType.Numeric, DetalleMo.orienta_gas);
                cmd.Parameters.AddWithValue("@in_niv_ug", NpgsqlDbType.Numeric, DetalleMo.niv_ug);
                cmd.Parameters.AddWithValue("@in_niv_proy", NpgsqlDbType.Numeric, DetalleMo.niv_proy);
                cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, DetalleMo.Estado);
                cmd.Parameters.AddWithValue("@in_sistema", NpgsqlDbType.Integer, DetalleMo.paramSessionMo.Sistema);
                return Exec_sql.cargarDatosJson(cmd);
            }

        }

        /// <summary>
        /// FUNCION LLAMADA DESDE EL CONTROLADOR QUE PERMITE REALIZAR LAS ACCIONES EN LA APLICACION
        /// </summary>
        /// <param name="compromisoDetalleMoList"></param>
        /// <returns></returns>
        public static dynamic InsertarActualizar_EstructuraPartidas(List<Actualizar_EstructuraPartidaMo> compromisoDetalleMoList)
        {
            List<dynamic> respuestas = new List<dynamic>();
           
            try
            {
                foreach (var compromisoDetalleMo in compromisoDetalleMoList)
                {
                        dynamic respuesta = SQL_InsertarActualizar_EstructuraPartidas(compromisoDetalleMo);

                        respuestas.Add(respuesta);

                        // Verificar si la operación individual fue exitosa
                        if (!respuesta.success)
                        {
                            throw new Exception(respuesta.message);
                        }
                    
                }

                return new
                {
                    success = true,
                    message = "Operaciones completadas exitosamente",
                    result = ""
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// FUNCION QUE NOS PERMITE VALIDAR SI LOS REGISTROS CARGADOS PERTENECEN AL GPRD
        /// </summary>
        /// <param name="oParamSessionMo"></param>
        /// <returns></returns>
        public static dynamic ValidarEsGprd(ParamSessionMo oParamSessionMo)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = @"
                                SELECT * FROM public.sps_valida_carga_gprd
                                (@codemp,@anio);";
            cmd.Parameters.AddWithValue("@codemp", oParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", oParamSessionMo.Anio);
            var respuesta = Exec_sql.cargarDatosModel<Sel_Validacion>(cmd);
            return respuesta;
        }

        /// <summary>
        /// FUNCION QUE VALIDA SI HAY MOVIMIENTOS
        /// </summary>
        /// <param name="oParamSessionMo"></param>
        /// <returns></returns>
        public static dynamic ValidarHayMOvimientos(ParamSessionMo oParamSessionMo)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = @"
                                SELECT * from sps_valida_movimientos
                                (@codemp,@anio);";
            cmd.Parameters.AddWithValue("@codemp", oParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", oParamSessionMo.Anio);
            return Exec_sql.cargarDatosModel<Sel_Validacion>(cmd);
        }
    }
}
