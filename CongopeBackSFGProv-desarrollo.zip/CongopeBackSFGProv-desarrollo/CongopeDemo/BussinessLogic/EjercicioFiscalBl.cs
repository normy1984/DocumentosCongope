﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Npgsql;

namespace Congope.Empresas.BussinessLogic
{
    public class EjercicioFiscalBl
    {

        /// <summary>
        /// Método para ver la lista de Ejercicios Fiscales
        /// </summary>
        /// <returns>Lista de Empresas</returns>
        public static List<EjercicioFiscalMO> Listar()
        {

            List<EjercicioFiscalMO> oEjercicioFical = new List<EjercicioFiscalMO>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = "select * from vis_ejerciciofiscal";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oEjercicioFical.Add(new EjercicioFiscalMO()
                            {
                                id_per = Convert.ToInt32(dr[0]),
                                des_per = dr[1].ToString(),
                                fec_ini = dr[2].ToString(),
                                fec_fin = dr[3].ToString(),
                                estado = Convert.ToBoolean(dr[4])
                            });
                        }
                    }

                    return oEjercicioFical;
                }
                catch (Exception e)
                {

                    throw e;
                    return oEjercicioFical;
                }

            }

        }
    }
}
