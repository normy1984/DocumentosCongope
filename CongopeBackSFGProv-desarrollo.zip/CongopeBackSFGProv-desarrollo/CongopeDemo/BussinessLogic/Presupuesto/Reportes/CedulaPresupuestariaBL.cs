﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class CedulaPresupuestariaBL
    {
        public static dynamic Listar(string codemp, string fecha_hasta, int ing_gas, int nTodas, int nNivel, string sOperador, string sPartida = "")
        {

            string sql = "select * from sps_cedula_presupuestaria(@emp,@f_hasta,@inggas,@ntodas,@nnivelbusca,@soperador,@spartida)";
            
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
           
            //return Exec_sql.cargarDatosModel<CedulaPresupuestariaMO>(cmd);
            cmd.Parameters.AddWithValue("@emp", NpgsqlDbType.Varchar, codemp);
            cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, fecha_hasta);
            cmd.Parameters.AddWithValue("@inggas", NpgsqlDbType.Integer, ing_gas);
            cmd.Parameters.AddWithValue("@ntodas", NpgsqlDbType.Integer, nTodas);
            cmd.Parameters.AddWithValue("@nnivelbusca", NpgsqlDbType.Integer, nNivel);
            cmd.Parameters.AddWithValue("@soperador", NpgsqlDbType.Varchar, sOperador);
            cmd.Parameters.AddWithValue("@spartida", NpgsqlDbType.Varchar, sPartida);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
