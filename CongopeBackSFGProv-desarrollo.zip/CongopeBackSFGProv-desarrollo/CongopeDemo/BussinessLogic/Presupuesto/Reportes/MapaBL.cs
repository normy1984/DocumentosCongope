﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class MapaBL 
    {

        public static dynamic GenerarMapa(int periodo_vigente)
        {
            string sql = $@"select * from sps_generar_mapa(@periodo_vigente) ";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@periodo_vigente", NpgsqlDbType.Integer, periodo_vigente);
   
            var response = Exec_sql.cargarDatosJson(cmd);

            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
