﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    
    public class EjecucionPresupuestariaBL
    {/*
        public static dynamic Listar(string sFechaHasta)
        {
        
            string sql = "select * from sp_ejecucion_presupuestaria(@f_hasta)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, sFechaHasta);
            return Exec_sql.cargarDatosJson(cmd);
        }*/
        public static dynamic Listar(FiltroEjecucionPresupuestariaMO ejecucion)
        {

            string sql = "select * from sps_representaejecucion(@codemp,@anio,@fecha,@nivel)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, ejecucion.codemp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, ejecucion.anio);
            cmd.Parameters.AddWithValue("@fecha", NpgsqlDbType.Text, ejecucion.fecha);
            cmd.Parameters.AddWithValue("@nivel", NpgsqlDbType.Integer, ejecucion.nivel);
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic ListarPorGupoNaturaleza(FiltroEjecucionPresupuestariaMO ejecucion)
        {

            string sql = "select * from sps_representaEjecucionPorGrupoNaturaleza(@codemp,@anio,@fecha)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, ejecucion.codemp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, ejecucion.anio);
            cmd.Parameters.AddWithValue("@fecha", NpgsqlDbType.Text, ejecucion.fecha);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
