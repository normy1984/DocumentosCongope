﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class AsociacionContabilidadPresupuestoBL
    {
        public static dynamic Listar(int nanio, int nTipo_presupuesto)
        {
        
            string sql = "select * from sp_ver_asociacion_contabilidad_presupuesto(@anio_bus,@ntipo_presupuesto)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@anio_bus", NpgsqlDbType.Integer, nanio);
            cmd.Parameters.AddWithValue("@ntipo_presupuesto", NpgsqlDbType.Integer, nTipo_presupuesto);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
