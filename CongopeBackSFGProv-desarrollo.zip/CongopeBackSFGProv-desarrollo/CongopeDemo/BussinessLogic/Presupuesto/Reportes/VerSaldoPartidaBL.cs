﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class VerSaldoPartidaBL
    {
        public static dynamic Listar(int nanio, string sPartida)
        {
            
            string sql = "select * from sps_ver_saldos_partida(@anio_bus,@ntipo_presupuesto)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@anio_bus", NpgsqlDbType.Integer, nanio);
            cmd.Parameters.AddWithValue("@ntipo_presupuesto", NpgsqlDbType.Varchar, sPartida);
            return Exec_sql.cargarDatosJson(cmd);
        }
        public static dynamic ListarEvalPresPorUnidad(string codemp, int anio )
        {

            string sql = "select * from sps_evalpresporunidad(@in_codemp,@in_anio)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, codemp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, anio);
           
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
