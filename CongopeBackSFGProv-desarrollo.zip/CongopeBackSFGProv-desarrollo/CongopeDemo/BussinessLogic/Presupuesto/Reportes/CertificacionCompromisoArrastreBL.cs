﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Congope.Empresas.Models;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class CertificacionCompromisoArrastreBL
    {
        public static dynamic SqlCompromisoCertificacionesArrastre(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNo)
        {
            string sql = @"
        SELECT * FROM public.sps_compromisoscertificacionesarrastre
        (@fecha_inicio, @fecha_final, @codemp, @departamento, @estado, @tipo);
    ";

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;

            cmd.Parameters.AddWithValue("@fecha_inicio", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.fecha_inicio);
            cmd.Parameters.AddWithValue("@fecha_final", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.fecha_final);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.codemp);
            cmd.Parameters.AddWithValue("@departamento", NpgsqlDbType.Integer, ingresoCertificacionCompromisoNo.departamento);
            cmd.Parameters.AddWithValue("@estado", NpgsqlDbType.Integer, ingresoCertificacionCompromisoNo.estado);
            cmd.Parameters.AddWithValue("@tipo", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.tipo);

            return Exec_sql.cargarDatosModel<CertificacionCompromisoArrastreMo>(cmd);
        }

        /// <summary>
        /// Funcion que permite organizar el objeto para mostrar en el list principal
        /// </summary>
        /// <param name="ingresoCertificacionCompromisoNo"></param>
        /// <returns></returns>
        public static dynamic CertificacionesCompromisosArrastre(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNo)
        {
            var respuesta = new ApiResultMo<List<CertificacionCompromisoArrastreMo>>();
            var nuevoArreglo = new List<CertificacionCompromisoArrastreMo>();
            string departamento = string.Empty;

            var datosCertificaciones = SqlCompromisoCertificacionesArrastre(ingresoCertificacionCompromisoNo);

            if (datosCertificaciones.success)
            {
                var certificaciones = datosCertificaciones.result as List<CertificacionCompromisoArrastreMo>;

                foreach (var item in certificaciones)
                {
                    if (departamento != item.departamento)
                    {
                        nuevoArreglo.Add(new CertificacionCompromisoArrastreMo()
                        {
                            departamento = string.Empty,
                            concepto = item.departamento,
                            observacion = string.Empty,
                            documento = string.Empty,
                            fecha = string.Empty,
                            siglasnum = string.Empty,
                            comprometido = certificaciones.Where(x => x.departamento == item.departamento).Sum(x => x.comprometido),
                            devengado = certificaciones.Where(x => x.departamento == item.departamento).Sum(x => x.devengado),
                            saldo = certificaciones.Where(x => x.departamento == item.departamento).Sum(x => x.saldo)
                        });

                        departamento = item.departamento;
                    }
                    nuevoArreglo.Add(item);
                }

                respuesta.success = true;
                respuesta.result = nuevoArreglo;
            }
            else
            {
                respuesta.success = false;
                respuesta.message = datosCertificaciones.message;
            }

            return respuesta;
        }

        /// <summary>
        /// Funcion creada para actualizar la informacion de las certificaciones o los compromisos de arrastre
        /// </summary>
        /// <param name="actualizarCompromisoArrastreMo"></param>
        /// <returns></returns>
        public static dynamic ActualizarCompromisoCertificacionesArrastre(ActualizarCompromisoArrastreMo actualizarCompromisoArrastreMo)
        {

            string sql = @"
                        SELECT * from public.spu_compromisocertificadoarrastre(
                        @in_usuario, @in_arrastre, @in_observacion, 
                        @in_codemp, @in_anio, @in_sig_tip, @in_acu_tip);
                        ";

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;

            cmd.Parameters.AddWithValue("@in_usuario", NpgsqlDbType.Char, actualizarCompromisoArrastreMo.paramSessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_arrastre", NpgsqlDbType.Numeric, actualizarCompromisoArrastreMo.arrastre);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, actualizarCompromisoArrastreMo.observacion);
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, actualizarCompromisoArrastreMo.paramSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, actualizarCompromisoArrastreMo.paramSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, actualizarCompromisoArrastreMo.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Integer, actualizarCompromisoArrastreMo.acu_tip);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para obtener los detalles de los documentos de arrastre
        /// </summary>
        /// <param name="actualizarCompromisoArrastreMo"></param>
        /// <returns></returns>
        public static dynamic DetalleCompromisoCertificacionesArrastre(EntradasDetalleCompromisoArrastreMo actualizarCompromisoArrastreMo)
        {

            string sql = @"
                        SELECT * from public.sps_detallecertificacionescompromisosarrastre(
                        @in_codemp, @in_sig_tip,@in_anio, @in_acu_tip);
                        ";

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, actualizarCompromisoArrastreMo.paramSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, actualizarCompromisoArrastreMo.paramSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, actualizarCompromisoArrastreMo.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Integer, actualizarCompromisoArrastreMo.acu_tip);
            return Exec_sql.cargarDatosModel<SalidaDetalleCompromisoArrastreMo>(cmd);

        }

    }
}

