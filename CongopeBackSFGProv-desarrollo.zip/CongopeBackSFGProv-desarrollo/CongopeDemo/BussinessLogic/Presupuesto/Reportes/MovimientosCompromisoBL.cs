﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class MovimientosCompromisoBL
    {
        /// <summary>
        /// Funcion que carga la informacion de los movimientos presupuestarios por fecha y estado
        /// </summary>
        /// <param name="movimientosCompromisoMo"></param>
        /// <returns></returns>
        public static dynamic CargarListado(MovimientosCompromisoMo movimientosCompromisoMo)
        { 

        string sql = @"SELECT *, false as expandido from public.sps_movimientos_presupuestarios_filtradas
                           (
                            @codemp, @sig_tip, @estado, @fec_asi_inicio, @fec_asi_fin
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, movimientosCompromisoMo.codemp);
            cmd.Parameters.AddWithValue("@sig_tip", NpgsqlDbType.Text, movimientosCompromisoMo.sig_tip);
            cmd.Parameters.AddWithValue("@estado", NpgsqlDbType.Integer, movimientosCompromisoMo.estado);
            cmd.Parameters.AddWithValue("@fec_asi_inicio", NpgsqlDbType.Text, movimientosCompromisoMo.fec_asi_inicio);
            cmd.Parameters.AddWithValue("@fec_asi_fin", NpgsqlDbType.Text, movimientosCompromisoMo.fec_asi_fin);
            cmd.CommandText = sql;

            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Funcion que carga el detalle de la informacion
        /// </summary>
        /// <param name="detalleMovimientosCompromisoMo"></param>
        /// <returns></returns>

        public static dynamic CargarListadoDetalle(DetalleMovimientosCompromisoMo detalleMovimientosCompromisoMo)
        {

            string sql = @"SELECT * from public.sps_movimientos_por_compromiso
                           (
                            @codemp, @anio, @compromiso
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, detalleMovimientosCompromisoMo.codemp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, detalleMovimientosCompromisoMo.anio);
            cmd.Parameters.AddWithValue("@compromiso", NpgsqlDbType.Integer, detalleMovimientosCompromisoMo.compromiso);
            cmd.CommandText = sql;

            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
