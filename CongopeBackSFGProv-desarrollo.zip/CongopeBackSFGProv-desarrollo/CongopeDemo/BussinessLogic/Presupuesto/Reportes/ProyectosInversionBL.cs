﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ProyectosInversionBL
    {
        public static dynamic CargarResumenPresupuesto(ResumenPresupuestoFiltroMO resumenPresupoMo)
        {
            //sps_resumenpresupuestario('0004', 2022, '2022-02-19');
            string sql = @"Select * from sps_resumenpresupuestario(@codemp, @anio, @fecha);
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, resumenPresupoMo.codemp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, resumenPresupoMo.anio);
            cmd.Parameters.AddWithValue("@fecha", NpgsqlDbType.Text, resumenPresupoMo.fecha);
            cmd.CommandText = sql;
            var result = Exec_sql.cargarDatosJson(cmd);
            return result;
        }

        public static dynamic CargarPresupuestoXDirec_POA_TTHH(PresupuestoXDirec_POA_TTHHMO resumenPresupoMo)
        {
            string sp = "sps_presupuestoxdireccion";
            if (resumenPresupoMo.grupo=="G") {
                sp = "sps_direcciongrupopoa4";
            }
            
            //sps_resumenpresupuestario('0004', 2022, '2022-02-19');
            
            string sql = @"Select * from "+sp+ "(@codemp, @anio, @fecha,@prt_tthh_param);";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, resumenPresupoMo.codemp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, resumenPresupoMo.anio);
            cmd.Parameters.AddWithValue("@fecha", NpgsqlDbType.Text, resumenPresupoMo.fecha);
            
            if (resumenPresupoMo.prt_tthh_param.HasValue)
            {
                cmd.Parameters.AddWithValue("@prt_tthh_param", NpgsqlDbType.Integer, resumenPresupoMo.prt_tthh_param.Value);
            }
            else
            {
                cmd.Parameters.AddWithValue("@prt_tthh_param", NpgsqlDbType.Integer, DBNull.Value);
            }
            
            cmd.CommandText = sql;
            var result= Exec_sql.cargarDatosJson(cmd);
            if (result.message == "No existen registros")
                result = new { success = true, message = result.message };

            return result;
        }
    }
}
