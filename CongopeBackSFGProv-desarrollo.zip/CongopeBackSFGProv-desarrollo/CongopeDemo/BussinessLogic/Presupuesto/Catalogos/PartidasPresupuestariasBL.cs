﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using static iText.IO.Image.Jpeg2000ImageData;
using static iText.Signatures.LtvVerification;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Catalogos
{
    public class PartidasPresupuestariasBL
    {
        /// <summary>
        /// Método para ver las partidas presupuestarias
        /// </summary>
        /// <returns>Partidas Presupuestarias</returns>
        public static dynamic ListarPartidasPresupuestarias()
        {
            String tipo = "S";
            string sql = "";
            switch (tipo)
            {
                case "S":
                    sql = "select * from sps_ced_presupuestaria('" + Constantes.General.Empresa + "'," + Constantes.General.anio + ",'" + DateTime.Now.ToString("yyyy-MM-dd") + "',1,0) where out_ult_cue = '" + tipo + "'";
               
                    break;
                default:
                    break;
            }

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<PartidasPresupuestariasMO>(cmd);

        }

        public static dynamic ListarDetallePartidasCE(string in_acu_tip)
        {
            PartidaPresupuestariaDetMO pcertificacion=new PartidaPresupuestariaDetMO();
     
            string[] array = in_acu_tip.Split(' ');
            string tipo = array[0].ToUpper();
            int nivel = Convert.ToInt32(array[1]);
            ParamSessionMo parametros = new ParamSessionMo();
            string sql = "select * from sps_certificacion_presupuestaria_det(@in_codemp,@in_anio,@in_codigo,@in_nivel);";
 
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", string.IsNullOrEmpty(parametros.CodEmp) ? Constantes.General.Empresa : parametros.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", Convert.ToInt32(Constantes.General.anio)); 
            cmd.Parameters.AddWithValue("@in_codigo", tipo);
            cmd.Parameters.AddWithValue("@in_nivel",nivel);

           // return Exec_sql.cargarDatosModel<PartidaPresupuestariaDetMO>(cmd);

            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Insercion de Detalles de Partidas Presupuestarias
        /// </summary>
        /// <param name="accion">Al momento insertar</param>
        /// <param name="oPartidaPresupuestariaDetMO">Informacion de Partida</param>
        /// <param name="secuencia">Nro de moviemiento al que pertenece</param>
        /// <returns>Informacion de partida insertada</returns>
        public static dynamic InsertarActualizar_CertificacionPartidasDet(string accion, PartidaPresupuestariaDetMO oPartidaPresupuestariaDetMO,int secuencia)       
        {
            double val_cre = 0;
            if (accion=="INSERTAR" || accion=="ACTUALIZAR")
            {
               

                if (secuencia > 0)
                {
                    val_cre = oPartidaPresupuestariaDetMO.val_cre;
                }
                else
                {
                    val_cre = oPartidaPresupuestariaDetMO.val_cre;
                }
            }
            else {
                   //val_cre = oPartidaPresupuestariaDetMO.val_cre;//revisar donde necesita
                val_cre = oPartidaPresupuestariaDetMO.out_val_cre;
                secuencia = oPartidaPresupuestariaDetMO.out_sec_det;
            }
            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_certificacion_presupuestaria_det
                            (
                             @in_accion,
                             @in_codemp,                          
                             @in_sigtip,
                             @in_acutip,
                             @in_anio,                         
                             @in_user,  
                            @secuencia,
@in_cuenta,@in_val_cre
                             )";                    
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_accion", accion);
            cmd.Parameters.AddWithValue("@in_codemp", oPartidaPresupuestariaDetMO.VarSesion.CodEmp);          
            cmd.Parameters.AddWithValue("@in_sigtip", oPartidaPresupuestariaDetMO.sig_tip);            
            cmd.Parameters.AddWithValue("@in_acutip", Convert.ToInt32(oPartidaPresupuestariaDetMO.acu_tip));
            cmd.Parameters.AddWithValue("@in_anio", Convert.ToInt32(oPartidaPresupuestariaDetMO.VarSesion.Anio));      
            cmd.Parameters.AddWithValue("@in_user", (oPartidaPresupuestariaDetMO.VarSesion.codUsu).ToString());
            cmd.Parameters.AddWithValue("@secuencia", secuencia);
            cmd.Parameters.AddWithValue("@in_cuenta", oPartidaPresupuestariaDetMO.cuenta);
            cmd.Parameters.AddWithValue("@in_val_cre",val_cre );
           
            var response = Exec_sql.cargarDatosJson(cmd);//Exec_sql.cargarDatosModel<PartidaPresupuestariaDetMO>(cmd);

            if (response.message == "No existen registros") { 
                string respuesta = "La partida ya existe";
                return new { success = true, message = respuesta,result="" };
            }else
                return response;
        }

        public static dynamic EliminarDetallePartidaPresupuestaria(string in_codemp, int in_anio, string in_codigo, int in_nivel, string in_cuenta, int in_sec_det)
        {

           
            string sql = "select * from spd_partida_cert_presupuestaria(@in_codemp,@in_anio,@in_codigo,@in_nivel,@in_cuenta,@in_sec_det)"; 
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", in_codemp);
            cmd.Parameters.AddWithValue("@in_anio", in_anio);
            cmd.Parameters.AddWithValue("@in_codigo", in_codigo);
            cmd.Parameters.AddWithValue("@in_nivel", in_nivel);
            cmd.Parameters.AddWithValue("@in_cuenta", in_cuenta);
            cmd.Parameters.AddWithValue("@in_sec_det", in_sec_det);

            return Exec_sql.cargarDatosJson(cmd);

        }


        public static dynamic ValidarPartidaPresupuestariaDuplicada(string in_codemp, int in_anio, string in_cuenta, int in_acutip)
        {
            string sql = "select * from sps_partidaduplicada(@in_codemp,@in_anio,@in_acutip,@in_partida)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", in_codemp);
            cmd.Parameters.AddWithValue("@in_anio", in_anio);
            cmd.Parameters.AddWithValue("@in_acutip", in_acutip);        
            cmd.Parameters.AddWithValue("@in_partida", in_cuenta);

            return Exec_sql.cargarDatosJson(cmd);

        }


    }
}
