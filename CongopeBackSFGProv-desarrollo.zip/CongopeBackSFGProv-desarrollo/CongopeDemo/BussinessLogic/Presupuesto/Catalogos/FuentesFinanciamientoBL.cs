﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using iText.Forms.Form.Element;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Catalogos
{
    /// <summary>
    /// Clase para FuentesFinanciamiento
    /// </summary>
    public class FuentesFinanciamientoBL
    {
        /// <summary>
        /// Método que la lista las Fuentes de Financiamiento
        /// </summary>
        /// <returns>Lista de Fuentes Financiamiento</returns>
        public static dynamic Listar()
        {

            string sql = @"SELECT * FROM sps_fuentes_financiamiento()";

            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            return Exec_sql.cargarDatosModel<FuentesFinanciamientoMO>(cmd);
            //return Exec_sql.cargarDatosJson(cmd);            
        }


        /// <summary>
        /// Método que obtiene una fuente de financiamiento por identificador
        /// </summary>
        /// <param name="ffn_id"> Identificador de la fuente de financiamiento</param>
        /// <returns>Retorna los datos de la fuente de financiamiento encontrada</returns>
        public static dynamic ListarFuenteFinanciamientoCodigo(string ffn_id)
        {
            string sql = @"SELECT * FROM sps_detalle_fuente_financiamiento(@ffn_id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@ffn_id", ffn_id);

            return Exec_sql.cargarDatosModel<FuentesFinanciamientoMO>(cmd);
            //return Exec_sql.cargarDatosJson(cmd);  
        }



        /// <summary>
        /// Método que inserta o actualiza una Fuente de Financiamiento
        /// </summary>
        /// <param name="sTipoAccion"></param>
        /// <param name="oFuentesFinanciamientoMO"></param>
        /// <returns>True o False si se registra o actualiza la fuente de financiamiento</returns>
        public static dynamic InsertarActualizarFuenteFinanciamiento(string sTipoAccion, FuentesFinanciamientoMO oFuentesFinanciamientoMO)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"SELECT *
                            FROM spiu_fuente_financiamiento
                            (
                             @in_tipo_accion,
                             @in_ffn_id,
                             @in_ffn_nombre,
                             @in_ffn_ctapago
                             )";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_tipo_accion", sTipoAccion);
            cmd.Parameters.AddWithValue("@in_ffn_id", oFuentesFinanciamientoMO.ffn_id);
            cmd.Parameters.AddWithValue("@in_ffn_nombre", oFuentesFinanciamientoMO.ffn_nombre);
            cmd.Parameters.AddWithValue("@in_ffn_ctapago", oFuentesFinanciamientoMO.ffn_ctapago);

            return Exec_sql.cargarDatosModel<FuentesFinanciamientoBL>(cmd);

        }


        /// <summary>
        /// Método que valida la existencia de una fuente de financiamiento
        /// </summary>
        /// <param name="ffn_id"></param>
        /// <returns></returns>
        public static dynamic ValidarCrearFuenteFinanciamiento(string ffn_id)
        {
            string sql = "SELECT sps_validacion_registro_prfntfin(@in_ffn_id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_ffn_id", ffn_id);

            return Exec_sql.EjecutarQueryDelete(cmd);
        }



        /// <summary>
        /// Elimina una fuente de financiamiento en específico.
        /// </summary>
        /// <param name="ffn_id">Identificador de la fuente de financiamiento a eliminar.</param>
        /// <returns>True si la fuente de financiamiento fue eliminada correctamente; de lo contrario, false.</returns>
        public static dynamic EliminarFuenteFinanciamiento(string id)
        {
            string sql = "SELECT spd_fuente_financiamiento(@in_ffn_id)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_ffn_id", id);

            return Exec_sql.EjecutarQueryDelete(cmd);
        }


        /// <summary>
        /// Método que valida la existencia de una fuente de financiamiento en una partida (previo a eliminar)
        /// </summary>
        /// <param name="ffn_id"></param>
        /// <param name="anio"></param>
        /// <returns></returns>
        public static dynamic ValidarEliminacionFuenteFinanciamiento(string ffn_id, string codemp, int anio)
        {
            /*const int anio = 2024;
            const int itemAsoFFinanciamiento = 91;*/

            string sql = "SELECT sps_validacion_registro_prplacta(@in_codemp, @in_anio, @in_item_aso, @in_valor_nivel)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", codemp);
            cmd.Parameters.AddWithValue("@in_anio", anio);
            cmd.Parameters.AddWithValue("@in_item_aso", Convert.ToInt32(Constantes.General.itemAsoFFinanciamiento));
            cmd.Parameters.AddWithValue("@in_valor_nivel", ffn_id);

            return Exec_sql.EjecutarQueryDelete(cmd);
        }

    }

}