﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Catalogo;
using Congope.Empresas.Models.Genericas;
using iText.Html2pdf.Attach.Wrapelement;
using Npgsql;
using NpgsqlTypes;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Catalogos
{
    public class EstructuraCuentasPartidasBL
    {

        /// <summary>
        /// Funcion que carga el menu del sistema es una funcion recursiva
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        private static List<ArbolEstructuraCuentasPartidasMo> CargarArbolRecursivo(string codigo, int nivel, int identifi , ParamSessionMo paramSession)
        {
            var menu = new List<ArbolEstructuraCuentasPartidasMo>();
            var respuesta = SqlCargarArbol( codigo, nivel, identifi, paramSession);

            if (respuesta.success)
            {
                var objetoMenu = respuesta.result; // Suponiendo que respuesta.result es de tipo List<MenuMO> o MenuMO[]
                foreach (var item in objetoMenu)
                {
                    if (item.Totalhijos > 0)
                    {
                        item.Submenu = CargarArbolRecursivo(item.Cuenta, nivel + 1, identifi, paramSession); // Llamada recursiva para el siguiente nivel
                    }
                    else
                    {
                        item.Submenu = new List<ArbolEstructuraCuentasPartidasMo>(); // Inicializar Submenu si es null
                    }
                    menu.Add(item); // Agregar cada ítem de objetoMenu a la lista menu
                }
            }
            return menu;
        }

        /// <summary>
        /// Funcion que carga los diferentes menus a los que tendra acceso el usuario
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        public static dynamic CargarArbol(Sel_ArbolEstructuraCuentasPartidasMo sel_Arbol)

        {

            var menu = CargarArbolRecursivo(string.Empty, 1, sel_Arbol.identifi, sel_Arbol.sessionMo);

            // En este caso no se devuelve el objeto directamente ya que el lenguaje de programacion evita los subniveles muy profundos, se devuelve un JSON
            string jsonResult = JsonSerializer.Serialize(menu, new JsonSerializerOptions {WriteIndented = true });
    
            return new
            {
                success = true,
                message = "",
                result = jsonResult
            };
        }

        /// <summary>
        /// Consulta Sql que permite obtener los permisos de acceso a los que tiene acceso un usuario
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        protected static dynamic SqlCargarArbol(string codigo, int nivel, int identifi ,  ParamSessionMo paramSession)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.sps_cuentas_partidas
                            (@nivel, @codigo, @codemp, @anio, @sistema, @identifi);;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@nivel", NpgsqlDbType.Integer, nivel);
            cmd.Parameters.AddWithValue("@codigo", NpgsqlDbType.Text, codigo);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, paramSession.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, paramSession.Anio);
            cmd.Parameters.AddWithValue("@sistema", NpgsqlDbType.Integer,paramSession.Sistema);
            cmd.Parameters.AddWithValue("@identifi", NpgsqlDbType.Integer, identifi);

            return Exec_sql.cargarDatosModel<ArbolEstructuraCuentasPartidasMo>(cmd);

        }


        public static dynamic CargarListPartidas(Sel_ArbolEstructuraCuentasPartidasMo sel_Arbol)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.sps_cuentas_partidas_list
                            (@codemp, @anio, @sistema, @identifi);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, sel_Arbol.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, sel_Arbol.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@sistema", NpgsqlDbType.Integer, sel_Arbol.sessionMo.Sistema);
            cmd.Parameters.AddWithValue("@identifi", NpgsqlDbType.Integer, sel_Arbol.identifi);

            return Exec_sql.cargarDatosJson(cmd);

        }


        public static dynamic CargarCoPlactaXcodigo(Sel_EstructuraCuentasXcodigoMo sel_Estructura)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.sps_coplacta_x_codigo
                            (@codemp, @anio, @cuenta);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, sel_Estructura.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, sel_Estructura.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@cuenta", NpgsqlDbType.Varchar, sel_Estructura.cuenta);
           
            return Exec_sql.cargarDatosJson(cmd);

        }


        public static dynamic SelectEstructuraNuevoGenerico(Sel_SelectEstructuraNuevoGenericoMo sel_Estructura)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           select * from public.sps_procesar_cuentas_estructuras
                           (@codemp, @anio, @sistema,@cuenta, @identifi);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, sel_Estructura.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, sel_Estructura.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@cuenta", NpgsqlDbType.Varchar, sel_Estructura.cuenta);
            cmd.Parameters.AddWithValue("@sistema", NpgsqlDbType.Integer, sel_Estructura.sessionMo.Sistema);
            cmd.Parameters.AddWithValue("@identifi", NpgsqlDbType.Integer, sel_Estructura.identifi);
           
            return Exec_sql.cargarDatosJson(cmd);

        }


        public static dynamic Sql_IU_EstructuraPartidaCuentaMo(IU_EstructuraPartidaCuentaMo DetalleMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT * FROM public.spiu_estructura_cuenta_partida
                            (@in_sistema, @in_codemp, @in_anio, @in_cuenta, @in_niv_cue, 
                            @in_identifi, @in_ult_cue, @in_cre_por, @in_nom_cue, @in_cuenta_p);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_sistema", NpgsqlDbType.Integer, DetalleMo.sessionMo.Sistema);
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Text, DetalleMo.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, DetalleMo.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, DetalleMo.cuenta);
            cmd.Parameters.AddWithValue("@in_niv_cue", NpgsqlDbType.Integer, DetalleMo.niv_cue);
            cmd.Parameters.AddWithValue("@in_identifi", NpgsqlDbType.Smallint, DetalleMo.identifi);
            cmd.Parameters.AddWithValue("@in_ult_cue", NpgsqlDbType.Char, DetalleMo.ult_cue);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Varchar, DetalleMo.sessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_nom_cue", NpgsqlDbType.Varchar, DetalleMo.nom_cue);
            cmd.Parameters.AddWithValue("@in_cuenta_p", NpgsqlDbType.Char, DetalleMo.cuenta_p);

            return Exec_sql.cargarDatosJson(cmd);

        }


        public static dynamic IU_EstructuraPartidaCuentaMo(List<IU_EstructuraPartidaCuentaMo> DetalleMo)
        {
            try
            {
                foreach (var compromisoDetalleMo in DetalleMo)
                {
                   
                        dynamic respuesta = Sql_IU_EstructuraPartidaCuentaMo(compromisoDetalleMo);

                        // Verificar si la operación individual fue exitosa
                        if (!respuesta.success)
                        {
                        throw new Exception(respuesta.message);
                    }


                }
                return new
                {
                    success = true,
                    message = "Operaciones completadas exitosamente",
                    result = ""
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }

        }


    }
}
