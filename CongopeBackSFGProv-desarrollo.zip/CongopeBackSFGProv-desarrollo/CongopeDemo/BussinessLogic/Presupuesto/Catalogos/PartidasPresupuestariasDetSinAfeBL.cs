﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Catalogo;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Catalogos
{
    public class PartidasPresupuestariasDetSinAfeBL
    {
        public static dynamic InsertarActualizar_PartidasSinAfeCab(PartidaSinAfeCabMO certificacionSinAf)
        {
            string sql = "";
            string usuario = "";
            DateTime now = DateTime.Now;
            // if (accion == "NUEVO" || accion == "ACTUALIZAR")
            // {
            if (certificacionSinAf.accion == "NUEVO") {
             
                certificacionSinAf.fec_apr = certificacionSinAf.fec_asi;                         
                certificacionSinAf.estado = 0;
            }/*else if (certificacionSinAf.accion == "EDITAR"){
                certificacionSinAf.fec_mod = now.ToString("yyyy-MM-dd");
            }*/
            usuario = certificacionSinAf.VarSesion.codUsu.ToString();
            certificacionSinAf.fec_mod = certificacionSinAf.fec_asi;
            certificacionSinAf.fec_cre = certificacionSinAf.fec_asi;
            sql = "select * from spiu_certificacionsinafe_cab(" +
                "@in_accion,@in_codemp,@in_acutip,@in_anio,@in_des_cab," +
                "@in_valor_total,@in_fec_asi,@in_fec_apr,@in_cre_por,@in_fec_cre," +
                "@in_fec_mod,@in_mod_por,@in_departam,@in_solicita,@in_tipo_doc,@in_estado)";
            // }

            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_accion", certificacionSinAf.accion);
            cmd.Parameters.AddWithValue("@in_codemp", certificacionSinAf.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_acutip", certificacionSinAf.acu_tip);
            cmd.Parameters.AddWithValue("@in_anio", certificacionSinAf.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_des_cab", certificacionSinAf.des_cab);
            cmd.Parameters.AddWithValue("@in_valor_total", certificacionSinAf.valor_total);
            cmd.Parameters.AddWithValue("@in_fec_asi", certificacionSinAf.fec_asi);
            cmd.Parameters.AddWithValue("@in_fec_apr", certificacionSinAf.fec_apr);
            cmd.Parameters.AddWithValue("@in_cre_por", usuario);
            cmd.Parameters.AddWithValue("@in_fec_cre", certificacionSinAf.fec_cre);
            cmd.Parameters.AddWithValue("@in_fec_mod", certificacionSinAf.fec_mod);
            cmd.Parameters.AddWithValue("@in_mod_por", usuario);
            cmd.Parameters.AddWithValue("@in_departam", certificacionSinAf.departam);
            cmd.Parameters.AddWithValue("@in_solicita", string.IsNullOrEmpty(usuario) ? 0 : Convert.ToInt32(usuario));
            cmd.Parameters.AddWithValue("@in_tipo_doc", certificacionSinAf.tipo_doc);
            cmd.Parameters.AddWithValue("@in_estado", certificacionSinAf.estado);
           // return Exec_sql.cargarDatosJson(cmd);
            var response = Exec_sql.cargarDatosJson(cmd);
            //   Console.WriteLine("REspuesta",response);
            if (response.message == "No existen registros")
            {
                string respuesta = "Se ha actualizado el registro exitosamente";
                return new { success = true, message = respuesta, result = new object[0] };
            }
            else
            {
                return response;
            }

        }

        public static dynamic InsertarActualizar_PartidasSinAfeDet(PartidaSinAfeDetMO detallePartida)
        {
            string sql = "";
            // if (accion == "NUEVO" || accion == "ACTUALIZAR")
            // {
            sql = "select * from spiu_certificacionsinafe_det(" +
                "@in_accion,@in_codemp,@in_acutip,@in_anio,@in_partida,@in_valor)";
            // }
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_accion", detallePartida.accion);
            cmd.Parameters.AddWithValue("@in_codemp", detallePartida.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_acutip", detallePartida.acutip);
            cmd.Parameters.AddWithValue("@in_anio", detallePartida.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_partida", detallePartida.partida);// partida.partida);
            cmd.Parameters.AddWithValue("@in_valor", detallePartida.valor);
            return Exec_sql.cargarDatosJson(cmd);
        }
        public static dynamic ListarDetPartidasSinAfe(PartidaSinAfeDetMO partidaDet)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = $@" SELECT * from public.sps_detalle_partidassinaf
                            (@in_codemp, @in_anio, @in_codigo);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", partidaDet.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", partidaDet.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_codigo", partidaDet.acutip);
            var response = Exec_sql.cargarDatosJson(cmd);
          
            return response;
            
        }

    }
}
