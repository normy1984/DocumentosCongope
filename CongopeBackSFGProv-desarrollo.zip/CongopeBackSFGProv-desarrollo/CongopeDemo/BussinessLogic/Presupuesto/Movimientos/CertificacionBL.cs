﻿using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.Win32;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class CertificacionBL
    {

        /// <summary>
        /// Metodo para liquidar certificacion presupuestaria(Moviiento y detalle partida)
        /// </summary>
        /// <param name="pcertificacion">Detallle de partida presupuestaria</param>
        /// <returns>Estructura de certificacion</returns>
        public static dynamic LiquidarCertificacionesPresupuestarias(PartidaPresupuestariaDetMO pcertificacion,string accion)
        {
            ParamSessionMo VarSesion = pcertificacion.VarSesion;
            dynamic movimiento= InsertarActualizarCertificacionesPresupuestariasF(accion, pcertificacion);
            
            var response = PartidasPresupuestariasBL.ListarDetallePartidasCE(pcertificacion.sig_tip + " " + pcertificacion.acu_tip);

            if (response.message == "Success")
            {
                string jsonString = response.result;
                List<PartidaPresupuestariaDetMO> detpartidas = JsonConvert.DeserializeObject<List<PartidaPresupuestariaDetMO>>(jsonString);

                //PartidaPresupuestariaDetMO detpartidas = JsonConvert.DeserializeObject <PartidaPresupuestariaDetMO>(jsonString);
                //List <PartidaPresupuestariaDetMO> detpartidas = response.result;
                foreach (PartidaPresupuestariaDetMO p in detpartidas)
                {
                    p.VarSesion = VarSesion;
                    p.sig_tip = pcertificacion.sig_tip;
                    p.acu_tip = pcertificacion.acu_tip;
                    PartidasPresupuestariasBL.InsertarActualizar_CertificacionPartidasDet
                    (accion, p, movimiento.result[0].out_acu_tip);
                }

            }          
            return movimiento;
            //Analizar si se pue hacer para todos los tipos CE,CO,etc         
        }

        /// <summary>
        /// Servicio que permite validar y aprobar la certificacion
        /// </summary>
        /// <param name="parametros">Parametros de sesión</param>
        /// <param name="sig_tip">Tipo Certificacion</param>
        /// <param name="acu_tip">Numero de Certificacion</param>
        /// <returns></returns>
        public static dynamic AprobarCertificacionesPresupuestarias(ParamSessionMo parametros,string sig_tip,int acu_tip)
        {

             string sql = "select * from spu_aprobar_compromiso(@in_codemp, @in_anio, @in_sigtip, @in_acutip)";

               NpgsqlCommand cmd = new NpgsqlCommand(sql);
               cmd.Parameters.AddWithValue("@in_codemp", parametros.CodEmp);
               cmd.Parameters.AddWithValue("@in_anio", parametros.Anio);
               cmd.Parameters.AddWithValue("@in_sigtip", sig_tip);
               cmd.Parameters.AddWithValue("@in_acutip", acu_tip);

               var response = Exec_sql.cargarDatosJson(cmd); return response;
            return response;
        }

        /// <summary>
        /// Mètodo para desaprobar una certificación
        /// </summary>
        /// <param name="parametros">Parametros de inicio de sesión</param>
        /// <param name="sig_tip">tipo de la Certificación</param>
        /// <param name="acu_tip">Número de la certificación</param>
        /// <returns>Datos de l Cerficaciòn que se desaprobó</returns>
        public static dynamic DesaprobarCertificacionesPresupuestarias(ParamSessionMo parametros, string sig_tip, int acu_tip)
        {

            string sql = "select * from spu_desaprobar_compromiso(@in_codemp, @in_anio, @in_sigtip, @in_acutip)";

            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", parametros.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", parametros.Anio);
            cmd.Parameters.AddWithValue("@in_sigtip", sig_tip);
            cmd.Parameters.AddWithValue("@in_acutip", acu_tip);

            var response = Exec_sql.cargarDatosJson(cmd); return response;
            return response;
        }
        public static dynamic InsertarActualizarCertificacionesPresupuestariasF(string accion,PartidaPresupuestariaDetMO pcertificacion)
        {
            //CambiarContrasenaMo el nombre del sp xq se esta insertando una certificacion, es parte del proceso de liquidacion
            string sql = @"select * from spiu_movimientos_certificado
                           (
                            @in_accion,
                            @in_codemp,
                            @in_sigtip,
                            @in_acutip,
                            @in_anio,
                            @in_user
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_accion", accion);
            cmd.Parameters.AddWithValue("@in_codemp", pcertificacion.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_sigtip", pcertificacion.sig_tip);
            cmd.Parameters.AddWithValue("@in_acutip", Convert.ToInt32(pcertificacion.acu_tip));
            cmd.Parameters.AddWithValue("@in_anio", pcertificacion.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_user", pcertificacion.VarSesion.codUsu.ToString());
         
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<CertificacionesPresupuestariasMO>(cmd);
        }

        /// <summary>
        /// Mètodo para listar los compromisos asociados a una certificación
        /// </summary>
        /// <param name="codemp">Codigo Empresa</param>
        /// <param name="sigtip">Tipo de Certificación</param>
        /// <param name="acutip">Número de Certificación</param>
        /// <param name="anio">Anio de Certificación</param>
        /// <returns>Lista de compromisos</returns>
        public static dynamic ListarCertificadosConCompromisos(string codemp, string sigtip, int acutip, int anio)
        {

            string sql = "select * from sps_certificados_compromisos(@in_codemp,@in_sigtip,@in_acutip,@in_anio) ";
              
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", codemp);
            cmd.Parameters.AddWithValue("@in_sigtip", sigtip);
            cmd.Parameters.AddWithValue("@in_acutip", acutip);
            cmd.Parameters.AddWithValue("@in_anio", anio);

            var response = Exec_sql.cargarDatosJson(cmd);

            if (response.message == "Error: No existen registros")
            {
                string respuesta = "";
                return new { success = true, message = respuesta, result = "" };
            }
            else
                return response;
        }

        /// <summary>
        /// Mètodo para listar las acciones de los botones de acuerdo al estado
        /// </summary>
        /// <param name="codemp">Código Empresa</param>
        /// <param name="sigtip">Còdigo de la certificación</param>
        /// <param name="acutip">Número de Certificación</param>
        /// <param name="anio">Año</param>
        /// <returns>Definición de acción de los botones</returns>
        public static dynamic ListarAccionesBotonesPorEstado(string codemp, string sigtip, int acutip, int anio)
        {

            string sql = "select * from sps_accion_botones(@in_codemp,@in_anio,@in_sigtip,@in_acutip) ";
      
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", codemp);
            cmd.Parameters.AddWithValue("@in_sigtip", sigtip);
            cmd.Parameters.AddWithValue("@in_acutip", acutip);
            cmd.Parameters.AddWithValue("@in_anio", anio);

            var response = Exec_sql.cargarDatosJson(cmd);
        
            return response;
        }

        public static dynamic QuitarAsociacion(ParamSessionMo parametros, string sigtip, int acutip)
        {

            string sql = "select * from spu_quitar_asociacion(@in_codemp,@in_sigtip,@in_acutip,@in_anio,@in_user) ";

            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", parametros.CodEmp);
            cmd.Parameters.AddWithValue("@in_sigtip", sigtip);
            cmd.Parameters.AddWithValue("@in_acutip", acutip);
            cmd.Parameters.AddWithValue("@in_anio", parametros.Anio);
            cmd.Parameters.AddWithValue("@in_user", parametros.codUsu);

            var response = Exec_sql.cargarDatosJson(cmd);

            return response;
        }

    }
}
