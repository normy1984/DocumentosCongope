﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;
using System.Globalization;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class MovimientosPresupuestariosBL
    {
        /// <summary>
        /// Método para ver la lista de movimientos presupuestarios, certificaciones
        /// </summary>
        /// <param name="tipo">Tipo de Movimiento presupuestario</param>
        /// <param name="anio">Anio de consulta</param>
        /// <returns>Certificaciones Presupuestarias</returns>
        public static dynamic ListarMovimientosPresupuestarios(string tipo, int anio)
        {
            string sql = "select * from sps_movimientos_presupuestarios(@in_codemp,@in_anio,@in_codigo)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, anio);
            cmd.Parameters.AddWithValue("@in_codigo", NpgsqlDbType.Varchar, tipo.ToUpper());
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
        }
      

        //public static dynamic ObtenerSecuencialMovimientosPresupuestarios(string empresa, int anio, string tipo)
        //{        
        //    string sql = "select * from sps_movimientos_presupuestarios_max('" + Constantes.General.Empresa + "'," + Constantes.General.anio + ",'" + tipo + "')";
        //    NpgsqlCommand cmd = new NpgsqlCommand();
        //    cmd.CommandText = sql;
        //    return Exec_sql.cargarDatosJson(cmd);
        //}

        public static dynamic ListarDetalleMovimientoPresupuestarioCodigoCE(string in_acu_tip)
        {
            /*
             * string[] array = in_acu_tip.Split(' ');
            string sql = "select * from sps_movimientos_presupuestarios_codigo(@in_codemp,@anio,@in_codigo,@acu_tip)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_codigo", Convert.ToString(array[0].ToUpper()));     
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
             */
            string[] array = in_acu_tip.Split(' ');
            string sql = "select * from sps_movimientos_presupuestarios_detalle(@in_codemp,@anio,@in_codigo,@acu_tip)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_codigo", Convert.ToString(array[0].ToUpper()));     
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);

        }
        /// <summary>
        /// Ver Mov presupuestario por codigo
        /// </summary>
        /// <param name="in_acu_tip">codigo de Mov presupuestario</param>
        /// <returns></returns>
        public static dynamic ListarMovimientoPresupuestariosCodigo(MovimientosPresupuestariosCaebeceraMO in_acu_tip)
        {
            string[] array = in_acu_tip.siglas_num.Split(' ');
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = @"
                       select 
                        p.num_com,
                        p.des_cab,
                        p.solicita,
                        p.departam,
                        p.fec_asi,
                        p.fec_apr,
                        CONCAT(p.sig_tip,' ',p.acu_tip) as siglasnum,
                        (select t.descrip from tablas t where t.codtab = 2 and t.codigo = p.estado) as estado_desc,
                        p.acu_tip1 as anulado_siglasnum,
                        (select pa.acu_tip  from prcabmov pa where p.sig_tip = 'CO' and pa.anio = p.anio and p.codemp = pa.codemp and pa.sig_tip1 = p.sig_tip and pa.acu_tip1 = p.acu_tip) as anula_siglas_num,
                        (select trim(t.descrip) from tablas t where t.codtab = 54 and t.codigo = p.solicita) as solicita_desc,
                        (select trim(t.descrip) from tablas t where t.codtab = 19 and t.codigo = p.departam) as departam_desc,
                        p.valor_contrato,
                        trim(p.cod_proceso) as cod_proceso,
                        p.sig_tipce,
                        p.acu_tipce,
                        p.anio,
                        (select trim(t.descrip) from public.usuarios t where t.cod_usu = p.cre_por :: integer) as creado_por,
                        (select trim(t.descrip) from public.usuarios t where t.cod_usu = p.mod_por :: integer) as modificado_por,
                        p.estado
                        from prcabmov p 
                        where 
                        p.sig_tip = @sig_tip
                        and p.anio = @anio
                        and acu_tip = @acu_tip;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@sig_tip", Convert.ToString(array[0].ToUpper()));
            cmd.Parameters.AddWithValue("@anio", in_acu_tip.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));
            cmd.Parameters.AddWithValue("@cod_emp", in_acu_tip.VarSesion.CodEmp);

            return Exec_sql.cargarDatosJson(cmd);

        }

        public static dynamic ListarMovimientoPresupuestariosCodigoCE(string in_acu_tip, int anio)
        {
            string[] array = in_acu_tip.Split(' ');
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from public.sps_movimientos_ce(@in_acu_tip,@in_anio)";
             /*   @"
                       select 
                        p.num_com,
                        p.des_cab,
                        p.solicita,
                        p.departam,
                        p.fec_asi,
                        p.fec_apr,
                        CONCAT(p.sig_tip,' ',p.acu_tip) as siglasnum,
                        (select t.descrip from tablas t where t.codtab = 2 and t.codigo = p.estado) as estado_desc,
                        p.acu_tip1 as anulado_siglasnum,
  
                        (select trim(t.descrip) from tablas t where t.codtab = 54 and t.codigo = p.solicita) as solicita_desc,
                        (select trim(t.descrip) from tablas t where t.codtab = 19 and t.codigo = p.departam) as departam_desc,
                        p.valor_contrato,
                        trim(p.cod_proceso) as cod_proceso,
                        p.sig_tipce,
                        p.acu_tipce,
                        p.anio,
                        (select trim(t.descrip) from public.usuarios t where t.cod_usu = p.cre_por :: integer) as creado_por,
                        CASE
                            WHEN p.mod_por ='' then
                            (select trim(t.descrip) from public.usuarios t where t.cod_usu = p.cre_por :: integer)
                            ELSE 
                            (select trim(t.descrip) from public.usuarios t where t.cod_usu = p.mod_por :: integer)
                        END as modificado_por,
                        p.estado
                        from prcabmov p 
                        where 
                        p.sig_tip = @sig_tip
                        and p.anio = @anio
                        and acu_tip = @acu_tip;";*/
             cmd.CommandText = sql;
          //  cmd.Parameters.AddWithValue("@sig_tip", Convert.ToString(array[0].ToUpper()));
          //  cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", Int32.Parse(array[1]));
            cmd.Parameters.AddWithValue("@in_anio", anio);

            return Exec_sql.cargarDatosJson(cmd);

        }



        /// <summary>
        /// Ver Detalle presupuestario por codigo
        /// </summary>
        /// <param name="in_acu_tip">codigo de Mov presupuestario</param>
        /// <returns></returns>
        public static dynamic ListarDetalleMovimientoPresupuestariosCodigo(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = @"
                SELECT
                TRIM(p.cuenta) as cuenta,
                (select nom_cue from prplacta p2 where p2.cuenta = p.cuenta and p2.anio = p.anio) as nom_cue,
                p.val_cre,
                p.val_deb,
                (p.val_cre - p.val_deb) as val_sal
                from prdetmov p
                where p.sig_tip = @sig_tip
                and P.anio = @anio
                and acu_tip = @acu_tip;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@sig_tip", Convert.ToString(array[0].ToUpper()));
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }


        /// <summary>
        /// Ver Detalle presupuestario por codigo
        /// </summary>
        /// <param name="in_acu_tip">codigo de Mov presupuestario</param>
        /// <returns></returns>
        public static dynamic ListarDetalleCompromisoPresupuestariosCodigo(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = @"
               SELECT
                TRIM(p.cuenta) as cuenta,
                (select concat('CE ',p3.acu_tip)  from prcercom p3 where p3.partida = p.cuenta and p3.anio = p.anio and p3.acu_tip_co = p.acu_tip AND p3.sec_det = p.sec_det) as certificacion,
                (select nom_cue from prplacta p2 where p2.cuenta = p.cuenta and p2.anio = p.anio) as nom_cue,
                p.val_cre,
                p.val_deb,
                (p.val_cre - p.val_deb) as val_sal,
                p.asociac,
                p.estado,
                p.periodo,
                p.sec_det,
                (select 
                (select val_cert from prdetmov pr where pr.codemp = p3.codemp and pr.anio = p3.anio and pr.sig_tip = 'CE' and pr.acu_tip = p3.acu_tip and pr.cuenta = p3.partida) 
                from prcercom p3 where p3.partida = p.cuenta and p3.anio = p.anio and p3.acu_tip_co = p.acu_tip AND p3.sec_det = p.sec_det) as valor_maximo
                from prdetmov p 
                where p.sig_tip = @sig_tip
                and P.anio = @anio
                and acu_tip = @acu_tip;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@sig_tip", Convert.ToString(array[0].ToUpper()));
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion utilizada para insertar o actualizar la informacion de un movimiento presupuestario
        /// </summary>
        /// <param name="accion">Accion que realizarà el procedimiento: Insertar, Actualizar</param>
        /// <param name="oMovimientosPresupuestariosMO"></param>
        /// <returns>Resultado de la accion Insertar, Actualizar</returns>
        public static dynamic InsertarActualizar_MovimientosPresupuestarios(string accion,
            MovimientosPresupuestariosMO oMovimientosPresupuestariosMO)
        {
            string sig_tip = Constantes.TipoMovimiento.Certificacion;
            int acu_tip = 0;
            int acu_tip1 = 0;
            int estado = 2;

           if( oMovimientosPresupuestariosMO.codigo_est!=0)              
                estado = oMovimientosPresupuestariosMO.codigo_est;
            

            if (oMovimientosPresupuestariosMO.siglasnum != "")
            {
                string[] array = oMovimientosPresupuestariosMO.siglasnum.Split(' ');
                acu_tip = Convert.ToInt32(array[1]);
            }

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_movimientos_presupuestarios      
                             (
                                 @in_accion,
                                 @in_codemp,
                                 @in_anio,
                                 @in_sig_tip,
                                 @in_cre_por,
                                 @in_estado,                               
                                 @in_num_com,
                                 @in_departam,
                                 @in_responsable,
                                 @in_fec_apr, 
                                 @in_fec_asi,
                                 @in_acu_tip,
                                 @in_des_cab,
                                 @in_cod_proceso,
                                 @in_mod_por,
                                 @in_tot_cre,
                                @in_valor_contrato,
                                @in_acu_tip1)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_accion", accion);
            cmd.Parameters.AddWithValue("@in_codemp", oMovimientosPresupuestariosMO.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", oMovimientosPresupuestariosMO.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_sig_tip", sig_tip);
            cmd.Parameters.AddWithValue("@in_cre_por", oMovimientosPresupuestariosMO.VarSesion.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_estado", estado);
            cmd.Parameters.AddWithValue("@in_num_com", oMovimientosPresupuestariosMO.num_com.Trim());
            cmd.Parameters.AddWithValue("@in_departam", oMovimientosPresupuestariosMO.departam);
            cmd.Parameters.AddWithValue("@in_responsable", oMovimientosPresupuestariosMO.solicita);
            cmd.Parameters.AddWithValue("@in_fec_apr", oMovimientosPresupuestariosMO.fec_apr.Substring(0, 10));
            cmd.Parameters.AddWithValue("@in_fec_asi", oMovimientosPresupuestariosMO.fec_asi.Substring(0, 10));
            cmd.Parameters.AddWithValue("@in_acu_tip", acu_tip);
            cmd.Parameters.AddWithValue("@in_des_cab", oMovimientosPresupuestariosMO.des_cab);
            cmd.Parameters.AddWithValue("@in_cod_proceso", oMovimientosPresupuestariosMO.cod_proceso);
            cmd.Parameters.AddWithValue("@in_mod_por", oMovimientosPresupuestariosMO.VarSesion.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_tot_cre", oMovimientosPresupuestariosMO.tot_cre);
            cmd.Parameters.AddWithValue("@in_valor_contrato", oMovimientosPresupuestariosMO.valor_contrato);
            cmd.Parameters.AddWithValue("@in_acu_tip1", acu_tip1);

            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
        }
   

        /// <summary>
        /// Funcion utilizada para insertar o actualizar la informacion de un movimiento presupuestario
        /// </summary>
        /// <param name="sTipoAccion"></param>
        /// <param name="otipoComprobanteMO"></param>
        /// <returns></returns>
        public static dynamic Anular_CertificacionPresupuestaria(string accion, MovimientosPresupuestariosMO oMovimientosPresupuestariosMO)
        {
            string[] variablesGenerales = oMovimientosPresupuestariosMO.descrip.Split('|');
            int acu_tip = 0;
            int estado = oMovimientosPresupuestariosMO.codigo_est;
            String sig_tip = "";

            if (accion == "ANULAR")
                estado = 2;



            if (oMovimientosPresupuestariosMO.siglasnum != "")
            {
                string[] array = oMovimientosPresupuestariosMO.siglasnum.Split(' ');
                sig_tip = array[0];
                acu_tip = Convert.ToInt32(array[1]);
            }

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_anular_certificacion         
                             (
                                 @in_accion,
                                 @in_codemp,
                                 @in_anio,
                                 @in_sig_tip,
                                 @in_cre_por,
                                 @in_estado,                               
                                 @in_num_com,
                                 @in_departam,
                                 @in_responsable,
                                 @in_fec_apr, 
                                 @in_fec_asi,
                                 @in_acu_tip,
                                 @in_des_cab,
                                 @in_cod_proceso,
                                 @in_mod_por,
                                 @in_tot_cre,
                                @in_valor_contrato
                                )";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_accion", accion);
            cmd.Parameters.AddWithValue("@in_codemp", variablesGenerales[0]);
            cmd.Parameters.AddWithValue("@in_anio", Convert.ToInt32(variablesGenerales[1]));
            cmd.Parameters.AddWithValue("@in_sig_tip", sig_tip);
            cmd.Parameters.AddWithValue("@in_cre_por", variablesGenerales[2]);
            cmd.Parameters.AddWithValue("@in_estado",estado);
            cmd.Parameters.AddWithValue("@in_num_com", oMovimientosPresupuestariosMO.num_com.Trim());
            cmd.Parameters.AddWithValue("@in_departam", oMovimientosPresupuestariosMO.departam);
            cmd.Parameters.AddWithValue("@in_responsable", oMovimientosPresupuestariosMO.solicita);
            cmd.Parameters.AddWithValue("@in_fec_apr", oMovimientosPresupuestariosMO.fec_apr.Substring(0, 10));
            cmd.Parameters.AddWithValue("@in_fec_asi", oMovimientosPresupuestariosMO.fec_asi.Substring(0, 10));
            cmd.Parameters.AddWithValue("@in_acu_tip", acu_tip);
            cmd.Parameters.AddWithValue("@in_des_cab", oMovimientosPresupuestariosMO.des_cab);
            cmd.Parameters.AddWithValue("@in_cod_proceso", oMovimientosPresupuestariosMO.cod_proceso);
            cmd.Parameters.AddWithValue("@in_mod_por", variablesGenerales[2]);
            cmd.Parameters.AddWithValue("@in_tot_cre", oMovimientosPresupuestariosMO.tot_cre);
            cmd.Parameters.AddWithValue("@in_valor_contrato", oMovimientosPresupuestariosMO.valor_contrato);


            Console.WriteLine(cmd);

            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
        }

       
    }
}
