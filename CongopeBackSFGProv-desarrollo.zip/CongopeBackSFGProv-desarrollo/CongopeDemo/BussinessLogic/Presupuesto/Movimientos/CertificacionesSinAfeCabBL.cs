﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class CertificacionesSinAfeCabBL
    {
        public static dynamic ListarCertificacionesSinAfeCab(CertificacionesSinAfeCabMO tipo)
        {
            string sql = "select * from sps_certificacionessinafe(@in_codemp,@in_anio,@in_acutip)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acutip", NpgsqlDbType.Integer, tipo.acutip);
            return Exec_sql.cargarDatosJson(cmd);

        }

        public static dynamic BuscarCertificacionSinAfeCabCod(CertificacionesSinAfeCabMO tipo)
        {
            string sql = "select * from sps_certificacionsinafecod(@in_codemp,@in_anio,@in_acutip)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acutip", NpgsqlDbType.Integer, tipo.acutip);
            return Exec_sql.cargarDatosJson(cmd);

        }
    }
}
