﻿using Congope.Empresas.Data;
using Congope.Empresas.Extensiones;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Bpm;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Reportes;
using Congope.Empresas.Reportes;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json;

namespace Congope.Empresas.BussinessLogic.Bpm
{
    public class BpmBl
    {
        private readonly CamundaBpm _camunda;
        private readonly DocumentoBpmBL _repo;
        private readonly IHubContext<NotificacionesHub> _hubContext;
        // Constructor
        public BpmBl(AppDbContext context,
            IHubContext<NotificacionesHub> hubContext)
        {
            _camunda = new CamundaBpm();
            _repo = new DocumentoBpmBL(hubContext,context);
            _hubContext = hubContext;
        }

        // Ejemplo de insertar documento al iniciar flujo
        public async Task<string> IniciarFlujoYGuardarDocumento(dynamic datosInicio)
        {
            try
            {
                var datosUsuario = JsonConvert.DeserializeObject<dynamic>(datosInicio.ToString());


                // Mapeamos la información de firma a un modelo específico para un manejo más estructurado.
                VariablesPdfMO VariablesDocumento = JsonConvert.DeserializeObject<VariablesPdfMO>(datosUsuario.DatosPdf.ToString());
                BpmMo VariablesInicio = JsonConvert.DeserializeObject<BpmMo>(datosUsuario.VariablesInicio.ToString());



                // Mapeamos la información recibida a la estructura de documento.

                var processJson = await IniciarFlujo(VariablesInicio);

                // Obtener processInstanceId del JSON devuelto por Camunda
                var processObj = JsonConvert.DeserializeObject<dynamic>(processJson);
                string processInstanceId = processObj.id;

                var doc = new DocumentoBpmMo
                {
                    DocumentoId = VariablesInicio.IdDocumento,
                    ProcessInstanceId = processInstanceId,
                    Estado = "Iniciado",
                    FechaInicio = DateTime.UtcNow,
                    Anio = VariablesDocumento.VarSesion.Anio
                };

                await _repo.InsertarDocumentoAsync(doc);

                FIRMA_RPT207_COMPROMISOS.CargarReporte(VariablesDocumento);


                var payload = new { 
                    ProcessId = $"{processInstanceId}",
                    Documento = VariablesInicio.IdDocumento,
                };
                await _hubContext.Clients.All.SendAsync("DocumentoFirmado", ApiResultMo<object>.Ok(payload));

                return processInstanceId;
            }
            catch (Exception ex) { 
            Console.WriteLine(ex.ToString());
                return "no";
            }

        }

        // 1️⃣ Iniciar flujo
        public async Task<string> IniciarFlujo(BpmMo dto)
        {
            var variables = new
            {
                Analista = new { value = dto.Creador, type = "String" },
                Director = new { value = dto.AprobadorN1, type = "String" },
                Coordinador = new { value = dto.AprobadorN2, type = "String" },
                DocumentoId = new { value = dto.IdDocumento, type = "String" } // relacionar documento
            };
            return await _camunda.StartProcessAsync("Proceso_Certificacion", variables);
        }

        // 2️⃣ Completar tarea enviando variable 'aprobado'
        public async Task CompleteTaskAsync(string taskId, string processInstanceId, bool aprobado)
        {
            var variables = new
            {
                aprobado = new { value = aprobado, type = "Boolean" }
            };

            // ✅ Completar la tarea en Camunda
            await _camunda.CompleteTaskAsync(taskId, variables);

            // ✅ Buscar tareas activas después de completar
            var tasks = await GetTasksByDocumentoAsync(processInstanceId);
            var tareaActual = tasks?.FirstOrDefault();

            // ✅ Determinar estado del documento
            var doc = new DocumentoBpmMo
            {
                ProcessInstanceId = processInstanceId,
                Estado = tareaActual?.TaskDefinitionKey ?? "Finalizado",
                FechaFin = DateTime.UtcNow
            };

            await _repo.ActualizarDocumentoAsync(doc);

            // ✅ Notificar a todos por SignalR
          

         
        }


        // 3️⃣ Obtener tareas de un usuario
        public async Task<IEnumerable<TareaBpmMo>> GetTasksByUserAsync(string assignee)
        {
            var response = await _camunda.GetTasksAsync(new
            {
                processDefinitionKey = "Proceso_Certificacion",
                assignee = assignee
            });

            return JsonConvert.DeserializeObject<IEnumerable<TareaBpmMo>>(response);
        }

        // 4️⃣ Obtener tareas activas de un documento (usando processInstanceId)
        public async Task<IEnumerable<TareaBpmMo>> GetTasksByDocumentoAsync(string processInstanceId)
        {
            var response = await _camunda.GetActiveTasksByProcessAsync(processInstanceId);

            return JsonConvert.DeserializeObject<IEnumerable<TareaBpmMo>>(response);
        }

        // 5️⃣ Obtener detalle de una tarea
        public async Task<TareaBpmMo?> GetTaskDetailAsync(string taskId)
        {
            var response = await _camunda.GetTaskDetailAsync(taskId);

            return JsonConvert.DeserializeObject<TareaBpmMo>(response);
        }

        // 6️⃣ Obtener historial de un documento (recorrido del proceso)
        public async Task<IEnumerable<HistorialBpmMo>> GetHistorialByDocumentoAsync(string processInstanceId)
        {
            var response = await _camunda.GetHistoryAsync(processInstanceId);

            return JsonConvert.DeserializeObject<IEnumerable<HistorialBpmMo>>(response);
        }

        // 7️⃣ Obtener variables del proceso (ej: DocumentoId, aprobado, etc.)
        public async Task<Dictionary<string, object>> GetVariablesByDocumentoAsync(string processInstanceId)
        {
            var response = await _camunda.GetProcessVariablesAsync(processInstanceId);

            return JsonConvert.DeserializeObject<Dictionary<string, object>>(response);
        }

        // 8️⃣ (Azúcar) Estado resumido de un documento
        public async Task<EstadoDocumentoMo> GetEstadoDocumentoAsync(string processInstanceId)
        {
            // Consultar la tarea activa
            var tareas = await GetTasksByDocumentoAsync(processInstanceId);
            var tareaActual = tareas?.FirstOrDefault();

            return new EstadoDocumentoMo
            {
                Proceso = "Proceso_Certificacion",
                TareaActual = tareaActual?.Name,
                UsuarioAsignado = tareaActual?.Assignee
            };
        }

        // 9️⃣ Anular/Cancelar un proceso de un documento
        public async Task AnularDocumentoAsync(string processInstanceId, string razon = "Documento anulado por usuario")
        {
            await _camunda.CancelProcessAsync(processInstanceId, razon);
        }
    }
}
