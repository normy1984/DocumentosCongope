﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Extensiones;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Bpm;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using MongoDB.Bson;
using Org.BouncyCastle.Asn1.Ocsp;

public class DocumentoBpmBL
{
    private readonly AppDbContext _context;
    private readonly IHubContext<NotificacionesHub> _hubContext;


    public DocumentoBpmBL(
       IHubContext<NotificacionesHub> hubContext,
        AppDbContext context)
    {
        _context = context;
        _hubContext = hubContext;
    }

    // Inserta un documento nuevo
    public async Task InsertarDocumentoAsync(DocumentoBpmMo doc)
    {
        _context.documentoproceso.Add(doc);
        await _context.SaveChangesAsync();
    }

    // Actualiza un documento existente según DocumentoId y ProcessInstanceId
    public async Task ActualizarDocumentoAsync(DocumentoBpmMo doc)
    {
        var existing = await _context.documentoproceso
            .FirstOrDefaultAsync(d => d.ProcessInstanceId == doc.ProcessInstanceId);

        if (existing != null)
        {
            existing.Estado = doc.Estado;
            existing.FechaFin = doc.FechaFin;
            await _context.SaveChangesAsync();

            var payload = new
            {
                ProcessId = $"{doc.ProcessInstanceId}",
                Documento = existing.DocumentoId
            };
            await _hubContext.Clients.All.SendAsync("DocumentoFirmado", ApiResultMo<object>.Ok(payload));

            if (doc.Estado == "Finalizado")
            {
                await GenerarDocumentoFinalAsync(existing.DocumentoId, existing.Anio ?? DateTime.Now.Year);
            }
        }
        else
        {
            throw new Exception("Documento no encontrado para actualizar");
        }
    }


    // Obtener un documento por su ID
    public async Task<DocumentoBpmMo?> ObtenerDocumentoPorIdAsync(string documentoId, int Anio)
    {
        return await _context.documentoproceso
            .FirstOrDefaultAsync(d => d.DocumentoId == documentoId
            && d.Estado != "Finalizado"
            && d.Anio == Anio);
    }


    // Actualizar estado de un documento
    public async Task ActualizarEstadoAsync(string documentoId, string nuevoEstado, int Anio, DateTime? fechaFin = null)
    {
        var doc = await ObtenerDocumentoPorIdAsync(documentoId, Anio);
        if (doc == null) return;

        doc.Estado = nuevoEstado;
        if (fechaFin.HasValue)
            doc.FechaFin = fechaFin;

        _context.documentoproceso.Update(doc);
        await _context.SaveChangesAsync();
    }

    // Listar todos los documentos
    public async Task<List<DocumentoBpmMo>> ListarDocumentosAsync()
    {
        return await _context.documentoproceso.ToListAsync();
    }

    // FUNCION PARA GUARDAR LOS DOCUMENTOS UNA VEZ QUE YA ESTEN FIRMADOS
    public async Task GenerarDocumentoFinalAsync(string documentoId, int Anio, int codSistema = 2)
    {
        var filtro1 = new Dictionary<string, object>
    {
        { "Referencia", documentoId },
        { "Anio", Anio },
        { "Nombre", $"{documentoId}_{Anio}" } // Nombre único del documento.
    };

        // Consultamos MongoDB para obtener los documentos a firmar usando el filtro proporcionado.
        var registros = Exec_sql.ObtenerDatosMongo("Firmas_Electronicas", filtro1, "NumeroFirmas");
        var documento_0 = registros.result[0];
        BsonDocument bsonDocument_0 = BsonDocument.Parse(documento_0.ToString());
        BsonBinaryData binData = bsonDocument_0["FileBase64"].AsBsonBinaryData;

        // Para convertirlo nuevamente a byte[]
        byte[] fileBytes = binData.Bytes;

        // Diccionario para mapear los valores de codsistema con las colecciones
        var collectionMap = new Dictionary<int, string>
    {
        { 1, "Contabilidad" },
        { 2, "Presupuesto" },
        { 3, "Inventarios" },
        { 4, "Nomina" },
        { 5, "ActivosFijos" }
    };

        // Asignar la colección usando el codsistema, o un valor predeterminado si no existe
        var Collection = collectionMap.ContainsKey(codSistema) ? collectionMap[codSistema] : "";
        var uploadsFolder = Path.Combine(Conexion.RutaDocumentos, Collection);
        var NombreArchivo = $"{documentoId}_{Anio}.pdf";

        if (Conexion.GuardaArchivosRepositorio)
        {
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var filePath = Path.Combine(uploadsFolder, NombreArchivo);

            // ✅ Guardar archivo con WriteAllBytesAsync
            await File.WriteAllBytesAsync(filePath, fileBytes);
        }
        else
        {
            SharepointBL.CargarSharepoint(fileBytes, NombreArchivo, uploadsFolder);
        }
    }

}
