﻿namespace Congope.Empresas.Models
{
    public class ApiResultMo<TResult>
    {
        public bool success { get; set; }
        public string message { get; set; }
        public TResult result { get; set; }

        // Constructor sin parámetros
        public ApiResultMo()
        {
            success = false;
            message = string.Empty;
            result = default(TResult);
        }

        public ApiResultMo(bool _success, String _message, TResult _result)
        {
            success = _success;
            message = _message;
            result = _result;
        }

        public static ApiResultMo<TResult> Ok(TResult result, string message = "Operación exitosa.") =>
            new ApiResultMo<TResult>(true, message, result);

        public static ApiResultMo<TResult> Fail(string message) =>
            new ApiResultMo<TResult>(false, message, default);


    }
}
