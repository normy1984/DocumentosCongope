using System;

namespace Congope.Empresas.Models.Parametrizacion
{
    public class ParametrosGeneralesMO
    {
        public int codigo { get; set; }
        public string descrip { get; set; }
        public int activo { get; set; }
        public string dato_adi { get; set; }
    }
}
