﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Parametrizacion
{
    public class Sel_EstructuraPartidaMo
    {
        public int identifi { get; set; }
        public ParamSessionMo sessionMo { get; set; }
    }
        public class Actualizar_EstructuraPartidaMo
        {
        public int niv_est { get; set; }
        public int identifi { get; set; }
        public string des_est { get; set; }
        public int lon_est { get; set; }
        public string cre_por { get; set; }
        public int con_est { get; set; }
        public int item_aso { get; set; }
        public int foce { get; set; }
        public int orienta_gas { get; set; }
        public int niv_ug { get; set; }
        public int niv_proy { get; set; }
        public int Estado { get; set; }            // Estado
        public ParamSessionMo paramSessionMo { get; set; }
        }

    public class Sel_Validacion
    {
        public Boolean Validacion { get; set; }
        
    }

}
