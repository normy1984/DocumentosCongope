﻿namespace Congope.Empresas.Models
{
    public class CuentasContableMO
    {
       
        public string cuenta { get; set; }
        public string nom_cue { get; set; }
        public double valtotal { get; set; }
        
    }

    

    public class InformacionCuentasMO {
    //    public string des_est { get; set; }
        public string niv_est { get; set; }
        public string descripcion { get; set; }
        public string niv_digitos { get; set; }
    //    public string seleccion { get; set; }
        public string nombre_cuenta{ get; set; }
    }
}
