﻿namespace Congope.Empresas.Models.Genericas
{
    public class FirmaEcRecibeDocumentoMo
    {
        public string NombreDocumento { get; set; }
        public string Archivo { get; set; } // Base64 del archivo
    }

    public class FirmaEcCargarArchivoMo
    {
        public string Cedula { get; set; }
        public string NombreArchivo { get; set; }

    }

    public class PosicionesFirmaMo
    {
        public int PosicionX { get; set; }
        public int PosicionY { get; set; }

    }
}
