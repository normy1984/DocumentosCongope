﻿namespace Congope.Empresas.Models.Genericas
{
    public class LoginMo
    {
        public int CodigoUsu { get; set; }
        public string login { get; set; }
        public string contrasena { get; set; }
        public string llave { get; set; }
        public string contrasena_nv { get; set; }
        public string llave_nv { get; set; }
        public string NombresCompletos { get; set; }
        public string correo { get; set; }
        public string CodigoSistema { get; set; }
        public string NombreSistema { get; set; }
        public int CodigoAnio { get; set; }
        public string Codemp { get; set; }
        public int EsAdmin { get ;set; }
        public bool usuarioConsulta { get; set; }
        public string ced_funcionario { get; set; }

    }

    public class CredencialesLogo {
        public string login { get; set; }
        public string contrasena { get; set; }
    }


    public class CambiarContrasenaMo
    {
        public int CodUsu { get; set; }
        public string contrasenaAnterior { get; set; }
        public string contrasenaNueva { get; set; }
    }

    public class TokenRequest
    {
        public string token { get; set; }
    }


    public class IdUsuario
    {
        public required string ciRuc { get; set; }
    }
}
