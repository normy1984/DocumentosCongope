﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Congope.Empresas.Models.Genericas
{
    public class TimbradaDto
    {
        public DateTime Fecha { get; set; }
        public TimeSpan? Entrada { get; set; }
        public TimeSpan? Salida { get; set; }
    }

    [Table("attlog", Schema = "timbradas")]
    public class Attlog
    {
        [Column("pin")]
        public int Pin { get; set; }

        [Column("atttime")]
        public DateTime Atttime { get; set; }
    }

    [Table("userinfo", Schema = "timbradas")]
    public class Userinfo
    {

        [Key] // <-- Esto indica la PK
        [Column("badgenumber")]
        public string? Badgenumber { get; set; }


        [Column("ssn")]
        public string? Ssn { get; set; }
    }
}
