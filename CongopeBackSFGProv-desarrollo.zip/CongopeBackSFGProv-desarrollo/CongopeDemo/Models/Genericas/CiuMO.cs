﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class CiuMO
    {
        public float codtab { get; set; }
        public string grupo { get; set; }
        public string cedruc { get; set; }
        public string descrip { get; set; }
        public string direcci { get; set; }
        public string telefon1 { get; set; }
        public string email1 { get; set; }
        public float ciudad { get; set; }
        public string nombre_ciudad { get; set; }
        public float titulo { get; set; }
        public string nombre_titulo { get; set; }
        public float rucoced { get; set; }
        public float contribespe { get; set; }
        public string banco { get; set; }
        public string nombre_banco { get; set; }
        public string nrocta { get; set; }
        public float tipocta { get; set; }
        public string nombre_tipocta { get; set; }
        public string numero_iden { get; set; }
        public string nombre_iden { get; set; }
        public string fechanac { get; set; }
        public float discapacidad { get; set; }
        public float porcen_disca { get; set; }
        public string contesp_nrores { get; set; }
        public float obligado_conta { get; set; }
        public string serie { get; set; }

    }
}
