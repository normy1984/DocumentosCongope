﻿using Newtonsoft.Json;

namespace Congope.Empresas.Models.Genericas
{
    // Clases para deserializar la respuesta
    public class GraphSearchResponse
    {
        [JsonProperty("value")]
        public List<SearchResultItem> Value { get; set; }
    }

    public class SearchResultItem
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("webUrl")]
        public string WebUrl { get; set; }

        [JsonProperty("lastModifiedDateTime")]
        public DateTime LastModifiedDateTime { get; set; }

        [JsonProperty("size")]
        public long Size { get; set; }

        [JsonProperty("file")]
        public FileInfo File { get; set; }
    }

    public class FileInfo
    {
        [JsonProperty("mimeType")]
        public string MimeType { get; set; }
    }

    public class FileSearchResult
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string WebUrl { get; set; }
        public DateTime LastModified { get; set; }
        public long Size { get; set; }
        public string ContentType { get; set; }
    }
}
