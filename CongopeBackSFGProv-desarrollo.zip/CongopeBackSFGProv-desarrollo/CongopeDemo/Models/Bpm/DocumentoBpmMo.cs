﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Congope.Empresas.Models.Bpm
{
    [Table("documento_proceso")] // nombre exacto de la tabla en Postgres
    public class DocumentoBpmMo
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }                  // PK autoincremental interno

        [Column("documentoid")]
        public string DocumentoId { get; set; }         // Número de documento

        [Column("processinstanceid")]
        [StringLength(64)]
        public string ProcessInstanceId { get; set; } // ID de Camunda

        [Column("total_firmas")]
        public int? TotalFirmas { get; set; }      // Número de firmas requeridas

        [Column("ancho_firma")]
        public int? AnchoFirma { get; set; }        // Ancho del campo de firma

        [Column("alto_firma")]
        public int? AltoFirma { get; set; }         // Alto del campo de firma

        [Column("posiciony")]
        public int? PosicionY { get; set; }       // Posición vertical de la firma

        [Column("estado")]
        [StringLength(50)]
        public string Estado { get; set; }           // Activo, Finalizado, Anulado

        [Column("fechainicio")]
        public DateTime FechaInicio { get; set; }    // Inicio del proceso

        [Column("fechafin")]
        public DateTime? FechaFin { get; set; }      // Fin del proceso

        [Column("anio")]
        public int? Anio { get; set; }      // Año del documento
    }
}
