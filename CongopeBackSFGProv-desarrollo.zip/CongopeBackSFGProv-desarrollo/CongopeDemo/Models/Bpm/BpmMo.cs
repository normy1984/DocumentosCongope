﻿using Congope.Empresas.Models.Reportes;

namespace Congope.Empresas.Models.Bpm
{
    // TABLA PARA GUARDAR LA RELACION ENTRE EL PROCESO Y EL DOCUMENTO


    public class BpmMo
    {
        public string Creador { get; set; }
        public string AprobadorN1 { get; set; }
        public string AprobadorN2 { get; set; }
        public string IdDocumento { get; set; }
    }

    public class TareaBpmMo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Assignee { get; set; }
        public string ProcessInstanceId { get; set; }
        public string TaskDefinitionKey { get; set; }
    }

    public class TareaCompletaBpmMo
    {
        public string TaskId { get; set; }
        public string ProcessId { get; set; }
        public bool Aprobado { get; set; }
    }

    public class EstadoDocumentoMo
    {
        public string Proceso { get; set; }
        public string? TareaActual { get; set; }
        public string? UsuarioAsignado { get; set; }
    }

    public class HistorialBpmMo
    {
        public string id { get; set; }
        public string activityName { get; set; }
        public string activityType { get; set; }
        public string startTime { get; set; }
        public string endTime { get; set; }
    }


    public class IniciarProcesoDocumentoFirmaMo
    {
        public BpmMo VariablesInicio { get; set; }
        public VariablesPdfMO VariablesDocumento { get; set; }
    }


}
