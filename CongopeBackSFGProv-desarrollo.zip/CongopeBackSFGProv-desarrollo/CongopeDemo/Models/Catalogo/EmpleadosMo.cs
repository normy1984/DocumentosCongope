﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Catalogo
{
    public class EmpleadosMo {
        public string cedruc { get; set; }
        public string descrip { get; set; }
        public string direcci { get; set; }
        public string telefon1 { get; set; }
        public string telefon2 { get; set; }
        public string fax1 { get; set; }
        public string fax2 { get; set; }
        public string email1 { get; set; }
        public string email2 { get; set; }
        public string fec_ini { get; set; }
        public string fec_fin { get; set; }
        public string cuenta { get; set; }
        public string libretmi { get; set; }
        public string afiiess { get; set; }
        public int tiposan { get; set; }
        public int instruc { get; set; }
        public int sexo { get; set; }
        public int tipocta { get; set; }
        public string banco { get; set; }
        public int rucoced { get; set; }
        public string cuentaco { get; set; }
        public double suelunif { get; set; }
        public double suelante { get; set; }
        public double sueliess { get; set; }
        public string partida { get; set; }
        public string fecnac { get; set; }
        public int regimen { get; set; }
        public int estciv { get; set; }
        public int estado { get; set; }
        public string cuentaaso { get; set; }
        public int fondo_reser { get; set; }
        public string extension { get; set; }
        public int crg_id { get; set; }
        public int cargas_famil { get; set; }
        public int nombramiento { get; set; }
        public int discapacitado { get; set; }
        public int dias_lab { get; set; }
        public string provincia { get; set; }
        public string ciudad { get; set; }
        public int nacionalidad { get; set; }
        public int etnico { get; set; }
        public int enf_catastrofico { get; set; }
        public int enf_alergias { get; set; }
        public int enf_otros { get; set; }
        public int grupo { get; set; }
        public int grado { get; set; }
        public int duracion_cont { get; set; }
        public int cambioad { get; set; }
        public string declara_bien { get; set; }
        public string clave { get; set; }
        public int pago_decimos { get; set; }
        public int pago_decimocuarto { get; set; }
        public int th_perfil { get; set; }
        public string image { get; set; }
        public string code { get; set; }
        public ParamSessionMo sessionMo { get; set; }
    }

    public class EmpleadosPorCodigoMo
    {
        public string Cedruc { get; set; }
        public ParamSessionMo sessionMo { get; set; }
    }

    public class EmpleadosSubirFotoMo
    {
        public string Cedruc { get; set; }
        public IFormFile? uploadFile { get; set; }
    }
}
