﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Catalogo
{

    public class Sel_ArbolEstructuraCuentasPartidasMo
    {
        public int identifi { get; set; }
        public ParamSessionMo sessionMo { get; set; }
       
    }

    public class Sel_EstructuraCuentasXcodigoMo
    {
        public string cuenta { get; set; }
        public ParamSessionMo sessionMo { get; set; }

    }
    public class ArbolEstructuraCuentasPartidasMo
    {
        public string Cuenta { get; set; }
        public string Nom_cue { get; set; }
        public string Ult_cue { get; set; }
        public int Niv_cue { get; set; }
        public int Totalhijos { get; set; }
        public List<ArbolEstructuraCuentasPartidasMo> Submenu { get; set; } = new List<ArbolEstructuraCuentasPartidasMo>();
    }


    public class Sel_SelectEstructuraNuevoGenericoMo
    {
        public int identifi { get; set; }
        public string cuenta { get; set; }
        public ParamSessionMo sessionMo { get; set; }

    }


    public class IU_EstructuraPartidaCuentaMo
    {
        public string cuenta { get; set; }
        public int identifi { get; set; }
        public string nom_cue { get; set; }
        public string ult_cue { get; set; }
        public int niv_cue { get; set; }
        public string cuenta_p { get; set; }
        public ParamSessionMo sessionMo { get; set; }

    }


}
