﻿namespace Congope.Empresas.Models.Catalogo
{
    public class CuentasBancariasMo
    {
        public int ctapag { get; set; }
        public string cuenta { get; set; }
        public string nombreCuenta { get; set; }
        public string cuentaBancaria { get; set; }

}
}
