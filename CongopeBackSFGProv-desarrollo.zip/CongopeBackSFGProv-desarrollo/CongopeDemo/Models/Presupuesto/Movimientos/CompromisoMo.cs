﻿using Congope.Empresas.Models.Genericas;
using Org.BouncyCastle.Utilities;

namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class CompromisoCabeceraMo
    {
        public string sig_tip { get; set; }
        public double acu_tip { get; set; }
        public string num_com { get; set; }
        public string des_cab { get; set; }
        public double tot_deb { get; set; }
        public double tot_cre { get; set; }
        public double totinid { get; set; }
        public double totinic { get; set; }
        public string fec_asi { get; set; }
        public string fec_apr { get; set; }
        public string fec_anu { get; set; }
        public int estado { get; set; }
        public int periodo { get; set; }
        public int nropagos { get; set; }
        public int pagosre { get; set; }
        public int incremen { get; set; }
        public double comprom { get; set; }
        public string sig_tip1 { get; set; }
        public double acu_tip1 { get; set; }
        public int estadono { get; set; }
        public int liquida { get; set; }
        public int departam { get; set; }
        public int solicita { get; set; }
        public string cedruc { get; set; }
        public int tipopro { get; set; }
        public int retfte { get; set; }
        public int retiva { get; set; }
        public string cur { get; set; }
        public double pagado { get; set; }
        public double recaudad { get; set; }
        public string sig_tipce { get; set; }
        public int acu_tipce { get; set; }
        public string cod_proceso { get; set; }
        public int arrastre { get; set; }
        public int tipo_contrato { get; set; }
        public string admin_contrato { get; set; }
        public double valor_contrato { get; set; }
        public string observacion { get; set; }
        public int desagrupar { get; set; }
        public ParamSessionMo sessionMo { get; set; }
    }
    public class CompromisoDetalleMo
    {
        public string sig_tip { get; set; }
        public double acu_tip { get; set; }
        public int sec_det { get; set; }
        public string cuenta { get; set; }
        public double val_deb { get; set; }
        public double val_cre { get; set; }
        public string fec_det { get; set; }
        public string cod_cli { get; set; }
        public string fec_pos { get; set; }
        public string nroctac { get; set; }
        public int nro_che { get; set; }
        public int tip_com { get; set; }
        public string des_det { get; set; }
        public int estado { get; set; }
        public int periodo { get; set; }
        public string factura { get; set; }
        public int asociac { get; set; }
        public int devengad { get; set; }
        public int saldo { get; set; }
        public double pagado { get; set; }
        public double recaudad { get; set; }
        public double val_cert { get; set; }
        public double acu_tip_ce { get; set; }
        public ParamSessionMo sessionMo { get; set; }
    }


    public class AnularCompromisoCabeceraMo
    {
        public string siglas_num { get; set; }
        public ParamSessionMo VarSesion { get; set; }
        public int liquidar { get; set; }
    }


    public class AprobarCompromisoCabeceraMo
    {
        public string siglas_num { get; set; }
        public string fecha_apr { get; set; }
        public ParamSessionMo VarSesion { get; set; }
        
    }


    public class AsociarCompromisoCabeceraMo
    {
        public string siglas_num { get; set; }
        public bool asociar { get; set; }
        public int departamento { get; set; }
        public ParamSessionMo VarSesion { get; set; }

    }


    public class IU_AsociarCompromisoCabeceraMo
    {
        public double acu_tip_co { get; set; }
        public List<double> acu_tip_ce { get; set; }
        public bool asociar { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }



    public class IU_Codigo_AsociarCompromisoCabeceraMo
    {
        public double acu_tip_co { get; set; }
        public double acu_tip_ce { get; set; }
        public bool asociar { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }

}
