﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class CertificacionesSinAfeCabMO
    {
        public ParamSessionMo VarSesion { get; set; }
        public int acutip { get; set; }
    }

    public class CertificacionSinAfeCabCodMO
    {
        public string n_estado { get; set; }
        public string codemp { get; set; }
        public ParamSessionMo VarSesion { get; set; }
        public string acu_tip { get; set; }
        public string des_cab { get; set; }
        public int valor_total { get; set; }
        public string fec_asi { get; set; }
        public string fec_apr { get; set; }
        public string cre_por { get; set; }
        public string fec_cre { get; set; }
        public string fec_mod { get; set; }
        public int estado { get; set; }
        public int departam { get; set; }
        public int solicita { get; set; }
        public int tipo_doc { get; set; }



    }
}
