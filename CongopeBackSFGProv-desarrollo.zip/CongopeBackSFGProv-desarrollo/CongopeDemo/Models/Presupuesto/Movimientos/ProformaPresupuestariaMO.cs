﻿namespace Congope.Empresas.Models.Presupuesto
{
    public class ProformaPresupuestariaMO
    {
        public string anio { get; set; }
        public string sig_tip { get; set; }
        public string acu_tip { get; set; }
        public string fec_asi { get; set; }
        public string fec_apr { get; set; }
        public string num_com { get; set; }
        public string des_cab { get; set; }
        public string cre_por { get; set; }
        public string fec_cre { get; set; }
        public string mod_por { get; set; }
        public string fec_mod { get; set; }
        public string estado { get; set; }
        public string cuenta { get; set; }
        public string nom_cue { get; set; }
        public string val_deb { get; set; }
        public string val_cre { get; set; }
        public string asociac { get; set; }
    }
}
