﻿namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class ReformaPresupuestariaMO
    {
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }
        public string siglasnum { get; set; }
        public string num_com { get; set; }
        public string descrip { get; set; }
        public string fec_asi { get; set; }
        public string fec_apr { get; set; }
        public string des_cab { get; set; }     
        public double tot_cre { get; set; }
        public double tot_deb { get; set; }      
        public int codigo_est { get; set; }
        public int out_anio { get; set; }
        public int solicita { get; set; }
        public int departam { get; set; }
        public int out_departamento { get; set; }
        public int out_responsable { get; set; }
        public int out_cre_por { get; set; }
        public string out_cre_por_desc { get; set; }
        public int out_mod_por { get; set; }
        public string out_mod_por_desc { get; set; }
        public decimal out_valor_contrato { get; set; }   

        public string in_cod_proceso { get; set; }
    }
}
