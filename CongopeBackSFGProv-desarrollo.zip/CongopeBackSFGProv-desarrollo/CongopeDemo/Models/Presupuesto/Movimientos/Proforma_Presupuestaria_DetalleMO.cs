﻿namespace Congope.Empresas.Models.Presupuesto
{
    public class Proforma_Presupuestaria_DetalleMO
    {
        public string codemp { get; set; }
        public string anio { get; set; }
        public string sig_tip { get; set; }
        public string acu_tip { get; set; }
        public string sec_det { get; set; }
        public string ycodemp { get; set; }
        public string yanio { get; set; }
        public string ysig_tip { get; set; }
        public string yacu_tip { get; set; }
        public string cuenta { get; set; }
        public string val_deb { get; set; }
        public string val_cre { get; set; }
        public string fec_det { get; set; }
        public string cod_cli { get; set; }
        public string fec_pos { get; set; }
        public string nroctac { get; set; }
        public string nro_che { get; set; }
        public string tip_com { get; set; }
        public string cre_por { get; set; }
        public string fec_cre { get; set; }
        public string mod_por { get; set; }
        public string fec_mod { get; set; }
        public string des_det { get; set; }
        public string estado { get; set; }
        public string periodo { get; set; }
        public string factura { get; set; }
        public string asociac { get; set; }
        public string devengad { get; set; }
        public string saldo { get; set; }
        public string pagado { get; set; }
        public string recaudad { get; set; }
        public string val_cert { get; set; }

    }
}
