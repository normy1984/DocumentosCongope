﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    /// <summary>
    /// Clase Modelo que contiene la información para movimientos presupuestarios
    /// </summary>
    public class MovimientosPresupuestariosMO
    {
        public string siglasnum { get; set; }
        public string num_com { get; set; }
        public string descrip { get; set; }
        public string fec_asi { get; set; }
        public string fec_apr { get; set; }
        public string out_fec_apr { get; set; }
        public string des_cab { get; set; }     
        public float tot_cre { get; set; }  
        public float certificado { get; set; }
        public int codigo_est { get; set; }
        public int out_anio { get; set; }
        public int solicita { get; set; }
        public int departam { get; set; }
        public int out_departamento { get; set; }
        public int out_responsable { get; set; }
        public int out_cre_por { get; set; }
        public string out_cre_por_desc { get; set; }
        public int out_mod_por { get; set; }
        public string out_mod_por_desc { get; set; }
        public decimal out_valor_contrato { get; set; }
        public decimal valor_contrato { get; set; }
        public string cod_proceso { get; set; }
        public string anula_liquida { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }

    public class MovimientosPresupuestariosCaebeceraMO
    {
        public string siglas_num { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }


}
