﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class MovimientosCompromisoMo
    {
        public string sig_tip { get; set; }
        public int estado { get; set; }
        public string fec_asi_inicio { get; set; }
        public string fec_asi_fin { get; set; }
        public string codemp { get; set; }
    }

    public class DetalleMovimientosCompromisoMo
    {
        public int compromiso { get; set; }
        public string codemp { get; set; }
        public int anio { get; set; }

    }
}
