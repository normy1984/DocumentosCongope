﻿namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class ResumenPresupuestoMO
    {
       /* 
        * public string denominacion { get; set; }
        public float codificado { get; set; }
        public float certificado { get; set; }
        public float porcentaje_cert { get; set; }
        public float comprometido { get; set; }
        public float porcentaje_comp { get; set; }
        public float devengado { get; set; }
        public float porcentaje_dev { get; set; }
        public float pagado { get; set; }
        public float porcentaje_pag { get; set; }*/
    }

    public class ResumenPresupuestoFiltroMO
    {
        public string codemp { get; set; }
        public int anio { get; set; }
        public string fecha { get; set; }
       
    }
    public class PresupuestoXDirec_POA_TTHHMO
    {
        public string codemp { get; set; }
        public int anio { get; set; }
        public string fecha { get; set; }
        public int? prt_tthh_param { get; set; }// int? permite valores NULL
        public string? grupo { get; set; }// int? permite valores NULL

    }
}
