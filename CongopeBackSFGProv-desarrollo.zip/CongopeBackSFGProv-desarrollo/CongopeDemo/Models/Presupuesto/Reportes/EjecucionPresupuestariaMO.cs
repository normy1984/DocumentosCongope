﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class EjecucionPresupuestariaMO
    {
        public int grupo { get; set; }
        public string descripcion { get; set; }
        public decimal codificado { get; set; }
        public decimal devengado { get; set; }
        public decimal diferencia { get; set; }
        public decimal porcentaje { get; set; }
        public decimal orden { get; set; }
    }

    public class FiltroEjecucionPresupuestariaMO
    {
        public string codemp { get; set; }
        public int anio { get; set; }
        public string fecha { get; set; }
        public int? nivel { get; set; }
    }
}
