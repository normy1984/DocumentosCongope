﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Npgsql;

namespace Congope.Empresas.Models.Presupuesto
{
    public class EstructuraPartidaGastosMO
    {

        public string niv_est { get; set; }
        public string des_est { get; set; }
        public string lon_est { get; set; }
        public string item_aso { get; set; }
        public string foce { get; set; }
        public string orienta_gas { get; set; }
        public string niv_ug { get; set; }
        public string niv_comp { get; set; }
        public string niv_proy { get; set; }
      //  public string anio { get; set; }
       // public string identifi { get; set; }
        public string digitos{ get; set; }



    }
}
