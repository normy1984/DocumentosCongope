﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Npgsql;

namespace Congope.Empresas.Models.Presupuesto.Catalogos
{
    public class FuentesFinanciamientoMO
    {
        public string ffn_id { get; set; }
        public string ffn_nombre { get; set; }
        public string ffn_ctapago { get; set; }

    }
}