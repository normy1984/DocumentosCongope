﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Catalogos
{
    public class PartidaSinAfeDetMO
    {
        public ParamSessionMo? VarSesion { get; set; }
        public string?accion { get; set; }
        public int acutip { get; set; }
        public string? partida { get; set; }
        public double? valor { get; set; }
    }

    public class PartidaSinAfeCabMO
    {
        public ParamSessionMo? VarSesion { get; set; }
        public string? accion { get; set; }
        public int acu_tip { get; set; }
        public string? des_cab { get; set; }
        public double? valor_total { get; set; }
        public string? fec_asi { get; set; }
        public string? fec_apr { get; set; }
        public int? estado { get; set; }
        public string? fec_cre { get; set; }
        public string? fec_mod { get; set; }
  //      public string? mod_por { get; set; }
        public int departam { get; set; }
   //     public int solicita { get; set; }
        public int tipo_doc { get; set; }
    }
}
