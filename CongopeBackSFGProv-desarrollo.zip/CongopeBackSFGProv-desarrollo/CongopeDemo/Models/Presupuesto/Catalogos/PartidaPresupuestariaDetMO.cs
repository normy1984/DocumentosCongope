﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Catalogos
{
    public class PartidaPresupuestariaDetMO
    {
        public ParamSessionMo VarSesion { get; set; }
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }
        public string cuenta { get; set; }
        public int sec_det { get; set; }
        public int asociac { get; set; }
        public double val_cre { get; set; }

        //Para salida en el front
        public int out_sec_det { get; set; }
        public string out_cuenta { get; set; }
        public string out_sig_tip { get; set; }
        public string nom_cue { get; set; }
        public double val_devengado { get; set; }
        public double out_val_cre { get; set; }

        //ESTO FUE PARA RECUPERAR EL DETALLE DE UNA CERTIFICACION
        public double certificado { get; set; }
        public double out_asociac { get; set; }
        public double valor_maximo { get; set; }

        public double saldo { get; set; }
        public double val_dist { get; set; }

    }
}
