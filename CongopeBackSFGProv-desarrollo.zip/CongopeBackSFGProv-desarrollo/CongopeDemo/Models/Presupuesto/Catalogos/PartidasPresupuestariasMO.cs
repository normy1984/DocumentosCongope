﻿namespace Congope.Empresas.Models.Presupuesto.Catalogos
{
    public class PartidasPresupuestariasMO
    {
        public string out_ult_cue { get; set; }
        public string out_cuenta { get; set; }
        public string out_nom_cu { get; set; }
        public string out_por_comprometer { get; set; }
    }
}
