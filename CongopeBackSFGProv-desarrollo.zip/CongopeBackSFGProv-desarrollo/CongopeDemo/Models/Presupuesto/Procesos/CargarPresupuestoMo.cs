﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Procesos
{
    public class CargarPresupuestoTipoMo
    {
        public int longitud { get; set; }
    }
    public class ValidarPresupuestoMo
    {
        public IFormFile File { get; set; }
        public int Anio { get; set; }
        public string Codemp { get; set; }
    }

    public class EstructuraPresupuestoMo
    {
        public string Partida_presupuestaria { get; set; }
        public string Nombre { get; set; }
        public double Gastos { get; set; }
        public double Ingresos { get; set; }
        public int Tipo { get; set; }
        public int Nivel { get; set; }
        public string Ultimo_nivel { get; set; }
        public string Cuenta_padre { get; set; }
        public ParamSessionMo ParamSessionMo { get; set; }
    }

    
}
