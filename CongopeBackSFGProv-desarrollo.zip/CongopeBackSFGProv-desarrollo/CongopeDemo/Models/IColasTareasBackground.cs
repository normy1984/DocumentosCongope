﻿namespace Congope.Empresas.Models
{
    public interface IColasTareasBackground
    {
        void Enqueue(Func<CancellationToken, Task> workItem);
        Task<Func<CancellationToken, Task>> DequeueAsync(CancellationToken cancellationToken);
    }
}
