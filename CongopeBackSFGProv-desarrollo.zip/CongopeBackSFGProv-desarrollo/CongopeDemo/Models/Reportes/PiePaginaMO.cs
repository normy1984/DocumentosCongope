﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace Congope.Empresas.Models.Reportes
{
    public class PiePaginaMO
    {
        public string reporte { get; set; }
        public string descrip { get; set; }
        public string firma1 { get; set; }
        public string firma2 { get; set; }
        public string firma3 { get; set; }
        public string firma4 { get; set; }
        public string firma5 { get; set; }
        public string firma6 { get; set; }
        public string cabecera { get; set; }
        public string pie { get; set; }
        public int imp_fecha { get; set; }
        public string cuerpo_reporte { get; set; }
        public string orientacion { get; set; }
        public string numero_documento { get; set; }
        public ParamSessionMo ?VarSesion { get; set; }

        public PiePaginaMO()
        {
                reporte= "REPORTE SIN FORMATO";
                descrip= "REPORTE SIN FORMATO";
                firma1= "";
                firma2= "";
                firma3= "";
                firma4= "";
                firma5= "";
                firma6= "";
                cabecera= "";
                pie= "";
                imp_fecha= 1;
                cuerpo_reporte= "EL REPORTE SOLICITADO NO EXISTE.. CONTACTESE CON EL ADMINISTRADOR!!";
                orientacion= "P";
                numero_documento= "DOCUMENTO NN.";
    }
    }
}
