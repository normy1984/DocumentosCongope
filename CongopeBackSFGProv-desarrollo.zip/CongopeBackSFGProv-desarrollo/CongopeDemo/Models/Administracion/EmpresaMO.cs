﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Administracion
{
    /// <summary>
    /// Modelo de Empresa
    /// </summary>
    public class EmpresaMO
    {
        public string? codemp { get; set; }
        public string? nom_emp { get; set; }
        public string? ruc_emp { get; set; }
        public string? dir_emp { get; set; }
        public string? tel1_emp { get; set; }
        public string? tel2_emp { get; set; }
        public string? fax1_emp { get; set; }
        public string? fax2_emp { get; set; }
        public string? email1 { get; set; }
        public string? email2 { get; set; }
        public string? rep_emp { get; set; }
        public string? rep_ruc { get; set; }
        public string? cont_emp { get; set; }
        public string? cont_ruc { get; set; }
        public int estado { get; set; }
        public string? dirfinan { get; set; }
        public string? diradmin { get; set; }
        public string? dirfoto { get; set; }
        public string? serieret { get; set; }
        public string? autoret { get; set; }
        public string? ciudad { get; set; }
        public string? pathlogo { get; set; }
        public int tipodato { get; set; }
        public int nodeviva { get; set; }
        public int t_factura { get; set; }
        public string? subempre { get; set; }
        public int color01 { get; set; }
        public int color02 { get; set; }
        public int tipoemp { get; set; }
        public string? path_imag_ser { get; set; }
        public int varios_co { get; set; }
        public string? path_archielec { get; set; }
        public string? nomcomercial { get; set; }
        public string? contrib_espe { get; set; }
        public int obligado_conta { get; set; }
        public int provincia { get; set; }
        public string? path_archielec_apr { get; set; }
        public int actnrocr { get; set; }
        public string? path_docum { get; set; }
        public string? version_fecha { get; set; }
        public string? dir_web_presu { get; set; }
        public string? dfin_emp { get; set; }
        public string? dfin_ruc { get; set; }
        public string? path_cpbtesegreso { get; set; }
        public string? teso_emp { get; set; }
        public string? teso_ruc { get; set; }
        public string? aut_liq_comp { get; set; }
        public int region { get; set; }
        public string? dir_web_viaticos { get; set; }
        public string? dir_pagina_web { get; set; }
        public int tipoemplea { get; set; }
        public int ente_ss { get; set; }
        public string? ImagenBase64 { get; set; }
        public IFormFile? uploadFile { get; set; }
        public int Anio { get; set; }
        public int Sistema { get; set; }
        public int codUsu { get; set; }
    }
}
