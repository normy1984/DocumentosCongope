﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Administracion
{
    public class UsuariosMO
    {
        public int CodUsu { get; set; }
        public string Cedruc { get; set; }
        public int EsAdministrador { get; set; }
        public bool UsuarioConsulta { get; set; }
        public List<string> PerfilesMenu { get; set; } = new List<string>();
    }

    public class UsuarioMenuPerfilMO
    {
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
        public int Nivel { get; set; }
        public int TotalHijos { get; set; }
        public bool Checked { get; set; }
        public List<UsuarioMenuPerfilMO> Submenu { get; set; } = new List<UsuarioMenuPerfilMO>();
    }


    public class ConsultaAprobarDocumentosMo
    {
        public int CodUsu { get; set; }
        public int CodSistema { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }

    public class AprobarDesaprobarDocumentosMo
    {
        public int CodUsu { get; set; }
        public int CodSistema { get; set; }
        public string SigTip { get; set; }
        public int Aprueba { get; set; }
        public int Desaprueba { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }


    public class InsertarUsuariosMo
    {
        public string Descrip { get; set; }
        public string Cedruc { get; set; }
        public string Correo_origen { get; set; }

    }


    public class ActualizarUsuariosMo
    {

        public int Codusu { get; set; }
        public string Descrip { get; set; }
        public string Cedruc { get; set; }
        public string Correo_origen { get; set; }

    }

}
