﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.Reportes
{
    public class RPT241_MOVIMIENTO_COMPROMISO
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */

                var vReportes = new
                {
                    sig_tip = DatosReporte.param1,
                    acu_tip = DatosReporte.param2,
                    anio = DatosReporte.VarSesion.Anio,
                };

                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                NpgsqlCommand cmd = new NpgsqlCommand();

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"
                                select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa; 
                                ";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", DatosReporte.tipo_reporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/



                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];


                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"
                                SELECT men_html from mensajes_html p 
                                where p.men_codigo  = 8; 
                                ";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];


                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA prcabmov ///////////////////
                    ////////////////////////////////////////////////////


                    oReporte.numero_documento = $"COMPROMISO NO.: {Convert.ToString(vReportes.anio)} - {Convert.ToString(vReportes.acu_tip)} {Convert.ToString(vReportes.sig_tip)}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE prdetmov 
                    ///AQUI SE CONSTRUYE EL HTML RECURSIVO///////////////////
                    ////////////////////////////////////////////////////

                    sql = @"SELECT * from public.sps_movimientos_por_compromiso
                           (
                            @codemp, @anio, @compromiso
                            );
                            ";
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, codEmpresa.ToString());
                    cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, vReportes.anio);
                    cmd.Parameters.AddWithValue("@compromiso", NpgsqlDbType.Integer, Convert.ToInt16(vReportes.sig_tip));
                    cmd.CommandText = sql;

                    var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);

                    Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);


                    float Total = 0;
                    string html_detalle = "";

                    /***
                     * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
                     * para evitar la distorsion de la presentacion
                     */

                    foreach (var item in Datosprdetmov)
                    {
                        html_detalle += $@"
                                    <tr>
                                        <td style=""font-size: 10px;word-break: break-all;max-width: 50%;"">{item["siglasnum"]}</td>
                                        <td style=""font-size: 10px;"">{item["documento"]}</td>
                                        <td style=""font-size: 10px;"">{item["fecha"]}</td>
                                        <td style=""font-size: 10px;word-break: break-all;max-width: 40%;"">{item["concepto"]}</td>
                                        <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["valor"])}</td>
                                    </tr>";
                        Total = Total + Convert.ToSingle(item["valor"]);
                    }


                    //REEMPLAZO DEL TOTAL
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));
                    htmlContent = htmlContent.Replace("##VALOR_TOTAL##", string.Format("{0:N2}", Total));

                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
    }
}

