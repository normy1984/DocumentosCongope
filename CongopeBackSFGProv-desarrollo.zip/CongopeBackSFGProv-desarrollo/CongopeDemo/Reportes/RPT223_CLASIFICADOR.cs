﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Ocsp;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Congope.Empresas.Reportes
{
    public class RPT223_CLASIFICADOR
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            //string fecha_hasta = "";
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                var vReportes = new
                {
                    fecha_hasta = DatosReporte.param1,
                    tipo_presu = DatosReporte.param2,
                    clasificador = DatosReporte.param3,
                };


                //string codEmpresa = Constantes.General.Empresa;
                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                int  codusu = DatosReporte.VarSesion.codUsu;
                NpgsqlCommand cmd = new NpgsqlCommand();

                string sNombreReporte = "RPT223_CLASIFICADOR";

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", sNombreReporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "P";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 11;";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];

                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA ///////////////////
                    ////////////////////////////////////////////////////

                    oReporte.numero_documento = $"AL : {Convert.ToString(vReportes.fecha_hasta)}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE  
                    ////////////////////////////////////////////////////
                    sql = @"SELECT * FROM sp_consulta_por_clasificador_presupuestario(@f_hasta,@ntipopresu,@sclafificador) ;";                    
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, vReportes.fecha_hasta);
                    cmd.Parameters.AddWithValue("@ntipopresu", NpgsqlDbType.Integer, Int32.Parse(vReportes.tipo_presu));
                    cmd.Parameters.AddWithValue("@sclafificador", NpgsqlDbType.Varchar, vReportes.clasificador);

                    var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
                    Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

                    string html_detalle = "";

                    /***
                     * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
                     * para evitar la distorsion de la presentacion
                     */

                    float Totasig_ini = 0;
                    float Totreformas = 0;
                    float Totcodificado = 0;
                    float Totcertificado = 0;
                    float Totcomprometido = 0;
                    float Totdevengado = 0;
                    float Totpagado = 0;
                    float Totpor_comprometer = 0;
                    float Totpor_devengar = 0;
                    float Totpor_pagar = 0;


                    foreach (var item in Datosprdetmov)
                    {
                        html_detalle += $@"
                            <tr>
                                <td style=""font-size: 7px;word-break: break-all;max-width: 8%;"">{item["clasificador"]}</td>
                                <td style=""font-size: 7px;"">{item["categoria"]}</td>
                                <td style=""font-size: 7px;"">{item["nom_cue"]}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["asig_ini"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["reformas"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["codificado"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["certificado"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["comprometido"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["devengado"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["pagado"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["por_comprometer"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["por_devengar"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["por_pagar"])}</td>
                                <td style=""font-size: 7px;text-align: right;"">{string.Format("{0:N2}", item["porcen_eje"])}</td>
                            </tr>";

                        Totasig_ini = Convert.ToSingle(item["totalasig_ini"]);  
                        Totreformas = Convert.ToSingle(item["totalreformas"]);
                        Totcodificado = Convert.ToSingle(item["totalcodificado"]);
                        Totcertificado = Convert.ToSingle(item["totalcertificado"]);
                        Totcomprometido = Convert.ToSingle(item["totalcomprometido"]);
                        Totdevengado = Convert.ToSingle(item["totaldevengado"]);
                        Totpagado = Convert.ToSingle(item["totalpagado"]);
                        Totpor_comprometer = Convert.ToSingle(item["totalpor_comprometer"]);
                        Totpor_devengar = Convert.ToSingle(item["totalpor_devengar"]);
                        Totpor_pagar = Convert.ToSingle(item["totalpor_pagar"]);

                    }
                  
                    //REEMPLAZO DEL TOTAL
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));

                    htmlContent = htmlContent.Replace("##VALORTOTALASIGINI##", string.Format("{0:N2}", Totasig_ini));
                    htmlContent = htmlContent.Replace("##VALORTOTALREFORMAS##", string.Format("{0:N2}", Totreformas));
                    htmlContent = htmlContent.Replace("##VALORTOTALCODIFICADO##", string.Format("{0:N2}", Totcodificado));
                    htmlContent = htmlContent.Replace("##VALORTOTALCERTIFICADO##", string.Format("{0:N2}", Totcertificado));
                    htmlContent = htmlContent.Replace("##VALORTOTALCOMPROMETIDO##", string.Format("{0:N2}", Totcomprometido));
                    htmlContent = htmlContent.Replace("##VALORTOTALDEVENGADO##", string.Format("{0:N2}", Totdevengado));
                    htmlContent = htmlContent.Replace("##VALORTOTALPAGADO##", string.Format("{0:N2}", Totpagado));
                    htmlContent = htmlContent.Replace("##VALORTOTALPORCOMPROMETER##", string.Format("{0:N2}", Totpor_comprometer));
                    htmlContent = htmlContent.Replace("##VALORTOTALPORDEVENGAR##", string.Format("{0:N2}", Totpor_devengar));
                    htmlContent = htmlContent.Replace("##VALORTOTALPORPAGAR##", string.Format("{0:N2}", Totpor_pagar));

                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return PdfBL.GenerarPDFBase64(oReporte);
                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
        

    }
}
