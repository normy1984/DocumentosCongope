﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using iText.Html2pdf;
using iText.IO.Font.Constants;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout.Element;
using iText.Layout.Font;
using iText.Layout.Properties;
using Newtonsoft.Json;
using Npgsql;
using static System.Runtime.InteropServices.JavaScript.JSType;
using iText.Layout;
using iText.Layout.Borders;
using iText.Kernel.Colors;
using System.Globalization;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.Reportes
{
    public class RPT_CEDULA_GASTOS
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                var vReportes = new
                {
                    fecha_hasta = DatosReporte.param1,
                    ing_gas = DatosReporte.param2,
                    nTodos = DatosReporte.param3,
                    nNivel = DatosReporte.param4,
                    sOperador = DatosReporte.param5,
                    sPartida = DatosReporte.param6
                };

                string codEmpresa = Constantes.General.Empresa;
                NpgsqlCommand cmd = new NpgsqlCommand();

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", "RPTCEDULAGASTOS");
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";
                    oReporte.cuerpo_reporte = "";

                    /// LINEA AGREGADA PARA LA VARIABLE DE SESION
                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return GenerarPDFBase64(oReporte, DatosReporte);
                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }

        /// <summary>
        /// Funcion para construir el string base 64 que se retorna para la construccion del PDF
        /// </summary>
        /// <param name="CuerpoReporte"></param>
        /// <returns></returns>
        public static dynamic GenerarPDFBase64(PiePaginaMO CuerpoReporte, VariablesPdfMO DatosReporte)
        {
            var vReportes = new
            {
                fecha_hasta = DatosReporte.param1,
                ing_gas = DatosReporte.param2,
                nTodos = DatosReporte.param3,
                nNivel = DatosReporte.param4,
                sOperador = DatosReporte.param5,
                sPartida = DatosReporte.param6
            };

            NpgsqlCommand cmd = new NpgsqlCommand();
            var DatosUsuario = UsuariosBL.CargarUsuarioCodigo(CuerpoReporte.VarSesion.codUsu);
            var DatosEmpresa = EmpresaDataBL.ObtenerEmpresaCodigo(CuerpoReporte.VarSesion.CodEmp);

            var correo = DatosUsuario.result[0].correo;
            int indiceArroba = correo.IndexOf('@');
            string username = correo.Substring(0, indiceArroba);

            var imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + DatosEmpresa.result[0].pathlogo);
            if (!System.IO.File.Exists(imagen))
            {
                imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + Conexion.ErrorImagen);
            }

            CuerpoReporte.numero_documento = "AL " + RetornaFechaCompleta(Convert.ToString(vReportes.fecha_hasta)); 

            var DatosCabeceraPdf = new DatosCabecera_Pdf_Mo
            {
                NombreReporte = CuerpoReporte.descrip,
                NombreUsuario = username.ToUpper(),
                NumeroDocumento = CuerpoReporte.numero_documento,
                FilePath_LogoPdf = imagen,
                NombreInstitucion_Pdf = DatosEmpresa.result[0].nom_emp
            };

            var DatosPiePdf = new DatosPie_Pdf_Mo
            {
                MostrarFechaHora = CuerpoReporte.imp_fecha,
                Direccion_Pdf = DatosEmpresa.result[0].dir_emp,
                Telefono_Pdf = "Telf: " + DatosEmpresa.result[0].tel1_emp,
                ciudad_Pdf = DatosEmpresa.result[0].ciudad.ToUpper() + "-ECUADOR",
                email_Pdf = "Email: " + DatosEmpresa.result[0].email1
            };

            FontProvider fontProvider = new FontProvider();
            fontProvider.AddSystemFonts();
            fontProvider.AddFont(StandardFonts.HELVETICA);
            ConverterProperties properties = new ConverterProperties();
            properties.SetFontProvider(fontProvider);

            PdfFont font = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);
            float fontSize = 10;
            var Orientacion = CuerpoReporte.orientacion == "L" ? PageSize.A4.Rotate() : PageSize.A4;

            try
            {
                // Primera pasada: Generar el documento y calcular el número total de páginas
                byte[] pdfBytes;
                using (MemoryStream ms = new MemoryStream())
                {
                    using (PdfWriter writer = new PdfWriter(ms))
                    using (PdfDocument pdf = new PdfDocument(writer))
                    {
                        Document document = new Document(pdf, Orientacion);
                        // LLAMADA A LAS CLASES DE LA CABECERA Y PIE DE PAGINA
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new CabeceraEventHandler(DatosCabeceraPdf));
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new PieEventHandler(DatosPiePdf));

                        document.SetFont(font).SetFontSize(fontSize);
                        document.SetMargins(125, 20, 80, 20);

                        if (!string.IsNullOrEmpty(CuerpoReporte.cabecera))
                        {
                            document.Add(new Paragraph(CuerpoReporte.cabecera).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }

                        string sql = @"SELECT * FROM sps_cedula_presupuestaria(@emp,@f_hasta,@inggas,@ntodas,@nnivelbusca,@soperador,@spartida) ;";
                        cmd.CommandText = sql;
                        cmd.Parameters.AddWithValue("@emp", NpgsqlDbType.Varchar, CuerpoReporte.VarSesion.CodEmp);
                        cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, vReportes.fecha_hasta);
                        cmd.Parameters.AddWithValue("@inggas", NpgsqlDbType.Integer, Int32.Parse(vReportes.ing_gas));
                        cmd.Parameters.AddWithValue("@ntodas", NpgsqlDbType.Integer, Int32.Parse(vReportes.nTodos));
                        cmd.Parameters.AddWithValue("@nnivelbusca", NpgsqlDbType.Integer, Int32.Parse(vReportes.nNivel));
                        cmd.Parameters.AddWithValue("@soperador", NpgsqlDbType.Varchar, vReportes.sOperador);
                        cmd.Parameters.AddWithValue("@spartida", NpgsqlDbType.Varchar, vReportes.sPartida);

                        var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
                        Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

                        float[] cellWidthCI = { 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f};
                        Table TablaCentralInformacion = new Table(UnitValue.CreatePercentArray(cellWidthCI)).UseAllAvailableWidth();

                        AddFilaEnbezado(TablaCentralInformacion, "Partida");
                        AddFilaEnbezado(TablaCentralInformacion, "Descripcion");
                        AddFilaEnbezado(TablaCentralInformacion, "asig. Ini.");
                        AddFilaEnbezado(TablaCentralInformacion, "Reformas");
                        AddFilaEnbezado(TablaCentralInformacion, "Codificado");
                        AddFilaEnbezado(TablaCentralInformacion, "Comprom");
                        AddFilaEnbezado(TablaCentralInformacion, "Devengado");
                        AddFilaEnbezado(TablaCentralInformacion, "Por Compr.");
                        AddFilaEnbezado(TablaCentralInformacion, "Por deven.");
                        AddFilaEnbezado(TablaCentralInformacion, "Pagado");


                        for (var i = 0; i < Datosprdetmov.Count; i++)
                        {
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["partida"].Value, "String");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["nombre"].Value, "String");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["asig_ini"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["reformas"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["codificado"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["comprometido"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["devengado"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["por_comprometer"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["por_devengar"].Value, "Numero");
                            AddFilaCentral(TablaCentralInformacion, Datosprdetmov[i]["pagado"].Value, "Numero");
                        }


                        AddFilaFinal(TablaCentralInformacion, "", "String");
                        AddFilaFinal(TablaCentralInformacion, "TOTALES", "String");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_asig_ini"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_reformas"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_codificado"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_comprometido"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_devengado"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_por_comprometer"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_por_devengar"].Value, "Numero");
                        AddFilaFinal(TablaCentralInformacion, Datosprdetmov[0]["tot_pagado"].Value, "Numero");

                        document.Add(TablaCentralInformacion);


                        if (!string.IsNullOrEmpty(CuerpoReporte.pie))
                        {
                            document.Add(new Paragraph(CuerpoReporte.pie).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }



                        float[] cellWidth = { 33f, 34f, 33f };
                        Table TablaFirmas = new Table(UnitValue.CreatePercentArray(cellWidth)).UseAllAvailableWidth();
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma1);
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma2);
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma3);
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma4);
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma5);
                        PdfBL.AddFirmaToTable(TablaFirmas, CuerpoReporte.firma6);

                        if (!PdfBL.TieneEspacioSuficiente(document, TablaFirmas))
                        {
                            document.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                        }

                        document.Add(TablaFirmas);

                        document.Close();

                        pdfBytes = ms.ToArray();
                    }
                }

                // Segunda pasada: Reabrir el documento y actualizar el pie de página con el número total de páginas

                string pdfBase64 = PdfBL.GenerarDocumentoBase64(pdfBytes);


                return new
                {
                    success = true,
                    message = "",
                    result = pdfBase64
                };
            }
            catch (NullReferenceException ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
        }

        public static void AddFilaEnbezado(Table table, string Cabecera)
        {
            

            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER)
                .SetBorderBottom(new SolidBorder(ColorConstants.BLACK, 1));

            Cell cell = new Cell()
                .Add(new Paragraph(Cabecera).SetBold())
                .SetBorder(Border.NO_BORDER)
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(8f)
                .AddStyle(styleCell);
            table.AddCell(cell);

        }

        public static void AddFilaCentral(Table table, dynamic texto, dynamic Tipo)

        {
            Style styleText = new Style();
            if(Tipo == "String")
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.LEFT);
            }
            else
           { 
                styleText = new Style()
.SetTextAlignment(TextAlignment.RIGHT);
                decimal numero = Convert.ToDecimal(texto);
                texto = numero.ToString("#,##0.00", CultureInfo.InvariantCulture);
            }

            var MaxTamaSinCaracteres = 16;

            if (texto.Length > MaxTamaSinCaracteres && !texto.Contains(" "))
            {
                // Dividir el texto en pedazos de máximo 50 caracteres
                string textoCortado = "";
                for (int i = 0; i < texto.Length; i += MaxTamaSinCaracteres)
                {
                    textoCortado += texto.Substring(i, Math.Min(MaxTamaSinCaracteres, texto.Length - i)) + "\n";
                }

                texto = textoCortado;

            }
                Cell cell = new Cell()
                .Add(new Paragraph(texto))
                .SetBorder(Border.NO_BORDER)
                .SetFontSize(6f)
                .AddStyle(styleText);
            table.AddCell(cell);

        }

        public static void AddFilaFinal(Table table, dynamic texto, string Tipo)
        {
            Style styleText = new Style();
            if (Tipo == "String")
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.CENTER);
            }
            else
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.RIGHT);
                decimal numero = Convert.ToDecimal(texto);
                texto = numero.ToString("#,##0.00", CultureInfo.InvariantCulture);
            }

            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER)
                .SetBorderTop(new SolidBorder(ColorConstants.BLACK, 1));

            Cell cell = new Cell()
                .Add(new Paragraph(texto).SetBold())
                .SetBorder(Border.NO_BORDER)
                                .SetFontSize(6f)
                .AddStyle(styleText)
                   .AddStyle(styleCell);
            table.AddCell(cell);
        }

        private static string RetornaFechaCompleta(string sFecha)
        {
            string sfechaCompleta = "";
            int nAnioFecha = DateTime.Parse(sFecha).Year;
            int nMesFecha = DateTime.Parse(sFecha).Month;
            int nDiaFecha = DateTime.Parse(sFecha).Day;
            string sMesFecha = "";
            switch (nMesFecha)
            {
                case 1:
                    sMesFecha = "ENERO";
                    break;
                case 2:
                    sMesFecha = "FEBRERO";
                    break;
                case 3:
                    sMesFecha = "MARZO";
                    break;
                case 4:
                    sMesFecha = "ABRIL";
                    break;
                case 5:
                    sMesFecha = "MAYO";
                    break;
                case 6:
                    sMesFecha = "JUNIO";
                    break;
                case 7:
                    sMesFecha = "JULIO";
                    break;
                case 8:
                    sMesFecha = "AGOSTO";
                    break;
                case 9:
                    sMesFecha = "SEPTIEMBRE";
                    break;
                case 10:
                    sMesFecha = "OCTUBRE";
                    break;
                case 11:
                    sMesFecha = "NOVIEMBRE";
                    break;
                case 12:
                    sMesFecha = "DICIEMBRE";
                    break;
            }

            sfechaCompleta = " " + nDiaFecha + " DE " + sMesFecha + " DEL " + nAnioFecha + " ";

            return sfechaCompleta;

        }

    }
}
