﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using iText.Html2pdf;
using iText.IO.Font.Constants;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout.Element;
using iText.Layout.Font;
using iText.Layout.Properties;
using Newtonsoft.Json;
using Npgsql;
using iText.Layout;
using iText.Layout.Borders;
using iText.Kernel.Colors;
using System.Globalization;
using NpgsqlTypes;
using System;
using System.Runtime.ConstrainedExecution;
using iText.Kernel.Pdf.Canvas;
using Congope.Empresas.Models.Genericas;
using MongoDB.Bson;
using System.IO;
using iText.Layout.Layout;

namespace Congope.Empresas.Reportes
{
    public class FIRMA_RPT207_COMPROMISOS
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                 * 
                 * 
                */
                var vReportes = new
                {
                    sig_tip = DatosReporte.param1,
                    acu_tip = DatosReporte.param2,
                    anio = DatosReporte.VarSesion.Anio,

                };

                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                NpgsqlCommand cmd = new NpgsqlCommand();


                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", "RPT207_COMPROMISOS");
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    PiePaginaMO oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";
                    oReporte.cuerpo_reporte = "";
                    oReporte.numero_documento = DatosReporte.param3;

                    /// LINEA AGREGADA PARA LA VARIABLE DE SESION
                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return GenerarPDFBase64(oReporte);
                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }

        /// <summary>
        /// Funcion para construir el string base 64 que se retorna para la construccion del PDF
        /// </summary>
        /// <param name="CuerpoReporte"></param>
        /// <returns></returns>
        public static dynamic GenerarPDFBase64(PiePaginaMO CuerpoReporte)
        {
            var DatosUsuario = UsuariosBL.CargarUsuarioCodigo(CuerpoReporte.VarSesion.codUsu);
            var DatosEmpresa = EmpresaDataBL.ObtenerEmpresaCodigo(CuerpoReporte.VarSesion.CodEmp);

            var correo = DatosUsuario.result[0].correo;
            int indiceArroba = correo.IndexOf('@');
            string username = correo.Substring(0, indiceArroba);

            PdfBL.NombreUsuario = DatosUsuario.result[0].NombresCompletos;

            var imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + DatosEmpresa.result[0].pathlogo);
            if (!System.IO.File.Exists(imagen))
            {
                imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + Conexion.ErrorImagen);
            }

            var DatosCabeceraPdf = new DatosCabecera_Pdf_Mo
            {
                NombreReporte = CuerpoReporte.descrip,
                NombreUsuario = username.ToUpper(),
                NumeroDocumento = CuerpoReporte.numero_documento,
                FilePath_LogoPdf = imagen,
                NombreInstitucion_Pdf = DatosEmpresa.result[0].nom_emp
            };

            var DatosPiePdf = new DatosPie_Pdf_Mo
            {
                MostrarFechaHora = CuerpoReporte.imp_fecha,
                Direccion_Pdf = DatosEmpresa.result[0].dir_emp,
                Telefono_Pdf = "Telf: " + DatosEmpresa.result[0].tel1_emp,
                ciudad_Pdf = DatosEmpresa.result[0].ciudad.ToUpper() + "-ECUADOR",
                email_Pdf = "Email: " + DatosEmpresa.result[0].email1
            };


            List<BsonDocument> bsonElements = new List<BsonDocument>();

            FontProvider fontProvider = new FontProvider();
            fontProvider.AddSystemFonts();
            fontProvider.AddFont(StandardFonts.HELVETICA);
            ConverterProperties properties = new ConverterProperties();
            properties.SetFontProvider(fontProvider);

            PdfFont font = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);
            var Orientacion = CuerpoReporte.orientacion == "P" ? PageSize.A4.Rotate() : PageSize.A4;

            var firmas = new string[] { CuerpoReporte.firma1, CuerpoReporte.firma2, CuerpoReporte.firma3,
                                CuerpoReporte.firma4, CuerpoReporte.firma5, CuerpoReporte.firma6 };
            var totalFirmas = firmas.Count(firma => !string.IsNullOrEmpty(firma));

            float[] cellWidth;

            switch (totalFirmas)
            {
                case 1:
                    cellWidth = new float[] { 100f }; // una columna 100%
                    break;
                case 2:
                    cellWidth = new float[] { 50f, 50f }; // dos columnas
                    break;
                default:
                    cellWidth = new float[] { 33f, 34f, 33f }; // tres columnas
                    break;
            }

                    try
            {
                string documentoBase64 = string.Empty;

                // Generar el número de documentos según total_documentos

                /*for (int i = 0; i <= total_documentos; i++)
                {*/
                    using (MemoryStream msOutput = new MemoryStream())

                    using (PdfWriter writer = new PdfWriter(msOutput))
                    using (PdfDocument pdf = new PdfDocument(writer))
                    {
                        Document document = new Document(pdf, Orientacion);

                        // LLAMADA A LAS CLASES DE LA CABECERA Y PIE DE PAGINA
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new CabeceraEventHandler(DatosCabeceraPdf));
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new PieEventHandler(DatosPiePdf));

                       

                        document.SetMargins(125, 20, 80, 20);

                        if (!string.IsNullOrEmpty(CuerpoReporte.cabecera))
                        {
                            document.Add(new Paragraph(CuerpoReporte.cabecera).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }

                        float[] cellWidthCI = { 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f, 10f };
                        Table TablaCentralInformacion = new Table(UnitValue.CreatePercentArray(cellWidthCI)).UseAllAvailableWidth();

                        // Agregar pie de página si es necesario
                        if (!string.IsNullOrEmpty(CuerpoReporte.pie))
                        {
                            document.Add(new Paragraph(CuerpoReporte.pie).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }

                        var texto = "Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto.Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor(N.del T.persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original.Fue popularizado en los 60s con la creación de las hojas las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.";

                        for (int m = 0; m < 20; m++)
                        {
                            document.Add(new Paragraph(texto));
                        }
                     

                        Table TablaFirmas = new Table(UnitValue.CreatePercentArray(cellWidth)).UseAllAvailableWidth();

                        for (int numerofirma = 0; numerofirma < totalFirmas; numerofirma++)
                        {
                            AddFirmaToTable(TablaFirmas, firmas[numerofirma], numerofirma + 1, 100);
                        }

                    float AltoRequeridoTabla = PdfBL.AltoRequeridoTabla(pdf, document, TablaFirmas);

                    // Reutilizar la tabla de firmas creada fuera del ciclo
                    if (!PdfBL.TieneEspacioSuficienteFinal(document, AltoRequeridoTabla))
                    {
                        document.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                    }
                    PdfBL.UbicacionFinalFirma(pdf, document, TablaFirmas, CuerpoReporte.numero_documento, totalFirmas, CuerpoReporte.VarSesion.Anio);

                    document.Add(TablaFirmas);
                    //document.Add(new Paragraph("\n")); // un salto de línea

                    document.Close();
                        // Agregar una palabra diferente en cada documento generado
                        byte[] pdfBytes;
                        // El documento se cierra automáticamente después del bloque `using`
                        pdfBytes = msOutput.ToArray();
                        
                        documentoBase64 = string.IsNullOrEmpty(documentoBase64) ? PdfBL.GenerarDocumentoBase64(pdfBytes) : documentoBase64;

                        bsonElements.Add(GeneraDocumentoBson(PdfBL.GenerarDocumentoBase64(pdfBytes), totalFirmas, CuerpoReporte.numero_documento, CuerpoReporte.VarSesion.Anio));

                    }
                //}


                var filtro = new Dictionary<string, object>
                {
                    { "Referencia",  CuerpoReporte.numero_documento },
                    { "Anio", CuerpoReporte.VarSesion.Anio}
                };

                //ELIMINO TODOS LOS DOCUMENTOS QUE CUMPLAN LA CONDICION INICIAL
                var eliminar = Exec_sql.EjecutarComandoMongo("Firmas_Electronicas", "deletemany", filtro);
                if (!eliminar.success) throw new Exception(eliminar.message);

                var insertar = Exec_sql.EjecutarComandoMongo("Firmas_Electronicas", "insertmany", filtro, null, bsonElements);
                if (!insertar.success) throw new Exception(insertar.message);


                return new
                {
                    success = true,
                    message = "",
                    result = documentoBase64
                };
            }
            catch (NullReferenceException ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
        }



        public static BsonDocument GeneraDocumentoBson(string Documento, int numeroDocumento, string referencia, int anio)
        {
            // Convertir el Base64 de vuelta a un array de bytes
            byte[] decodedBytes = Convert.FromBase64String(Documento);

            // Crear un objeto BsonBinaryData con los bytes decodificados
            BsonBinaryData binData = new BsonBinaryData(decodedBytes);

            var uploadData = new
            {
                Referencia = referencia,
                Anio = anio,
                Nombre = referencia + "_"+ anio,
                Tipo = "application/pdf",
                NumeroFirmas = 0,
                FechaSubida = DateTime.Now,
                FileBase64 = binData
            };

            return uploadData.ToBsonDocument();

            
        }



        public static void AddFirmaToTable(Table table, string firma, int numeroFirma, int TotalDocumentos)
        {
            firma = firma.Replace("&", PdfBL.NombreUsuario);

            // Crear el texto condicional
            //string texto = TotalDocumentos == 0 ? "" : numeroFirma <= TotalDocumentos ? "Firmado electrónicamente" : "";
            string texto = "";
            // Crear el texto con el estilo deseado (azul, cursiva, negrita) solo para el "texto"
            var textoEstilizado = new Paragraph("\n\n" + texto)  // Solo el texto con estilo
                .SetBold()  // Aplicar negrita
                .SetItalic()  // Aplicar cursiva
                .SetFontColor(ColorConstants.BLUE);  // Color azul (RGB: 0, 0, 255)

            // Crear el contenido de la firma sin formato adicional
            var firmaContenido = new Paragraph(firma); // La firma no tiene formato extra

            // Agregar el texto estilizado y la firma a la celda
            Cell cell = new Cell()
                .Add(textoEstilizado)
                .Add(firmaContenido)  // Firma sin formato adicional
                //.SetBorder(new SolidBorder(1)) // borde negro de 1 punto
                .SetBorder(Border.NO_BORDER)
                .SetTextAlignment(TextAlignment.CENTER);

            // Agregar la celda a la tabla
            table.AddCell(cell);
        }


        public static void AddFilaEnbezado(Table table, string Cabecera)
        {


            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER)
                .SetBorderBottom(new SolidBorder(ColorConstants.BLACK, 1));

            Cell cell = new Cell()
                .Add(new Paragraph(Cabecera).SetBold())
                .SetBorder(Border.NO_BORDER)
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(8f)
                .AddStyle(styleCell);
            table.AddCell(cell);

        }

        public static void AddFilaCentral(Table table, dynamic texto, dynamic Tipo)

        {
            Style styleText = new Style();
            if (Tipo == "String")
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.LEFT);
            }
            else
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.RIGHT);
                decimal numero = Convert.ToDecimal(texto);
                texto = numero.ToString("#,##0.00", CultureInfo.InvariantCulture);
            }

            var MaxTamaSinCaracteres = 16;

            if (texto.Length > MaxTamaSinCaracteres && !texto.Contains(" "))
            {
                // Dividir el texto en pedazos de máximo 50 caracteres
                string textoCortado = "";
                for (int i = 0; i < texto.Length; i += MaxTamaSinCaracteres)
                {
                    textoCortado += texto.Substring(i, Math.Min(MaxTamaSinCaracteres, texto.Length - i)) + "\n";
                }

                texto = textoCortado;

            }
            Cell cell = new Cell()
            .Add(new Paragraph(texto))
            .SetBorder(Border.NO_BORDER)
            .SetFontSize(6f)
            .AddStyle(styleText);
            table.AddCell(cell);

        }

        public static void AddFilaFinal(Table table, dynamic texto, string Tipo)
        {
            Style styleText = new Style();
            if (Tipo == "String")
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.CENTER);
            }
            else
            {
                styleText = new Style()
.SetTextAlignment(TextAlignment.RIGHT);
                decimal numero = Convert.ToDecimal(texto);
                texto = numero.ToString("#,##0.00", CultureInfo.InvariantCulture);
            }

            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER)
                .SetBorderTop(new SolidBorder(ColorConstants.BLACK, 1));

            Cell cell = new Cell()
                .Add(new Paragraph(texto).SetBold())
                .SetBorder(Border.NO_BORDER)
                                .SetFontSize(6f)
                .AddStyle(styleText)
                   .AddStyle(styleCell);
            table.AddCell(cell);
        }

        private static string RetornaFechaCompleta(string sFecha)
        {
            string sfechaCompleta = "";
            int nAnioFecha = DateTime.Parse(sFecha).Year;
            int nMesFecha = DateTime.Parse(sFecha).Month;
            int nDiaFecha = DateTime.Parse(sFecha).Day;
            string sMesFecha = "";
            switch (nMesFecha)
            {
                case 1:
                    sMesFecha = "ENERO";
                    break;
                case 2:
                    sMesFecha = "FEBRERO";
                    break;
                case 3:
                    sMesFecha = "MARZO";
                    break;
                case 4:
                    sMesFecha = "ABRIL";
                    break;
                case 5:
                    sMesFecha = "MAYO";
                    break;
                case 6:
                    sMesFecha = "JUNIO";
                    break;
                case 7:
                    sMesFecha = "JULIO";
                    break;
                case 8:
                    sMesFecha = "AGOSTO";
                    break;
                case 9:
                    sMesFecha = "SEPTIEMBRE";
                    break;
                case 10:
                    sMesFecha = "OCTUBRE";
                    break;
                case 11:
                    sMesFecha = "NOVIEMBRE";
                    break;
                case 12:
                    sMesFecha = "DICIEMBRE";
                    break;
            }

            sfechaCompleta = " " + nDiaFecha + " DE " + sMesFecha + " DEL " + nAnioFecha + " ";

            return sfechaCompleta;

        }

    }
}
