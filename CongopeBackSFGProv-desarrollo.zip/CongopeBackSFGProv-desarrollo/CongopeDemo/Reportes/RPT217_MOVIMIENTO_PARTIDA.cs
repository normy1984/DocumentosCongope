﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Ocsp;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Congope.Empresas.Reportes
{
    public class RPT217_MOVIMIENTO_PARTIDA
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                var vReportes = new
                {
                    nTipoPresupuestoID = DatosReporte.param1,
                    sFechaDesde = DatosReporte.param2,
                    sFechaHasta = DatosReporte.param3,
                    sPartida = DatosReporte.param4
                };


                //string codEmpresa = Constantes.General.Empresa;
                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                int  codusu = DatosReporte.VarSesion.codUsu;
                int anio = DatosReporte.VarSesion.Anio;
                NpgsqlCommand cmd = new NpgsqlCommand();

                string sNombreReporte = "RPT217_MOVIMIENTO_PARTIDA";

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", sNombreReporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "P";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 9;";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];

                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA ///////////////////
                    ////////////////////////////////////////////////////

                    oReporte.numero_documento = $"DEL: {Convert.ToString(vReportes.sFechaDesde)} AL: {Convert.ToString(vReportes.sFechaHasta)}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE  
                    ////////////////////////////////////////////////////
                    sql = @"SELECT * FROM sps_movimiento_por_partida(@emp,@anio_bus,@f_desde,@f_hasta,@spartida)";
                    cmd.CommandText = sql;

                    cmd.Parameters.AddWithValue("@emp", NpgsqlDbType.Varchar, codEmpresa);
                    cmd.Parameters.AddWithValue("@anio_bus", NpgsqlDbType.Integer, anio);
                    cmd.Parameters.AddWithValue("@f_desde", NpgsqlDbType.Varchar, vReportes.sFechaDesde);
                    cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, vReportes.sFechaHasta);
                    cmd.Parameters.AddWithValue("@spartida", NpgsqlDbType.Varchar, vReportes.sPartida);
                    //
                    var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
                    Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

                    string html_detalle = "";

                    /***
                     * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
                     * para evitar la distorsion de la presentacion
                     */
                    float TotalReformas = 0;
                    float TotalCertificado = 0;
                    float TotalComprometido = 0;
                    float TotalDevengado = 0;
                    string sPartida = "";
                    string sNombrePartida = "";

                    foreach (var item in Datosprdetmov)
                    {
                        html_detalle += $@"
                        <tr>
                            <td style=""font-size: 10px;""><b>{item["fec_det"]}</b></td>
                            <td style=""font-size: 10px;""><b>{item["sig_acu_tip"]}</b></td>
                            <td style=""font-size: 10px;""><b>{item["des_cab"]}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["inicial"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["reforma"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["codificado"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["certificado"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["comprometido"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["devengado"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["por_comprometer"])}</b></td>
                            <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["por_devengar"])}</b></td>
                            <td style=""font-size: 10px;""><b>{item["num_com"]}</b></td>
                        </tr>";

                        TotalReformas += Convert.ToSingle(item["reforma"]);
                        TotalCertificado += Convert.ToSingle(item["certificado"]);
                        TotalComprometido += Convert.ToSingle(item["comprometido"]);
                        TotalDevengado += Convert.ToSingle(item["devengado"]);

                        sPartida = item["partida"];
                        sNombrePartida = item["nombre_partida"];
                    }

                    htmlContent = htmlContent.Replace("##PARTIDA##", Convert.ToString(sPartida));
                    htmlContent = htmlContent.Replace("##NOMBREPARTIDA##", Convert.ToString(sNombrePartida));

                    //REEMPLAZO DEL TOTAL
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));
                    htmlContent = htmlContent.Replace("##VALORTOTALREFORMAS##", string.Format("{0:N2}", TotalReformas));
                    htmlContent = htmlContent.Replace("##VALORTOTALCERTIFICADO##", string.Format("{0:N2}", TotalCertificado));
                    htmlContent = htmlContent.Replace("##VALORTOTALCOMPROMETIDO##", string.Format("{0:N2}", TotalComprometido));
                    htmlContent = htmlContent.Replace("##VALORTOTALDEVENGADO##", string.Format("{0:N2}", TotalDevengado));

                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;

                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
    }
}
