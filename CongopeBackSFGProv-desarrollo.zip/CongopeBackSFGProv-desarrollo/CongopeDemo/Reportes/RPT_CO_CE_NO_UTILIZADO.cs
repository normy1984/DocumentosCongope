﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using System.Text;

namespace Congope.Empresas.Reportes
{
    public class RPT_CO_CE_NO_UTILIZADO
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */

                var vReportes = new IngresoCertificacionCompromisoNoUtilizadosMo
                {
                    codemp = DatosReporte.VarSesion.CodEmp,
                    fecha_inicio = DatosReporte.param1,
                    fecha_final = DatosReporte.param2,
                    departamento = Convert.ToInt16(DatosReporte.param3),
                    estado = Convert.ToInt16(DatosReporte.param4),
                    tipo = DatosReporte.param5,
                };

                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                NpgsqlCommand cmd = new NpgsqlCommand();

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/

                var Nombre_Reporte = "RPT237_COMPROMISOS_NO_UTILIZADOS";

                if (vReportes.tipo == "CE")
                {
                    Nombre_Reporte = "RPT232_CERTIFIADOS_NO_UTILIZADOS";
                }

                string sql = @"
                                select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa; 
                                ";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", Nombre_Reporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/



                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];


                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"
                                SELECT men_html from mensajes_html p 
                                where p.men_codigo  = 10; 
                                ";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];


                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA prcabmov ///////////////////
                    ////////////////////////////////////////////////////


                    oReporte.numero_documento = $"DESDE : {vReportes.fecha_inicio.Substring(0, 10)} HASTA: {vReportes.fecha_final.Substring(0, 10)}";

                    var filtros = string.Empty;
                    filtros += (vReportes.departamento != 0) ? "POR DEPARTAMENTO - " : string.Empty;
                    filtros += (vReportes.estado != 0) ? "POR ESTADO - " : string.Empty;
                    filtros = (filtros == string.Empty) ? "- TODOS -" : "FILTROS : - "+ filtros;

                    oReporte.numero_documento += $"\n{filtros}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE prdetmov 
                    ///AQUI SE CONSTRUYE EL HTML RECURSIVO///////////////////
                    ////////////////////////////////////////////////////


                    var Datosprdetmov = CertificacionCompromisoNoUtilizadosBL.SqlCompromisoCertificacionesNoUtilizadas(vReportes);
                    StringBuilder htmlDetalle = new StringBuilder();

                    // Definir fragmentos HTML comunes
                    string plantillaFilaDepartamento = @"
                    <tr>
                        <td style=""font-size: 12px;"" colspan=""6""><strong>{0}</strong></td>
                    </tr>
                    <tr>
                        <td colspan=6><hr></td>
                    </tr>";

                    string plantillaFilaSubtotal = @"
                    <tr>
                        <td colspan=6><hr></td>
                    </tr>
                    <tr>
                        <td style=""font-size: 12px;text-align: right;"" colspan=5><strong>Subtotal:</strong></td>
                        <td style=""font-size: 12px;text-align: right;""><strong>{0:N2}</strong></td>
                    </tr>";

                    string plantillaFilaDatos = @"
                    <tr>
                        <td style=""font-size: 10px;"">{0}</td>
                        <td style=""font-size: 10px;"">{1}</td>
                        <td style=""font-size: 10px;"">{2}</td>
                        <td style=""font-size: 10px;"">{3}</td>
                        <td style=""font-size: 10px;word-break: break-all;max-width: 40%;"">{4}</td>
                        <td style=""font-size: 10px;text-align: right;"">{5:N2}</td>
                    </tr>";

                    string departamento = string.Empty;

                    if (Datosprdetmov.success)
                    {
                        var certificaciones = Datosprdetmov.result as List<CertificacionCompromisoNoUtilizadosMo>;

                        foreach (var item in certificaciones)
                        {
                            if (departamento != item.departamento && string.IsNullOrEmpty(departamento))
                            {
                                htmlDetalle.AppendFormat(plantillaFilaDepartamento, item.departamento);
                                departamento = item.departamento;
                            }
                            else if (departamento != item.departamento)
                            {
                                htmlDetalle.AppendFormat(plantillaFilaSubtotal, certificaciones.Where(x => x.departamento == departamento).Sum(x => x.valor));
                                htmlDetalle.AppendFormat(plantillaFilaDepartamento, item.departamento);
                                departamento = item.departamento;
                            }

                            htmlDetalle.AppendFormat(plantillaFilaDatos, item.siglasnum, item.documento, item.fecha, item.estado, item.concepto, item.valor);
                        }

                        // Agregar la fila de subtotal final para el último departamento
                        htmlDetalle.AppendFormat(plantillaFilaSubtotal, certificaciones.Where(x => x.departamento == departamento).Sum(x => x.valor));
                    }

                    // Reemplazar el marcador en el contenido HTML
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", htmlDetalle.ToString());


                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
    }
}
