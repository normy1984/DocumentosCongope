﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Ocsp;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Congope.Empresas.Reportes
{
    public class RPT220_ESTADOEJEPRE
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            //string fecha_hasta = "";
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                var vReportes = new
                {
                    fecha_hasta = DatosReporte.param1
                };


                //string codEmpresa = Constantes.General.Empresa;
                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                int  codusu = DatosReporte.VarSesion.codUsu;
                NpgsqlCommand cmd = new NpgsqlCommand();

                string sNombreReporte = "RPT220_ESTADOEJEPRE";

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", sNombreReporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 7;";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];

                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA ///////////////////
                    ////////////////////////////////////////////////////

                    oReporte.numero_documento = $"AL : {Convert.ToString(vReportes.fecha_hasta)}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE  
                    ////////////////////////////////////////////////////
                    sql = @"SELECT * FROM sp_ejecucion_presupuestaria(@f_hasta)";
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, vReportes.fecha_hasta);

                    var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
                    Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

                    string html_detalle = "";

                    /***
                     * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
                     * para evitar la distorsion de la presentacion
                     */

                    string sGrupo = "";
                    int sResultado;
                    string sDescripcion = "";
                    foreach (var item in Datosprdetmov)
                    {
                        sResultado = 0;
                        sGrupo = item["grupo"];
                        sDescripcion = item["descripcion"];
                        sDescripcion = sDescripcion.ToString().Trim().Substring(0, 3);
                        if (sDescripcion == "(=)")
                        {
                            sResultado = 1;
                        }


                        if (int.Parse(sGrupo) == 0 && sResultado == 0)
                        {
                            html_detalle += $@"
                            <tr>
                                <td style=""font-size: 10px;word-break: break-all;max-width: 5%; color:rgb(255,0,0); ""></td>
                                <td style=""font-size: 10px;""><b>{item["descripcion"]}</b></td>
                                <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["codificado"])}</b></td>
                                <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["devengado"])}</b></td>
                                <td style=""font-size: 10px;text-align: right;""><b>{string.Format("{0:N2}", item["diferencia"])}</b></td>
                                <td style=""font-size: 10px;text-align: right;""></td>
                            </tr>";
                        }
                        else
                        {
                            if (sResultado == 1)
                            {
                                html_detalle += $@"
                                <tr>
                                    <td style=""font-size: 10px;word-break: break-all;max-width: 5%;""></td>
                                    <td style=""font-size: 10px;""><FONT COLOR=""blue""><b>{item["descripcion"]}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["codificado"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["devengado"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["diferencia"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""></td>
                                </tr>";
                            }
                            else
                            {
                                html_detalle += $@"
                                <tr>
                                    <td style=""font-size: 8px;word-break: break-all;max-width: 5%;"">{item["grupo"]}</td>
                                    <td style=""font-size: 8px;"">{item["descripcion"]}</td>
                                    <td style=""font-size: 8px;text-align: right;"">{string.Format("{0:N2}", item["codificado"])}</td>
                                    <td style=""font-size: 8px;text-align: right;"">{string.Format("{0:N2}", item["devengado"])}</td>
                                    <td style=""font-size: 8px;text-align: right;"">{string.Format("{0:N2}", item["diferencia"])}</td>
                                    <td style=""font-size: 8px;text-align: right;"">{string.Format("{0:N2}", item["porcentaje"])}</td>
                                </tr>";
                            }
                            
                        }
                    }
                  
                    //REEMPLAZO DEL TOTAL
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));


                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;

                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
        //public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        //{
        //    //string fecha_hasta = "";
        //    try
        //    {
        //        /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
        //        */
        //        var vReportes = new
        //        {
        //            fecha_hasta = DatosReporte.param1,
        //            ing_gas = DatosReporte.param2,
        //            nTodos = DatosReporte.param3,
        //            nNivel = DatosReporte.param4,
        //            sOperador = DatosReporte.param5
        //        };

        //        //fecha_hasta = "2024-06-20";
        //        string codEmpresa = Constantes.General.Empresa;
        //        NpgsqlCommand cmd = new NpgsqlCommand();

        //        /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
        //        string sql = @"select * from piepagina p 
        //                        where trim(p.reporte)  like @nombreReporte
        //                        and p.codemp = @codEmpresa; 
        //                        ";
        //        cmd.CommandText = sql;
        //        cmd.Parameters.AddWithValue("@nombreReporte", "RPTCEDULAGASTOS");
        //        cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
        //        var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

        //        /** CARGA EL CUERPO DEL REPORTE **/
        //        if (DatosBase.success)
        //        {
        //            var oReporte = DatosBase.result[0];

        //            /**
        //             * ORIENTACION
        //             * L: landscape/Horizontal
        //             * P: portrait /Vertical 
        //             * */
        //            oReporte.orientacion = "L";

        //            /*** CONTENIDO HTML DESDE BASE DE DATOS
        //                     * */
        //            sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 5;";
        //            cmd.CommandText = sql;
        //            var DatosHtml = Exec_sql.cargarDatosJson(cmd);
        //            DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
        //            string htmlContent = DatosHtml[0]["men_html"];

        //            ////////////////////////////////////////////////////
        //            ///DATOS DE LA CABECERA ///////////////////
        //            ////////////////////////////////////////////////////

        //            oReporte.numero_documento = $"AL : {Convert.ToString(vReportes.fecha_hasta)}";

        //            ////////////////////////////////////////////////////
        //            ///DATOS DEL DETALLE  
        //            ////////////////////////////////////////////////////
        //            //sql = @"SELECT * FROM sps_cedula_presupuestaria('0004', '" + vReportes.fecha_hasta + "', " + vReportes.ing_gas + ", " + vReportes.nTodos + ", "+ vReportes.nNivel + ", '" + vReportes.sOperador + "', '') ;";
        //            cmd.CommandText = sql;

        //            var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
        //            Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

        //            float Total_asig_ini = 0;
        //            float Total_reformas = 0;
        //            float Total_codificado = 0;
        //            float Total_comprometido = 0;
        //            float Total_devengado = 0;
        //            float Total_por_comprometer = 0;
        //            float Total_por_devengar = 0;
        //            float Total_pagado = 0;

        //            string html_detalle = "";

        //            /***
        //             * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
        //             * para evitar la distorsion de la presentacion
        //             */

        //            foreach (var item in Datosprdetmov)
        //            {
        //                html_detalle += $@"
        //                            <tr>
        //                                <td style=""font-size: 10px;word-break: break-all;max-width: 10%;"">{item["partida"]}</td>
        //                                <td style=""font-size: 10px;"">{item["nombre"]}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["asig_ini"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["reformas"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["codificado"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["comprometido"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["devengado"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["por_comprometer"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["por_devengar"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["pagado"])}</td>
        //                            </tr>";

        //                Total_asig_ini = item["tot_asig_ini"];
        //                Total_reformas = item["tot_reformas"];
        //                Total_codificado = item["tot_codificado"];
        //                Total_comprometido = item["tot_comprometido"];
        //                Total_devengado = item["tot_devengado"];
        //                Total_por_comprometer = item["tot_por_comprometer"];
        //                Total_por_devengar = item["tot_por_devengar"];
        //                Total_pagado = item["tot_pagado"];

        //            }

        //            //REEMPLAZO DEL TOTAL
        //            htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_ASIG##", string.Format("{0:N2}", Total_asig_ini));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_REFORMAS##", string.Format("{0:N2}", Total_reformas));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_CODIFICADO##", string.Format("{0:N2}", Total_codificado));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_COMPROMETIDO##", string.Format("{0:N2}", Total_comprometido));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_DEVENGADO##", string.Format("{0:N2}", Total_devengado));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_POR_COMPROMETER##", string.Format("{0:N2}", Total_por_comprometer));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_POR_DEVENGAR##", string.Format("{0:N2}", Total_por_devengar));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_PAGADO##", string.Format("{0:N2}", Total_pagado));

        //            oReporte.cuerpo_reporte = htmlContent;

        //            return PdfBL.GenerarPDFBase64(oReporte);


        //        }
        //        else
        //        {
        //            return DatosBase;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        SeguridadBL.WriteErrorLog(e);
        //        return new
        //        {
        //            success = false,
        //            message = "Error: " + e.Message,
        //            result = ""
        //        };
        //    }


        //}
        //fin

    }
}
