﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using Newtonsoft.Json;
using System.Text.Json;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    public class FirmaEcController : Controller
    {

        private readonly FirmaEcBL _firmaEcBL;
        private readonly FirmaEcRecibeBL _firmaEcRecibeBL;

        public FirmaEcController(FirmaEcBL firmaEcBL,
            FirmaEcRecibeBL firmaEcRecibeBL
            )
        {
            _firmaEcBL = firmaEcBL;
            _firmaEcRecibeBL = firmaEcRecibeBL;
        }
        /// <summary>
        /// Funcion que permite subir los archivos al servidor de Firmas para firmarlo
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("CargaArchivoFirma")]
        public async Task<dynamic> CargarArchivoAsync(dynamic InformacionCargaArchivos)
        {


            return await _firmaEcBL.CargarArchivoAsync(InformacionCargaArchivos);
            //return aver;

        }


        /// <summary>
        /// Función que recibe el o los archivos firmados para almacenarlos en una ubicacion o en una base de datos
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("recibeFirmados")]
        public async Task<IActionResult> Upload([FromBody] FirmaEcRecibeDocumentoMo request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.NombreDocumento) || string.IsNullOrWhiteSpace(request.Archivo))
                return BadRequest("Invalid Request");

            var result = await _firmaEcRecibeBL.RecibeFirmados(request);

            return result == "OK" ? Ok("OK") : StatusCode(500, result);
        }

        /// <summary>
        /// Esta funcion recibe la informacion de un filtro para visualizar los documentos y devuelve el primer elemento
        /// </summary>
        /// <param name="filtro"></param>
        /// <returns></returns>
        [HttpPost("ObtenerBase64")]
        public dynamic DocumentoBase64Firmas(Dictionary<string, object> filtro)
        {
            // Validar el request
            return _firmaEcBL.DocumentoBase64Firmas(filtro);
           
        }


    }
}
