﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CorreoController : Controller
    {

        /// <summary>
        /// Funcion que actualiza los datos del body de cada una de las opciones del aprobar o desaprobar de los usuarios
        /// </summary>
        /// <param name="oCorreo"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic Post([FromBody] CorreoMo oCorreo)
        {
           return new CorreoBL().Enviar(oCorreo);
        }

        
    }
}
