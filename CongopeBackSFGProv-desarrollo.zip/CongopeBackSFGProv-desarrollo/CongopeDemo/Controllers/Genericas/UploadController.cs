﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Congope.Empresas.Data;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UploadController : Controller
    {
        /// <summary>
        /// Controlador que elimina el registro de archivo adjunto
        /// </summary>
        /// <param name="IdArchivo"></param>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        [HttpDelete("{IdArchivo}")]
        public dynamic DeleteArchivosCargados(int IdArchivo, [FromBody] UploadMo uploadMo)
        {
            return UploadBL.DeleteArchivosCargados(uploadMo);
        }

        /// <summary>
        /// Controlador que llama a la funcion para crear un nuevo archivo adjunto
        /// </summary>
        /// <param name="file"></param>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic UploadFile(IFormFile file, [FromForm] UploadMo uploadMo)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("No se proporcionó ningún archivo o el archivo está vacío.");
            }

          
            if (uploadMo == null)
            {
                return BadRequest("No se proporcionó ningún objeto para la carga útil.");
            }

            if (Conexion.GuardaArchivosRepositorio)
            {
                return UploadBL.UploadFile(file, uploadMo);
            }
            else {
                return SharepointBL.UploadFile(file, uploadMo);
            }


            //
        }

        /// <summary>
        /// Funcion que lista los archivos adjuntos
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>

        [Route("CargarList")]
        [HttpPost]
        public dynamic CargarList(UploadMo uploadMo)
        {
            return UploadBL.ListArchivosCargados(uploadMo);
        }


        /// <summary>
        /// Controlador que devuelve los archivos en base 64 para mostrarlos en el angular
        /// </summary>
        /// <param name="uploadMo"></param>
        /// <returns></returns>
        [Route("VerArchivo")]
        [HttpPost]
        public dynamic VerArchivosRepositorio(UploadMo uploadMo)
        {
            if (Conexion.GuardaArchivosRepositorio)
            {
                return UploadBL.VerArchivosRepositorio(uploadMo);
            }
            else
            {
                return SharepointBL.DescargarDesdeSharepoint(uploadMo);
            }
            
        }


    }
}

