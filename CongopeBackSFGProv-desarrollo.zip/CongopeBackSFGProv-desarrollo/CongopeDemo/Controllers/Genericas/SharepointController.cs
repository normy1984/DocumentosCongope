﻿using Congope.Empresas.BussinessLogic.Genericas;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    public class SharepointController : Controller
    {
        [HttpGet("Buscar")]
        public dynamic BuscarArchivosPorContenido(string campo)
        {

            return SharepointBL.BuscarArchivosPorContenido(campo);
        }

      /*  [HttpPost("upload")]
        public dynamic UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("Archivo no proporcionado.");

            using var ms = new MemoryStream();
            file.CopyTo(ms);
            var fileBytes = ms.ToArray();

            return SharepointBL.UploadFile(fle, "contabilidad");

        }*/
    }
}
