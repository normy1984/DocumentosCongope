﻿using Congope.Empresas.BussinessLogic.Bpm;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Bpm;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Bpm
{
    [Route("api/[controller]")]
    [ApiController]
    public class BpmController : Controller
    {
        private readonly BpmBl _BpmBl;
        private readonly DocumentoBpmBL _DocumentoBl;

        public BpmController(
            BpmBl bpmBl, 
            DocumentoBpmBL documentoBl
            )
        {
            _BpmBl = bpmBl;
            _DocumentoBl = documentoBl;
        }

        // 1️⃣ Iniciar proceso
        [HttpPost("IniciarBpm")]
        public async Task<ApiResultMo<string>> IniciarFlujo([FromBody] dynamic datosInicio)
        {
            var result = await _BpmBl.IniciarFlujoYGuardarDocumento(datosInicio);
            return ApiResultMo<string>.Ok(result);
        }

        // 2️⃣ Completar tarea
        [HttpPost("CompletarTarea")]
        public async Task<ApiResultMo<string>> CompletarTarea([FromBody] TareaCompletaBpmMo dto)
        {
            await _BpmBl.CompleteTaskAsync(dto.TaskId, dto.ProcessId, dto.Aprobado);
            return ApiResultMo<string>.Ok("Tarea completada");
        }

        // 3️⃣ Obtener tareas de un usuario
        [HttpGet("TareasUsuario/{assignee}")]
        public async Task<IActionResult> TareasUsuario(string assignee)
        {
            var tasks = await _BpmBl.GetTasksByUserAsync(assignee);
            return Ok(tasks);
        }

        // 4️⃣ Obtener tareas activas de un documento
        [HttpGet("TareasDocumento/{processInstanceId}")]
        public async Task<ApiResultMo<IEnumerable<TareaBpmMo>>> TareasDocumento(string processInstanceId)
        {
            var tasks = await _BpmBl.GetTasksByDocumentoAsync(processInstanceId);

            // Validar si la colección viene vacía o nula
            if (tasks == null || !tasks.Any())
            {
                return ApiResultMo<IEnumerable<TareaBpmMo>>.Fail("Ya no hay tareas"); // devuelve lista vacía
                                                                                        // o también puedes devolver un mensaje
                                                                                        // return ApiResultMo<IEnumerable<TareaBpmMo>>.Ok(null, "No se encontraron tareas");
            }
            // Si tiene tareas, se envían normalmente
            return ApiResultMo<IEnumerable<TareaBpmMo>>.Ok(tasks);
        }

        // 5️⃣ Obtener detalle de una tarea
        [HttpGet("DetalleTarea/{taskId}")]
        public async Task<IActionResult> DetalleTarea(string taskId)
        {
            var task = await _BpmBl.GetTaskDetailAsync(taskId);
            if (task == null) return NotFound("Tarea no encontrada");
            return Ok(task);
        }

        // 6️⃣ Obtener historial de un documento
        [HttpGet("HistorialDocumento/{processInstanceId}")]
        public async Task<IActionResult> HistorialDocumento(string processInstanceId)
        {
            var historial = await _BpmBl.GetHistorialByDocumentoAsync(processInstanceId);
            return Ok(historial);
        }

        // 7️⃣ Obtener variables de un documento
        [HttpGet("VariablesDocumento/{processInstanceId}")]
        public async Task<IActionResult> VariablesDocumento(string processInstanceId)
        {
            var variables = await _BpmBl.GetVariablesByDocumentoAsync(processInstanceId);
            return Ok(variables);
        }

        // 8️⃣ Obtener estado resumido de un documento
        [HttpGet("EstadoDocumento/{processInstanceId}")]
        public async Task<IActionResult> EstadoDocumento(string processInstanceId)
        {
            var estado = await _BpmBl.GetEstadoDocumentoAsync(processInstanceId);
            return Ok(estado);
        }
        // 9️⃣ Anular un documento/proceso
        [HttpDelete("AnularDocumento/{processInstanceId}")]
        public async Task<IActionResult> AnularDocumento(string processInstanceId, [FromQuery] string razon = "Documento anulado por usuario")
        {
            await _BpmBl.AnularDocumentoAsync(processInstanceId, razon);
            return Ok($"Documento con proceso {processInstanceId} anulado correctamente");
        }

        // obtener el id del documento por Id del documento
        [HttpGet("{id}")]
        public async Task<ApiResultMo<DocumentoBpmMo>> ObtenerPorId(string id, int Anio)
        {
            var doc = await _DocumentoBl.ObtenerDocumentoPorIdAsync(id, Anio);
            if (doc == null)
                return ApiResultMo<DocumentoBpmMo>.Fail("Documento no encontrado");
            return ApiResultMo<DocumentoBpmMo>.Ok(doc);
        }

    }
}
