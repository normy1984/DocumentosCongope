﻿using Congope.Empresas.BussinessLogic.Bpm;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Bpm;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Bpm
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentoBpmController : Controller
    {
      
        private readonly DocumentoBpmBL _DocumentoBl;

        public DocumentoBpmController(
            DocumentoBpmBL documentoBl
            )
        {
           
            _DocumentoBl = documentoBl;
        }

        // 1️⃣ Iniciar proceso
        [HttpGet]
        public async Task<ApiResultMo<List<DocumentoBpmMo>>> TareasUsuario()
        {
            var tasks = await _DocumentoBl.ListarDocumentosAsync();
            return ApiResultMo<List<DocumentoBpmMo>>.Ok(tasks);
        }
    }
}
