﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Administracion
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsuariosController : Controller
    {
        /// <summary>
        /// Lista los usuarios disponibles para poder editarlos
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public dynamic ListarUsuarios()
        {
            return UsuariosBL.ListarUsuarios();
        }

        /// <summary>
        /// Funcion que retorna el tipo de login de la aplicacion, sirve para cuando la autenticacion es Ldap
        /// el usuario no pueda resetear contraseñas
        /// </summary>
        /// <returns></returns>

        [HttpGet("ValidarTipoIngreso")]
        public dynamic ValidarTipoIngreso()
        {
            var respuesta = new ApiResultMo<bool>();
            respuesta.success = true;
            respuesta.result = Conexion.TipoLogin == "ldap";

            return respuesta;
        }

        /// <summary>
        /// Carga de informacion del usuario de acuerdo al perfil que tiene asignado
        /// </summary>
        /// <param name="codUsu"></param>
        /// <returns></returns>
        [HttpGet("CargarMenuPerfil/{codUsu}")]
        public dynamic CargarMenuPerfil(int codUsu)
        {
            return UsuariosBL.CargarMenuPerfil(codUsu, 1, "");
        }


        /// <summary>
        /// Listado de funcionarios a partir de los que se puede crear un usuario
        /// </summary>
        /// <returns></returns>
        [HttpGet("ListarFuncionarios")]

        public dynamic ListarFuncionarios()
        {
            return UsuariosBL.ListarFuncionarios();
        }

        /// <summary>
        /// Servicio que carga a un usuario de acuerdo al codigo
        /// </summary>
        /// <param name="CodUsu"></param>
        /// <returns></returns>
        [HttpGet("{CodUsu}")]

        public dynamic CargarUsuarioCodigo(int CodUsu)
        {
            return UsuariosBL.CargarUsuarioCodigo(CodUsu);
        }

        /// <summary>
        /// Servicio que retorna los menus de aprobar y desaprobar
        /// </summary>
        /// <returns></returns>
        [HttpGet("MenuAprobarDesaprobar")]
        public dynamic CargarMenusAprobarDesaprobar()
        {
            return UsuariosBL.CargarMenusAprobarDesaprobar();
        }

        /// <summary>
        /// Servicio que actualiza a los usuarios del sistema
        /// </summary>
        /// <param name="oUsuariosMO"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic ActualizarUsuario(UsuariosMO oUsuariosMO)
        {
            return UsuariosBL.ActualizarUsuario(oUsuariosMO);
        }


        /// <summary>
        /// Opciones de aprobar o desaprobar
        /// </summary>
        /// <param name="vConsultaAprobarDocumentosMo"></param>
        /// <returns></returns>
        [HttpPost("CargarOpcionesAprobarDesaprobar")]
        public dynamic CargarOpcionesAprobarDesaprobar(ConsultaAprobarDocumentosMo vConsultaAprobarDocumentosMo)
        {
            return UsuariosBL.CargarOpcionesAprobarDesaprobar(vConsultaAprobarDocumentosMo);
        }

        /// <summary>
        /// Servicio que realiza la aprobacion o desaprobacion de las opciones del usuario
        /// </summary>
        /// <param name="vAprobarDesaprobarDocumentosMo"></param>
        /// <returns></returns>
        [HttpPost("ApruebaDesapruebaDocumentos")]
        public dynamic ApruebaDesapruebaDocumentos(AprobarDesaprobarDocumentosMo vAprobarDesaprobarDocumentosMo)
        {
            return UsuariosBL.ApruebaDesapruebaDocumentos(vAprobarDesaprobarDocumentosMo);
        }


        /// <summary>
        /// Funcion utilizada para el reset de la contraseña
        /// </summary>
        /// <param name="Codigo_usuario"></param>
        /// <returns></returns>
        [HttpPut("ResetearContrasena/{Codigo_usuario}")]
        public dynamic ResetearContrasena(int Codigo_usuario)
        {
            return UsuariosBL.ResetearContrasena(Codigo_usuario);
        }

        /// <summary>
        /// Funcion utilizada para el reset de la contraseña
        /// </summary>
        /// <param name="Codigo_usuario"></param>
        /// <returns></returns>
        [HttpPut("CambiarContrasena/{Codusu}")]
        public dynamic CambiarContrasena(int Codusu, CambiarContrasenaMo cambiarContrasenaMo)
        {
            return UsuariosBL.CambiarContrasena(cambiarContrasenaMo);
        }

        /// <summary>
        /// Servicio que da de alta o baja a los usuarios
        /// </summary>
        /// <param name="Codusu"></param>
        /// <returns></returns>
        [HttpPut("ActivarUsuario/{Codusu}")]
        public dynamic ActivarUsuario(int Codusu)
        {
            return UsuariosBL.ActivarInactivarUsuario(Codusu, 1);
        }

        /// <summary>
        /// Servicio que inactiva a un usuario
        /// </summary>
        /// <param name="Codusu"></param>
        /// <returns></returns>
        [HttpPut("InactivarUsuario/{Codusu}")]
        public dynamic InactivarUsuario(int Codusu)
        {
            return UsuariosBL.ActivarInactivarUsuario(Codusu, 2);
        }

        /// <summary>
        /// Funcion que realiza la insercion de los usuarios
        /// </summary>
        /// <param name="insertarUsuariosMo"></param>
        /// <returns></returns>
        [HttpPost("InsertarUsuario")]
        public dynamic InsertarUsuario(InsertarUsuariosMo insertarUsuariosMo)
        {
            return UsuariosBL.InsertarUsuario(insertarUsuariosMo);
        }

        /// <summary>
        /// Funcion que llama al procedimiento de actualizacion de los usuarios
        /// </summary>
        /// <param name="actualizarUsuariosMo"></param>
        /// <returns></returns>
        [HttpPost("ActualizarGeneralUsuario")]
        public dynamic ActualizarGeneralUsuario(ActualizarUsuariosMo actualizarUsuariosMo)
        {
            return UsuariosBL.ActualizarGeneralUsuario(actualizarUsuariosMo);
        }


    }
}
