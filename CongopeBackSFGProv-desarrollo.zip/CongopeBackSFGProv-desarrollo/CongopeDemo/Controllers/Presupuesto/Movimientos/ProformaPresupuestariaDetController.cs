﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.BussinessLogic.Presupuesto;
using Microsoft.AspNetCore.Mvc;
using Congope.Empresas.Models.Presupuesto.Movimientos;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProformaPresupuestariaDetController
    {
        [HttpGet]
        public dynamic Get(string codemp, int anio, string sig_tip, int acu_tip)
        {
            return ProformaPresupuestariaDetBL.Listar(codemp, anio, sig_tip, acu_tip);
        }


        [HttpPost("detalle")]
        public dynamic InsertaActualizaDetallePresupuesto([FromBody] List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            return ProformaPresupuestariaDetBL.InsertarActualizar_DetalleMovimientosPresupuesto(compromisoDetalleMoList);
        }


        //[HttpPost("detalle")]
        //public dynamic InsertaActualizaDetallePresupueSto([FromBody] List<CompromisoDetalleMo> compromisoDetalleMoList)
        //{
        //    return CompromisoBL.InsertarActualizar_DetalleCompromisoList(compromisoDetalleMoList);
        //}

    }
}
