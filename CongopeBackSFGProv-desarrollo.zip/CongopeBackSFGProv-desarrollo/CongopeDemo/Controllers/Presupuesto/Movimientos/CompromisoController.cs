﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompromisoController : ControllerBase
    {
        /// <summary>
        /// LLamada para insertar o actualizar los compromisos
        /// </summary>
        /// <param name="compromisoCabeceraMo"></param>
        /// <returns></returns>
        [HttpPost("cabecera")]
        public dynamic InsertUpdateCabecera([FromBody] CompromisoCabeceraMo compromisoCabeceraMo)
        {
            return CompromisoBL.InsertarActualizar_CabeceraCompromiso(compromisoCabeceraMo);
        }
        /// <summary>
        /// Llamada para actualizar o insertar los detalles
        /// </summary>
        /// <param name="compromisoDetalleMoList"></param>
        /// <returns></returns>

        [HttpPost("detalle")]
        public dynamic InsertUpdateDetalle([FromBody] List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            return CompromisoBL.InsertarActualizar_DetalleCompromisoList(compromisoDetalleMoList);
        }

        /// <summary>
        /// Llamada para listar los detalles por codigo
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpPost("CertDetalle")]
        public dynamic ListarDetalleCompromisoCertificadoCodigo(AnularCompromisoCabeceraMo acu_tip)
        {
            return CompromisoBL.ListarDetalleCompromisoCertificadoCodigo(acu_tip);
        }

        /// <summary>
        /// Funcion para listar las cabeceras de los certificados
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpPost("CertCebecera")]
        public dynamic ListarCebeceraNuevoCompromisoCertificadoCodigo(MovimientosPresupuestariosCaebeceraMO acu_tip)
        {
            return CompromisoBL.ListarCebeceraNuevoCompromisoCertificadoCodigo(acu_tip);
        }

        /// <summary>
        /// Llamada para aprobar el Compromiso Presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        [HttpPost("Aprobar")]
        public dynamic AprobarCompromisoPresupuestario(AprobarCompromisoCabeceraMo acu_tip)
        {
            return CompromisoBL.AprobarCompromisoPresupuestario(acu_tip);
        }


        /// <summary>
        /// Lllamada para desaprobar el compromiso presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        [HttpPost("Desaprobar")]
        public dynamic DesAprobarCompromisoPresupuestario(MovimientosPresupuestariosCaebeceraMO acu_tip)
        {
            return CompromisoBL.DesAprobarCompromisoPresupuestario(acu_tip);
        }


        /// <summary>
        /// Llamada para anular el compromiso presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpPost("Anular")]
        public dynamic AnularCompromisoPresupuestario(AnularCompromisoCabeceraMo acu_tip)
        {
            return CompromisoBL.AnularCompromisoPresupuestario(acu_tip);
        }

        /// <summary>
        /// Llamada para mostrar las certificaciones presupuestarias habilitadas
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>

        [HttpPost("ListCertificacion")]
        public dynamic ListCertificacionesPresupuestariasHabilitadas(MovimientosPresupuestariosCaebeceraMO sig_tip)
        {
            return CompromisoBL.ListCertificacionesPresupuestariasHabilitadas(sig_tip);
        }


        /// <summary>
        /// Carga de la lista de los compromisos presupuestarios
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>

        [HttpPost("ListarCompromisos")]
        public dynamic ListarCompromisosPresupuestarios(MovimientosPresupuestariosCaebeceraMO sig_tip)
        {
            return CompromisoBL.ListarCompromisosPresupuestarios(sig_tip);
        }
        /// <summary>
        /// Funcion que trae los datos del administrador de contrato
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>
        [HttpPost("ListarAdministradores")]
        public dynamic ListarAdministradorContrato(MovimientosPresupuestariosCaebeceraMO sig_tip)
        {
            return CompromisoBL.ListarAdministradorContrato(sig_tip);
        }

        /// <summary>
        /// Funcion post para cargar la informacion de la cabecera del movimiento presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        [HttpPost("ListarMovimientoPresupuestariosCodigo")]
        public dynamic ListarMovimientoPresupuestariosCodigo(MovimientosPresupuestariosCaebeceraMO in_acu_tip)
        {

            return CompromisoBL.ListarMovimientoPresupuestariosCodigo(in_acu_tip);


        }



        /// <summary>
        /// Llamada para mostrar las certificaciones para asociar o desasociar
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>

        [HttpPost("AsociarCertificacion")]
        public dynamic AsociarDesasociarCertificados(AsociarCompromisoCabeceraMo sig_tip)
        {
            return CompromisoBL.AsociarDesasociarCertificados(sig_tip);
        }

        /// <summary>
        /// Funcion que permite asociar o desasociar certificaciones
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>

        [HttpPost("IU_AsociarCertificacion")]
        public dynamic IU_AsociarDesasociarCertificados(IU_AsociarCompromisoCabeceraMo sig_tip)
        {
            return CompromisoBL.IU_AsociarDesasociarCertificados(sig_tip);
        }
    }
}
