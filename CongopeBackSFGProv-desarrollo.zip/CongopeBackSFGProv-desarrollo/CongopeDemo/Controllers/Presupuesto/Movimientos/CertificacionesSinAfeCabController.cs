﻿using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class CertificacionesSinAfeCabController : ControllerBase
    {
        [HttpPost("ListarCertificacionesSinAfeCab")]
        public dynamic ListarCertificacionesSinAfeCab(CertificacionesSinAfeCabMO certificacionSinAfe)
        {
            return CertificacionesSinAfeCabBL.ListarCertificacionesSinAfeCab(certificacionSinAfe);
        }
        [HttpPost("CertificacionSinAfeCabCod")]
        public dynamic CertificacionSinAfeCabCod(CertificacionesSinAfeCabMO certificacionSinAfe)
        {
            return CertificacionesSinAfeCabBL.BuscarCertificacionSinAfeCabCod(certificacionSinAfe);
        }

        [HttpPost("PartidaSinAfeCabecera")]
        public dynamic Post(PartidaSinAfeCabMO certificacionSinAf)
        {
            return PartidasPresupuestariasDetSinAfeBL.InsertarActualizar_PartidasSinAfeCab(certificacionSinAf);
        }

        [HttpPost("PartidaSinAfeDetalle")]
        public dynamic Post(PartidaSinAfeDetMO partidapr)
        {      
            
            return PartidasPresupuestariasDetSinAfeBL.InsertarActualizar_PartidasSinAfeDet(partidapr          
                );
        }



        [HttpPost("ListarPartidasCerSinAfe")]
        public dynamic ListarDetPartidasSinAfe(PartidaSinAfeDetMO certificacionSinAfe)
        {
            return PartidasPresupuestariasDetSinAfeBL.ListarDetPartidasSinAfe(certificacionSinAfe);
        }
    }
}
