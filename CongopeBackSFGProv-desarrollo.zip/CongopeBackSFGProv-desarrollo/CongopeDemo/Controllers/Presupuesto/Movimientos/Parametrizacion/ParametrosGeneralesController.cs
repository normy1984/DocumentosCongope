﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParametrosGeneralesController
    {
        [HttpGet]
        public dynamic Get(int nCodtab)
        {
            return ParametrosGeneralesBL.ListaParametrosGenerales(nCodtab);
        }

        //[HttpPost("inserta_actualiza_ciu")]
        //public dynamic Inserta_Actualiza_CIU(CiuMO ciuMO)
        //{
        //    return ListaCiuBL.Insertar_Actualiza_CIU(ciuMO);
        //}

        [HttpPut("ActivarDesactivarParametro/{codtab},{codigo},{estado},{datoadi}")]
        public dynamic ActivarDesactivarParametro(int codtab, int codigo, int estado, string datoadi = "")
        {
            return ParametrosGeneralesBL.ActivarDesactivarParametro(codtab,codigo, estado, datoadi);
        }

    }
}
