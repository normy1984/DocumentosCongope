﻿using Congope.Empresas.BussinessLogic.Parametrizacion;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Parametrizacion
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EstructuraPartidaController : Controller
    {
        /// <summary>
        /// FUNCION UTILIZADA PARA CARGAR LA INFORMACION DE LA ESTRUCTURA DE LA PARTIDA PRESUPUESTARIA
        /// </summary>
        /// <param name="sel_Estructura"></param>
        /// <returns></returns>
        [HttpPost("ListarEstructura")]
        public dynamic ListarEstructuraPartidas(Sel_EstructuraPartidaMo sel_Estructura)
        {
            return EstructuraPartidasBL.ListarEstructuraPartidas(sel_Estructura);
        }

        /// <summary>
        /// FUNCION PARA ACTUALIZAR LA INFORMACION DE LA ESTRUCTURA DE PARTIDAS
        /// </summary>
        /// <param name="sel_Estructura"></param>
        /// <returns></returns>
        [HttpPost("InsertarActualizarEstructura")]
        public dynamic InsertarActualizar_EstructuraPartidas(List<Actualizar_EstructuraPartidaMo> sel_Estructura)
        {
            return EstructuraPartidasBL.InsertarActualizar_EstructuraPartidas(sel_Estructura);
        }

/// <summary>
/// VALIDAR SI EL SISTEMA FUE CARGADO DESDE EL GPRD
/// </summary>
/// <param name="sessionMo"></param>
/// <returns></returns>
        [HttpPost("ValidaGprd")]
        public dynamic ValidarEsGprd(ParamSessionMo sessionMo)
        {
            return EstructuraPartidasBL.ValidarEsGprd(sessionMo);
        }


        /// <summary>
        /// VALIDAR SI EL EN EL SISTEMA YA HAY MOVIMIENTOS
        /// </summary>
        /// <param name="sessionMo"></param>
        /// <returns></returns>
        [HttpPost("ValidaHayMovimientos")]
        public dynamic ValidarHayMOvimientos(ParamSessionMo sessionMo)
        {
            return EstructuraPartidasBL.ValidarHayMOvimientos(sessionMo);
        }
    }
}
