﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientoPorPartidaController
    {
        [HttpGet]
        public dynamic Get(string codemp, int anio, string sFechaDesde, string sFechaHasta, string sPartida)
        {
            return MovimientoPorPartidaBL.Listar(codemp, anio, sFechaDesde, sFechaHasta, sPartida);
        }
    }
}
