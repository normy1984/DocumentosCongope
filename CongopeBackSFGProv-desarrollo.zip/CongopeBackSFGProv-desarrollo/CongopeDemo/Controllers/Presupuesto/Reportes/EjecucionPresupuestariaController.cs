﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class EjecucionPresupuestariaController
    {
        [HttpGet]
        /*  public dynamic Get(string sFechaHasta)
          {
              return EjecucionPresupuestariaBL.Listar(sFechaHasta);
          }*/
        public dynamic Get([FromQuery] FiltroEjecucionPresupuestariaMO ejecucion)
        {
            return EjecucionPresupuestariaBL.Listar(ejecucion);
        }
        [HttpGet("ListarPorGupoNaturaleza")]
        public dynamic GetRepresentantesGrupoNaturaleza([FromQuery] FiltroEjecucionPresupuestariaMO ejecucion)
        {
            return EjecucionPresupuestariaBL.ListarPorGupoNaturaleza(ejecucion);
        }
    }
}
