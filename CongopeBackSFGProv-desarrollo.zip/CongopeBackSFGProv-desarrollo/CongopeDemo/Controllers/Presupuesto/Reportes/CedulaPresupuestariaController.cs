﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class CedulaPresupuestariaController
    {
        [HttpGet]
        public dynamic Get(string codemp, string fecha_hasta, int ing_gas, int nTodos, int nNivel, string sOperador, string sPartida = "")
        {
            return CedulaPresupuestariaBL.Listar(codemp, fecha_hasta, ing_gas, nTodos, nNivel, sOperador, sPartida);
        }

    }
}
