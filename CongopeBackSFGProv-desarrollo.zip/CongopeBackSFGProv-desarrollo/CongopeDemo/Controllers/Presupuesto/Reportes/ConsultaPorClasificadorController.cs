﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsultaPorClasificadorController
    {
        [HttpGet]
        public dynamic Get(string sFechaHasta, int nTipoPresu, string sClasificador = "")
        {
            return ConsultaPorClasificadorBL.Listar(sFechaHasta, nTipoPresu, sClasificador);
        }
    }
}
