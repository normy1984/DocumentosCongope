﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class MapaController 
    {
        [HttpGet]
        public dynamic Get(int periodo_vigente)
        {
            return MapaBL.GenerarMapa(periodo_vigente);
        }
    }
}
