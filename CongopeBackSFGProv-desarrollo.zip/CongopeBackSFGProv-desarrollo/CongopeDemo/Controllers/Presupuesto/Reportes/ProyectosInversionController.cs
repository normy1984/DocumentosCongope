﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProyectosInversionController
    {


        [HttpGet]
        public dynamic CargarResumenPresupuesto([FromQuery] ResumenPresupuestoFiltroMO resumenPresupMo)
        {
            return ProyectosInversionBL.CargarResumenPresupuesto(resumenPresupMo);
        }

        [HttpGet]
        [Route("CargarPresupuestoxDireccion")]
        public dynamic CargarPresupuestoXDirec_POA_TTHH([FromQuery] PresupuestoXDirec_POA_TTHHMO resumenPresupMo)
        {
            return ProyectosInversionBL.CargarPresupuestoXDirec_POA_TTHH(resumenPresupMo);
        }

    }
}
