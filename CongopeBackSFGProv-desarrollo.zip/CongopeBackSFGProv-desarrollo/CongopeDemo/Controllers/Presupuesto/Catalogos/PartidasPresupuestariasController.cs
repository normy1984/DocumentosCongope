﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Parametrizacion;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Catalogos
{

    [Route("api/[controller]")]
    [ApiController]
    public class PartidasPresupuestariasController : ControllerBase
    {

        [HttpGet]
        public dynamic Get()
        {
            return PartidasPresupuestariasBL.ListarPartidasPresupuestarias();
        }


        /// <summary>
        /// Tipo de movimiento por codigo
        /// </summary>
        /// <param name="in_acu_tip">Codigo del Movimiento</param>
        /// <returns>Movimiento por código</returns>
        [HttpGet("DetallePartidasCE/{in_acu_tip}")]
        public dynamic ListarDetallePartidasCE(string in_acu_tip)
        {
            return PartidasPresupuestariasBL.ListarDetallePartidasCE(in_acu_tip);

        }

        /// <summary>
        /// Metodo usado en la Liquidacion de certificacion Presupuestaria
        /// </summary>
        /// <param name="oPartidaPresupuestariaDetMO">Informacion de la partida presupuestaria</param>
        /// <returns></returns>
        [HttpPost("Detalle")]
        public dynamic Post([FromBody] PartidaPresupuestariaDetMO oPartidaPresupuestariaDetMO)
        {
            string sTipoAccion = "INSERTAR";
            return PartidasPresupuestariasBL.InsertarActualizar_CertificacionPartidasDet(sTipoAccion, oPartidaPresupuestariaDetMO, 0);
        }

        [HttpPost("DetalleActualizar")]
        public dynamic Actualiza([FromBody] PartidaPresupuestariaDetMO oPartidaPresupuestariaDetMO)
        {
            string sTipoAccion = "ACTUALIZAR";
            return PartidasPresupuestariasBL.InsertarActualizar_CertificacionPartidasDet(sTipoAccion, oPartidaPresupuestariaDetMO, oPartidaPresupuestariaDetMO.out_sec_det);
        }

        /// <summary>
        /// Método para eliminar el detalle de una partida presupuestaria
        /// </summary>
        /// <param name="id">ID de la fuente de financiamiento que se desea eliminar</param>
        /// <returns></returns>        
        [HttpDelete("Detalle/{in_codemp}/{in_anio}/{in_codigo}/{in_nivel}/{in_cuenta}/{in_sec_det}")]
        public dynamic Delete(string in_codemp, int in_anio, string in_codigo, int in_nivel, string in_cuenta, int in_sec_det)
        {
            var result = PartidasPresupuestariasBL.EliminarDetallePartidaPresupuestaria(in_codemp, in_anio, in_codigo, in_nivel, in_cuenta, in_sec_det);

            if (result.success)
            {
                return Ok(new { success = true, message = result.message });
            }
            else
            {
                return BadRequest(new { success = false, message = result.message });
            }
        }

        [HttpGet("PartidaDuplicada/{in_anio}/{in_codigo}")]
        public dynamic ValidarPartidasDuplicada(string in_codemp, int in_anio, string in_codigo, int in_acutip)
        {
            return PartidasPresupuestariasBL.ValidarPartidaPresupuestariaDuplicada(in_codemp, in_anio, in_codigo, in_acutip);
        }

        

    }
}
