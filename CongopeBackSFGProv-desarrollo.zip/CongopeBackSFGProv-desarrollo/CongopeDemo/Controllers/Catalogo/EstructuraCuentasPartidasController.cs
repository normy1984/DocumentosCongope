﻿using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.Models.Catalogo;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace Congope.Empresas.Controllers.Catalogo
{

    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EstructuraCuentasPartidasController : Controller
    {

/// <summary>
/// Funcion que devuelve una estructura de arbol, para la creacion del objeto en el front
/// </summary>
/// <param name="sel_Arbol"></param>
/// <returns></returns>
        [HttpPost("GenerarArbol")]
        public dynamic CargarArbol(Sel_ArbolEstructuraCuentasPartidasMo sel_Arbol)
        {
            return EstructuraCuentasPartidasBL.CargarArbol(sel_Arbol);
        }

        /// <summary>
        /// Funcion que devuelve una estructura de arbol, para la creacion del objeto en el front
        /// </summary>
        /// <param name="sel_Arbol"></param>
        /// <returns></returns>
        [HttpPost("GenerarListCuentas")]
        public dynamic CargarListPartidas(Sel_ArbolEstructuraCuentasPartidasMo sel_Arbol)
        {
            return EstructuraCuentasPartidasBL.CargarListPartidas(sel_Arbol);
        }


        [HttpPost("CargarCoPlactaXcodigo")]
        public dynamic CargarCoPlactaXcodigo(Sel_EstructuraCuentasXcodigoMo sel_Estructura)
        {
            return EstructuraCuentasPartidasBL.CargarCoPlactaXcodigo(sel_Estructura);
        }



        [HttpPost("SelectEstructuraNuevoGenerico")]
        public dynamic SelectEstructuraNuevoGenerico(Sel_SelectEstructuraNuevoGenericoMo sel_Estructura)
        {
            return EstructuraCuentasPartidasBL.SelectEstructuraNuevoGenerico(sel_Estructura);
        }



        [HttpPost("IU_EstructuraPartidaCuentaMo")]
        public dynamic IU_EstructuraPartidaCuentaMo(List<IU_EstructuraPartidaCuentaMo> sel_Estructura)
        {
            return EstructuraCuentasPartidasBL.IU_EstructuraPartidaCuentaMo(sel_Estructura);
        }
    }
}
