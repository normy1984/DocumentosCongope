﻿using Congope.Empresas.BussinessLogic.Catalogo;
using Congope.Empresas.Models.Catalogo;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Catalogo
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EmpleadosController : Controller
    {
        /// <summary>
        /// Función que trae la informacion de la lista de empleados
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public dynamic EmpleadoLista()
        {
            return EmpleadosBL.EmpleadoLista();
        }

        /// <summary>
        /// Controlador que trae la informacion de loe empleados por codigo
        /// </summary>
        /// <param name="empleadosPorCodigoMo"></param>
        /// <returns></returns>
        [HttpPost("EmpleadoPersonalesPorCodigo")]
        public dynamic EmpleadoPersonalesPorCodigo(EmpleadosPorCodigoMo empleadosPorCodigoMo)
        {
            return EmpleadosBL.EmpleadoPersonalesPorCodigo(empleadosPorCodigoMo);
        }

        /// <summary>
        /// Controlador que trae la información de las tablas por codigo
        /// </summary>
        /// <param name="tablasporCodigo"></param>
        /// <returns></returns>
        [HttpPost("TablasGeneralesPorCodigo")]
        public dynamic TablasGeneralesPorCodigo(EmpleadosPorCodigoMo tablasporCodigo)
        {
            return EmpleadosBL.TablasGeneralesPorCodigo(tablasporCodigo);
        }

        /// <summary>
        /// Controlador que trae la informacion demaografica para el empleado
        /// </summary>
        /// <param name="CodigoPadre"></param>
        /// <returns></returns>
        [HttpGet("DatosDemograficos/{id}")]
        public dynamic DatosDemograficos(string id)
        {
            return EmpleadosBL.DatosDemograficos(id);
        }


        /// <summary>
        /// Funcion que devuelve los datos de la fotografia en base 64
        /// </summary>
        /// <param name="ruta"></param>
        /// <returns></returns>
        [HttpGet("CargarFotos/{ruta}")]
        public dynamic CargarFoto(string ruta)
        {
            return EmpleadosBL.CargarFoto(ruta);
        }


        /// <summary>
        /// Funcion que recibe el numero de cedula y la foto para cargar al servidor
        /// </summary>
        /// <param name="subirFotoMo"></param>
        /// <returns></returns>
        [HttpPost("SubirFotoEmpleado")]
        public dynamic SubirFotoEmpleado([FromForm] EmpleadosSubirFotoMo subirFotoMo)
        {
            return EmpleadosBL.SubirFotoEmpleado(subirFotoMo);
        }

        /// <summary>
        /// Funcion para insertar o actualizar los registros de los empleados
        /// </summary>
        /// <param name="empleadosMo"></param>
        /// <returns></returns>
        [HttpPost("InsertarActualizarEmpleado")]
        public dynamic InsertarActualizarEmpleado(EmpleadosMo empleadosMo)
        {
            return EmpleadosBL.InsertarActualizarEmpleado(empleadosMo);
        }
    }
}
