using Congope.Empresas.Data;
using Congope.Empresas.Extensiones;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using OfficeOpenXml;
using Congope.Empresas.Models;
using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Genericas;

//LINEA DE CONFIGURACION DE LA LIBRERIA EPPlus 

ExcelPackage.LicenseContext = LicenseContext.NonCommercial;


var builder = WebApplication.CreateBuilder(args);


// Lineas para la configuracion LDAP

// Configuraci�n de LDAP desde la clase est�tica para que mi localhost escuche en la ip
/*builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(5142); // HTTP
});

*/


// Add services to the container

builder.Services.AddControllers();

builder.Services.AddApplicationServices();

builder.Services.AddSignalR(); // Registrar SignalR

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

builder.Services.AddCors(options => {
    options.AddPolicy("NuevaPolitica", app =>
    {
        app.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
    });


    /*options.AddPolicy("NuevaPolitica", policy =>
     {
         policy
             .WithOrigins("http://192.168.50.54") // tu front Angular
             .AllowAnyHeader()
             .AllowAnyMethod()
             .AllowCredentials(); // permite enviar cookies o token
     });*/
});


/// funcionalidad de JwtBearer
/// 

if (Conexion.TipoLogin == "keycloak")
{
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    }).
        AddJwtBearer(options =>
        {

            options.Authority = Conexion.JwtConfiguracion.JwtAuthority;
            options.IncludeErrorDetails = true;
            options.RequireHttpsMetadata = false; // Solo para desarrollo local
            options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                ValidIssuer = Conexion.JwtConfiguracion.JwtIssuer,
                ValidAudience = Conexion.JwtConfiguracion.JwtAudience,
            };
        });
}
else
{

    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options => {
        options.IncludeErrorDetails = true;
        options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ValidIssuer = Conexion.JwtConfiguracion.JwtIssuer,
            ValidAudience = Conexion.JwtConfiguracion.JwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Conexion.JwtConfiguracion.JwtKey))
        };
    });
}

builder.Services.AddSingleton<IColasTareasBackground, ColasTareasBackground>();
builder.Services.AddHostedService<ColasTareasBackgroundBL>();
builder.Services.AddHostedService<BootTelegramBL>(); // SERVICIO DE 

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseCors("NuevaPolitica");


app.UseHttpsRedirection();

//ya  no con swagger
app.UseStaticFiles();
app.UseRouting();

//// uso de autenticacion
app.UseAuthentication();

app.UseAuthorization();

//ya  no con swagger
app.MapControllers();

// EXPONE EL ENDPOINT HUB
app.MapHub<NotificacionesHub>(Conexion.HubMensajes);

app.Run();
