import 'dart:convert';
import 'dart:io';
import 'package:app/Screens/Loading/escoge_login.dart';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Public/Register/register_person.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:http/http.dart' as http;

class PreLoading extends StatefulWidget{
  _PreLoading createState()=>new _PreLoading();
}
class _PreLoading extends State<PreLoading>{
  final _globalKey = GlobalKey<ScaffoldState>();
  var JsonData=null;
  var data;
  var usuario;
  var password;
  var url;
  var _token;
  List <String> cantones=['Carchi'];
  //List <String> cantones=['Azuay', 'Bolívar', 'Cañar', 'Carchi', 'Chimborazo', 'Cotopaxi', 'El Oro' ,'Esmeraldas', 'Galápagos', 'Guayas', 'Imbabura', 'Loja', 'Los Ríos', 'Manabí', 'Morona Santiago', 'Napo', 'Orellana', 'Pastaza', 'Pichincha', 'Santa Elena', 'Santo Domingo de los Tsáchilas', 'Sucumbíos', 'Tungurahua', 'Zamora Chinchipe'];
  var _selectCanton;

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    String urls='http://181.196.49.46';
    SharedPreferences url= await SharedPreferences.getInstance();
    url.setString('url', urls);
  }

  //Amarillo ffc20e
  //Negro 616163
  //Rojo d71921
  //Naranja 1063ad
  //Verde 1063ad

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    //Formulario de ingreso//
    Widget formularioIngreso = Container(
      padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 60*SizeConfig.heightMultiplier),
              child: Text("Debes seleccionar la provincia a la que perteneces",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6 * SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 2 * SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10 * SizeConfig.widthMultiplier, right: 10 * SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(15 * SizeConfig.widthMultiplier)),
                ),

                child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                        left: 2 * SizeConfig.widthMultiplier,
                        right: 2 * SizeConfig.widthMultiplier),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                          Radius.circular(1 * SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.white),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        hint: Container(
                          alignment: Alignment.centerLeft,
                          child: Text('Seleccionar',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 2.3*SizeConfig.textMultiplier,
                              fontFamily: 'Poppins',
                              color: Colors.white,
                            ),
                          ),
                        ),
                        iconEnabledColor: Colors.white,
                        // Not necessary for Option 1
                        value: _selectCanton,
                        isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectCanton = newValue.toString();
                          });
                        },
                        items: cantones.map((location) {
                          return DropdownMenuItem(
                            child: Text(location,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 2.5*SizeConfig.textMultiplier,
                                color: HexColor('616163'),
                              ),
                            ),
                            value: location,
                          );
                        }).toList(),
                        selectedItemBuilder: (BuildContext context) {
                          return cantones.map((location) {
                            return Container(
                                alignment: Alignment.centerLeft,
                                child:Text(location,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    color: Colors.white,
                                  ),
                                )
                            );
                          }).toList();
                        },
                      ),
                    )
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Provincia",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              height: 6*SizeConfig.heightMultiplier,
              margin: EdgeInsets.only(top: 5*SizeConfig.heightMultiplier),
              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
              child: SizedBox(
                width: double.maxFinite,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                  ),
                  color:  HexColor("ff7400"),
                  child: Text("Siguiente",
                    style: TextStyle(
                      fontSize: 2.5*SizeConfig.textMultiplier,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  onPressed: (){
                    if(_selectCanton==null){
                      ErrorGuardar('Por favor selecciona una provincia');
                    }else{
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> Login()));
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
    // TODO: implement build
    return WillPopScope(
      onWillPop: (){
        exit(0);
      },
      child:Scaffold(
        backgroundColor: Colors.white,
        key: _globalKey,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/icons/Portada.png'),
              fit: BoxFit.fitHeight
            ),
          ),
          child: Container(
              child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Align(
                    alignment: Alignment.center,
                    child: formularioIngreso,
                  )
              )
          ),
        ),
      ),
    );
  }
}