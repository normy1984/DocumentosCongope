import 'dart:convert';
import 'dart:io';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Public/Register/register_person.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:http/http.dart' as http;

class EscogerLogin extends StatefulWidget{
  _EscogerLogin  createState()=>new _EscogerLogin ();
}
class _EscogerLogin  extends State<EscogerLogin >{
  final _globalKey = GlobalKey<ScaffoldState>();
  var JsonData=null;
  var data;
  var usuario;
  var password;
  var url;
  var _token;
  List <String> cantones=['Carchi'];
  //List <String> cantones=['Azuay', 'Bolívar', 'Cañar', 'Carchi', 'Chimborazo', 'Cotopaxi', 'El Oro' ,'Esmeraldas', 'Galápagos', 'Guayas', 'Imbabura', 'Loja', 'Los Ríos', 'Manabí', 'Morona Santiago', 'Napo', 'Orellana', 'Pastaza', 'Pichincha', 'Santa Elena', 'Santo Domingo de los Tsáchilas', 'Sucumbíos', 'Tungurahua', 'Zamora Chinchipe'];
  var _selectCanton;

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    String urls='http://181.196.49.46';
    SharedPreferences url= await SharedPreferences.getInstance();
    url.setString('url', urls);
  }

  //Amarillo ffc20e
  //Negro 616163
  //Rojo d71921
  //Naranja 1063ad
  //Verde 1063ad

  TipoLogin(String acceso)async{
    String tipoAcceso='';
    setState(() {
      tipoAcceso=acceso;
    });
    SharedPreferences _acceso= await SharedPreferences.getInstance();
    _acceso.setString('tipoAcceso', tipoAcceso);
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    //Formulario de ingreso//
    Widget formularioIngreso = Container(
      padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: 95*SizeConfig.widthMultiplier,
              height: 30*SizeConfig.heightMultiplier,
              child: Image(
                image: AssetImage("images/icons/congope.png"),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 3*SizeConfig.widthMultiplier, right: 3*SizeConfig.widthMultiplier),
              child: Text("Bienvenido a \nMi Territorio",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 3.5*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 1.5*SizeConfig.heightMultiplier),
              child: Text("Selecciona el tipo de acceso que posees",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 1.5*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: HexColor('616163'),
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 5*SizeConfig.heightMultiplier),
              width: 90*SizeConfig.widthMultiplier,
              child: Table(
                children: [
                  TableRow(
                    children: [
                      Container(
                          padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                          margin: EdgeInsets.only(left: 3*SizeConfig.widthMultiplier, right: 3*SizeConfig.widthMultiplier),
                          width: 35*SizeConfig.widthMultiplier,
                          height: 18*SizeConfig.heightMultiplier,
                          decoration: BoxDecoration(
                              border: Border.all(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
                              borderRadius: BorderRadius.all(Radius.circular(7*SizeConfig.widthMultiplier))
                          ),
                          child: InkWell(
                            onTap: (){
                              TipoLogin('institucional');
                            },
                            child: Column(
                              children: [
                                Container(
                                  child: Icon(Icons.apartment, size: 22*SizeConfig.imageSizeMultiplier, color: HexColor("01579b"),),
                                ),
                                Container(
                                  width: 25*SizeConfig.widthMultiplier,
                                  child: Text('Acceso Institucional',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 2*SizeConfig.textMultiplier,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                      ),
                      Container(
                          margin: EdgeInsets.only(left: 3*SizeConfig.widthMultiplier, right: 3*SizeConfig.widthMultiplier),
                          padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                          width: 35*SizeConfig.widthMultiplier,
                          height: 18*SizeConfig.heightMultiplier,
                          decoration: BoxDecoration(
                              border: Border.all(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
                              borderRadius: BorderRadius.all(Radius.circular(7*SizeConfig.widthMultiplier))
                          ),
                          child: InkWell(
                            onTap: (){
                              TipoLogin('publico');
                            },
                            child: Column(
                              children: [
                                Container(
                                  child: Icon(Icons.account_box, size: 22*SizeConfig.imageSizeMultiplier, color: HexColor("01579b"),),
                                ),
                                Container(
                                  width: 20*SizeConfig.widthMultiplier,
                                  child: Text('Acceso Público',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 2*SizeConfig.textMultiplier,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                      ),
                    ]
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
    // TODO: implement build
    return WillPopScope(
      onWillPop: (){
        exit(0);
      },
      child:Scaffold(
        backgroundColor: Colors.white,
        key: _globalKey,
        body: Center(
          child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Align(
                    alignment: Alignment.center,
                    child: formularioIngreso,
                  )
              )
          ),
        ),
      ),
    );
  }
}