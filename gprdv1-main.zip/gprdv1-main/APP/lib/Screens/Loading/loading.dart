import 'dart:io';
import 'package:app/Screens/Loading/pre_loading.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Loading extends StatefulWidget{
  var token, data;
  Loading({this.token, this.data}):super();
  _Loading createState()=>new _Loading();
}
class _Loading extends State<Loading>{
  final _globalKey = GlobalKey<ScaffoldState>();
  var JsonData=null;
  var _data;
  var _token;
  TextEditingController user= new TextEditingController();
  TextEditingController pass= new TextEditingController();

  @override
  void initState() {
    super.initState();
    //Remplazo(widget.token, widget.data);
    new Future.delayed(new Duration(seconds: 5), () {
      Navigator.push(context, MaterialPageRoute(builder: (context)=>PreLoading()));
    });
  }

  /*Remplazo(var token, var data){
    setState(() {
      _token=token;
      _data=data;
    });
  }*/

  @override
  Widget build(BuildContext context) {
    //Logo//
    Widget loadingPage= Container(
      height: 50*SizeConfig.heightMultiplier,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage("images/icons/congope.png"),
            fit: BoxFit.fitWidth
        ),
      ),

    );
    // TODO: implement build
    bool shouldPop = true;
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=>exit(0)));
        return shouldPop;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        key: _globalKey,
        body: Center(
          child: Container(
            color: Colors.white,
            child: loadingPage,
          ),
        ),
      ),
    );
  }
}