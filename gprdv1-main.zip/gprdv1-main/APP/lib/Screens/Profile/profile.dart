import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class Perfil extends StatefulWidget{
  Perfil():super();
  _Perfil createState()=>new _Perfil();
}
class _Perfil extends State<Perfil>{
  var id;
  var _url;
  var _perfil;
  var _token;
  var _pass;
  bool _isLoading=false;
  TextEditingController descripcionController= new TextEditingController();
  Widget menuL=Container();
  TextEditingController oldpass= TextEditingController();
  TextEditingController pass= TextEditingController();
  TextEditingController confirm= TextEditingController();
  @override
  void initState() {
    super.initState();
    getData();
  }
  getData()async{
    SharedPreferences idpref = await SharedPreferences.getInstance();
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    SharedPreferences passpref = await SharedPreferences.getInstance();
    setState(() {
      id=idpref.getString('userId');
      _url=urlpref.getString('url');
      _token=tokenpref.getString('token');
      _pass=passpref.getString('password');
    });
    DataPerfil();
  }

  DataPerfil() async {
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/profile/${id}');
    });
    final response =await http.get(uri, headers: {
      //'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _perfil=responseData['data'];
        _isLoading=false;
        print(_perfil['name']);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _perfil;
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> Formulario(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 55*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                                child: Text("Cambio de contraseña",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                              height: 6*SizeConfig.heightMultiplier,
                              margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                              ),
                              child: TextField(
                                textAlign: TextAlign.center,
                                textAlignVertical: TextAlignVertical.top,
                                controller: oldpass,
                                obscureText: true,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  isDense: true,
                                ),
                                style: TextStyle(
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  fontFamily: 'Poppins',
                                  color: HexColor('616163'),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                            child: Text("Anterior Contraseña",
                              style: TextStyle(
                                fontSize: 2*SizeConfig.textMultiplier,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          Container(
                              height: 6*SizeConfig.heightMultiplier,
                              margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                              ),
                              child: TextField(
                                textAlign: TextAlign.center,
                                textAlignVertical: TextAlignVertical.top,
                                controller: pass,
                                obscureText: true,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  isDense: true,
                                ),
                                style: TextStyle(
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  fontFamily: 'Poppins',
                                  color: HexColor('616163'),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                            child: Text("Nueva Contraseña",
                              style: TextStyle(
                                fontSize: 2*SizeConfig.textMultiplier,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          Container(
                              height: 6*SizeConfig.heightMultiplier,
                              margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                              ),
                              child: TextField(
                                textAlign: TextAlign.center,
                                textAlignVertical: TextAlignVertical.top,
                                controller: confirm,
                                obscureText: true,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  isDense: true,
                                ),
                                style: TextStyle(
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  fontFamily: 'Poppins',
                                  color: HexColor('616163'),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                            child: Text("Confirmar Contraseña",
                              style: TextStyle(
                                fontSize: 2*SizeConfig.textMultiplier,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                              if(pass.text==confirm.text ){
                                                if(confirm.text==''){
                                                  ErrorGuardar('Todos los campos son obligatorios');
                                                }else if(oldpass.text==''){
                                                  ErrorGuardar('Todos los campos son obligatorios');
                                                }else if(pass.text==''){
                                                  ErrorGuardar('Todos los campos son obligatorios');
                                                }else if(oldpass.text!=_pass){
                                                  ErrorGuardar('La contraseña anterior no coincide');
                                                }else{
                                                  CambioClave();
                                                }
                                              }else{
                                                ErrorGuardar('La contraseña no coincide');

                                              }
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                              setState(() {
                                                pass.text='';
                                                oldpass.text='';
                                                confirm.text='';
                                              });
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> DatosGuardados(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 27*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                                child: Text("Contraseña actualizada exitosamente",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                setState(() {
                                  pass.text='';
                                  oldpass.text='';
                                  confirm.text='';
                                });
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>Perfil()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  CambioClave() async{
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
    });

    final response =await http.post('${_url}/api/client/change/${id}', headers: {
      'Authorization': 'Bearer $_token',
      //'Content-Type' : 'application/json'
    },
      body: {
        'oldPass':oldpass.text,
        'password': pass.text,
        'confirmacionPass': confirm.text,
      },
    );
    print(response.body);
    if (response.statusCode == 200) {
      var responseData = json.decode(response.body);
      print("registro Exitoso");

      DatosGuardados();
    }else{
      ErrorGuardar('Error al actualizar la contraseña');
      print(response.statusCode);
      print(response.body);
      print('Error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget BarraAzul=Container(
        height: 5*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("18364a"),//ul: #
        child: Center(
          child: Text('Mi Ficha',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 2.5*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget FichaFoto=Container(
      width: 100*SizeConfig.widthMultiplier,
      decoration: BoxDecoration(
        color: HexColor('01579b'),
      ),
      child: Column(
        children: [
          Container(
              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
              child: Column(
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.white,
                    //backgroundImage: AssetImage('images/Iconos/foto_presidente.png'),
                    radius: 17*SizeConfig.widthMultiplier,
                    child: Center(
                      child: Icon(Icons.account_circle, size: 34*SizeConfig.imageSizeMultiplier,),
                    )
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier, top: 0.5*SizeConfig.heightMultiplier),
                    child: Text('s',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 2.3*SizeConfig.textMultiplier,
                          color: Colors.transparent,
                          fontWeight: FontWeight.bold
                      ),
                    ),
                  ),
                ],
              )
          ),
          Container(
            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
            child: Stack(
              children: [
                Positioned(
                    child: Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      height:5*SizeConfig.heightMultiplier,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(5*SizeConfig.widthMultiplier),
                            topLeft: Radius.circular(5*SizeConfig.widthMultiplier),
                          ),
                          border: Border.all(color: Colors.white)
                      ),
                    )
                ),
                Center(
                  child: Container(
                    height: 6*SizeConfig.heightMultiplier,
                    width: 85*SizeConfig.widthMultiplier,
                    padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                        border: Border.all(color: Colors.grey)
                    ),
                    child: Table(
                      children: [
                        TableRow(
                            children: [
                              Container(
                                child: Column(
                                  children: [
                                    Container(
                                      child: Text(_perfil==null?'':_perfil['name'],
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 2*SizeConfig.textMultiplier,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                      child: Text('Nombre',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 1.2*SizeConfig.textMultiplier,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ]
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 100*SizeConfig.widthMultiplier,
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.white)
            ),
            child: Column(
              children: [
                Container(
                  width: 85*SizeConfig.widthMultiplier,
                  padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey)
                  ),
                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(10),
                      1:FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                          children: [
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    alignment: Alignment.centerLeft,
                                    child: Text(_perfil==null?'':_perfil['age'].toString(),
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    child: Text('Edad',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 1.2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 0.2*SizeConfig.heightMultiplier),
                              child: Center(
                                child: Icon(Icons.check_circle, size: 8*SizeConfig.imageSizeMultiplier, color: HexColor('ff7400'),),
                              ),
                            ),
                          ]
                      )
                    ],
                  ),
                ),
                Container(
                  width: 85*SizeConfig.widthMultiplier,
                  padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey)
                  ),
                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(10),
                      1:FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                          children: [
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    alignment: Alignment.centerLeft,
                                    child: Text(_perfil==null?'':_perfil['ethnicity'],
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    child: Text('Etnia',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 1.2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 0.2*SizeConfig.heightMultiplier),
                              child: Center(
                                child: Icon(Icons.check_circle, size: 8*SizeConfig.imageSizeMultiplier, color: HexColor('ff7400'),),
                              ),
                            ),
                          ]
                      )
                    ],
                  ),
                ),
                Container(
                  width: 85*SizeConfig.widthMultiplier,
                  padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey)
                  ),
                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(10),
                      1:FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                          children: [
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    alignment: Alignment.centerLeft,
                                    child: Text(_perfil==null?'':_perfil['gender'],
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    child: Text('Género',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 1.2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 0.2*SizeConfig.heightMultiplier),
                              child: Center(
                                child: Icon(Icons.check_circle, size: 8*SizeConfig.imageSizeMultiplier, color: HexColor('ff7400'),),
                              ),
                            ),
                          ]
                      )
                    ],
                  ),
                ),
                Container(
                  width: 85*SizeConfig.widthMultiplier,
                  padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey)
                  ),
                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(10),
                      1:FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                          children: [
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    alignment: Alignment.centerLeft,
                                    child: Text(_perfil==null?'':_perfil['canton'],
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    child: Text('Cantón',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 1.2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 0.2*SizeConfig.heightMultiplier),
                              child: Center(
                                child: Icon(Icons.check_circle, size: 8*SizeConfig.imageSizeMultiplier, color: HexColor('ff7400'),),
                              ),
                            ),
                          ]
                      )
                    ],
                  ),
                ),
                Container(
                  width: 85*SizeConfig.widthMultiplier,
                  padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 0.5*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(2*SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey)
                  ),
                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(10),
                      1:FlexColumnWidth(2),
                    },
                    children: [
                      TableRow(
                          children: [
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    alignment: Alignment.centerLeft,
                                    child: Text(_perfil==null?'':_perfil['email'],
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                                    child: Text('Email',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 1.2*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 0.2*SizeConfig.heightMultiplier),
                              child: Center(
                                child: Icon(Icons.check_circle, size: 8*SizeConfig.imageSizeMultiplier, color: HexColor('ff7400'),),
                              ),
                            ),
                          ]
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier, bottom: 3*SizeConfig.heightMultiplier),
                  child: InkWell(
                    onTap: (){
                      Formulario();
                    },
                    child: Container(
                      width: 70*SizeConfig.widthMultiplier,
                      height: 5*SizeConfig.heightMultiplier,
                      decoration: BoxDecoration(
                          color: HexColor("01579b"),
                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                      ),
                      child: Center(
                        child: Text("Cambiar contraseña",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.bold,
                              fontSize: 2.5*SizeConfig.textMultiplier,
                              color: Colors.white
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.of(context).pop();
        return shouldPop;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(color: HexColor('1063ad')),
          title: Center(
            child: Container(
                padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                child: Align(
                  alignment: Alignment.center,
                  child: Image(
                    image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                    width: 40*SizeConfig.widthMultiplier,
                  ),
                )
            ),
          ),
          leading: Container(
            child: IconButton(
                icon: Icon(Icons.arrow_back,),
                onPressed: (){
                  Navigator.of(context).pop();
                }
            ),
          ),
        ),
        drawer: menuL,
        body: _isLoading?Center(
          child: CircularProgressIndicator(),
        ):Container(
          color: Colors.transparent,
          child: Column(
            children: [
              Expanded(
                  flex:2,
                  child: Container(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        children: [
                          FichaFoto,
                        ],
                      ),
                    ),
                  )
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}