import 'dart:convert';
import 'dart:io';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:http/http.dart' as http;

class RegisterUser extends StatefulWidget{
  _RegisterUser createState()=>new _RegisterUser();
}
class _RegisterUser extends State<RegisterUser>{
  final _globalKey = GlobalKey<ScaffoldState>();
  var JsonData=null;
  var data;
  var usuario;
  var password;
  var url;
  var _cliente;
  var _cantones=[];
  var _token;
  var client;
  var _etnias=[];
  List <String> genero=['Masculino', 'Femenino', 'Otro',];
  List <String> etnia=['Mestizo', 'Afroamericano', 'Indígena'];
  var _selectCanton, _selectGenero, _selectEtnia;

  //var _token;
  bool _isLoading=false;
  TextEditingController email= TextEditingController();
  TextEditingController pass= TextEditingController();
  TextEditingController confirm= TextEditingController();
  TextEditingController nombre= TextEditingController();
  TextEditingController edad= TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    SharedPreferences usuarioprefs = await SharedPreferences.getInstance();
    SharedPreferences passwordpref = await SharedPreferences.getInstance();
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      usuario=usuarioprefs.getString('usuario');
      password=passwordpref.getString('password');
      url=urlpref.getString('url');
    });
    Locations();
    GetEtnias();
  }

  Future<List> Locations() async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${url}/api/locations');
    });
    final response =await http.get(uri, headers: {
      //'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _cantones=responseData['data'];
        print(_cantones);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _cantones;
  }

  GetEtnias()async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${url}/api/settings');
    });
    final response =await http.get(uri, headers: {
      //'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _etnias=responseData['data']['ethnicity'];
        print(_etnias);
      });
    }else{
      print('Erro lista profesionales');
    }
  }

  Future<dynamic> DatosGuardados(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 27*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                                child: Text("Registro exitoso",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  NuevosDatos(){
    setState(() {
      _cliente={
        'full_name':nombre.text,
        'age': edad.text,
        'ethnicity': _selectEtnia.toString(),
        'gender': _selectGenero.toString(),
        'canton': _selectCanton.toString(),
        'email':  email.text,
        'password': pass.text,
      };
    });
    print(_cliente);
    RegistroCliente();
  }

  ValidarDatos(){
    if(nombre.text==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(edad.text==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(email.text==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(pass.text==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(_selectEtnia==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(_selectGenero==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(_selectCanton==''){
      ErrorGuardar('Todos los datos son obligatorios');
    }else if(_selectCanton=='Ninguno'){
      ErrorGuardar('Todos los datos son obligatorios');
    }
    RegistroCliente();
  }

  RegistroCliente() async{
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      url=urlpref.getString('url');
    });

    final response =await http.post('${url}/api/register', headers: {
      //'Authorization': 'Bearer $token',
      //'Content-Type' : 'application/json'
    },
      body: {
        'full_name':nombre.text,
        'age': edad.text,
        'ethnicity': _selectEtnia.toString(),
        'gender': _selectGenero.toString(),
        'canton': _selectCanton.toString(),
        'email':  email.text,
        'password': pass.text,
      },
    );
    print(response.body);
    if (response.statusCode == 200) {
      var responseData = json.decode(response.body);
      print("registro Exitoso");
      setState(() {
        client=responseData['data']['client_id'].toString();
        _token=responseData['data']['token'].toString();
      });
      SharedPreferences url= await SharedPreferences.getInstance();
      url.setString('userId', client.toString());
      SharedPreferences token= await SharedPreferences.getInstance();
      url.setString('token', _token.toString());
      DatosGuardados();
    }else{
      ErrorGuardar('Error al realizar el registro');
      print(response.statusCode);
      print(response.body);
      print('Error');
    }
  }

  //Amarillo ffc20e
  //Negro 616163
  //Rojo d71921
  //Naranja 1063ad
  //Verde 1063ad
  @override
  Widget build(BuildContext context) {
    //Logo Umani//
    //Imagen Empresa//
    bool shouldPop = true;
    //Formulario de ingreso//
    Widget FormularioIngreso = Container(
      padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: Text("Registro",
                style: TextStyle(
                  fontSize: 3.5*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.text,
                  controller: nombre,
                  obscureText: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Nombre Completo",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.phone,
                  controller: edad,
                  obscureText: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Edad",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Center(
              child: Container(
                  height: 6 * SizeConfig.heightMultiplier,
                  margin: EdgeInsets.only(top: 2.5 * SizeConfig.heightMultiplier),
                  padding: EdgeInsets.only(left: 10 * SizeConfig.widthMultiplier, right: 10 * SizeConfig.widthMultiplier),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                        Radius.circular(15 * SizeConfig.widthMultiplier)),
                  ),

                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                        left: 2 * SizeConfig.widthMultiplier,
                        right: 2 * SizeConfig.widthMultiplier),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                          Radius.circular(1 * SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        hint: Text('Seleccionar',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 2*SizeConfig.textMultiplier
                          ),
                        ),
                        // Not necessary for Option 1
                        value: _selectEtnia,
                        isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectEtnia = newValue;
                          });
                        },
                        items: _etnias.map((location) {
                          return DropdownMenuItem(
                            child: new Text(location,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 2*SizeConfig.textMultiplier,
                                color: HexColor('616163'),
                              ),
                            ),
                            value: location.toString(),
                          );
                        }).toList(),
                      ),
                    ),
                  )
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Etnia",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6 * SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1 * SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10 * SizeConfig.widthMultiplier, right: 10 * SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(15 * SizeConfig.widthMultiplier)),
                ),

                child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                        left: 2 * SizeConfig.widthMultiplier,
                        right: 2 * SizeConfig.widthMultiplier),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                          Radius.circular(1 * SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        hint: Text('Seleccionar', textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 2.3*SizeConfig.textMultiplier,
                            fontFamily: 'Poppins',
                            color: HexColor('616163'),
                          ),
                        ),
                        // Not necessary for Option 1
                        value: _selectGenero,
                        isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectGenero = newValue.toString();
                          });
                        },
                        items: genero.map((location) {
                          return DropdownMenuItem(
                            child: Text(location,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 2.3*SizeConfig.textMultiplier,
                                fontFamily: 'Poppins',
                                color: HexColor('616163'),
                              ),
                            ),
                            value: location,
                          );
                        }).toList(),
                      ),
                    )
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Genero",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Center(
              child: Container(
                  height: 6 * SizeConfig.heightMultiplier,
                  margin: EdgeInsets.only(top: 2.5 * SizeConfig.heightMultiplier),
                  padding: EdgeInsets.only(left: 10 * SizeConfig.widthMultiplier, right: 10 * SizeConfig.widthMultiplier),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                        Radius.circular(15 * SizeConfig.widthMultiplier)),
                  ),

                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.only(
                        left: 2 * SizeConfig.widthMultiplier,
                        right: 2 * SizeConfig.widthMultiplier),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                          Radius.circular(1 * SizeConfig.widthMultiplier)),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        hint: Text('Seleccionar',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontSize: 2*SizeConfig.textMultiplier
                          ),
                        ),
                        // Not necessary for Option 1
                        value: _selectCanton,
                        isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectCanton = newValue;
                          });
                        },
                        items: _cantones.map((location) {
                          return DropdownMenuItem(
                            child: new Text(location['description'],
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontFamily: "Poppins",
                                fontSize: 2*SizeConfig.textMultiplier,
                                color: HexColor('616163'),
                              ),
                            ),
                            value: location['description'].toString(),
                          );
                        }).toList(),
                      ),
                    ),
                  )
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Cantón",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.text,
                  controller: email,
                  obscureText: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Email",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  controller: pass,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Contraseña",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  controller: confirm,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Confirmar Contraseña",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              height: 6*SizeConfig.heightMultiplier,
              margin: EdgeInsets.only(top: 1.7*SizeConfig.heightMultiplier, bottom: 2.3*SizeConfig.heightMultiplier),
              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
              child: SizedBox(
                width: double.maxFinite,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                  ),
                  color:  HexColor("01579b"),
                  child: Text("Registrar",
                    style: TextStyle(
                      fontSize: 2.5*SizeConfig.textMultiplier,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  onPressed: (){
                    if(pass.text==confirm.text){
                      ValidarDatos();
                    }else{
                      ErrorGuardar('Las contraseñas no coinciden');
                    }

                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
        return shouldPop;
      },
      child:Scaffold(
        backgroundColor: Colors.white,
        key: _globalKey,
        appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          iconTheme: IconThemeData(color: HexColor('1063ad')),
          title: Center(
            child: Container(
                padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                child: Align(
                  alignment: Alignment.center,
                  child: Image(
                    image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                    width: 40*SizeConfig.widthMultiplier,
                  ),
                )
            ),
          ),
          leading: Container(
            child: IconButton(
                icon: Icon(Icons.arrow_back,),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> Login()));
                }
            ),
          ),
        ),
        body: Center(
          child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: <Widget>[
                        FormularioIngreso,
                      ],
                    ),
                  )
              )
          ),
        ),
      ),
    );
  }
}