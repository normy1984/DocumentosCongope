import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Profile/profile.dart';
import 'package:app/Screens/Public/OpenData/open_data_project.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:app/Screens/Workers/Projects/list_project_competence.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class OpenDataProjectDetail extends StatefulWidget{
  var proyecto, anio;
  OpenDataProjectDetail({this.proyecto, this.anio}):super();
  _OpenDataProjectDetail createState()=>new _OpenDataProjectDetail();
}
class _OpenDataProjectDetail extends State<OpenDataProjectDetail>{
  var _token;
  bool _isLoading=false;
  var _url, _client_id, calificacion=0;
  var _proyecto;
  var _anio;
  var _comments;
  var _perfil;
  var _respuestas;
  var _selectCanton, _selectAnio, _selectEtnia;
  TextEditingController commentController= TextEditingController();

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences clientpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _client_id=clientpref.getString('userId');
      _token=tokenpref.getString('token');
    });
    Remplazo(widget.proyecto, widget.anio);
    //ListComment();
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  Remplazo (var proyecto, var anio) async{
    setState(() {
      _proyecto=proyecto;
      _anio=anio;
    });
    print(_proyecto['id']);
  }

  RegistroComentario() async{
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
    });

    final response =await http.post('${_url}/api/client/reviews?author_id=${_client_id}&type=project&type_id=${_proyecto['id'].toString()}&comment=${commentController.text}&rating=${calificacion.toString()}', headers: {
      'Authorization': 'Bearer $_token',
      //'Content-Type' : 'application/json'
      },
    );
    if (response.statusCode == 200) {
      var responseData = json.decode(response.body);
      print("registro Exitoso");
      DatosGuardados();
    }else{
      ErrorGuardar('Error al registrar el comentario');
      print(response.statusCode);
      print(response.body);
      print('Error');
    }
  }

  ListComment() async{
    var uri;
    setState(() {
      print(_proyecto['id'].toString());
      _isLoading=true;
      uri=Uri.parse('${_url}/api/client/reviews?author_id=${_client_id}&type=project&type_id=${_proyecto['id'].toString()}');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData = json.decode(response.body);
    if (response.statusCode == 200) {
      setState(() {
        _isLoading=false;
        _comments=responseData['data'];
        print(_comments);
      });
    }else{
      print(response.statusCode);
      print('Erro lista profesionales');
    }
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> DetalleComentario(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                height: 65*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: InkWell(
                            onTap: (){
                              Navigator.of(context).pop();
                            },
                            child: Container(
                                width: 10*SizeConfig.widthMultiplier,
                                height: 10*SizeConfig.imageSizeMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Center(
                                    child: Icon(Icons.check, color: Colors.white),
                                  ),
                                )
                            ),
                          ),
                        )
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                      child: Text("Respuestas",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontFamily: "Poppins",
                            fontWeight: FontWeight.bold,
                            fontSize: 2.3*SizeConfig.textMultiplier,
                            color: Colors.black
                        ),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                        padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                        child: Container(
                          width: 90*SizeConfig.widthMultiplier,
                          height: 40*SizeConfig.heightMultiplier,
                          child: ListView.separated(
                              padding: EdgeInsets.zero,
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              physics: BouncingScrollPhysics(),
                              itemCount: _respuestas==null?0:_respuestas.length,
                              separatorBuilder: (BuildContext context, int index) => Container(
                                padding: EdgeInsets.only( top: 0.2*SizeConfig.heightMultiplier),
                              ),
                              itemBuilder: (BuildContext context, int index){
                                return Container(
                                  margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                  child: Column(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(bottom: 1*SizeConfig.heightMultiplier),
                                        child: Table(
                                          children: [
                                            TableRow(
                                                children: [
                                                  Container(
                                                      margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                      child: Text('Autor: '+_respuestas[index]['author'].toString(),
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          fontFamily: 'Poppins',
                                                          fontWeight: FontWeight.bold,
                                                          color: Colors.black,
                                                          fontSize: 1.8*SizeConfig.textMultiplier,
                                                        ),
                                                      )
                                                  ),
                                                ]
                                            ),
                                            TableRow(
                                                children: [
                                                  Column(
                                                    children: [
                                                      Row(
                                                        children: [
                                                          Container(
                                                              margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                              child: Text('Fecha: ',
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  fontFamily: 'Poppins',
                                                                  fontWeight: FontWeight.bold,
                                                                  color: Colors.black,
                                                                  fontSize: 1.8*SizeConfig.textMultiplier,
                                                                ),
                                                              )
                                                          ),
                                                          Container(
                                                              margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                              child: Text(_respuestas[index]['created_at'].toString().substring(0,11)+'-'+_respuestas[index]['created_at'].toString().substring(10,16),
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                  fontFamily: 'Poppins',
                                                                  color: Colors.black,
                                                                  fontSize: 1.8*SizeConfig.textMultiplier,
                                                                ),
                                                              )
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  )
                                                ]
                                            ),
                                            TableRow(
                                                children: [
                                                  Container(
                                                      decoration:BoxDecoration(
                                                          border: Border(
                                                              bottom: BorderSide(color: Colors.grey)
                                                          )
                                                      ),
                                                      margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                      padding:EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                                                      child: Text(_respuestas[index]['comment'],
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(
                                                          fontFamily: 'Poppins',
                                                          color: Colors.black,
                                                          fontSize: 1.8*SizeConfig.textMultiplier,
                                                        ),
                                                      )
                                                  ),
                                                ]
                                            ),
                                          ],
                                        ),
                                      )

                                    ],
                                  ),
                                );
                              }
                          ),
                        )
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: InkWell(
                        onTap: (){
                          Navigator.of(context).pop();
                          //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                        },
                        child: Container(
                          width: 60*SizeConfig.widthMultiplier,
                          height: 5*SizeConfig.heightMultiplier,
                          decoration: BoxDecoration(
                              color: HexColor("01579b"),
                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                          ),
                          child: Center(
                            child: Text("Aceptar",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.5*SizeConfig.textMultiplier,
                                  color: Colors.white
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> DatosGuardados(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 27*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                                child: Text("Comentario registrado exitosamente",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>OpenDataProjectDetail(anio: _anio, proyecto: _proyecto,)));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Perfil del Proyecto',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget CabeceraProject=Container(
        width: 95*SizeConfig.widthMultiplier,
        padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
        child: Column(
          children: [
            Center(
                child: Container(
                  child: Text('Nombre del proyecto',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 1.8*SizeConfig.textMultiplier,
                      color: Colors.black,
                      fontFamily: 'Poppins',
                    ),
                  ),
                )
            ),
            Container(
              margin:EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Center(
                child: Text(_proyecto['name'],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 1.8*SizeConfig.textMultiplier,
                    color: Colors.black,
                    fontFamily: 'Poppins',
                  ),
                ),
              ),
            ),
            Center(
                child: Container(
                  margin:EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                  child: Text('Descripción del proyecto',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 1.8*SizeConfig.textMultiplier,
                      color: Colors.black,
                      fontFamily: 'Poppins',
                    ),
                  ),
                )
            ),
            Center(
                child: Container(
                  margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                  child: Text(_proyecto['qualitative_benefit'],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 1.8*SizeConfig.textMultiplier,
                      color: Colors.black,
                      fontFamily: 'Poppins',
                    ),
                  ),
                )
            ),

            Container(
              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(6),
                  1:FlexColumnWidth(6)
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Fecha inicio: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['date_init'],
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Fecha fin: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['date_end'],
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        )
                      ]
                  ),
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Duración: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['month_duration'].toString()+' meses',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Beneficiarios: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['beneficiaries'].toString()=='null'?'N/D':'${_proyecto['beneficiaries']}',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        )
                      ]
                  ),
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('A. Presupuestario: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['budget_progress']==null?'0':_proyecto['budget_progress'],
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: HexColor('1063ad'),
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  //inversion texto lista proyectos
                                  Text('Avance físico: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['physical_progress'].toString(),
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: HexColor('1063ad'),
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        )
                      ]
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(10),
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Presupuesto: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text('\$'+_proyecto['encoded'],
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ]
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(10),
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 2*SizeConfig.widthMultiplier),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Text('Sector: ',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                  Text(_proyecto['zone'],
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 1.6*SizeConfig.textMultiplier,
                                      color: Colors.black,
                                      fontFamily: 'Poppins',
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        )
                      ]
                  ),
                ],
              ),
            ),
          ],
        )

    );
    Widget Calificacion=Container(
        width: double.infinity,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
              child: Center(
                child: Text('Calificación Proyecto',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: Colors.black,
                    fontSize: 3.3*SizeConfig.textMultiplier,
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
              child: RatingBar.builder(
                initialRating: 0,
                minRating: 1,
                direction: Axis.horizontal,
                itemCount: 5,
                allowHalfRating: false,
                itemSize: 12*SizeConfig.imageSizeMultiplier,
                unratedColor: Colors.black,
                glowColor: Colors.white,
                itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                itemBuilder: (context, _) => Icon(
                    Icons.star,
                    color: Colors.amber
                ),
                onRatingUpdate: (value){
                  calificacion=value.toInt();
                  print(calificacion.toString());
                },
              ),
            ),
          ],
        )
    );
    Widget Comentarios=Container(
      width: 90*SizeConfig.widthMultiplier,
      margin: EdgeInsets.only(bottom: 3*SizeConfig.heightMultiplier),
      child: Column(
        children: [
          Container(
              margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
              height: 6*SizeConfig.heightMultiplier,
              width: double.infinity,
              color: HexColor("01579b"),
              child: Center(
                child: Text('Comentario',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 3.3*SizeConfig.textMultiplier,
                  ),
                ),
              )
          ),
          Container(
            child: Container(
                height: 20*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  controller: commentController,
                  obscureText: false,
                  textInputAction: TextInputAction.done,
                  maxLines: 6,
                  //keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                    hintText: "",
                    hintStyle: TextStyle(
                      fontSize: 2*SizeConfig.textMultiplier,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  textAlignVertical: TextAlignVertical.center,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 2.2*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor("616163"),
                  ),
                )
            ),
          ),
          Container(
            height: 6*SizeConfig.heightMultiplier,
            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
            child: SizedBox(
              width: double.maxFinite,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                ),
                color:  HexColor("01579b"),
                child: Text("Enviar",
                  style: TextStyle(
                    fontSize: 2.5*SizeConfig.textMultiplier,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
                onPressed: (){
                  if(commentController.text==''){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else if(calificacion==0){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else{
                    RegistroComentario();
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
    Widget Listado=Container(
      width: 90*SizeConfig.widthMultiplier,
      margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier, bottom: 2*SizeConfig.heightMultiplier),
      child: ListView.separated(
            padding: EdgeInsets.zero,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            physics: BouncingScrollPhysics(),
            itemCount: _proyecto['reviews']==null?0:_proyecto['reviews'].length,
            separatorBuilder: (BuildContext context, int index) => Container(
              padding: EdgeInsets.only( top: 0.2*SizeConfig.heightMultiplier),
            ),
            itemBuilder: (BuildContext context, int index){
              return Container(
                margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier),
                child: Column(
                  children: [
                    if(_client_id.toString()==_proyecto['reviews'][index]['author_id'].toString())
                      Table(
                        children: [
                          TableRow(
                              children: [
                                Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                            margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                            child: Text('Autor: ',
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.bold,
                                                color: Colors.black,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                              ),
                                            )
                                        ),
                                        Container(
                                            margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                            child: Text(_proyecto['reviews'][index]['author'].toString(),
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontFamily: 'Poppins',
                                                color: Colors.black,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                              ),
                                            )
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ]
                          ),
                          TableRow(
                              children: [
                                Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                            margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                            child: Text('Fecha y Hora: ',
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.bold,
                                                color: Colors.black,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                              ),
                                            )
                                        ),
                                        Container(
                                            margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                            child: Text(_proyecto['reviews'][index]['created_at'].toString().substring(0,11)+' - '+_proyecto['reviews'][index]['created_at'].toString().substring(11,16),
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontFamily: 'Poppins',
                                                color: Colors.black,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                              ),
                                            )
                                        ),
                                      ],
                                    )
                                  ],
                                )
                              ]
                          ),
                          TableRow(
                              children: [
                                Column(
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                            margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                            child: Text('Calificación: ',
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.bold,
                                                color: Colors.black,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                              ),
                                            )
                                        ),
                                        Container(
                                          margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                          child: RatingBar.builder(
                                            initialRating: double.parse(_proyecto['reviews'][index]['rating'].toString()),
                                            minRating: 1,
                                            direction: Axis.horizontal,
                                            itemCount: 5,
                                            allowHalfRating: false,
                                            itemSize: 5*SizeConfig.imageSizeMultiplier,
                                            unratedColor: Colors.black,
                                            glowColor: Colors.white,
                                            itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                                            itemBuilder: (context, _) => Icon(
                                                Icons.star,
                                                color: Colors.amber
                                            ),
                                            onRatingUpdate: (value){
                                              print(value);
                                            },
                                            ignoreGestures: true,
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                )
                              ]
                          ),
                          TableRow(
                              children: [
                                Container(
                                    decoration: BoxDecoration(
                                        border:Border(
                                            bottom: BorderSide(color: Colors.grey)
                                        )
                                    ),
                                    margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                    padding:EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                                    child: Text(_proyecto['reviews'][index]['comment'],
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        color: Colors.black,
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                      ),
                                    )
                                ),
                              ]
                          ),
                        ],
                      )

                  ],
                ),
              );
            }
        ),
      );

    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectOpenData(anio: _anio,)));
        return shouldPop;
      },
      child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectOpenData(anio: _anio,)));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                child: Align(
                    alignment: Alignment.center,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        children: [
                          Titulo,
                          CabeceraProject,
                          Calificacion,
                          Comentarios,
                          Listado,
                        ],
                      ),
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Perfil()));
                      },
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()))
                      },
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}