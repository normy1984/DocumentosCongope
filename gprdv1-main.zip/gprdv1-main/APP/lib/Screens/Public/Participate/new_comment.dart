import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Profile/profile.dart';
import 'package:app/Screens/Public/Participate/comment_list.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class NewComment extends StatefulWidget{
  NewComment():super();
  _NewComment createState()=>new _NewComment();
}
class _NewComment extends State<NewComment>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  var responseData;
  var _tematica=[];
  var calificacion;
  var _tematicaSelected;
  var _cantones=[];
  bool _isLoading=false;
  var _url, _client_id;
  var _selectCanton, _selectAnio, _selectEtnia;
  String _anio='2022';
  List <String> anios=['2021','2020'];
  TextEditingController commentController= TextEditingController();
  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences clientpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _client_id=clientpref.getString('userId');
      _token=tokenpref.getString('token');
    });
    Locations();
    ListaTematica(_url);
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  //Lista de Paises
  Future<List> ListaTematica(String URL) async{
    var uri;
    setState(() {
      uri=Uri.parse('${URL}/api/client/subjects');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
    });
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _tematica=responseData['data'];
        print(_tematica);
      });
    }else{
      print(response.body);
      print('ErrorPais');
    }
    return _tematica;
  }

  Future<dynamic> DatosGuardados(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 27*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                                child: Text("Comentario registrado exitosamente",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>CommentList()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  RegistroComentario(String URL) async{
    /*print(_client_id.toString());
    print(_tematicaSelected);
    print(commentController.text);
    print(calificacion.toString());
    print(_selectCanton);*/
    final response =await http.post('${URL}/api/client/reviews?author_id=${_client_id.toString()}&type=subject&type_id=${_tematicaSelected}&comment=${commentController.text}&rating=${calificacion.toString()}&location_id=${_selectCanton}', headers: {
      'Authorization': 'Bearer $_token',
      //'Content-Type' : 'application/json'
    },
    );
    if (response.statusCode == 200) {
      var responseData = json.decode(response.body);
      print("registro Exitoso");
      DatosGuardados();
    }else{
      ErrorGuardar('Error al registrar el comentario');
      print(response.statusCode);
      print(response.body);
    }
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<List> Locations() async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/locations');
    });
    final response =await http.get(uri, headers: {
      //'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _cantones=responseData['data'];
        print(_cantones);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _cantones;
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Nuevo Comentario',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget CabeceraProject=Container(
        width: 90*SizeConfig.widthMultiplier,
        padding: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(4),
                  1:FlexColumnWidth(9),
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier),
                            height: 11*SizeConfig.imageSizeMultiplier,
                            width: 11*SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                            ),
                            child: Center(
                                child: Text('Cantón',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                    color: Colors.black,
                                    fontFamily: 'Poppins',
                                  ),
                                )
                            )
                        ),
                        Container(
                            height: 5 * SizeConfig.heightMultiplier,
                            margin: EdgeInsets.only(top: 0 * SizeConfig.heightMultiplier),
                            padding: EdgeInsets.only(left: 3 * SizeConfig.widthMultiplier, right: 0 * SizeConfig.widthMultiplier),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(15 * SizeConfig.widthMultiplier)),
                            ),

                            child: Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: 2 * SizeConfig.widthMultiplier,
                                    right: 2 * SizeConfig.widthMultiplier),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(1 * SizeConfig.widthMultiplier)),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    hint: Text('Seleccionar', textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                        fontFamily: 'Poppins',
                                        color: HexColor('616163'),
                                      ),
                                    ),
                                    // Not necessary for Option 1
                                    value: _selectCanton,
                                    isExpanded: true,
                                    onChanged: (newValue) {
                                      setState(() {
                                        _selectCanton = newValue;
                                      });
                                    },
                                    items: _cantones.map((location) {
                                      return DropdownMenuItem(
                                        child: new Text(location['description'],
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 2*SizeConfig.textMultiplier,
                                            color: HexColor('616163'),
                                          ),
                                        ),
                                        value: location['id'].toString(),
                                      );
                                    }).toList(),
                                  ),
                                )
                            )
                        ),
                      ]
                  )
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(4),
                  1:FlexColumnWidth(9),
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier),
                            height: 11*SizeConfig.imageSizeMultiplier,
                            width: 11*SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                            ),
                            child: Center(
                                child: Text('Área temática',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                    color: Colors.black,
                                    fontFamily: 'Poppins',
                                  ),
                                )
                            )
                        ),
                        Container(
                            height: 5 * SizeConfig.heightMultiplier,
                            margin: EdgeInsets.only(top: 0 * SizeConfig.heightMultiplier),
                            padding: EdgeInsets.only(left: 3 * SizeConfig.widthMultiplier, right: 0 * SizeConfig.widthMultiplier),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(15 * SizeConfig.widthMultiplier)),
                            ),

                            child: Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: 2 * SizeConfig.widthMultiplier,
                                    right: 2 * SizeConfig.widthMultiplier,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(1 * SizeConfig.widthMultiplier)),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    hint: Text('Seleccionar', textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                        fontFamily: 'Poppins',
                                        color: HexColor('616163'),
                                      ),
                                    ),
                                    // Not necessary for Option 1
                                    value: _tematicaSelected,
                                    isExpanded: true,
                                    onChanged: (newValue) {
                                      setState(() {
                                        _tematicaSelected = newValue;
                                      });
                                    },
                                    items: _tematica.map((location) {
                                      return DropdownMenuItem(
                                        child: new Text(location['name'],
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 2*SizeConfig.textMultiplier,
                                            color: HexColor('616163'),
                                          ),
                                        ),
                                        value: location['id'].toString(),
                                      );
                                    }).toList(),
                                  ),
                                )
                            )
                        ),
                      ]
                  )
                ],
              ),
            ),
          ],
        )

    );
    Widget Calificacion=Container(
        width: double.infinity,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
              child: Center(
                child: Text('Calificación',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: Colors.black,
                    fontSize: 3.3*SizeConfig.textMultiplier,
                  ),
                ),
              ),
            ),
            Container(
                margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                child: Center(
                  child: RatingBar.builder(
                    initialRating: 0,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: false,
                    itemCount: 5,
                    unratedColor: Colors.black,
                    glowColor: Colors.white,
                    itemSize: 10*SizeConfig.imageSizeMultiplier,
                    itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                    itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: Colors.amber
                    ),
                    onRatingUpdate: (rating) {
                      calificacion=rating.toInt();
                    },
                    //onRatingUpdate: (double value) { return null; },
                  ),
                )
            )
          ],
        )
    );
    Widget Comentarios=Container(
      width: 90*SizeConfig.widthMultiplier,
      child: Column(
        children: [
          Container(
              margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
              height: 6*SizeConfig.heightMultiplier,
              width: double.infinity,
              color: HexColor("01579b"),
              child: Center(
                child: Text('Comentario',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 3.3*SizeConfig.textMultiplier,
                  ),
                ),
              )
          ),
          Container(
            child: Container(
                height: 20*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  controller: commentController,
                  obscureText: false,
                  textInputAction: TextInputAction.done,
                  maxLines: 6,
                  //keyboardType: TextInputType.multiline,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                    hintText: "",
                    hintStyle: TextStyle(
                      fontSize: 2*SizeConfig.textMultiplier,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  textAlignVertical: TextAlignVertical.center,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 2.2*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor("616163"),
                  ),
                )
            ),
          ),
          Container(
            height: 6*SizeConfig.heightMultiplier,
            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier, bottom: 4*SizeConfig.heightMultiplier),
            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
            child: SizedBox(
              width: double.maxFinite,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                ),
                color:  HexColor("01579b"),
                child: Text("Enviar",
                  style: TextStyle(
                    fontSize: 2.5*SizeConfig.textMultiplier,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
                onPressed: (){
                  if(commentController.text==''){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else if(calificacion==0){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else if(_selectCanton==''){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else if(_tematicaSelected==''){
                    ErrorGuardar('Todos los datos son necesarios');
                  }else{
                    RegistroComentario(_url.toString());
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );

    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> CommentList()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> CommentList()));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                color: Colors.transparent,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Titulo,
                        CabeceraProject,
                        Calificacion,
                        Comentarios,
                      ],
                    ),
                  )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Perfil()));
                      },
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()))
                      },
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}