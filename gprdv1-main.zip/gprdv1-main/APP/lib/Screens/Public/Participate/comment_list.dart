import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Profile/profile.dart';
import 'package:app/Screens/Public/Participate/new_comment.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class CommentList extends StatefulWidget{
  CommentList():super();
  _CommentList createState()=>new _CommentList();
}
class _CommentList extends State<CommentList>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  bool _isLoading=false;
  var _url, _client_id;
  var _comments;
  var _respuestas;
  var _selectCanton, _selectAnio, _selectEtnia;

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences clientpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();

    setState(() {
      _url=urlpref.getString('url');
      _client_id=clientpref.getString('userId');
      _token=tokenpref.getString('token');
    });
    ListComment();
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  Future<List> ListComment() async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/client/reviews?author_id=${_client_id}&type=subject');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _comments=responseData['data'];
        print(_comments);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _comments;
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> DetalleComentario(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                  padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                  height: 65*SizeConfig.heightMultiplier,
                  width: 95*SizeConfig.widthMultiplier,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                  ),
                  child: Column(
                    children: [
                      Container(
                          margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                          child: Align(
                            alignment: Alignment.topCenter,
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                  width: 10*SizeConfig.widthMultiplier,
                                  height: 10*SizeConfig.imageSizeMultiplier,
                                  decoration: BoxDecoration(
                                      color: HexColor("01579b"),
                                      borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                  ),
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Center(
                                      child: Icon(Icons.check, color: Colors.white),
                                    ),
                                  )
                              ),
                            ),
                          )
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                        child: Text("Respuestas",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.bold,
                              fontSize: 2.3*SizeConfig.textMultiplier,
                              color: Colors.black
                          ),
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                          padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                          child: Container(
                            width: 90*SizeConfig.widthMultiplier,
                            height: 40*SizeConfig.heightMultiplier,
                            child: ListView.separated(
                                padding: EdgeInsets.zero,
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                physics: BouncingScrollPhysics(),
                                itemCount: _respuestas==null?0:_respuestas.length,
                                separatorBuilder: (BuildContext context, int index) => Container(
                                  padding: EdgeInsets.only( top: 0.2*SizeConfig.heightMultiplier),
                                ),
                                itemBuilder: (BuildContext context, int index){
                                  return Container(
                                    margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                    child: Column(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(bottom: 1*SizeConfig.heightMultiplier),
                                          child: Table(
                                            children: [
                                              TableRow(
                                                  children: [
                                                    Container(
                                                        margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                        child: Text('Autor: '+_respuestas[index]['author'].toString(),
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            fontFamily: 'Poppins',
                                                            fontWeight: FontWeight.bold,
                                                            color: Colors.black,
                                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                                          ),
                                                        )
                                                    ),
                                                  ]
                                              ),
                                              TableRow(
                                                  children: [
                                                    Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Container(
                                                                margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                                child: Text('Fecha: ',
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    fontFamily: 'Poppins',
                                                                    fontWeight: FontWeight.bold,
                                                                    color: Colors.black,
                                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                                  ),
                                                                )
                                                            ),
                                                            Container(
                                                                margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                                child: Text(_respuestas[index]['created_at'].toString().substring(0,11)+'-'+_respuestas[index]['created_at'].toString().substring(10,16),
                                                                  textAlign: TextAlign.left,
                                                                  style: TextStyle(
                                                                    fontFamily: 'Poppins',
                                                                    color: Colors.black,
                                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                                  ),
                                                                )
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    )
                                                  ]
                                              ),
                                              TableRow(
                                                  children: [
                                                    Container(
                                                        decoration:BoxDecoration(
                                                          border: Border(
                                                            bottom: BorderSide(color: Colors.grey)
                                                          )
                                                        ),
                                                        margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, right: 3*SizeConfig.widthMultiplier),
                                                        padding:EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                                                        child: Text(_respuestas[index]['comment'],
                                                          textAlign: TextAlign.left,
                                                          style: TextStyle(
                                                            fontFamily: 'Poppins',
                                                            color: Colors.black,
                                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                                          ),
                                                        )
                                                    ),
                                                  ]
                                              ),
                                            ],
                                          ),
                                        )

                                      ],
                                    ),
                                  );
                                }
                            ),
                          )
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                        child: InkWell(
                          onTap: (){
                            Navigator.of(context).pop();
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>CommentList()));
                            //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                          },
                          child: Container(
                            width: 60*SizeConfig.widthMultiplier,
                            height: 5*SizeConfig.heightMultiplier,
                            decoration: BoxDecoration(
                                color: HexColor("01579b"),
                                borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                            ),
                            child: Center(
                              child: Text("Aceptar",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    color: Colors.white
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Participa',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget Comentarios=Container(
      width: 90*SizeConfig.widthMultiplier,
      child: Column(
        children: [
          Container(
            height: 6*SizeConfig.heightMultiplier,
            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
            child: SizedBox(
              width: double.maxFinite,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                ),
                color:  HexColor("01579b"),
                child: Text("Nuevo Comentario",
                  style: TextStyle(
                    fontSize: 2.5*SizeConfig.textMultiplier,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> NewComment()));
                  //_initPusher();
                },
              ),
            ),
          ),
        ],
      ),
    );

    Widget Contenido=Container(
      width: 90*SizeConfig.widthMultiplier,
      margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
      height: 58*SizeConfig.heightMultiplier,
      child: _isLoading?Center(
        child: CircularProgressIndicator(),
      ):Container(
        child: ListView.separated(
            padding: EdgeInsets.zero,
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            physics: BouncingScrollPhysics(),
            itemCount: _comments==null?0:_comments.length,
            separatorBuilder: (BuildContext context, int index) => Container(
              padding: EdgeInsets.only( top: 0.2*SizeConfig.heightMultiplier),
            ),
            itemBuilder: (BuildContext context, int index){
              return Container(
                margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                child: Column(
                  children: [
                    if(_comments.length==0)
                      Center(
                          child: Text('No existe información',
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              fontSize: 2*SizeConfig.textMultiplier,
                            ),
                          )
                      )
                    else
                      Container(
                        margin: EdgeInsets.only(bottom: 1*SizeConfig.heightMultiplier),
                        decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(color: Colors.black87),
                              top: BorderSide(color: Colors.black87),
                              left: BorderSide(color: Colors.black87),
                              right: BorderSide(color: Colors.black87),
                            ),
                            borderRadius: BorderRadius.all(Radius.circular(3*SizeConfig.widthMultiplier))
                        ),
                        child: ExpansionTile(
                          title: Table(
                            children: [
                              TableRow(
                                  children: [
                                    Container(
                                        margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                        child: Text(_comments[index]['author'].toString(),
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                          ),
                                        )
                                    ),
                                  ]
                              ),
                              TableRow(
                                  children: [
                                    Column(
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                                margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                child: Text('Fecha: ',
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black,
                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                  ),
                                                )
                                            ),
                                            Container(
                                                margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                child: Text(_comments[index]['created_at'].toString().substring(0,11)+'-'+_comments[index]['created_at'].toString().substring(10,16),
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    color: Colors.black,
                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                  ),
                                                )
                                            ),
                                          ],
                                        )
                                      ],
                                    )
                                  ]
                              ),
                              TableRow(
                                  children: [
                                    Column(
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                                margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                child: Text('Calificación: ',
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                    fontFamily: 'Poppins',
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black,
                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                  ),
                                                )
                                            ),
                                            Container(
                                              margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                              child: RatingBar.builder(
                                                initialRating: double.parse(_comments[index]['rating'].toString()),
                                                minRating: 1,
                                                direction: Axis.horizontal,
                                                itemCount: 5,
                                                allowHalfRating: false,
                                                itemSize: 5*SizeConfig.imageSizeMultiplier,
                                                unratedColor: Colors.black,
                                                glowColor: Colors.white,
                                                itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
                                                itemBuilder: (context, _) => Icon(
                                                    Icons.star,
                                                    color: Colors.amber
                                                ),
                                                onRatingUpdate: (value){
                                                  print(value);
                                                },
                                                ignoreGestures: true,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    )
                                  ]
                              ),
                              TableRow(
                                  children: [
                                    Container(
                                        margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                        padding:EdgeInsets.only(bottom: 1*SizeConfig.heightMultiplier),
                                        child: Text(_comments[index]['comment'],
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            color: Colors.black,
                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                          ),
                                        )
                                    ),
                                  ]
                              ),
                            ],
                          ),
                          children: <Widget>[
                            if(_comments[index]['replies'].length.toString()=='0')
                              Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      top: BorderSide(color: Colors.black87),
                                    ),
                                  ),
                                  child:Text('')
                              )
                            else
                              Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      top: BorderSide(color: Colors.black87),
                                    ),
                                  ),
                                  margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                  child: Column(
                                    children: [
                                      Table(
                                        children: [
                                          TableRow(
                                              children: [
                                                Container(
                                                    margin:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 4*SizeConfig.widthMultiplier),
                                                    child: Text('Autor: '+_comments[index]['replies'][0]['author'].toString(),
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        fontFamily: 'Poppins',
                                                        fontWeight: FontWeight.bold,
                                                        color: Colors.black,
                                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                                      ),
                                                    )
                                                ),
                                              ]
                                          ),
                                          TableRow(
                                              children: [
                                                Column(
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Container(
                                                            margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 4*SizeConfig.widthMultiplier),
                                                            child: Text('Fecha: ',
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                fontFamily: 'Poppins',
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black,
                                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                                              ),
                                                            )
                                                        ),
                                                        Container(
                                                            margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 1*SizeConfig.widthMultiplier),
                                                            child: Text(_comments[index]['replies'][0]['created_at'].toString().substring(0,11)+'-'+_comments[index]['replies'][0]['created_at'].toString().substring(10,16),
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(
                                                                fontFamily: 'Poppins',
                                                                color: Colors.black,
                                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                                              ),
                                                            )
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                )
                                              ]
                                          ),
                                          TableRow(
                                              children: [
                                                Container(
                                                    margin:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, left: 4*SizeConfig.widthMultiplier),
                                                    padding:EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                                                    child: Text(_comments[index]['replies'][0]['comment'],
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                        fontFamily: 'Poppins',
                                                        color: Colors.black,
                                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                                      ),
                                                    )
                                                ),
                                              ]
                                          ),
                                          TableRow(
                                              children: [
                                                InkWell(
                                                  onTap: ()async{
                                                    setState(() {
                                                      _respuestas=_comments[index]['replies'];
                                                      DetalleComentario();
                                                    });
                                                  },
                                                  child: Container(
                                                    height: 3*SizeConfig.heightMultiplier,
                                                    width: 28*SizeConfig.widthMultiplier,
                                                    margin:EdgeInsets.only(bottom: 0.9*SizeConfig.heightMultiplier, right: 20*SizeConfig.widthMultiplier, left: 20*SizeConfig.widthMultiplier),
                                                    decoration:BoxDecoration(
                                                      color: HexColor('1063ad'),
                                                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                                    ),
                                                    child: Center(
                                                      child: Text("Ver Más",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                          fontWeight: FontWeight.bold,
                                                          fontSize: 1.8*SizeConfig.textMultiplier,
                                                          color: Colors.white,
                                                          fontFamily: 'Poppins',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ]
                                          )
                                        ],
                                      ),
                                    ],
                                  )
                              ),
                          ],
                        ),
                      )
                  ],
                ),
              );
            }
        ),
      )
    );

    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> PublicMenu()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> PublicMenu()));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                color: Colors.transparent,
                child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Titulo,
                        Comentarios,
                        Contenido,
                      ],
                    ),
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Perfil()));
                      },
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()))
                      },
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}