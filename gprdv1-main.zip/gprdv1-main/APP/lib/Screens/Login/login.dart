import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:app/Screens/Login/reset_password.dart';
import 'package:app/Screens/Public/Register/register_person.dart';
import 'package:app/Screens/Public/public_menu.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:http/http.dart' as http;

class Login extends StatefulWidget{
  _Login createState()=>new _Login();
}
class _Login extends State<Login>{
  final _globalKey = GlobalKey<ScaffoldState>();
  var JsonData=null;
  var data;
  var usuario;
  var password;
  var url;
  var tipoAcceso='publico';
  var _token;
  bool _institucion=false;
  List <String> cantones=['Tulcán', 'Mira', 'Espejo',];
  Random rnd = new Random();
  var max = 9999;
  var min = 1000;
  var codigo;
  var _selectCanton;
  TextEditingController user= TextEditingController();
  TextEditingController user1= TextEditingController();
  TextEditingController pass= TextEditingController();


  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    SharedPreferences usuarioprefs = await SharedPreferences.getInstance();
    SharedPreferences passwordpref = await SharedPreferences.getInstance();
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      usuario=usuarioprefs.getString('usuario');
      password=passwordpref.getString('password');
      url=urlpref.getString('url');
    });
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Validar(){
    if(user.text=='' || pass.text==''){
      ErrorGuardar('Ususario o contraseña incorrectos');
    }else{
      GetToken(user.text, pass.text);
    }
  }


  GetToken(String users, String pass) async{
    setState(() {
      bool _Loading=true;
    });
    print(tipoAcceso);
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      url=urlpref.getString('url');
    });
    var _uri;
    if(tipoAcceso=='institucional'){
      setState(()  {
        _uri=url+'/api/login?email=${users}&password=${pass}';
      });
    }else if(tipoAcceso=='publico'){
      setState(() {
        _uri=url+'/api/loginclientes';
      });
    }
    if(usuario.toString()!=users || password.toString()!=pass){
      //DatosEquivocados();
    };
    final response= await http.post('${_uri}',
      body: {
        'email':users,
        'password':pass,
      },
      headers: <String, String>{},
    );
    JsonData=json.decode(response.body);
    if(response.statusCode == 200){
      String urls=url;
      SharedPreferences user= await SharedPreferences.getInstance();
      user.setString('usuario', users);
      SharedPreferences password= await SharedPreferences.getInstance();
      password.setString('password', pass);
      SharedPreferences _url= await SharedPreferences.getInstance();
      _url.setString('url', urls);
      SharedPreferences _idUser= await SharedPreferences.getInstance();
      _idUser.setString('userId', JsonData['data']['client_id'].toString());
      setState(() {
        _token=JsonData['data']['token'];
        bool _Loading=false;
      });
      SharedPreferences token= await SharedPreferences.getInstance();
      token.setString('token', _token.toString());
      if(tipoAcceso=='institucional'){
        setState(()  {
          Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()));
        });
      }else if(tipoAcceso=='publico'){
        setState(()  {
          Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
        });
      }
    }
    else{
      ErrorGuardar('Ususario o contraseña incorrectos');
      print(response.body);
      print(response.statusCode);

    }
  }

  GetToken1(String users) async{
    setState(() {
      bool _Loading=true;
    });
    print(tipoAcceso);
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      url=urlpref.getString('url');
    });
    var _uri;
    setState(() {
      _uri=url+'/api/createPasswordReset';
    });
    if(usuario.toString()!=users || password.toString()!=pass){
      //DatosEquivocados();
    };
    final response= await http.post('${_uri}',
      body: {
        'email':users,
      },
      headers: <String, String>{},
    );
    var JsonData1=json.decode(response.body);
    if(response.statusCode == 200){
      //print(JsonData1);
      Navigator.push(context, MaterialPageRoute(builder: (context)=>ResetPassword(tok: JsonData1['token'],eml: users, codigo: JsonData1['code'],)));
      setState(() {
        user1.text='';
      });
    }
    else{
      ErrorGuardar('El usuario no se encuentra registrado');
      print(response.body);
      print(response.statusCode);

    }
  }

  Future<dynamic> Email(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                  padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                  height: 37*SizeConfig.heightMultiplier,
                  width: 95*SizeConfig.widthMultiplier,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                  ),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Container(
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: InkWell(
                                      onTap: (){
                                        Navigator.of(context).pop();
                                      },
                                      child: Container(
                                          width: 10*SizeConfig.widthMultiplier,
                                          height: 10*SizeConfig.imageSizeMultiplier,
                                          decoration: BoxDecoration(
                                              color: HexColor("01579b"),
                                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                          ),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Center(
                                              child: Icon(Icons.check, color: Colors.white),
                                            ),
                                          )
                                      ),
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                child: Text("Recuperar Contraseña",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontWeight: FontWeight.bold,
                                      fontSize: 2.3*SizeConfig.textMultiplier,
                                      color: Colors.black
                                  ),
                                ),
                              ),
                              Container(
                                  height: 6*SizeConfig.heightMultiplier,
                                  margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                                  padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                                  ),
                                  child: TextField(
                                    textAlign: TextAlign.center,
                                    textAlignVertical: TextAlignVertical.top,
                                    keyboardType: TextInputType.text,
                                    controller: user1,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                    style: TextStyle(
                                      fontSize: 2.3*SizeConfig.textMultiplier,
                                      fontFamily: 'Poppins',
                                      color: HexColor('616163'),
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                child: Text("Email",
                                  style: TextStyle(
                                    fontSize: 2*SizeConfig.textMultiplier,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                    fontFamily: 'Poppins',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                                child: InkWell(
                                  onTap: (){
                                    if(user1.text==null){
                                      Navigator.of(context).pop();
                                      ErrorGuardar('El email es requerido');
                                      setState(() {
                                        user1.text='';
                                      });
                                    }else{
                                      GetToken1(user1.text.toString());
                                    }
                                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                                  },
                                  child: Container(
                                    width: 60*SizeConfig.widthMultiplier,
                                    height: 5*SizeConfig.heightMultiplier,
                                    decoration: BoxDecoration(
                                        color: HexColor("01579b"),
                                        borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                    ),
                                    child: Center(
                                      child: Text("Aceptar",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontWeight: FontWeight.bold,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                            color: Colors.white
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
              ),
            )
        );
      },
    );
  }

  //Amarillo ffc20e
  //Negro 616163
  //Rojo d71921
  //Naranja 1063ad
  //Verde 1063ad

  @override
  Widget build(BuildContext context) {
    //Logo Umani//
    //Imagen Empresa//
    Widget ImagenEmpresa= Container(
      width: double.infinity,
      child: Image(
        image: AssetImage("images/icons/LOGO-PREFECTURA-CARCHI.png"),
        height: 25*SizeConfig.heightMultiplier,
      )
    );
    //Formulario de ingreso//
    Widget formularioIngreso = Container(
      padding: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: Text("Datos de Ingreso",
                style: TextStyle(
                  fontSize: 3.5*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier),
              child: Text("Cuida tus contraseñas no las compartas con nadie",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 1.3*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: HexColor('616163'),
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.text,
                  controller: user,
                  obscureText: false,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Email",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
                height: 6*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                ),
                child: TextField(
                  textAlign: TextAlign.center,
                  textAlignVertical: TextAlignVertical.top,
                  controller: pass,
                  obscureText: true,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  style: TextStyle(
                    fontSize: 2.3*SizeConfig.textMultiplier,
                    fontFamily: 'Poppins',
                    color: HexColor('616163'),
                  ),
                )
            ),
            Container(
              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
              child: Text("Contraseña",
                style: TextStyle(
                  fontSize: 2*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 3*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
              child: CheckboxListTile(
                title: Text('Marca esta opción si eres funcionario de un Gobierno Autónomo Descentralizado Provincial',
                  style: TextStyle(
                    fontSize: 1.45*SizeConfig.textMultiplier,
                    color: Colors.black,
                    fontFamily: 'Poppins',
                  ),
                ),
                value: _institucion,
                onChanged: (bool? value){
                  setState(() {
                    _institucion=value!;
                  });
                  if(_institucion==false){
                    setState(() {
                      tipoAcceso='publico';
                    });
                  }else if(_institucion==true){
                    setState(() {
                      tipoAcceso='institucional';
                    });
                  }
                },
                controlAffinity: ListTileControlAffinity.leading,
              )
            ),
            Container(
              height: 6*SizeConfig.heightMultiplier,
              margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
              child: SizedBox(
                width: double.maxFinite,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                  ),
                  color:  HexColor("01579b"),
                  child: Text("Ingresar",
                    style: TextStyle(
                      fontSize: 2.5*SizeConfig.textMultiplier,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  onPressed: (){
                    //GetToken(user.text, pass.text, url);
                    Validar();
                    //Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
                    //Navigator.push(context, MaterialPageRoute(builder: (context)=> PublicMenu()));
                  },
                ),
              ),
            ),
            Container(
              height: 6*SizeConfig.heightMultiplier,
              margin: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
              padding: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier, right: 10*SizeConfig.widthMultiplier),
              child: SizedBox(
                width: double.maxFinite,
                child: RaisedButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                  ),
                  color:  HexColor("ff7400"),
                  child: Text("Registrar",
                    style: TextStyle(
                      fontSize: 2.5*SizeConfig.textMultiplier,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>RegisterUser()));
                    //_initPusher();
                  },
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 1.5*SizeConfig.heightMultiplier),
              child: InkWell(
                onTap: (){
                  Email();
                },
                child: Text('Recuperar Contraseña',
                  style: TextStyle(
                    fontSize: 1.5*SizeConfig.textMultiplier,
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
    // TODO: implement build
    return WillPopScope(
      onWillPop: (){
        exit(0);
      },
      child:Scaffold(
        backgroundColor: Colors.white,
        key: _globalKey,
        body: Center(
          child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: <Widget>[
                        ImagenEmpresa,
                        formularioIngreso,
                      ],
                    ),
                  )
              )
          ),
        ),
      ),
    );
  }
}