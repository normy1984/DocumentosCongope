import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Workers/Citizenship/groups.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:intl/intl.dart';

class GruposInteres{
  String indicadores='';
  double valor=0;
  GruposInteres(this.indicadores, this.valor);
}

class Territorios{
  String canton='';
  double total=0;
  Territorios(this.canton, this.total);
}

class Visitas{
  String indicadores='';
  double valor=0;
  Visitas(this.indicadores, this.valor);
}

class Comentario{
  String name='';
  double total=0;
  Comentario(this.name, this.total);
}

class CitizenMenu extends StatefulWidget{
  CitizenMenu():super();
  _CitizenMenu createState()=>new _CitizenMenu();
}
class _CitizenMenu extends State<CitizenMenu>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  var _url;
  var _grupos;
  var _cantones;
  var _visitas;
  var _territorio;
  var _dataGrupos;
  var _comentarios;
  var _dataVisitas;
  List<Territorios> _dataTerritorio=[];
  List<Comentario> _dataComentarios=[];
  String rango2030='', rango3040='', rango4050='', rango50='';
  String numeroVisitas='';
  List <String> mes=<String>['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  var _selectMes;
  String _mesString='';
  var _isLoading=false;
  TextEditingController anioController= TextEditingController();
  List<charts.Series<dynamic, String>> seriesList=[];
  List<charts.Series<dynamic, String>> seriesList2=[];
  List<charts.Series<dynamic, String>> seriesList3=[];
  List<charts.Series<dynamic, String>> seriesList4=[];

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _token=tokenpref.getString('token');
      Grupos('2022');
    });
  }

  Future<List> Locations() async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/locations');
    });
    final response =await http.get(uri, headers: {
      //'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _cantones=responseData['data'];
        Territorio();
      });
    }else{
      print('Erro lista profesionales');
    }
    return _cantones;
  }

  Grupos(String anio) async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/groupClient');
      //Locations();
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _grupos=responseData['data'];
        seriesList=_createData();
      });
    }else{
      print('Erro lista profesionales');
    }
  }

  Territorio()async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/locationsGroupClient');
      //Locations();
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _territorio=responseData['data'];
        seriesList3=_createData3();
      });
      Detalle3();
    }else{
      print('Erro lista profesionales');
    }
  }

  ComentarioData()async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/reviewsDetails');
      //Locations();
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _comentarios=responseData['data'];
        seriesList4=_createData4();
      });
      Detalle4();
    }else{
      print('Erro lista profesionales');
    }
  }

  VisitasData(String fecha) async{
    print(fecha);
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/visitClient/${fecha}');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _visitas=responseData['data'];
        if(_visitas.length==0){

        }else{
          seriesList2=_createData2();
        }
        //seriesList=_createData();
      });
      if(_visitas==null){
        setState(() {
          numeroVisitas='0';
        });
      }
      Detalle2();
    }else{
      print('Erro lista profesionales');
    }
  }

  List<charts.Series<GruposInteres, String>> _createData(){
    setState(() {
      rango2030=_grupos==null?'0':_grupos[0]['rango20-30'].toString();
      rango3040=_grupos==null?'0':_grupos[1]['rango30-40'].toString();
      rango4050=_grupos==null?'0':_grupos[2]['rango40-50'].toString();
      rango50=_grupos==null?'0':_grupos[3]['rango50'].toString();
      _dataGrupos = [
        GruposInteres('20-30', double.parse(rango2030)),
        GruposInteres('30-40', double.parse(rango3040)),
        GruposInteres('40-50', double.parse(rango4050)),
        GruposInteres('50', double.parse(rango50)),
      ];
    });
    return [charts.Series<GruposInteres, String>(
      id: 'Composicion de Gasto',
      domainFn: (GruposInteres gasto, _)=>gasto.indicadores,
      measureFn: (GruposInteres gasto, _)=>gasto.valor,
      data: _dataGrupos,
      labelAccessorFn: (GruposInteres gasto, _) =>gasto.valor.toString(),
    )];
  }
  List<charts.Series<Visitas, String>> _createData2(){
    setState(() {
      numeroVisitas=_visitas==null?'0':_visitas['numero'].toString();
      _dataVisitas = [
        Visitas('${_selectMes}', double.parse(numeroVisitas)),
      ];
    });
    return [charts.Series<Visitas, String>(
      id: 'Visitas al mes',
      domainFn: (Visitas gasto, _)=>gasto.indicadores,
      measureFn: (Visitas gasto, _)=>gasto.valor,
      data: _dataVisitas,
      labelAccessorFn: (Visitas gasto, _) =>gasto.valor.toString(),
    )];
  }
  List<charts.Series<Territorios, String>> _createData3(){
    setState(() {
      for (var trabJson in _territorio) {
        try {
          _dataTerritorio.add(Territorios(trabJson['canton'],double.parse(trabJson['total'].toString())));
        } catch (e) {
          print(e.toString());
        }
      }
    });
    return [charts.Series<Territorios, String>(
      id: 'Visitas al mes',
      domainFn: (Territorios gasto, _)=>gasto.canton,
      measureFn: (Territorios gasto, _)=>gasto.total,
      data: _dataTerritorio,
      labelAccessorFn: (Territorios gasto, _) =>gasto.total.toString(),
    )];
  }

  List<charts.Series<Comentario, String>> _createData4(){
    setState(() {
      for (var trabJson in _comentarios[0]) {
        try {
          _dataComentarios.add(Comentario(trabJson['name'],double.parse(trabJson['total'].toString())));
        } catch (e) {
          print(e.toString());
        }
      }
    });
    return [charts.Series<Comentario, String>(
      id: 'Visitas al mes',
      domainFn: (Comentario gasto, _)=>gasto.name,
      measureFn: (Comentario gasto, _)=>gasto.total,
      data: _dataComentarios,
      labelAccessorFn: (Comentario gasto, _) =>gasto.total.toString(),
    )];
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  barChart(){
    return charts.BarChart(
      seriesList,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }
  barChart2(){
    return charts.BarChart(
      seriesList2,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }
  barChart3(){
    return charts.BarChart(
      seriesList3,
      animate: true,
      vertical: false,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }
  barChart4(){
    return charts.BarChart(
      seriesList4,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }

  Future<dynamic> Detalle1(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 59*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            width: 80*SizeConfig.widthMultiplier,
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                  child: Text("Usuarios Registrados por Grupos de Edad",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.3*SizeConfig.textMultiplier,
                                        color: Colors.black
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                width: 90*SizeConfig.widthMultiplier,
                                height: 30*SizeConfig.heightMultiplier,
                                child:barChart(),
                              )
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                                anioController.text=='';
                                _selectMes='Seleccionar';
                                _mesString='';
                                //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }
  Future<dynamic> Detalle2(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState){
            return Center(
              //backgroundColor: Colors.blue,
                child: Material(
                  type: MaterialType.transparency,
                  child: Container(
                    height: 57*SizeConfig.heightMultiplier,
                    width: 95*SizeConfig.widthMultiplier,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                    ),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Container(
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: InkWell(
                                      onTap: (){
                                        Navigator.of(context).pop();
                                      },
                                      child: Container(
                                          width: 10*SizeConfig.widthMultiplier,
                                          height: 10*SizeConfig.imageSizeMultiplier,
                                          decoration: BoxDecoration(
                                              color: HexColor("01579b"),
                                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                          ),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Center(
                                              child: Icon(Icons.check, color: Colors.white),
                                            ),
                                          )
                                      ),
                                    ),
                                  )
                              ),
                              Container(
                                child: Column(
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                      child: Text("Visitas Mensuales",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontWeight: FontWeight.bold,
                                            fontSize: 2.3*SizeConfig.textMultiplier,
                                            color: Colors.black
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                  padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                  child: Container(
                                    width: 90*SizeConfig.widthMultiplier,
                                    height: 30*SizeConfig.heightMultiplier,
                                    child:barChart2(),
                                  )
                              ),
                              Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        border: Border(
                                            bottom: BorderSide(color: HexColor("d71921"))
                                        )
                                    ),
                                  )
                              ),
                              Container(
                                margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                                  },
                                  child: Container(
                                    width: 60*SizeConfig.widthMultiplier,
                                    height: 5*SizeConfig.heightMultiplier,
                                    decoration: BoxDecoration(
                                        color: HexColor("01579b"),
                                        borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                    ),
                                    child: Center(
                                      child: Text("Aceptar",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontWeight: FontWeight.bold,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                            color: Colors.white
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )
            );
          }
        );
      },
    );
  }

  Future<dynamic> Detalle3(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 57*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                  child: Text("Usuarios Registrados por Cantón",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.3*SizeConfig.textMultiplier,
                                        color: Colors.black
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: SingleChildScrollView(
                                scrollDirection: Axis.vertical,
                                child: Container(
                                    width: 90*SizeConfig.widthMultiplier,
                                    height: 30*SizeConfig.heightMultiplier,
                                    child: barChart3()
                                ),
                              )
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                                anioController.text=='';
                                _selectMes='Seleccionar';
                                _mesString='';
                                //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }
  Future<dynamic> Detalle4(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 57*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                  child: Text("Comentarios por Área Temática",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.3*SizeConfig.textMultiplier,
                                        color: Colors.black
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                width: 90*SizeConfig.widthMultiplier,
                                height: 30*SizeConfig.heightMultiplier,
                                child:barChart4(),
                              )
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                                anioController.text=='';
                                _selectMes='Seleccionar';
                                _mesString='';
                                //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<dynamic> ErrorGuardar(String text){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 20*SizeConfig.heightMultiplier,
                width: 80*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("01579b"))
                                    )
                                ),
                                child: Text(""+text,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: HexColor("616163"),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.5*SizeConfig.textMultiplier,
                                    fontFamily: "Poppins",
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 60*SizeConfig.widthMultiplier,
                                height: 5*SizeConfig.heightMultiplier,
                                decoration: BoxDecoration(
                                    color: HexColor("01579b"),
                                    borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                ),
                                child: Center(
                                  child: Text("Aceptar",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontFamily: "Poppins",
                                        fontWeight: FontWeight.bold,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                        color: Colors.white
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  /*
  * */

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
            )
        ),
        child: Center(
          child: Text('Ciudadanía',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget MenuEmpresa1=Container(
      padding: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier, right: 5*SizeConfig.widthMultiplier, top: 0*SizeConfig.heightMultiplier, bottom: 2*SizeConfig.heightMultiplier),
      child: Align(
          alignment: Alignment.center,
          child: Column(
            children: [
              Container(
                  child: Table(
                    children: [
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(right: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    String fecha='';
                                    DateTime date=DateTime.now();
                                    setState(() {
                                      fecha = DateFormat('yyyy-MM-dd').format(date);
                                      _mesString=DateFormat('MM').format(date);
                                    });
                                    if(_mesString=='01'){
                                      setState(() {
                                        _selectMes='Enero';
                                      });
                                    }else if(_mesString=='02'){
                                      setState(() {
                                        _selectMes='Febrero';
                                      });
                                    }else if(_mesString=='03'){
                                      setState(() {
                                        _selectMes='Marzo';
                                      });
                                    }else if(_mesString=='04'){
                                      setState(() {
                                        _selectMes='Abril';
                                      });
                                    }else if(_mesString=='05'){
                                      setState(() {
                                        _selectMes='Mayo';
                                      });
                                    }else if(_mesString=='06'){
                                      setState(() {
                                        _selectMes='Junio';
                                      });
                                    }else if(_mesString=='07'){
                                      setState(() {
                                        _selectMes='Julio';
                                      });
                                    }else if(_mesString=='08'){
                                      setState(() {
                                        _selectMes='Agosto';
                                      });
                                    }else if(_mesString=='09'){
                                      setState(() {
                                        _selectMes='Septiembre';
                                      });
                                    }else if(_mesString=='10'){
                                      setState(() {
                                        _selectMes='Octubre';
                                      });
                                    }else if(_mesString=='11'){
                                      setState(() {
                                        _selectMes='Noviembre';
                                      });
                                    }else if(_mesString=='12'){
                                      setState(() {
                                        _selectMes='Diciembre';
                                      });
                                    };
                                    VisitasData(fecha);
                                    //Detalle2();
                                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>ListCompetence()));
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-visita.png'),
                                          height: 36*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Visitas',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      ),
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier, right: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, bottom: 0*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    ComentarioData();
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-comentario.png'),
                                          height: 36*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Comentarios',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      ),
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, bottom: 0*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=> Groups()));
                                    //Detalle1();
                                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>CitizenMenu()));
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-grupos.png'),
                                          height: 36*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Grupos de \ninterés',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      ),
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, bottom: 0*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    Territorio();
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-territorio.png'),
                                          height: 36*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(

                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Territorio',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.5*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      )
                    ],
                  )
              ),
            ],
          )
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('images/icons/fondo.png'),
                        fit: BoxFit.cover
                    )
                ),
                child: Align(
                    alignment: Alignment.center,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        children: [
                          Titulo,
                          MenuEmpresa1,
                        ],
                      )
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}