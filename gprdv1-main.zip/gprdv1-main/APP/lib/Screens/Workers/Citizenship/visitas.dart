import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Workers/Citizenship/citizenship_menu.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:charts_flutter/flutter.dart' as charts;

class Visitas{
  String indicadores='';
  double valor=0;
  Visitas(this.indicadores, this.valor);
}

class VisitasData extends StatefulWidget{
  VisitasData():super();
  _VisitasData createState()=>new _VisitasData();
}
class _VisitasData extends State<VisitasData>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  var _url;
  var _grupos;
  var _cantones;
  var _visitas;
  var _territorio;
  var _dataGrupos;
  var _dataVisitas;
  var _dataTerritorio;
  String rango2030='', rango3040='', rango4050='', rango50='';
  String numeroVisitas='';
  List <String> mes=<String>['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  var _selectMes;
  String _mesString='';
  var responseData;
  var _isLoading=false;
  TextEditingController anioController= TextEditingController();
  List<charts.Series<dynamic, String>> seriesList=[];
  List<charts.Series<dynamic, String>> seriesList2=[];

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _token=tokenpref.getString('token');
    });
  }


  VisitasData(String fecha) async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/visitClient/${fecha}');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    if (response.statusCode == 200) {
      setState(() {
        responseData = json.decode(response.body);
        _isLoading=false;
        _visitas=responseData['data'];
        print(_visitas);
        seriesList2=_createData2();
        //seriesList=_createData();
      });
      print(_visitas.toString());

    }else{
      print('Erro lista profesionales');
    }
  }
  List<charts.Series<Visitas, String>> _createData2(){
    setState(() {
      numeroVisitas=responseData['data']==null?'0':_visitas['numero'].toString();
      _dataVisitas = [
        Visitas('${_selectMes}', double.parse(numeroVisitas)),
      ];
    });
    return [charts.Series<Visitas, String>(
      id: 'Visitas al mes',
      domainFn: (Visitas gasto, _)=>gasto.indicadores,
      measureFn: (Visitas gasto, _)=>gasto.valor,
      data: _dataVisitas,
    )];
  }

  @override
  void initState() {
    super.initState();
    getData();
  }
  barChart2(){
    return charts.BarChart(
      seriesList2,
      animate: true,
      vertical: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
            )
        ),
        child: Center(
          child: Text('Ciudadanía',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget MenuEmpresa1=Container(
      padding: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier, right: 5*SizeConfig.widthMultiplier, top: 0*SizeConfig.heightMultiplier, bottom: 2*SizeConfig.heightMultiplier),
      child: Align(
          alignment: Alignment.center,
          child: Container(
            child: Center(
              //backgroundColor: Colors.blue,
                child: Material(
                  type: MaterialType.transparency,
                  child: Container(
                    height: 75*SizeConfig.heightMultiplier,
                    width: 95*SizeConfig.widthMultiplier,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                    ),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                          child: Column(
                            children: [
                              Container(
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: InkWell(
                                      onTap: (){
                                        Navigator.of(context).pop();
                                      },
                                      child: Container(
                                          width: 10*SizeConfig.widthMultiplier,
                                          height: 10*SizeConfig.imageSizeMultiplier,
                                          decoration: BoxDecoration(
                                              color: HexColor("01579b"),
                                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                          ),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Center(
                                              child: Icon(Icons.check, color: Colors.white),
                                            ),
                                          )
                                      ),
                                    ),
                                  )
                              ),
                              Container(
                                child: Column(
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                      child: Text("Indicadores - Visitas Mensuales",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontWeight: FontWeight.bold,
                                            fontSize: 2.3*SizeConfig.textMultiplier,
                                            color: Colors.black
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                  margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                  padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                  child: Container(
                                    width: 95*SizeConfig.widthMultiplier,
                                    child: Column(
                                      children: [
                                        Container(
                                          child: Table(
                                            columnWidths: {
                                              0:FlexColumnWidth(4),
                                              1:FlexColumnWidth(6)
                                            },

                                            children: [
                                              TableRow(
                                                  children: [
                                                    Container(
                                                        child: Column(
                                                          children: [
                                                            Container(
                                                                height: 6*SizeConfig.heightMultiplier,
                                                                margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
                                                                padding: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier, right: 1*SizeConfig.widthMultiplier),
                                                                decoration: BoxDecoration(
                                                                    borderRadius: BorderRadius.all(Radius.circular(3*SizeConfig.widthMultiplier))
                                                                ),
                                                                child: TextField(
                                                                  textAlign: TextAlign.center,
                                                                  textAlignVertical: TextAlignVertical.top,
                                                                  keyboardType: TextInputType.number,
                                                                  controller: anioController,
                                                                  obscureText: false,
                                                                  decoration: InputDecoration(
                                                                    border: OutlineInputBorder(),
                                                                    isDense: true,
                                                                  ),
                                                                  style: TextStyle(
                                                                    fontSize: 2.3*SizeConfig.textMultiplier,
                                                                    fontFamily: 'Poppins',
                                                                    color: HexColor('616163'),
                                                                  ),
                                                                )
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                              child: Text("Año",
                                                                style: TextStyle(
                                                                  fontSize: 2*SizeConfig.textMultiplier,
                                                                  fontWeight: FontWeight.bold,
                                                                  color: Colors.black,
                                                                  fontFamily: 'Poppins',
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                    ),
                                                    Container(
                                                      child: Column(
                                                        children: [
                                                          Container(
                                                              height: 6 * SizeConfig.heightMultiplier,
                                                              margin: EdgeInsets.only(top: 1 * SizeConfig.heightMultiplier),
                                                              padding: EdgeInsets.only(left: 1 * SizeConfig.widthMultiplier, right: 1 * SizeConfig.widthMultiplier),
                                                              decoration: BoxDecoration(
                                                                borderRadius: BorderRadius.all(
                                                                    Radius.circular(3 * SizeConfig.widthMultiplier)),
                                                              ),

                                                              child: Container(
                                                                  width: double.infinity,
                                                                  padding: EdgeInsets.only(
                                                                      left: 2 * SizeConfig.widthMultiplier,
                                                                      right: 2 * SizeConfig.widthMultiplier),
                                                                  decoration: BoxDecoration(
                                                                    borderRadius: BorderRadius.all(
                                                                        Radius.circular(1 * SizeConfig.widthMultiplier)),
                                                                    border: Border.all(color: Colors.grey),
                                                                  ),
                                                                  child: DropdownButtonHideUnderline(
                                                                    child: DropdownButton(
                                                                      hint: Text('Seleccionar', textAlign: TextAlign.center,
                                                                        style: TextStyle(
                                                                          fontSize: 2.3*SizeConfig.textMultiplier,
                                                                          fontFamily: 'Poppins',
                                                                          color: HexColor('616163'),
                                                                        ),
                                                                      ),
                                                                      // Not necessary for Option 1
                                                                      value: _selectMes,
                                                                      isExpanded: true,
                                                                      onChanged: (newValue) {
                                                                        setState(() {
                                                                          _selectMes = newValue.toString();
                                                                        });
                                                                      },
                                                                      items: mes.map((location) {
                                                                        return DropdownMenuItem(
                                                                          child: Text(location,
                                                                            textAlign: TextAlign.center,
                                                                            style: TextStyle(
                                                                              fontSize: 2.3*SizeConfig.textMultiplier,
                                                                              fontFamily: 'Poppins',
                                                                              color: HexColor('616163'),
                                                                            ),
                                                                          ),
                                                                          value: location,
                                                                        );
                                                                      }).toList(),
                                                                    ),
                                                                  )
                                                              )
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                            child: Text("Mes",
                                                              style: TextStyle(
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                fontWeight: FontWeight.bold,
                                                                color: Colors.black,
                                                                fontFamily: 'Poppins',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ]
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              if(_selectMes==''){
                                                //FaltaDatos('Debes seleccionar el mes');
                                              }else if(anioController.text==''){
                                                //FaltaDatos('Debes ingresar el año');
                                              }else{
                                                if(_selectMes=='Enero'){
                                                  setState(() {
                                                    _mesString='01';
                                                  });
                                                }else if(_selectMes=='Febrero'){
                                                  setState(() {
                                                    _mesString='02';
                                                  });
                                                }else if(_selectMes=='Marzo'){
                                                  setState(() {
                                                    _mesString='03';
                                                  });
                                                }else if(_selectMes=='Abril'){
                                                  setState(() {
                                                    _mesString='04';
                                                  });
                                                }else if(_selectMes=='Mayo'){
                                                  setState(() {
                                                    _mesString='05';
                                                  });
                                                }else if(_selectMes=='Junio'){
                                                  setState(() {
                                                    _mesString='06';
                                                  });
                                                }else if(_selectMes=='Julio'){
                                                  setState(() {
                                                    _mesString='07';
                                                  });
                                                }else if(_selectMes=='Agosto'){
                                                  setState(() {
                                                    _mesString='08';
                                                  });
                                                }else if(_selectMes=='Septiembre'){
                                                  setState(() {
                                                    _mesString='09';
                                                  });
                                                }else if(_selectMes=='Octubre'){
                                                  setState(() {
                                                    _mesString='10';
                                                  });
                                                }else if(_selectMes=='Noviembre'){
                                                  setState(() {
                                                    _mesString='11';
                                                  });
                                                }else if(_selectMes=='Diciembre'){
                                                  setState(() {
                                                    _mesString='12';
                                                  });
                                                };
                                                String fecha='';
                                                setState(() {
                                                  numeroVisitas='0';
                                                  fecha=anioController.text+'-'+_mesString+'-01';
                                                });
                                                VisitasData(fecha);
                                                //GetRol(_token, _trabajadores['employee']['encid'].toString(),_mesString,anioController.text);
                                              }

                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Consultar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                              ),
                              if(_visitas==null)
                                Container(
                                  child: Center(
                                    child: Text("No hay datos",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontWeight: FontWeight.bold,
                                          fontSize: 2*SizeConfig.textMultiplier,
                                          color: Colors.white
                                      ),
                                    ),
                                  ),
                                )
                              else
                                Container(
                                    margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                    padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                    child: Container(
                                      width: 90*SizeConfig.widthMultiplier,
                                      height: 30*SizeConfig.heightMultiplier,
                                      child:barChart2(),
                                    )
                                ),
                              Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        border: Border(
                                            bottom: BorderSide(color: HexColor("d71921"))
                                        )
                                    ),
                                  )
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )
            ),
          )
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> CitizenMenu()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> CitizenMenu()));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                color: Colors.white,
                child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        MenuEmpresa1,
                      ],
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}