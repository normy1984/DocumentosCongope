import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Profile/profile.dart';
import 'package:app/Screens/Workers/Budget/budget_menu.dart';
import 'package:app/Screens/Workers/Citizenship/citizenship_menu.dart';
import 'package:app/Screens/Workers/Projects/list_competence.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class HomeWorker extends StatefulWidget{
  HomeWorker():super();
  _HomeWorker createState()=>new _HomeWorker();
}
class _HomeWorker extends State<HomeWorker>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  var _url;

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
    });
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                            child: Table(
                              children: [
                                TableRow(
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: InkWell(
                                        onTap: (){
                                          CerrarSesion();
                                          Navigator.of(context).pop();
                                        },
                                        child: Container(
                                          width: 60*SizeConfig.widthMultiplier,
                                          height: 5*SizeConfig.heightMultiplier,
                                          decoration: BoxDecoration(
                                              color: HexColor("01579b"),
                                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                          ),
                                          child: Center(
                                            child: Text("Aceptar",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontFamily: "Poppins",
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 2.5*SizeConfig.textMultiplier,
                                                  color: Colors.white
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: InkWell(
                                        onTap: (){
                                          Navigator.of(context).pop();
                                        },
                                        child: Container(
                                          width: 60*SizeConfig.widthMultiplier,
                                          height: 5*SizeConfig.heightMultiplier,
                                          decoration: BoxDecoration(
                                              color: HexColor("ff7400"),
                                              borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                          ),
                                          child: Center(
                                            child: Text("Cancelar",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontFamily: "Poppins",
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 2.5*SizeConfig.textMultiplier,
                                                  color: Colors.white
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ]
                                )
                              ],
                            )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
      height: 6*SizeConfig.heightMultiplier,
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
        )
      ),
      child: Center(
        child: Text('Estado Institucional',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 3.3*SizeConfig.textMultiplier,
          ),
        ),
      )
    );
    Widget MenuEmpresa1=Container(
      padding: EdgeInsets.only(left: 3*SizeConfig.widthMultiplier, right: 3*SizeConfig.widthMultiplier, top: 2*SizeConfig.heightMultiplier, bottom: 2*SizeConfig.heightMultiplier),
      child: Column(
        children: [
          Container(
              child: Table(
                children: [
                  TableRow(
                    children: [
                      Container(
                        margin: EdgeInsets.only(right: 1*SizeConfig.widthMultiplier),
                        decoration: BoxDecoration(
                            border: Border(
                              left: BorderSide( //                   <--- left side
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              top: BorderSide( //                    <--- top side
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              right: BorderSide( //                    <--- top side
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              bottom: BorderSide( //                    <--- top side
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                            ),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(5*SizeConfig.widthMultiplier),
                                topRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                bottomRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                bottomLeft: Radius.circular(5*SizeConfig.widthMultiplier)
                            )
                        ),
                        padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                        child: InkWell(
                            onTap:(){
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>ListCompetence(anio: DateTime.now().year.toString())));
                            },
                            child: Row(
                              children: [
                                Container(
                                  margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                  child: Image(
                                    image: AssetImage('images/icons/icono-proyecto.png'),
                                    height: 41*SizeConfig.imageSizeMultiplier,
                                    width: 41*SizeConfig.widthMultiplier,
                                  ),
                                ),
                                Container(
                                  margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                  child: Text('Proyecto',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                    ),
                                  ),
                                ),
                              ],
                            )
                        ),
                      ),
                    ]
                  ),
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier, right: 1*SizeConfig.widthMultiplier),
                          padding:EdgeInsets.only(top: 4*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                          decoration: BoxDecoration(
                              border: Border(
                                left: BorderSide( //                   <--- left side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                top: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                right: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                bottom: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                              ),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(5*SizeConfig.widthMultiplier),
                                  topRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                  bottomRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                  bottomLeft: Radius.circular(5*SizeConfig.widthMultiplier)
                              )
                          ),
                          child: InkWell(
                              onTap:(){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=> BudgetMenu()));
                              },
                              child: Row(
                                children: [
                                  Container(
                                    margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                    child: Image(
                                      image: AssetImage('images/icons/icono-presupuesto.png'),
                                      height: 41*SizeConfig.imageSizeMultiplier,
                                      width: 41*SizeConfig.widthMultiplier,
                                    ),
                                  ),
                                  Container(
                                    margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                    child: Text('Presupuesto',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                          ),
                        ),
                      ]
                  ),
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier),
                          padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                          decoration: BoxDecoration(
                              border: Border(
                                left: BorderSide( //                   <--- left side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                top: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                right: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                                bottom: BorderSide( //                    <--- top side
                                  color: Colors.transparent,
                                  width: 1.0,
                                ),
                              ),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(5*SizeConfig.widthMultiplier),
                                  topRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                  bottomRight: Radius.circular(5*SizeConfig.widthMultiplier),
                                  bottomLeft: Radius.circular(5*SizeConfig.widthMultiplier)
                              )
                          ),
                          child: InkWell(
                              onTap:(){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>CitizenMenu()));
                              },
                              child: Row(
                                children: [
                                  Container(
                                    margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                    child: Image(
                                      image: AssetImage('images/icons/icono-ciudadania.png'),
                                      height: 41*SizeConfig.imageSizeMultiplier,
                                    ),
                                  ),
                                  Container(
                                    margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                    child: Text('Ciudadanía',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                        fontSize: 2.5*SizeConfig.textMultiplier,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                          ),
                        ),
                      ]
                  )
                ],
              )
          ),
        ],
      )
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{

        //Navigator.push(context, MaterialPageRoute(builder: (context)=>Menu(token: _token,data: _data,)));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('01579b')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 0*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),

          ),
          body: Center(
            child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('images/icons/fondo.png'),
                    fit: BoxFit.cover
                  )
                ),
                child: Align(
                  alignment: Alignment.center,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Column(
                      children: [
                        Titulo,
                        MenuEmpresa1,
                      ],
                    )
                  )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: (){
                        //Navigator.push(context, MaterialPageRoute(builder: (context)=>Perfil()));
                      },
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: (){
                        Cerrar();
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}