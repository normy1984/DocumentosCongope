import 'dart:convert';
import 'dart:ui';
import 'package:app/Models/competenceModel.dart';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Workers/Projects/list_project_cantons.dart';
import 'package:app/Screens/Workers/Projects/list_project_competence.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class ListCompetence extends StatefulWidget{
  var anio;
  ListCompetence({this.anio}):super();
  _ListCompetence createState()=>new _ListCompetence();
}

class _ListCompetence extends State<ListCompetence>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  bool _isLoading=false;
  bool _switchCanton=false;
  var _url;
  List <String> cantones=['Carchi', 'Pichincha', 'Guayas', 'Cotopaxi', 'Tungurahua'];
  List <String> anios=['2022','2021', '2020', '2019', '2018', '2017', '2016', '2015', '2014'];
  var _selectCanton, _selectAnio, _selectEtnia;
  var _competencias;
  var _cantones;
  var _anio;
  var _canton;
  List<Competencia> competencesSearch=List<Competencia>.empty();
  List<Competencia> competencesSearch1=List<Competencia>.empty();

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _token=tokenpref.getString('token');
      Remplazo(widget.anio);
    });
    CompetenceList(_selectAnio);
  }

  Remplazo(var anio){
    setState(() {
      _anio=anio;
      _selectAnio=_anio;
    });
  }

  Future<List> CompetenceList(String anio) async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/departments?year=$anio');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _competencias=responseData['data'];
        print(responseData);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _competencias;
  }
  Future<List> CantonesList(String anio) async{
    print(anio);
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/budget-locations?year=$anio');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _cantones=responseData['data'];
        print(_cantones.length);
      });
    }else{
      print('Erro lista profesionales');
    }
    return _competencias;
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Proyecto',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget Busqueda=Container(
        padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier, top: 0*SizeConfig.heightMultiplier),
        child: Column(
          children: [
            Container(
              width: 100*SizeConfig.widthMultiplier,
              padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(6),
                  1:FlexColumnWidth(4)
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 10*SizeConfig.widthMultiplier),
                          child: Table(
                            columnWidths: {
                              0:FlexColumnWidth(1),
                              1:FlexColumnWidth(3)
                            },
                            children: [
                              TableRow(
                                  children: [
                                    Container(
                                        alignment: Alignment.centerRight,
                                        padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier),
                                        height: 11*SizeConfig.imageSizeMultiplier,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                                        ),
                                        child: Center(
                                            child: Text('Año',
                                              textAlign: TextAlign.right,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                                color: Colors.black,
                                                fontFamily: 'Poppins',
                                              ),
                                            )
                                        )
                                    ),
                                    Container(
                                        height: 5 * SizeConfig.heightMultiplier,
                                        width: 10*SizeConfig.widthMultiplier,
                                        margin: EdgeInsets.only(top: 0 * SizeConfig.heightMultiplier, right: 10*SizeConfig.widthMultiplier),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15 * SizeConfig.widthMultiplier)),
                                        ),

                                        child: Container(
                                            width: double.infinity,
                                            padding: EdgeInsets.only(
                                                left: 2 * SizeConfig.widthMultiplier,
                                                right: 2 * SizeConfig.widthMultiplier),
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(1 * SizeConfig.widthMultiplier)),
                                              border: Border.all(color: Colors.grey),
                                            ),
                                            child: DropdownButtonHideUnderline(
                                              child: DropdownButton(
                                                hint: Text('2022', textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                                    fontFamily: 'Poppins',
                                                    color: HexColor('616163'),
                                                  ),
                                                ),
                                                // Not necessary for Option 1
                                                value: _selectAnio,
                                                isExpanded: true,
                                                onChanged: (newValue) {
                                                  setState(() {
                                                    _selectAnio = newValue.toString();
                                                    _anio=_selectAnio;
                                                    if(_switchCanton==true){
                                                      CantonesList(_anio);
                                                    }else{
                                                      CompetenceList(_anio);
                                                    }
                                                  });
                                                },
                                                items: anios.map((location) {
                                                  return DropdownMenuItem(
                                                    child: Text(location,
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                                        fontFamily: 'Poppins',
                                                        color: HexColor('616163'),
                                                      ),
                                                    ),
                                                    value: location,
                                                  );
                                                }).toList(),
                                              ),
                                            )
                                        )
                                    ),
                                  ]
                              )
                            ],
                          ),
                        ),
                        Container(
                          child: Table(
                            children: [
                              TableRow(
                                  children: [
                                    Container(
                                        padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier),
                                        height: 11*SizeConfig.imageSizeMultiplier,
                                        width: 2*SizeConfig.widthMultiplier,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                                        ),
                                        child: Center(
                                            child: Text('Cantón',
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                                color: Colors.black,
                                                fontFamily: 'Poppins',
                                              ),
                                            )
                                        )
                                    ),
                                    Container(
                                        height: 5 * SizeConfig.heightMultiplier,
                                        margin: EdgeInsets.only(top: 0 * SizeConfig.heightMultiplier),
                                        padding: EdgeInsets.only(left: 0 * SizeConfig.widthMultiplier, right: 5 * SizeConfig.widthMultiplier),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(15 * SizeConfig.widthMultiplier)),
                                        ),

                                        child: Container(
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(1 * SizeConfig.widthMultiplier)),
                                            ),
                                            child: Switch(
                                              onChanged: (bool value){
                                                setState(() {
                                                  _switchCanton=value;
                                                  if(_switchCanton==true){
                                                    print(_selectAnio);
                                                    CantonesList(_selectAnio);
                                                    _canton=='true';
                                                    /*if(_selectAnio==null){
                                                        CantonesList(_selectAnio);
                                                      }else{
                                                        CantonesList(_selectAnio);
                                                      }*/
                                                  }else{
                                                    CompetenceList(_anio);
                                                    setState(() {
                                                      _canton=='false';
                                                    });
                                                  }
                                                });
                                              },
                                              value: _switchCanton,
                                            )
                                        )
                                    ),
                                  ]
                              )
                            ],
                          ),
                        )
                      ]
                  )
                ],
              ),
            ),
          ],
        )
    );

    Widget Listacompetencias = Container(
      height: 64*SizeConfig.heightMultiplier,
      padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier, left: 5.5*SizeConfig.widthMultiplier, right: 5.5*SizeConfig.widthMultiplier),
      child: _isLoading?Center(
        child: CircularProgressIndicator(),
      ):ListView.separated(
        padding: EdgeInsets.zero,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          return Container(
            height: 20*SizeConfig.heightMultiplier,
            child: Container(
              padding: EdgeInsets.only(bottom: 0*SizeConfig.heightMultiplier),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(width: 0.3*SizeConfig.widthMultiplier, color: HexColor('1063ad')),
                ),
              ),
              child:Row(
                children: <Widget>[
                  Column(
                    children: [
                      if(_competencias[index]['name']=='Desarrollo económico')
                        Container(
                          margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                          height: 12*SizeConfig.heightMultiplier,
                          width: 35*SizeConfig.widthMultiplier,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage('images/icons/icono-economico.png'),
                                  fit: BoxFit.contain
                              )
                          ),
                        )
                      else if (_competencias[index]['name']=='Desarrollo social')
                        Container(
                          margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                          height: 12*SizeConfig.heightMultiplier,
                          width: 35*SizeConfig.widthMultiplier,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage('images/icons/desarrollo-social.png'),
                                  fit: BoxFit.contain
                              )
                          ),
                        )
                      else if (_competencias[index]['name']=='Fiscalización')
                          Container(
                            margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                            height: 12*SizeConfig.heightMultiplier,
                            width: 35*SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage('images/icons/fiscalizacion.png'),
                                    fit: BoxFit.contain
                                )
                            ),
                          )
                        else if (_competencias[index]['name']=='Gestión Ambiental')
                            Container(
                              margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                              height: 12*SizeConfig.heightMultiplier,
                              width: 35*SizeConfig.widthMultiplier,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage('images/icons/gestion-ambiental.png'),
                                      fit: BoxFit.contain
                                  )
                              ),
                            )
                          else if (_competencias[index]['name']=='Obras Públicas')
                              Container(
                                margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                height: 12*SizeConfig.heightMultiplier,
                                width: 35*SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage('images/icons/obras-publicas.png'),
                                        fit: BoxFit.contain
                                    )
                                ),
                              )
                            else if (_competencias[index]['name']=='Recursos hídricos')
                                Container(
                                  margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                  height: 12*SizeConfig.heightMultiplier,
                                  width: 35*SizeConfig.widthMultiplier,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('images/icons/recursos-hidricos.png'),
                                          fit: BoxFit.contain
                                      )
                                  ),
                                )
                              else if (_competencias[index]['name']=='Gestión institucional')
                                  Container(
                                    margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                    height: 12*SizeConfig.heightMultiplier,
                                    width: 35*SizeConfig.widthMultiplier,
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage('images/icons/gestion-institucional.png'),
                                            fit: BoxFit.contain
                                        )
                                    ),
                                  )
                                else if (_competencias[index]['name']=='Cooperación internacional')
                                    Container(
                                      margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                      height: 12*SizeConfig.heightMultiplier,
                                      width: 35*SizeConfig.widthMultiplier,
                                      decoration: BoxDecoration(
                                          image: DecorationImage(
                                              image: AssetImage('images/icons/icono-internacional.png'),
                                              fit: BoxFit.contain
                                          )
                                      ),
                                    ),

                      Container(
                        width: 35*SizeConfig.widthMultiplier,
                        child: Text(_competencias[index]['name'],
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      )
                    ],
                  ),
                  // Texto
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, top: 1.5*SizeConfig.heightMultiplier),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('Número: '+_competencias[index]['project_count'].toString(),
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text('Total Inversión: \$'+_competencias[index]['encoded'].toString(),
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text('% de Inversión: '+_competencias[index]['percent'].toString(),
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          if(_competencias[index]['name']=='Desarrollo económico')
                            InkWell(
                              onTap: ()async{
                                var codigoCompetencia=_competencias[index]['code'].toString();
                                SharedPreferences url= await SharedPreferences.getInstance();
                                url.setString('codigoCompetencia', codigoCompetencia);
                                Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                              },
                              child: Container(
                                height: 3*SizeConfig.heightMultiplier,
                                width: 28*SizeConfig.widthMultiplier,
                                margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                decoration:BoxDecoration(
                                  color: HexColor('e96723'),
                                  borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                ),
                                child: Center(
                                  child: Text("Ver Más",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.8*SizeConfig.textMultiplier,
                                      color: Colors.white,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ),
                              ),
                            )
                          else if (_competencias[index]['name']=='Desarrollo social')
                            InkWell(
                              onTap: ()async{
                                var codigoCompetencia=_competencias[index]['code'].toString();
                                SharedPreferences url= await SharedPreferences.getInstance();
                                url.setString('codigoCompetencia', codigoCompetencia);
                                Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                              },
                              child: Container(
                                height: 3*SizeConfig.heightMultiplier,
                                width: 28*SizeConfig.widthMultiplier,
                                margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                decoration:BoxDecoration(
                                  color: HexColor('e55b40'),
                                  borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                ),
                                child: Center(
                                  child: Text("Ver Más",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.8*SizeConfig.textMultiplier,
                                      color: Colors.white,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ),
                              ),
                            )
                          else if (_competencias[index]['name']=='Fiscalización')
                              InkWell(
                                onTap: ()async{
                                  var codigoCompetencia=_competencias[index]['code'].toString();
                                  SharedPreferences url= await SharedPreferences.getInstance();
                                  url.setString('codigoCompetencia', codigoCompetencia);
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                },
                                child: Container(
                                  height: 3*SizeConfig.heightMultiplier,
                                  width: 28*SizeConfig.widthMultiplier,
                                  margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                  decoration:BoxDecoration(
                                    color: HexColor('cfae1e'),
                                    borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                  ),
                                  child: Center(
                                    child: Text("Ver Más",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                        color: Colors.white,
                                        fontFamily: 'Poppins',
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            else if (_competencias[index]['name']=='Gestión Ambiental')
                                InkWell(
                                  onTap: ()async{
                                    var codigoCompetencia=_competencias[index]['code'].toString();
                                    SharedPreferences url= await SharedPreferences.getInstance();
                                    url.setString('codigoCompetencia', codigoCompetencia);
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                  },
                                  child: Container(
                                    height: 3*SizeConfig.heightMultiplier,
                                    width: 28*SizeConfig.widthMultiplier,
                                    margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                    decoration:BoxDecoration(
                                      color: HexColor('00a037'),
                                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                    ),
                                    child: Center(
                                      child: Text("Ver Más",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 1.8*SizeConfig.textMultiplier,
                                          color: Colors.white,
                                          fontFamily: 'Poppins',
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              else if (_competencias[index]['name']=='Obras Públicas')
                                  InkWell(
                                    onTap: ()async{
                                      var codigoCompetencia=_competencias[index]['code'].toString();
                                      SharedPreferences url= await SharedPreferences.getInstance();
                                      url.setString('codigoCompetencia', codigoCompetencia);
                                      Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                    },
                                    child: Container(
                                      height: 3*SizeConfig.heightMultiplier,
                                      width: 28*SizeConfig.widthMultiplier,
                                      margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                      decoration:BoxDecoration(
                                        color: HexColor('ee8800'),
                                        borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                      ),
                                      child: Center(
                                        child: Text("Ver Más",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                            color: Colors.white,
                                            fontFamily: 'Poppins',
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                else if (_competencias[index]['name']=='Recursos hídricos')
                                    InkWell(
                                      onTap: ()async{
                                        var codigoCompetencia=_competencias[index]['code'].toString();
                                        SharedPreferences url= await SharedPreferences.getInstance();
                                        url.setString('codigoCompetencia', codigoCompetencia);
                                        Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                      },
                                      child: Container(
                                        height: 3*SizeConfig.heightMultiplier,
                                        width: 28*SizeConfig.widthMultiplier,
                                        margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                        decoration:BoxDecoration(
                                          color: HexColor('0097b7'),
                                          borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                        ),
                                        child: Center(
                                          child: Text("Ver Más",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 1.8*SizeConfig.textMultiplier,
                                              color: Colors.white,
                                              fontFamily: 'Poppins',
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  else if (_competencias[index]['name']=='Gestión institucional')
                                      InkWell(
                                        onTap: ()async{
                                          var codigoCompetencia=_competencias[index]['code'].toString();
                                          SharedPreferences url= await SharedPreferences.getInstance();
                                          url.setString('codigoCompetencia', codigoCompetencia);
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                        },
                                        child: Container(
                                          height: 3*SizeConfig.heightMultiplier,
                                          width: 28*SizeConfig.widthMultiplier,
                                          margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                          decoration:BoxDecoration(
                                            color: HexColor('862a89'),
                                            borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                          ),
                                          child: Center(
                                            child: Text("Ver Más",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 1.8*SizeConfig.textMultiplier,
                                                color: Colors.white,
                                                fontFamily: 'Poppins',
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    else if (_competencias[index]['name']=='Cooperación internacional')
                                        InkWell(
                                          onTap: ()async{
                                            var codigoCompetencia=_competencias[index]['code'].toString();
                                            SharedPreferences url= await SharedPreferences.getInstance();
                                            url.setString('codigoCompetencia', codigoCompetencia);
                                            Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCompetence(anio: _selectAnio)));
                                          },
                                          child: Container(
                                            height: 3*SizeConfig.heightMultiplier,
                                            width: 28*SizeConfig.widthMultiplier,
                                            margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                            decoration:BoxDecoration(
                                              color: HexColor('c52110'),
                                              borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                            ),
                                            child: Center(
                                              child: Text("Ver Más",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 1.8*SizeConfig.textMultiplier,
                                                  color: Colors.white,
                                                  fontFamily: 'Poppins',
                                                ),
                                              ),
                                            ),
                                          ),
                                        )


                        ],
                      ),
                    ),
                  ) ,
                ],
              ),
            ),
          );
        },
        itemCount: _competencias==null?0:_competencias.length,
        separatorBuilder: (BuildContext context, int index) => Container(
          padding: EdgeInsets.only( bottom: 2*SizeConfig.heightMultiplier),
        ),
      ),
    );

    Widget Listacantones = Container(
      height: 64*SizeConfig.heightMultiplier,
      padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier, left: 5.5*SizeConfig.widthMultiplier, right: 5.5*SizeConfig.widthMultiplier),
      child: _isLoading?Center(
        child: CircularProgressIndicator(),
      ):ListView.separated(
        padding: EdgeInsets.zero,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          return Container(
            height: 20*SizeConfig.heightMultiplier,
            child: Container(
              padding: EdgeInsets.only(bottom: 0*SizeConfig.heightMultiplier),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(width: 0.3*SizeConfig.widthMultiplier, color: HexColor('1063ad')),
                ),
              ),
              child:Row(
                children: <Widget>[
                  Column(
                    children: [
                      if(_cantones[index]['description']=='TULCAN')
                        Container(
                          margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                          height: 12*SizeConfig.heightMultiplier,
                          width: 35*SizeConfig.widthMultiplier,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage('images/icons/cantones.png'),
                                  fit: BoxFit.contain
                              )
                          ),
                        )
                      else if (_cantones[index]['description']=='BOLIVAR')
                        Container(
                          margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                          height: 12*SizeConfig.heightMultiplier,
                          width: 35*SizeConfig.widthMultiplier,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage('images/icons/cantones.png'),
                                  fit: BoxFit.contain
                              )
                          ),
                        )
                      else if (_cantones[index]['description']=='MIRA')
                          Container(
                            margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                            height: 12*SizeConfig.heightMultiplier,
                            width: 35*SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage('images/icons/cantones.png'),
                                    fit: BoxFit.contain
                                )
                            ),
                          )
                        else if (_cantones[index]['description']=='MONTUFAR')
                            Container(
                              margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                              height: 12*SizeConfig.heightMultiplier,
                              width: 35*SizeConfig.widthMultiplier,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: AssetImage('images/icons/cantones.png'),
                                      fit: BoxFit.contain
                                  )
                              ),
                            )
                          else if (_cantones[index]['description']=='ESPEJO')
                              Container(
                                margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                height: 12*SizeConfig.heightMultiplier,
                                width: 35*SizeConfig.widthMultiplier,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage('images/icons/cantones.png'),
                                        fit: BoxFit.contain
                                    )
                                ),
                              )
                            else if (_cantones[index]['description']=='SAN PEDRO DE HUACA')
                                Container(
                                  margin: EdgeInsets.only(top: 3.5*SizeConfig.heightMultiplier, left: 0*SizeConfig.widthMultiplier, right: 0*SizeConfig.widthMultiplier),
                                  height: 12*SizeConfig.heightMultiplier,
                                  width: 35*SizeConfig.widthMultiplier,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('images/icons/cantones.png'),
                                          fit: BoxFit.contain
                                      )
                                  ),
                                ),

                      Container(
                        width: 35*SizeConfig.widthMultiplier,
                        child: Text(_cantones[index]['description'],
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      )
                    ],
                  ),
                  // Texto
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, top: 1.5*SizeConfig.heightMultiplier),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('Número: ',
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.transparent,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text('Total Inversión:',
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.transparent,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text('Monto: \$'+_cantones[index]['amount'].toString(),
                            style: TextStyle(
                              fontSize: 1.8*SizeConfig.textMultiplier,
                              color: Colors.black,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          if(_cantones[index]['description']=='TULCAN')
                            InkWell(
                              onTap: ()async{
                                var idCanton=_cantones[index]['id'].toString();
                                SharedPreferences url= await SharedPreferences.getInstance();
                                url.setString('idCanton', idCanton);
                                Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                              },
                              child: Container(
                                height: 3*SizeConfig.heightMultiplier,
                                width: 28*SizeConfig.widthMultiplier,
                                margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                decoration:BoxDecoration(
                                  color: HexColor('01579b'),
                                  borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                ),
                                child: Center(
                                  child: Text("Ver Más",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.8*SizeConfig.textMultiplier,
                                      color: Colors.white,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ),
                              ),
                            )
                          else if (_cantones[index]['description']=='BOLIVAR')
                            InkWell(
                              onTap: ()async{
                                var idCanton=_cantones[index]['id'].toString();
                                SharedPreferences url= await SharedPreferences.getInstance();
                                url.setString('idCanton', idCanton);
                                Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                              },
                              child: Container(
                                height: 3*SizeConfig.heightMultiplier,
                                width: 28*SizeConfig.widthMultiplier,
                                margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                decoration:BoxDecoration(
                                  color: HexColor('01579b'),
                                  borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                ),
                                child: Center(
                                  child: Text("Ver Más",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 1.8*SizeConfig.textMultiplier,
                                      color: Colors.white,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ),
                              ),
                            )
                          else if (_cantones[index]['description']=='MIRA')
                              InkWell(
                                onTap: ()async{
                                  var idCanton=_cantones[index]['id'].toString();
                                  SharedPreferences url= await SharedPreferences.getInstance();
                                  url.setString('idCanton', idCanton);
                                  Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                                },
                                child: Container(
                                  height: 3*SizeConfig.heightMultiplier,
                                  width: 28*SizeConfig.widthMultiplier,
                                  margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                  decoration:BoxDecoration(
                                    color: HexColor('01579b'),
                                    borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                  ),
                                  child: Center(
                                    child: Text("Ver Más",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                        color: Colors.white,
                                        fontFamily: 'Poppins',
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            else if (_cantones[index]['description']=='MONTUFAR')
                                InkWell(
                                  onTap: ()async{
                                    var idCanton=_cantones[index]['id'].toString();
                                    SharedPreferences url= await SharedPreferences.getInstance();
                                    url.setString('idCanton', idCanton);
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                                  },
                                  child: Container(
                                    height: 3*SizeConfig.heightMultiplier,
                                    width: 28*SizeConfig.widthMultiplier,
                                    margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                    decoration:BoxDecoration(
                                      color: HexColor('01579b'),
                                      borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                    ),
                                    child: Center(
                                      child: Text("Ver Más",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 1.8*SizeConfig.textMultiplier,
                                          color: Colors.white,
                                          fontFamily: 'Poppins',
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              else if (_cantones[index]['description']=='ESPEJO')
                                  InkWell(
                                    onTap: ()async{
                                      var idCanton=_cantones[index]['id'].toString();
                                      SharedPreferences url= await SharedPreferences.getInstance();
                                      url.setString('idCanton', idCanton);
                                      Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                                    },
                                    child: Container(
                                      height: 3*SizeConfig.heightMultiplier,
                                      width: 28*SizeConfig.widthMultiplier,
                                      margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                      decoration:BoxDecoration(
                                        color: HexColor('01579b'),
                                        borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                      ),
                                      child: Center(
                                        child: Text("Ver Más",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                            color: Colors.white,
                                            fontFamily: 'Poppins',
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                else if (_cantones[index]['description']=='SAN PEDRO DE HUACA')
                                    InkWell(
                                      onTap: ()async{
                                        var idCanton=_cantones[index]['id'].toString();
                                        SharedPreferences url= await SharedPreferences.getInstance();
                                        url.setString('idCanton', idCanton);
                                        Navigator.push(context, MaterialPageRoute(builder: (context)=> ListProjectCantones(anio: _selectAnio)));
                                      },
                                      child: Container(
                                        height: 3*SizeConfig.heightMultiplier,
                                        width: 28*SizeConfig.widthMultiplier,
                                        margin:EdgeInsets.only(top: 0.9*SizeConfig.heightMultiplier),
                                        decoration:BoxDecoration(
                                          color: HexColor('01579b'),
                                          borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                                        ),
                                        child: Center(
                                          child: Text("Ver Más",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 1.8*SizeConfig.textMultiplier,
                                              color: Colors.white,
                                              fontFamily: 'Poppins',
                                            ),
                                          ),
                                        ),
                                      ),
                                    )

                        ],
                      ),
                    ),
                  ) ,
                ],
              )
            ),
          );
        },
        itemCount: _cantones==null?0:_cantones.length,
        separatorBuilder: (BuildContext context, int index) => Container(
          padding: EdgeInsets.only( bottom: 2*SizeConfig.heightMultiplier),
        ),
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
                  }
              ),
            ),
          ),
          body: _isLoading?Center(
            child: Container(
              child: CircularProgressIndicator(),
            ),
          ):Center(
            child: Container(
                color: Colors.transparent,
                child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Titulo,
                        Expanded(
                            child:SingleChildScrollView(
                              scrollDirection: Axis.vertical,
                              child: Column(
                                children: [
                                  Busqueda,
                                  if(_switchCanton==true)
                                    _cantones.length==0?Container(
                                      margin: EdgeInsets.only(top: 25*SizeConfig.heightMultiplier),
                                      child: Text('No existe información',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          fontSize:3*SizeConfig.textMultiplier,
                                        ),
                                      ),
                                    ):Listacantones
                                  else if(_switchCanton==false)
                                    _competencias==null?Container(
                                      margin: EdgeInsets.only(top: 25*SizeConfig.heightMultiplier),
                                      child: Text('No existe información',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          fontSize: 3.3*SizeConfig.textMultiplier,
                                        ),
                                      ),
                                    ):Listacompetencias
                                ],
                              ),
                            )
                        ),
                      ],
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}