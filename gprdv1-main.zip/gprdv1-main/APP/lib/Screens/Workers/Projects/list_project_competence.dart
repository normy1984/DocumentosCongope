import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Workers/Projects/list_competence.dart';
import 'package:app/Screens/Workers/Projects/project_detail.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class ListProjectCompetence extends StatefulWidget{
  var anio;
  ListProjectCompetence({this.anio}):super();
  _ListProjectCompetence createState()=>new _ListProjectCompetence();
}
class _ListProjectCompetence extends State<ListProjectCompetence>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  bool _isLoading=false;
  var _url, _codigoCompetencia;
  var cantones=[];
  List <String> anios=['2022','2021', '2020', '2019', '2018', '2017', '2016', '2015', '2014'];
  var _anio;
  var _proyectos;
  var _data;
  var _selectCanton, _selectAnio, _selectEtnia;

  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences codigoCompetenciapref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _codigoCompetencia=codigoCompetenciapref.getString('codigoCompetencia');
      _token=tokenpref.getString('token');
      Remplazo(widget.anio);
    });
    ProjectList(_anio);
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  Remplazo(var anio ){
    setState(() {
      _anio=anio;
      _selectAnio=_anio;
    });
  }

  Future<List> ProjectList(String anio) async{
    print(_codigoCompetencia);
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/projects?department=$_codigoCompetencia&year=$anio');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _proyectos=responseData['data'];
      });
      print(_proyectos);
    }else{
      print('Erro lista profesionales');
    }
    return _proyectos;
  }

   ProjectDet(String id) async{
    var uri;
    print(id);
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/projects/${id}?year=${_selectAnio}');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        _data=responseData['data'];
        Navigator.push(context, MaterialPageRoute(builder: (context)=> ProjectDetail(proyecto: _data,anio: _selectAnio,)));
      });
    }else{
      print(response.statusCode);
      print('Erro lista profesionales');
    }
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Proyecto',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    //Busqueda
    Widget Busqueda=Container(
        padding: EdgeInsets.only(left: 22*SizeConfig.widthMultiplier, right: 22*SizeConfig.widthMultiplier, top: 0*SizeConfig.heightMultiplier),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier),
              child: Table(
                columnWidths: {
                  0:FlexColumnWidth(2),
                  1:FlexColumnWidth(9),
                },
                children: [
                  TableRow(
                      children: [
                        Container(
                            padding: EdgeInsets.only(left: 0*SizeConfig.widthMultiplier),
                            height: 11*SizeConfig.imageSizeMultiplier,
                            width: 11*SizeConfig.widthMultiplier,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(15*SizeConfig.widthMultiplier))
                            ),
                            child: Center(
                                child: Text('Año',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                    color: Colors.black,
                                    fontFamily: 'Poppins',
                                  ),
                                )
                            )
                        ),
                        Container(
                            height: 5 * SizeConfig.heightMultiplier,
                            margin: EdgeInsets.only(top: 0 * SizeConfig.heightMultiplier),
                            padding: EdgeInsets.only(left: 3 * SizeConfig.widthMultiplier, right: 0 * SizeConfig.widthMultiplier),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(15 * SizeConfig.widthMultiplier)),
                            ),

                            child: Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(
                                    left: 2 * SizeConfig.widthMultiplier,
                                    right: 2 * SizeConfig.widthMultiplier),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(1 * SizeConfig.widthMultiplier)),
                                  border: Border.all(color: Colors.grey),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    hint: Text('${_anio}', textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 1.8*SizeConfig.textMultiplier,
                                        fontFamily: 'Poppins',
                                        color: HexColor('616163'),
                                      ),
                                    ),
                                    // Not necessary for Option 1
                                    value: _selectAnio,
                                    isExpanded: true,
                                    onChanged: (newValue) {
                                      setState(() {
                                        _selectAnio = newValue.toString();
                                        _anio=_selectAnio;
                                        ProjectList(_anio);
                                      });
                                    },
                                    items: anios.map((location) {
                                      return DropdownMenuItem(
                                        child: Text(location,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontSize: 1.8*SizeConfig.textMultiplier,
                                            fontFamily: 'Poppins',
                                            color: HexColor('616163'),
                                          ),
                                        ),
                                        value: location,
                                      );
                                    }).toList(),
                                  ),
                                )
                            )
                        ),
                      ]
                  )
                ],
              ),
            ),
          ],
        )
    );
    Widget Listacompetencias = Container(
      height: 61*SizeConfig.heightMultiplier,
      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 5*SizeConfig.widthMultiplier),
      child: _isLoading?Center(
        child: CircularProgressIndicator(),
      ):ListView.separated(
        padding: EdgeInsets.zero,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        itemBuilder: (BuildContext context, int index) {
          return Container(
            margin: EdgeInsets.only(bottom: 1*SizeConfig.heightMultiplier),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Colors.black87),
                top: BorderSide(color: Colors.black87),
                left: BorderSide(color: Colors.black87),
                right: BorderSide(color: Colors.black87),
              ),
              borderRadius: BorderRadius.all(Radius.circular(3*SizeConfig.widthMultiplier))
            ),
            child: ExpansionTile(
              title: Text(_proyectos[index]['name'],
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 1.9*SizeConfig.textMultiplier,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Poppins',
                ),
              ),
              initiallyExpanded: true,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 1.2*SizeConfig.heightMultiplier),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: Colors.black87),
                    ),
                  ),
                  child: Table(
                    columnWidths: {
                      0:FlexColumnWidth(6),
                      1:FlexColumnWidth(4)
                    },
                    children: [
                      TableRow(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                            child: Center(
                              child: Text('\$'+_proyectos[index]['encoded'].toString(),
                                style: TextStyle(
                                  fontSize: 1.8*SizeConfig.textMultiplier,
                                  color: HexColor("01579b"),
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Poppins',
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: ()async{
                              setState(() {
                                ProjectDet(_proyectos[index]['id'].toString());
                              });
                            },
                            child: Container(
                              height: 3*SizeConfig.heightMultiplier,
                              width: 28*SizeConfig.widthMultiplier,
                              margin:EdgeInsets.only(bottom: 0.9*SizeConfig.heightMultiplier, right: 5*SizeConfig.widthMultiplier),
                              decoration:BoxDecoration(
                                color: HexColor('1063ad'),
                                borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier),
                              ),
                              child: Center(
                                child: Text("Ver Detalle",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 1.8*SizeConfig.textMultiplier,
                                    color: Colors.white,
                                    fontFamily: 'Poppins',
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ]
                      )
                    ],
                  )
                ),
              ],
            ),
          );
        },
        itemCount: _proyectos==null?0:_proyectos.length,
        separatorBuilder: (BuildContext context, int index) => Container(
          padding: EdgeInsets.only( bottom: 2*SizeConfig.heightMultiplier),
        ),
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> ListCompetence(anio: _selectAnio)));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ListCompetence(anio: _selectAnio)));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                color: Colors.transparent,
                child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Titulo,
                        Busqueda,
                        Listacompetencias
                      ],
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}