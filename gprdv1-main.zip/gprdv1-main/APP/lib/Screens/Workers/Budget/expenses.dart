import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Workers/Budget/budget_menu.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:charts_flutter/flutter.dart' as charts;

class Gasto{
  String indicadores='';
  double valor=0;
  Gasto(this.indicadores, this.valor);
}

class Expenses extends StatefulWidget{
  var gasto;
  Expenses({this.gasto}):super();
  _Expenses createState()=>new _Expenses();
}
class _Expenses extends State<Expenses>{
  var _token;
  var _url;
  bool _isLoading=false;
  var _gasto;
  String capital='', current='', investment='', current_investment='', project='', totalG='';
  var _dataGasto;
  List<charts.Series<dynamic, String>> seriesList=[];



  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
    });
  }

  @override
  void initState() {
    super.initState();
    Remplazo(widget.gasto);
    getData();
    seriesList=_createData();
  }

  Remplazo(var gasto){
    setState(() {
      _gasto=gasto;
    });
  }

  List<charts.Series<Gasto, String>> _createData(){
    print(_gasto);
    setState(() {
      capital=_gasto['capital'].toString();
      current=_gasto['current'].toString();
      investment=_gasto['investment'].toString();
      current_investment=_gasto['current_investment'].toString();
      project=_gasto['project'].toString();
      totalG=_gasto['total'].toString();
      _dataGasto = [
        Gasto('Capital', double.parse(capital)),
        Gasto('Corriente', double.parse(current)),
        Gasto('Inversión', double.parse(investment)),
        Gasto('Cte Inversión', double.parse(current_investment)),
        Gasto('Proyectos Inversión', double.parse(project)),
        Gasto('G. Total', double.parse(totalG)),
      ];
    });
    return [charts.Series<Gasto, String>(
      id: 'Composicion de Gasto',
      domainFn: (Gasto gasto, _)=>gasto.indicadores,
      measureFn: (Gasto gasto, _)=>gasto.valor,
      data: _dataGasto,
    )];
  }

  barChart(){
    return charts.BarChart(
      seriesList,
      animate: true,
      vertical: false,
      defaultRenderer: charts.BarRendererConfig(
        groupingType: charts.BarGroupingType.grouped,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    bool shouldPop = true;
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        color: HexColor("01579b"),
        child: Center(
          child: Text('Composición de gasto',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> BudgetMenu()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> BudgetMenu()));
                  }
              ),
            ),
          ),
          body: Center(
            child: Container(
                color: Colors.transparent,
                child: Align(
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      Titulo,
                      Container(
                        width: 90*SizeConfig.widthMultiplier,
                        height: 70*SizeConfig.heightMultiplier,
                        child: Expanded(child: barChart()),
                      )
                    ],
                  ),
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}