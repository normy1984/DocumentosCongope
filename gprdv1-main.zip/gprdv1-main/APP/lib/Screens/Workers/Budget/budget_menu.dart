import 'dart:convert';
import 'dart:ui';
import 'package:app/Screens/Login/login.dart';
import 'package:app/Screens/Workers/home.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hexcolor/hexcolor.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:charts_flutter/flutter.dart' as charts;

class Gasto{
  String indicadores='';
  double valor=0;
  String ind = '';
  Gasto(this.indicadores, this.valor, this.ind);
}

class Fuentes{
  String indicadores='';
  double valor=0;
  String ind = '';
  Fuentes(this.indicadores, this.valor, this.ind);
}

class Subnacional{
  String indicadores='';
  double valor=0;
  String ind = '';
  Subnacional(this.indicadores, this.valor, this.ind);
}

class BudgetMenu extends StatefulWidget{
  BudgetMenu():super();
  _BudgetMenu createState()=>new _BudgetMenu();
}
class _BudgetMenu extends State<BudgetMenu>{
  var _token;
  var perfilTrabajadores;
  var organigrama;
  var _url;
  bool _isLoading=false;
  var _gasto;
  var _fuentes;
  var _subnacional;
  var _data1;
  var _data2;
  var _data3;
  var lista;
  String capital='', current='', investment='', current_investment='', project='', totalG='';
  String met='', own='', currentF='', financing='', cooperation='', totalF='';
  String metS='', current_expense='', project_investment='', current_investmentS='', current_saving='', financial_autonomy='';
  var _dataGasto;
  var _dataFuentes;
  var _dataSubnacional;
  List <String> anios=['2022','2021', '2020'];
  String _anio='2022';
  var _selectAnio;
  List<charts.Series<dynamic, String>> seriesList=[];
  List<charts.Series<dynamic, String>> seriesList2=[];
  List<charts.Series<dynamic, String>> seriesList3=[];



  getData() async {
    SharedPreferences urlpref = await SharedPreferences.getInstance();
    SharedPreferences tokenpref = await SharedPreferences.getInstance();
    setState(() {
      _url=urlpref.getString('url');
      _token=tokenpref.getString('token');
    });
    Presupuesto(_anio);
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  Presupuesto(String anio) async{
    var uri;
    setState(() {
      _isLoading=true;
      uri=Uri.parse('${_url}/api/user/budget-indicators?year=${anio}');
    });
    final response =await http.get(uri, headers: {
      'Authorization': 'Bearer $_token',
      //'apikey':_key,
    });
    var responseData;
    if (response.statusCode == 200) {
      responseData = json.decode(response.body);
      setState(() {
        _isLoading=false;
        lista=responseData['data'];
        print(lista);
        _gasto=responseData['data']['expenses'];
        _fuentes=responseData['data']['incomes'];
        _subnacional=responseData['data']['subnational'];
        seriesList=_createData();
        seriesList2=_createData2();
        seriesList3=_createData3();
      });

    }else{
      print('Erro lista profesionales');
    }
  }

  List<charts.Series<Gasto, String>> _createData(){
    setState(() {
      capital=_gasto['capital']['value']==null?'0':_gasto['capital']['value'].toString();
      current=_gasto['current']['value']==null?'0':_gasto['current']['value'].toString();
      investment=_gasto['investment']['value']==null?'0':_gasto['investment']['value'].toString();
      current_investment=_gasto['current_investment']['value']==null?'0':_gasto['current_investment']['value'].toString();
      project=_gasto['project']['value']==null?'0':_gasto['project']['value'].toString();
      totalG=_gasto['total']['value']==null?'0':_gasto['total']['value'].toString();
      _dataGasto = [
        Gasto('G.C.', double.parse(capital.toString()), _gasto['capital']['value_f'].toString()),
        Gasto('G.CR.', double.parse(current.toString()), _gasto['current']['value_f'].toString()),
        Gasto('G.I.', double.parse(investment.toString()), _gasto['investment']['value_f'].toString()),
        Gasto('G.CI.', double.parse(current_investment.toString()), _gasto['current_investment']['value_f'].toString()),
        Gasto('P.I.', double.parse(project.toString()), _gasto['project']['value_f'].toString()),
        Gasto('T.G.', double.parse(totalG.toString()), _gasto['total']['value_f'].toString()),
      ];
    });
    return [charts.Series<Gasto, String>(
      id: 'Composicion de Gasto',
      domainFn: (Gasto gasto, _)=>gasto.indicadores,
      measureFn: (Gasto gasto, _)=>gasto.valor,
      data: _dataGasto,
      labelAccessorFn: (Gasto gasto, _) =>gasto.ind.toString(),
    )];
  }

  List<charts.Series<Fuentes, String>> _createData2(){
    setState(() {
      met=_fuentes['met']['value']==null?'0':_fuentes['met']['value'].toString();
      own=_fuentes['own']['value']==null?'0':_fuentes['own']['value'].toString();
      currentF=_fuentes['current']['value']==null?'0':_fuentes['current']['value'].toString();
      financing=_fuentes['financing']['value']==null?'0':_fuentes['financing']['value'].toString();
      cooperation=_fuentes['cooperation']['value']==null?'0':_fuentes['cooperation']['value'].toString();
      totalF=_fuentes['total']['value']==null?'0':_fuentes['total']['value'].toString();
      _dataFuentes = [
        Fuentes('MET', double.parse(met.toString()), _fuentes['met']['value_f'].toString()),
        Fuentes('I.P.', double.parse(own.toString()), _fuentes['own']['value_f'].toString()),
        Fuentes('I.C.', double.parse(currentF.toString()), _fuentes['current']['value_f'].toString()),
        Fuentes('F.', double.parse(financing.toString()), _fuentes['financing']['value_f'].toString()),
        Fuentes('CP.', double.parse(cooperation.toString()), _fuentes['cooperation']['value_f'].toString()),
        Fuentes('T.I.', double.parse(totalF.toString()), _fuentes['total']['value_f'].toString()),
      ];
    });
    return [charts.Series<Fuentes, String>(
      id: 'Fuentes de Financiamento',
      domainFn: (Fuentes fuentes, _)=>fuentes.indicadores,
      measureFn: (Fuentes fuentes, _)=>fuentes.valor,
      data: _dataFuentes,
      labelAccessorFn: (Fuentes fuentes, _) =>fuentes.ind.toString(),
    )];
  }

  List<charts.Series<Subnacional, String>> _createData3(){
    setState(() {
      metS=_subnacional['met']['value']==null?'0':_subnacional['met']['value'].toString();
      current_expense=_subnacional['current_expense']['value']==null?'0':_subnacional['current_expense']['value'].toString();
      project_investment=_subnacional['project_investment']['value']==null?'0':_subnacional['project_investment']['value'].toString();
      current_investmentS=_subnacional['current_investment']['value']==null?'0':_subnacional['current_investment']['value'].toString();
      current_saving=_subnacional['current_saving']['value']==null?'0':_subnacional['current_saving']['value'].toString();
      financial_autonomy=_subnacional['financial_autonomy']['value']==null?'0':_subnacional['financial_autonomy']['value'].toString();
      _dataSubnacional = [
        Subnacional('% MET', double.parse(metS.toString()), _subnacional['met']['value_f'].toString()),
        Subnacional('% G.C.', double.parse(current_expense.toString()), _subnacional['current_expense']['value_f'].toString()),
        Subnacional('% P.I.', double.parse(project_investment.toString()), _subnacional['project_investment']['value_f'].toString()),
        Subnacional('% G.CI.', double.parse(current_investmentS.toString()), _subnacional['current_investment']['value_f'].toString()),
        Subnacional('A.H.', double.parse(current_saving.toString()), _subnacional['current_saving']['value_f'].toString()),
        Subnacional('G.A.F.', double.parse(financial_autonomy.toString()), _subnacional['financial_autonomy']['value_f'].toString()),
      ];
    });
    return [charts.Series<Subnacional, String>(
      id: 'Finanzas Subnacionales',
      domainFn: (Subnacional subnacional, _)=>subnacional.indicadores,
      measureFn: (Subnacional subnacional, _)=>subnacional.valor,
      data: _dataSubnacional,
      labelAccessorFn: (Subnacional subnacional, _) =>subnacional.valor.toString(),
    )];
  }

  barChart(){
    return charts.BarChart(
      seriesList,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }

  barChart2(){
    return charts.BarChart(
      seriesList2,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }

  barChart3(){
    return charts.BarChart(
      seriesList3,
      animate: true,
      vertical: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
    );
  }

  Future<dynamic> Detalle1(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                height: 88*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                        child: Column(
                          children: [
                            Container(
                                child: Align(
                                  alignment: Alignment.topCenter,
                                  child: InkWell(
                                    onTap: (){
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                        width: 10*SizeConfig.widthMultiplier,
                                        height: 10*SizeConfig.imageSizeMultiplier,
                                        decoration: BoxDecoration(
                                            color: HexColor("01579b"),
                                            borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                        ),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Center(
                                            child: Icon(Icons.check, color: Colors.white),
                                          ),
                                        )
                                    ),
                                  ),
                                )
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Text("Indicadores - Composición Gasto",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.3*SizeConfig.textMultiplier,
                                    color: Colors.black
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                padding: EdgeInsets.only(top: 4*SizeConfig.heightMultiplier,),
                                child: Container(
                                  width: 90*SizeConfig.widthMultiplier,
                                  height: 30*SizeConfig.heightMultiplier,
                                  child:barChart(),
                                )
                            ),
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Gasto Capital = G.C.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_gasto['capital']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Gasto Corriente = G.CR.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_gasto['current']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Gasto Inversión = G.I.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_gasto['investment']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Gasto Cte Inversión = G.CI.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_gasto['current_investment']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Proyectos Inversión = P.I.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Total de Gastos = T.G.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),
                                ],
                              ),
                            ),
                            Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(color: HexColor("d71921"))
                                      )
                                  ),
                                )
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: InkWell(
                                onTap: (){
                                  Navigator.of(context).pop();
                                  //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                                },
                                child: Container(
                                  width: 60*SizeConfig.widthMultiplier,
                                  height: 5*SizeConfig.heightMultiplier,
                                  decoration: BoxDecoration(
                                      color: HexColor("01579b"),
                                      borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                  ),
                                  child: Center(
                                    child: Text("Aceptar",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontWeight: FontWeight.bold,
                                          fontSize: 2.5*SizeConfig.textMultiplier,
                                          color: Colors.white
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ),
            )
        );
      },
    );
  }

  Future<dynamic> Detalle2(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                  padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                height: 90*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                        child: Column(
                          children: [
                            Container(
                                child: Align(
                                  alignment: Alignment.topCenter,
                                  child: InkWell(
                                    onTap: (){
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                        width: 10*SizeConfig.widthMultiplier,
                                        height: 10*SizeConfig.imageSizeMultiplier,
                                        decoration: BoxDecoration(
                                            color: HexColor("01579b"),
                                            borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                        ),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Center(
                                            child: Icon(Icons.check, color: Colors.white),
                                          ),
                                        )
                                    ),
                                  ),
                                )
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Text("Indicadores - Fuentes de Financiamiento",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.3*SizeConfig.textMultiplier,
                                    color: Colors.black
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                child: Container(
                                  width: 90*SizeConfig.widthMultiplier,
                                  height: 30*SizeConfig.heightMultiplier,
                                  child:barChart2(),
                                )
                            ),
                            Container(
                              child: Column(
                                children: [
                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("MET",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_fuentes['met']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Ingresos Propios = I.P.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_fuentes['own']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Ingresos Corrientes = I.C.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_fuentes['current']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Financiamiento = F.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_fuentes['financing']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Cooperación = C.P.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_fuentes['cooperation']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Total de Ingresos = T.I.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),
                                ],
                              ),
                            ),
                            Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(color: HexColor("d71921"))
                                      )
                                  ),
                                )
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: InkWell(
                                onTap: (){
                                  Navigator.of(context).pop();
                                  //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                                },
                                child: Container(
                                  width: 60*SizeConfig.widthMultiplier,
                                  height: 5*SizeConfig.heightMultiplier,
                                  decoration: BoxDecoration(
                                      color: HexColor("01579b"),
                                      borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                  ),
                                  child: Center(
                                    child: Text("Aceptar",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontWeight: FontWeight.bold,
                                          fontSize: 2.5*SizeConfig.textMultiplier,
                                          color: Colors.white
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ),
            )
        );
      },
    );
  }

  Future<dynamic> Detalle3(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                padding: EdgeInsets.only(bottom: 2*SizeConfig.heightMultiplier),
                height: 90*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                        child: Column(
                          children: [
                            Container(
                                child: Align(
                                  alignment: Alignment.topCenter,
                                  child: InkWell(
                                    onTap: (){
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                        width: 10*SizeConfig.widthMultiplier,
                                        height: 10*SizeConfig.imageSizeMultiplier,
                                        decoration: BoxDecoration(
                                            color: HexColor("01579b"),
                                            borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                        ),
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Center(
                                            child: Icon(Icons.check, color: Colors.white),
                                          ),
                                        )
                                    ),
                                  ),
                                )
                            ),
                            Container(
                              width:90*SizeConfig.widthMultiplier,
                              margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                              child: Text("Indicadores - Finanzas Subnacionales",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontWeight: FontWeight.bold,
                                    fontSize: 2.3*SizeConfig.textMultiplier,
                                    color: Colors.black
                                ),
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                child: Container(
                                  width: 90*SizeConfig.widthMultiplier,
                                  height: 30*SizeConfig.heightMultiplier,
                                  child:barChart3(),
                                )
                            ),
                            Container(
                              child: Column(
                                children: [

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Presupuesto = % MET",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['met']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("% Gasto Corriente = % G.C.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['current_expense']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("% Proyectos de Inversión = % P.I.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['project_investment']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("% Gasto Cte Inversión = % G.CI.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['current_investment']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Ahorro Corriente = A.H.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['current_saving']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),

                                  Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey)
                                      ),
                                      width: 90*SizeConfig.widthMultiplier,
                                      margin: EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, left: 5*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                      child: Row(
                                        children: [
                                          Icon(Icons.brightness_1, size: 3.5*SizeConfig.imageSizeMultiplier, color: Colors.blue),
                                          Container(
                                              width: 80*SizeConfig.widthMultiplier,
                                              margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier),
                                              child: Table(
                                                children: [
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          child: Text("Grado de Autonomía Financiera = G.A.F.",
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 2*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                  TableRow(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.only(top: 0.5*SizeConfig.heightMultiplier),
                                                          child: Text("Descripción = "+_subnacional['financial_autonomy']['description'],
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(
                                                                fontFamily: "Poppins",
                                                                fontSize: 1.7*SizeConfig.textMultiplier,
                                                                color: Colors.black
                                                            ),
                                                          ),
                                                        ),
                                                      ]
                                                  )
                                                ],
                                              )
                                          )
                                        ],
                                      )
                                  ),
                                ],
                              ),
                            ),
                            Container(
                                width: double.infinity,
                                padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(color: HexColor("d71921"))
                                      )
                                  ),
                                )
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: InkWell(
                                onTap: (){
                                  Navigator.of(context).pop();
                                  //Navigator.push(context, MaterialPageRoute(builder: (context)=>PublicMenu()));
                                },
                                child: Container(
                                  width: 60*SizeConfig.widthMultiplier,
                                  height: 5*SizeConfig.heightMultiplier,
                                  decoration: BoxDecoration(
                                      color: HexColor("01579b"),
                                      borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                  ),
                                  child: Center(
                                    child: Text("Aceptar",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontWeight: FontWeight.bold,
                                          fontSize: 2.5*SizeConfig.textMultiplier,
                                          color: Colors.white
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ),
            )
        );
      },
    );
  }

  CerrarSesion()async{
    SharedPreferences token= await SharedPreferences.getInstance();
    token.setString('token', '');
    SharedPreferences user= await SharedPreferences.getInstance();
    user.setString('usuario', '');
    SharedPreferences password= await SharedPreferences.getInstance();
    password.setString('password', '');
    SharedPreferences _idUser= await SharedPreferences.getInstance();
    _idUser.setString('userId', '');
    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
  }

  Future<dynamic> Cerrar(){
    return showDialog(
      context: this.context,
      builder: (BuildContext context){
        return Center(
          //backgroundColor: Colors.blue,
            child: Material(
              type: MaterialType.transparency,
              child: Container(
                height: 25*SizeConfig.heightMultiplier,
                width: 95*SizeConfig.widthMultiplier,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(5*SizeConfig.widthMultiplier)),
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                      child: Column(
                        children: [
                          Container(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: InkWell(
                                  onTap: (){
                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                      width: 10*SizeConfig.widthMultiplier,
                                      height: 10*SizeConfig.imageSizeMultiplier,
                                      decoration: BoxDecoration(
                                          color: HexColor("01579b"),
                                          borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                      ),
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: Icon(Icons.check, color: Colors.white),
                                        ),
                                      )
                                  ),
                                ),
                              )
                          ),
                          Container(
                            margin: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier),
                            child: Text("¿Desea cerrar sesión?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.bold,
                                  fontSize: 2.3*SizeConfig.textMultiplier,
                                  color: Colors.black
                              ),
                            ),
                          ),
                          Container(
                              width: double.infinity,
                              padding: EdgeInsets.only(top: 2*SizeConfig.heightMultiplier,),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(color: HexColor("d71921"))
                                    )
                                ),
                              )
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 3*SizeConfig.heightMultiplier),
                              child: Table(
                                children: [
                                  TableRow(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              CerrarSesion();
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("01579b"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Aceptar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.only(left: 2*SizeConfig.widthMultiplier, right: 2*SizeConfig.widthMultiplier),
                                          child: InkWell(
                                            onTap: (){
                                              Navigator.of(context).pop();
                                            },
                                            child: Container(
                                              width: 60*SizeConfig.widthMultiplier,
                                              height: 5*SizeConfig.heightMultiplier,
                                              decoration: BoxDecoration(
                                                  color: HexColor("ff7400"),
                                                  borderRadius: BorderRadius.all(Radius.circular(50*SizeConfig.widthMultiplier))
                                              ),
                                              child: Center(
                                                child: Text("Cancelar",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontFamily: "Poppins",
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 2.5*SizeConfig.textMultiplier,
                                                      color: Colors.white
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ]
                                  )
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    //Menu
    Widget Titulo=Container(
        height: 6*SizeConfig.heightMultiplier,
        width: double.infinity,
        decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: HexColor("ff7400"), width: 0.5*SizeConfig.widthMultiplier),
            )
        ),
        child: Center(
          child: Text('Presupuesto',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 3.3*SizeConfig.textMultiplier,
            ),
          ),
        )
    );
    Widget MenuEmpresa1=Container(
      padding: EdgeInsets.only(left: 5*SizeConfig.widthMultiplier, right: 5*SizeConfig.widthMultiplier, top: 2*SizeConfig.heightMultiplier, bottom: 2*SizeConfig.heightMultiplier),
      child: Align(
          alignment: Alignment.center,
          child: Column(
            children: [
              /*Container(
                height: 5*SizeConfig.heightMultiplier,
                margin: EdgeInsets.only(top: 0*SizeConfig.heightMultiplier),
                padding: EdgeInsets.only(left: 20*SizeConfig.widthMultiplier, right: 20*SizeConfig.widthMultiplier),
                child: SizedBox(
                  width: double.maxFinite,
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2*SizeConfig.widthMultiplier)
                    ),
                    color:  HexColor("d71921"),
                    child: Text("Indicadores",
                      style: TextStyle(
                        fontSize: 2.5*SizeConfig.textMultiplier,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                    ),
                    onPressed: (){
                      //GetToken(user.text, pass.text, url);
                      //Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
                    },
                  ),
                ),
              ),*/
              Container(
                  child: Table(
                    children: [
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(right: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    Detalle1();
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-composicion-gasto.png'),
                                          height: 41*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Composición\ngasto',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.2*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      ),
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier, right: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    Detalle2();
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-fuentes-financiamiento.png'),
                                          height: 41*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Fuentes\nfinanciamiento',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.2*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      ),
                      TableRow(
                          children: [
                            Container(
                              margin: EdgeInsets.only(left: 1*SizeConfig.widthMultiplier),
                              padding:EdgeInsets.only(top: 1*SizeConfig.heightMultiplier, bottom: 1*SizeConfig.heightMultiplier),
                              child: InkWell(
                                  onTap:(){
                                    Detalle3();
                                  },
                                  child: Row(
                                    children: [
                                      Container(
                                        margin:EdgeInsets.only(left: 5*SizeConfig.widthMultiplier),
                                        child: Image(
                                          image: AssetImage('images/icons/icono-subnacionales.png'),
                                          height: 41*SizeConfig.imageSizeMultiplier,
                                        ),
                                      ),
                                      Container(
                                        margin:EdgeInsets.only(right: 5*SizeConfig.widthMultiplier),
                                        child: Text('Finanzas\nsubnacionales',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                            fontSize: 2.2*SizeConfig.textMultiplier,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                              ),
                            ),
                          ]
                      )
                    ],
                  )
              ),
            ],
          )
      ),
    );
    bool shouldPop = true;
    // TODO: implement build
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
        return shouldPop;
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            iconTheme: IconThemeData(color: HexColor('1063ad')),
            title: Center(
              child: Container(
                  padding: EdgeInsets.only(right: 15*SizeConfig.widthMultiplier),
                  child: Align(
                    alignment: Alignment.center,
                    child: Image(
                      image: AssetImage('images/icons/LOGO-PREFECTURA-CARCHI.png'),
                      width: 40*SizeConfig.widthMultiplier,
                    ),
                  )
              ),
            ),
            leading: Container(
              child: IconButton(
                  icon: Icon(Icons.arrow_back,),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> HomeWorker()));
                  }
              ),
            ),
          ),
          body: Center(
            child: _isLoading?CircularProgressIndicator():Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('images/icons/fondo.png'),
                        fit: BoxFit.cover
                    )
                ),
                child: Align(
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        Titulo,
                        MenuEmpresa1,
                      ],
                    )
                )
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: HexColor("ff7400"),
                    blurRadius: 1,
                    spreadRadius: 10
                ),
              ],
            ),
            child: BottomNavigationBar(
              elevation: 10,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.white,
              onTap: (value) {
                // Respond to item press.
              },
              items: [
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                    //onTap: ()=>{PerfilTrabajador1(_token)},
                      child: CircleAvatar(
                        //backgroundImage: NetworkImage(''+_data['fotoTrabajador']),
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/perfil.png"),
                          height: 10*SizeConfig.heightMultiplier,
                          width: 10*SizeConfig.widthMultiplier,
                        ),

                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeWorker()))
                      },
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/inicio.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
                BottomNavigationBarItem(
                  label: '',
                  icon: InkWell(
                      onTap: ()=>{Cerrar()},
                      child: CircleAvatar(
                        radius: 5*SizeConfig.widthMultiplier,
                        backgroundColor: Colors.white,
                        child: Image(
                          image: AssetImage("images/icons/salir.png"),
                          height: 9.5*SizeConfig.heightMultiplier,
                          width: 9.5*SizeConfig.widthMultiplier,
                        ),
                      )
                  ),
                ),
              ],
            ),
          )
      ),
    );
  }
}