// @dart=2.9

import 'dart:io';
import 'package:app/Screens/Loading/escoge_login.dart';
import 'package:app/Screens/Loading/loading.dart';
import 'package:app/Screens/Loading/pre_loading.dart';
import 'package:app/SizeConfig/SizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hexcolor/hexcolor.dart';

void main() {
  HttpOverrides.global = MyHttpOverrides();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints){
        return OrientationBuilder(
          builder: (context, orientation){
            SizeConfig().init(constraints, orientation);
            return MaterialApp(
              localizationsDelegates: [
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              supportedLocales: [ // English, no country code
                const Locale('es', 'ES'), // Arabic, no country code
              ],
              debugShowCheckedModeBanner: false,
              theme: ThemeData(
                /*accentColor: HexColor("00A1D2"),
                primaryColor: HexColor("253166"),*/
                visualDensity: VisualDensity.adaptivePlatformDensity,
              ),
              locale: const Locale('es','ES'),
              home: Loading()
            );
          },
        );
      },
    );
  }
}

class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }
}
