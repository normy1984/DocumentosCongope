class Competencia{
  var codigo;
  var nombre;
  var proyectos;
  var valor;
  var porcentaje;
  Competencia(this.nombre, this.codigo, this.proyectos, this.valor, this.porcentaje);

  /*factory Competencia.fromJson(Map<String, dynamic> json){
    return Competencia(
      codigo : json['code'].toString(),
      nombre : json['name'].toString(),
      proyectos : json['projectcount'].toString(),
      valor : json['encoded'].toString(),
      porcentaje : json['percent'].toString()
    );
  }*/
  Competencia.fromJson(Map<String, dynamic> parsedJson){
    nombre = parsedJson['name'].toString();
    codigo = parsedJson['code'].toString();
    proyectos = parsedJson['projectcount'].toString();
    valor = parsedJson['encoded'].toString();
    porcentaje = parsedJson['percent'].toString();
  }
}
