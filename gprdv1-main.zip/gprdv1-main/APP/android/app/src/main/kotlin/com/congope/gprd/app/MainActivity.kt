package com.congope.gprd.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
