# Llankay CONGOPE

## Instalación:

* Requiere PHP 7.3.*, MySQL 8.*, Apache 2.4.*, Node.js 10.*, Composer 1.8.*

### Para una instalación fresca:
    
1. Instalar dependencias.
    * `composer install --prefer-dist`

2. Configurar parámetros.
    * Copiar `.env.example` a `.env` y actualizar los parámetros por defecto con los reales.
    * Crear el esquemas de base de datos.

3. Generar token de seguridad.
    * `php artisan key:generate`

4. Instalar plugins de presentación.
    * `npm install --save`

5. Generar los assets.
    * `npm run dev`
    
6. Almacenar rutas en cache.
    * `php artisan route:cache`

7. Publicar configuraciones de vendors.
    * `php artisan vendor:publish --provider="SlonCorp\Acl\AclServiceProvider"`
    * `php artisan vendor:publish --tag="accountant-configuration"`
    
8. Ejecutar migraciones y llenar las tablas con los catálogos iniciales propios del sistema.
    
    * `php artisan sloncorp:seed`
    
    * Base de datos del inventario vial
        * `# mysql -h localhost -u homestead -p inventory_roads_llankay < [ubicación del proyecto]/database/inventory_roads_data/carchi.sql`
        
9. Asegurarse que las librerías `php-pdo`, `php-mysqlnd`, `php-mcrypt`, `php-mbstring`, `php-xml`, `php-gd`, `php-pgsql`, `php72-php-zip` se encuentren instaladas.

10. Crear directorio principal de archivos
    * `# mkdir /opt/llankay`

11. Crear directorios para almacenar archivos de perfil, indicadores, vías, catálogos, justificaciones y reformas
    * Dentro del directorio `/opt/llankay/`
        * `# mkdir files indicators inventory_road inventory_roads_catalog justifications profiles reforms`

12. Cambiar permisos a carpetas de archivos
    
    * En ambiente de producción utilizando apache como web server se debe ejecutar
    
        * `# chown -R apache:apache /opt/llankay`
        * `# chown -R apache:apache [ubicación del proyecto]/storage`
    
    * Además se debe otorgar permisos 775 a las mismas carpetas
    
        * `# chmod -R 775 /opt/llankay`
        * `# chmod -R 775 [ubicación del proyecto]/storage`

13. Crear links simbólicos en el directorio (ejemplo vm Homestead) `/home/vagrant/Code/llankay/public`
    * `# ln -s /opt/llankay/files .`
    * `# ln -s /opt/llankay/justifications .`
    * `# ln -s /opt/llankay/profiles .`
    
14. Crear link simbólico en el directorio (ejemplo vm Homestead) `/home/vagrant/Code/llankay/public/images`   
    * `# ln -s /opt/llankay/inventory_road .` 

15. Asegurarse que cuando se encienda el servidor los servicios se inicien: `httpd`, `mysql`

16. Conexión a BD Postgres
    * Habilitar en el archivo php.ini las extenciones para los drivers de Postgres: `extension=pdo_pgsql` y `extension=pgsql`

17. Instalar Wkhtmltopdf con una de las opciones siguientes
    * Descargar wkhtmltopdf desde aquí https://wkhtmltopdf.org/downloads.html
    * Como dependencia de composer(ya está por defecto): `composer require h4cc/wkhtmltopdf-amd64 0.12.x` 
    * Vagrant: Mover los binarios a una dirección que no sea sincronizada ej:
        `cp vendor/h4cc/wkhtmltopdf-amd64/bin/wkhtmltopdf-amd64 /usr/local/bin/`
        * Permisos de ejecución: `chmod +x /usr/local/bin/wkhtmltopdf-amd64`
    