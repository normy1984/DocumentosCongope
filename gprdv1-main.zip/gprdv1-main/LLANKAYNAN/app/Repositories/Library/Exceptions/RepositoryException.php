<?php


namespace App\Repositories\Library\Exceptions;


class RepositoryException extends \Exception
{

}