<?php

namespace App\Models\Business\Roads;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase TypeCriticalPoint (tipo punto crítico)
 * @property mixed code
 * @property mixed descrip
 * @package App\Models\Business\Roads
 */
class TypeCriticalPoint extends Model
{

    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'tipo_punto_critico';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descrip'
    ];
}