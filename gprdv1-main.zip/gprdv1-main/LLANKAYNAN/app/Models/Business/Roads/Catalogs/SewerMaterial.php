<?php

namespace App\Models\Business\Roads\Catalogs;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase SewerMaterial
 * @package App\Models\Business\Roads\Catalogs
 */
class SewerMaterial extends Model
{
    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'material_alcantarilla';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var string
     */
    protected $primaryKey = 'descrip';

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descrip'
    ];
}
