<?php

namespace App\Models\Business\Roads\Catalogs;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase Status
 * @package App\Models\Business\Roads\Catalogs
 */
class Status extends Model
{
    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'estado';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var string
     */
    protected $primaryKey = 'descripcion';

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * Opción SIN DETERMINAR
     */
    const WITHOUT_DETERMINING = 'SIN DETERMINAR';

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descripcion'
    ];
}
