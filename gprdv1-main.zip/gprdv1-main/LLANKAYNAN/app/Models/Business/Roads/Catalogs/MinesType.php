<?php

namespace App\Models\Business\Roads\Catalogs;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase MinesType
 * @package App\Models\Business\Roads\Catalogs
 */
class MinesType extends Model
{
    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'tipo_minas';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var string
     */
    protected $primaryKey = 'descrip';

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descrip'
    ];
}
