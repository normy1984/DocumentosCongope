<?php

namespace App\Models\Business\Roads\Catalogs;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase BridgeRollingLayer
 * @package App\Models\Business\Roads\Catalogs
 */
class BridgeRollingLayer extends Model
{
    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'capa_rodadura_puente';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var string
     */
    protected $primaryKey = 'descrip';

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descrip'
    ];
}
