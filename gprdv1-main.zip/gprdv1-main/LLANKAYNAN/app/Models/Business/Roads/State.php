<?php

namespace App\Models\Business\Roads;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase State (Estado de vías)
 * @property mixed codigo
 * @property mixed descripcion
 * @package App\Models\Business\Roads
 */
class State extends Model
{

    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'estado';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descripcion'
    ];
}