<?php

namespace App\Models\Business\Roads;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase HorizontalSignal (Señalización horizontal)
 * @package App\Models\Business\Roads
 */
class HorizontalSignal extends Model
{

    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'sen_horizontal';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var string
     */
    protected $primaryKey = 'gid';

    /**
     * @var array
     */
    protected $fillable = [
        'gid',
        'tipo',
        'estado',
        'lado',
        'lati',
        'longi',
        'latf',
        'longf',
        'observ',
        'codigo'
    ];

}
