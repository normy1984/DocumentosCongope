<?php

namespace App\Models\Business\Roads;

use Illuminate\Database\Eloquent\Model;

/**
 * Clase RollingLeatherBridge (capa de rodadura de puentes)
 * @property mixed code
 * @property mixed descrip
 * @package App\Models\Business\Roads
 */
class RollingLeatherBridge extends Model
{

    /**
     * @var string
     */
    protected $connection = 'mysql2';

    /**
     * @var string
     */
    protected $table = 'capa_rodadura_puente';

    /**
     * @var bool
     */
    public $timestamps = false;

    /**
     * @var array
     */
    protected $fillable = [
        'codigo',
        'descrip'
    ];
}