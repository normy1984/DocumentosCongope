<?php

namespace App\Models\System;

use App\Models\BaseModel;

class Menu extends BaseModel
{
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * Get the parent that owns the menu.
     */
    public function parent()
    {
        return $this->belongsTo('App\Models\System\Menu', 'parent_id');
    }

    /**
     * Get the children for the menu.
     */
    public function children()
    {
        return $this->hasMany('App\Models\System\Menu', 'parent_id');
    }
}
