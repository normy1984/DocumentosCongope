<?php

namespace App\Models\Admin;

use App\Models\BaseModel;

/**
 * Clase Threshold (Umbral)
 * @package App\Models\Admin
 */
class Threshold extends BaseModel
{
    /**
     * @var string
     */
    protected $table = 'thresholds';

    /**
     * @var bool
     */
    public $timestamps = true;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'type',
        'color',
        'min',
        'max'
    ];
}
