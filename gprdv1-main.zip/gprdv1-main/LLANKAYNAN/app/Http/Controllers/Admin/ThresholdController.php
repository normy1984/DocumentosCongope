<?php

namespace App\Http\Controllers\Admin;

use App\Processes\Admin\ThresholdProcess;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

/**
 * Clase class ThresholdController extends Controller
 * @package App\Http\Controllers\Admin
 */
class ThresholdController extends Controller
{
    /**
     * @var $thresholdProcess
     */
    protected $thresholdProcess;

    /**
     * Constructor de ThresholdController.
     *
     * @param ThresholdProcess $thresholdProcess
     */
    public function __construct(
        ThresholdProcess $thresholdProcess
    ) {
        $this->thresholdProcess = $thresholdProcess;
    }

    /**
     * Mostrar formulario de edición de un indicador del plan.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function edit()
    {
        try {
            return response()->json($this->thresholdProcess->edit());
        } catch (\Throwable $e) {
            return response()->json(defaultCatchHandler($e));
        }
    }

    /**
     * Actualizar umbral.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request)
    {
        try {
            return response()->json($this->thresholdProcess->update($request));
        } catch (\Throwable $e) {
            return response()->json(defaultCatchHandler($e));
        }
    }
}
