<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Processes\Admin\UserProcess;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Throwable;

/**
 * Clase UserController
 * @package App\Http\Controllers\Admin
 */
class UserController extends Controller
{
    /**
     * @var UserProcess
     */
    protected $userProcess;

    /**
     * Constructor de UserController.
     *
     * @param UserProcess $userProcess
     */
    public function __construct(
        UserProcess $userProcess
    ) {
        $this->userProcess = $userProcess;
    }

    /**
     * Mostrar vista de listado de usuarios.
     *
     * @return JsonResponse
     */
    public function index()
    {
        try {

            $response['view'] = view('admin.user.index')->render();

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para cargar información de usuarios.
     *
     * @return JsonResponse
     */
    public function data()
    {
        try {

            return $this->userProcess->data();

        } catch (Throwable $e) {
            return datatableEmptyResponse($e, $e);
        }
    }

    /**
     * Llamada al proceso para mostrar el formulario de creación de usuario.
     *
     * @return JsonResponse
     */
    public function create()
    {
        try {

            $response = $this->userProcess->create();

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para almacenar nuevo usuario.
     *
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function store(Request $request)
    {
        try {

            $response = $this->userProcess->store($request);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }


    /**
     * Llamada al proceso para mostrar la información de usuario.
     *
     * @param int $id
     *
     * @return JsonResponse
     */
    public function show(int $id)
    {
        try {

            $response = $this->userProcess->show($id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para mostrar el formulario de edición de usuario.
     *
     * @param  int $id
     *
     * @return JsonResponse
     */
    public function edit(int $id)
    {
        try {

            $response = $this->userProcess->edit($id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para actualizar la información de usuario en la BD.
     *
     * @param Request $request
     * @param  int $id
     *
     * @return JsonResponse
     */
    public function update(Request $request, $id)
    {
        try {

            $response = $this->userProcess->update($request, $id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para eliminar lógicamente un usuario.
     *
     * @param  int $id
     *
     * @return JsonResponse
     */
    public function destroy(int $id)
    {
        try {
            $response = $this->userProcess->destroy($id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }


    /**
     * Llamada al proceso para cambiar de estado un usuario.
     *
     * @param  int $id
     *
     * @return JsonResponse
     */
    public function status(int $id)
    {
        try {
            $response = $this->userProcess->status($id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para actualizar la contraseña
     *
     * @param int $id
     *
     * @return JsonResponse
     */
    public function updatePassword(int $id)
    {
        try {
            $response = $this->userProcess->resetPassword($id);

        } catch (Throwable $e) {
            $response = defaultCatchHandler($e);
        }

        return response()->json($response);
    }

    /**
     * Llamada al proceso para verificar si el nombre de usuario ya existe.
     *
     * @param Request $request
     *
     * @return false|string
     */
    public function checkUsernameExists(Request $request)
    {
        $result = $this->userProcess->checkUsernameExists($request);
        return json_encode(!$result);
    }

}
