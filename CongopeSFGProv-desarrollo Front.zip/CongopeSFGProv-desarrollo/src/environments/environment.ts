export const environment = {
  //production: true,
  production: false,
//  apiUrl: 'http://localhost:4200',
   apiUrl: '//192.168.50.13:8088/chatia'
};
