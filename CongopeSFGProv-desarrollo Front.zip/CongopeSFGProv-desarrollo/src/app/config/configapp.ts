export const configapp = {
    // VARIABLE POR DEFECTO PARA TODOS LOS SERVICIOS DEL SISTEMA
    //apiUrl: "http://localhost:5142/api/",
    apiUrl:"https://back-sfgprov.congope.gob.ec/api/", 
    // RUTA DONDE SE ALOJAN LOS SERVICIOS
    //UrlServicios: "http://localhost:5142/",
    UrlServicios:"https://back-sfgprov.congope.gob.ec/", 
    // VARIABLE POR DEFECTO PARA LA PAGINACION DE LOS GRID DEL SISTEMA
    pageSizeOptions: [5, 10, 25, 100],
    // VARIABLE CON EL TEXTO QUE SE MUESTRA EN LA PAGINACION DEL SISTEMA
    mensajeItemsPagina: "Registros por página",
    // VARIABLE PARA LA ENCRIPTACION DEL TEXTO QUE SE MUESTRA EN LOS GET
    secretKeyCrypt: "gOXE7tCGPs0y0qda",
    // VARIABLE CON TIEMPO EN MINUTOS DE INACIVIDAD DEL USUARIO - SI NO REALIZA NINGUN MOVIMIENTO EL SISTEMA SE CIERRA
    tiempoInactividad: 15,
    // VARIABLE CON TIEMPO EN MINUTOS QUE INDICA CADA CUANTO TIEMPO SE RECARGA LAS NOTIFIACIONES
    tiemponNotificacion: 20,
    // VARIABLE DONDE ESTA PUBLICADO EL HUB DE MENSAJES
    hubMensajes: "hub/mensajes",
    // VARIABLE QUE LE INDICA A LA APLICACION QUE USAREMOS KEYCLOAK PARA EL LOGIN true (KEYCLOAK) || false(LOGIN PROPIO)
    Keycloack_login: false,
    // NOSONAR: Entorno de desarrollo y pruebas interno URL DE KEYCLOAK
    Keycloack_url: "https://keycloak.congope.gob.ec/",
    // REALM DE KEYCLOAK
    Keycloack_realm: "CONGOPE",
    // CLIENT_ID DE KEYCLOAK
    Keycloack_clientid: "ApiCongope",
    // CODIGO DE RECAPTCHA GOOGLE
    Recaptcha_Code: "6Ld0zNErAAAAAGTHadKRghUx2MCoaSMs5darTkYt",

}