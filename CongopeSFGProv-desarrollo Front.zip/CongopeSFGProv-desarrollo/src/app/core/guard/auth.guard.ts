//auth.guard.ts

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { configapp } from '@config/configapp';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard {
  constructor(private authService: AuthService, private router: Router) { }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    try {

      const paramSesion = sessionStorage.getItem('ParamSesiones');

      if (this.authService.currentUserValue && paramSesion) {
        return true;
      }
      // AQUI VALIDA SI EL LOGIN SE LO VA A REALIZAR CON KEYCLOAK CASO CONTRARIO SE HACE CON EL MODULO LOCAL
      if (configapp.Keycloack_login) {
        await this.authService.loadUserFromKeycloak();
        return true;
      }
      else {
        this.router.navigate(['/authentication/signin']);
        return false;
      }
    }
    catch (error) {
      console.error('Error en AuthGuard:', error);
      return false;
    }
  }
}
