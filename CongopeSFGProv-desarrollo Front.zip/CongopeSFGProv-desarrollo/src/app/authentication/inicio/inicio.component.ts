import { Component, OnInit, inject, ViewChild, ElementRef } from '@angular/core';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { ChartConfiguration, ChartOptions, ChartType } from 'chart.js';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import * as L from 'leaflet';  // Importar Leaflet


import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexFill,
  ApexTooltip,
  ApexTitleSubtitle,
  ApexGrid,
  ApexMarkers,
  ApexNonAxisChartSeries,
  ApexResponsive,
  NgApexchartsModule,
  ApexOptions,
} from 'ng-apexcharts';
import { Observable } from 'rxjs/internal/Observable';
//import { IgxGridModule } from 'igniteui-angular';
import * as $ from 'jquery'; // Importar jQuery
import { AfterViewInit } from '@angular/core';
import { ParamSessionMo } from 'app/models/param-session';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgModule } from '@angular/core';
//import { BrowserModule } from '@angular/platform-browser';

import { environment } from 'environments/environment.development';


@Component({
    selector: 'app-inicio',
    imports: [BreadcrumbComponent, NgApexchartsModule, FormsModule], // NgChartsModule
    templateUrl: './inicio.component.html',
    styleUrls: ['../../../assets/scss/chatia.css']
})



//, AfterViewInit
export class InicioComponent implements OnInit   {
  [x: string]: any;
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  alertas: any;
  /*grafico de pie*/ 
  public pieChartType: ChartType = 'pie';
  public pieChartLabels: string[] = ['Ventas', 'Gastos', 'Ahorros'];
  

public pieChartOptions: Partial<ApexOptions> = {
  series: [25, 30, 20, 25],
  chart: {
    type: 'pie',
    height: 290,
    width:300 ,
    toolbar: {
    show: true
  },
  },

  /*
  title: {
    text: 'Ingresos - Ejecución Presupuestaria',
    align: 'center',
    style: {
      fontSize: '10px',
      color: '#333'
    }},*/
  labels: ['Codificado', 'Certificado', 'Comprometido', 'Devengado'],
  responsive: [
    {
      breakpoint: 480,
      options: {
        chart: {
          width: 300,
        },
        legend: {
          //position: 'bottom',
          show:false,
        }
      }
    }
  ],
  legend: {
   // position: 'right'
   show:false,
  }
};

public anioMapa:string=this.ParamSessiones.anio.toString();
// @ViewChild('userNameInput') userNameInput!: ElementRef;
  @ViewChild('chatBox') chatBox!: ElementRef;
  @ViewChild('nameContainer') nameContainer!: ElementRef;
    public barChartOptions: ApexOptions = {
  };
  
constructor(private ServicioClienteHttp: ClienthttpCongopeService) {


  this.inicializa().subscribe({
    next: (fila) => {
        console.log("Datos recibidos para el gráfico", fila);
  // Bar chart chart 1
  this.barChartOptions = {
    series: [
      {
        name: 'Codificado',
       data: fila.map((item: { out_codificado: any; }) => item.out_codificado.toFixed(2)),
      },
      {
        name: 'Certificado',
        data: fila.map((item: { out_comprometido: any; }) => item.out_comprometido),
      },
      {
        name: 'Comprometido',
        data: fila.map((item: { out_devengado: any; }) => item.out_devengado),
      },
      {
        name: 'Devengado',
        data: fila.map((item: { out_devengado: any; }) => item.out_devengado),
      },
     
    ],
    chart: {
      type: 'bar',
      height: 300,
      foreColor: '#9aa0ac',
       width:500,
    },
  /*  title: {
    text: 'Ejecución Presupuestaria',
    align: 'center',
    style: {
      fontSize: '10px',
      color: '#333'
    }
  },*/
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        borderRadius: 5,
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent'],
    },
    xaxis: {
      categories: fila.map((item: { out_ugs_nombre: any; }) => item.out_ugs_nombre.replace("DIRECCION","DIR").substring(0,18)), //antes partida 
      labels: {
        style: {
          colors: '#9aa0ac',
          fontSize: '8px',
        },
      },
    },
    yaxis: {
      title: {
        text: '$ (Dólares)',
        style: {
          fontSize: '10px',
        },
      },
      labels: {
        style: {
          fontSize: '8px',
        },
      }
    },
    legend: {
          position: 'right',
        //  show:false,
        },
    grid: {
      show: true,
      borderColor: '#9aa0ac',
      strokeDashArray: 1,
    },
    fill: {
      opacity: 1,
    },
    tooltip: {
      theme: 'dark',
      marker: {
        show: true,
      },
      x: {
      },
    },
  };
}
});



}

/*
 enviarMensaje(datos: any) {
    this.http.post('/chatia', datos).subscribe(res => {
      console.log('Respuesta:', res);
    });
  }*/
toggleChat() {
  const chatContainer = document.getElementById('chat-container');
  const openChatBtn = document.getElementById('open-chat-btn');

  if (!chatContainer || !openChatBtn) {
    console.warn('Elementos no encontrados en el DOM');
    return;
  }

  // Scroll automático hacia abajo
  chatContainer.scrollTop = chatContainer.scrollHeight;

  if (chatContainer.style.display === 'none' || chatContainer.style.display === '') {
    chatContainer.style.display = 'flex';
    chatContainer.classList.add('show');
    openChatBtn.style.display = 'none';
  } else {
    chatContainer.style.display = 'none';
    chatContainer.classList.remove('show');
    openChatBtn.style.display = 'flex';
  }
}

/*
startChat() {
    const name = this.userNameInput.nativeElement.value.trim();

    if (!name) {
      alert('Por favor, ingresa tu nombre.');
      return;
    }

    // Ocultar contenedor de nombre
    this.nameContainer.nativeElement.style.display = 'none';

    // Mostrar mensaje de bienvenida en el chat
    const chatBoxEl = this.chatBox.nativeElement;
    const welcomeMessage = document.createElement('div');
    welcomeMessage.className = 'message bot-message';
    welcomeMessage.innerHTML = `
      <span class="icon"><i class="fas fa-robot"></i></span>
      <div class="message-content">¡Hola ${name}! ¿En qué puedo ayudarte hoy?</div>
    `;
    chatBoxEl.appendChild(welcomeMessage);
    chatBoxEl.scrollTop = chatBoxEl.scrollHeight;
  }
*/
userName: string = '';
userInput: string = '';

startChat() {
  const name = this.userName.trim();
  if (!name) {
    alert('Por favor, ingresa tu nombre.');
    return;
  }
      // Ocultar contenedor de nombre
    this.nameContainer.nativeElement.style.display = 'none';
    // Mostrar mensaje de bienvenida en el chat
    const chatBoxEl = this.chatBox.nativeElement;
    const welcomeMessage = document.createElement('div');
    welcomeMessage.className = 'message bot-message';
    welcomeMessage.innerHTML = `
      <span class="icon"><i class="fas fa-robot"></i></span>
      <div class="message-content">¡Hola ${name}! ¿En qué puedo ayudarte hoy?</div>
    `;
    chatBoxEl.appendChild(welcomeMessage);
   // chatBoxEl.scrollTop = chatBoxEl.scrollHeight;
  // Lógica para iniciar el chat con "name"
}
/*
toggleSendButton() {
  const user_input = this.userInput;
  const sendButton = document.getElementById("send_button") as HTMLButtonElement | null;

  if (sendButton) {
    sendButton.disabled = user_input === '';
  }
}*/
get isSendDisabled(): boolean {
  return this.userInput === '';
}

sendMessage() {
  const backendUrl = environment.apiUrl;
  /*environment.production
  ? 'http://192.168.50.13:8088/chatia'
  : '/chatia'; // En dev usa proxy*/
        const name = this.userName.trim();
        const message = this.userInput.trim();
        const chatBoxEl = this.chatBox.nativeElement;

        if (!message) return; // No enviar si el mensaje está vacío

        // Mostrar mensaje del usuario
        const userMessage = document.createElement("div");
        userMessage.className = "message user-message";
        userMessage.innerHTML = `
          <span class="icon"><i class="fas fa-user"></i></span>
          <div class="message-content"><strong>${name}:</strong> ${message}</div>
        `;    
        chatBoxEl.appendChild(userMessage);
    console.log("Enviando mensaje al backend...",message);
    console.log('🔧 URL del backend:', backendUrl);
    this.ServicioClienteHttp.enviarChat(backendUrl,message).subscribe({
       // this.ServicioClienteHttp.enviarChat("/chatia",message).subscribe({
        next: (data) => {
            console.log("Respuesta completa del backend:", data);
          //    console.log("🔄 Tipo de respuesta:", typeof data);
  //console.log("📦 Contenido de la respuesta:", data);
        //  let resultado: any[] = typeof data.result === 'string'  ? JSON.parse(data.result)  : data.result;
         // console.log("Respuesta del bot:",resultado);
          var errorMessage = document.createElement("div");
                    errorMessage.className = "message";
                    errorMessage.innerText = data.response;
                    chatBoxEl.appendChild(errorMessage);
          if ('error' in data) {
      console.warn("Error del servidor:", data.error);
    } else if ('response' in data) {
    } else {
      console.warn("Respuesta inesperada del servidor:", data);
    }
        },
        error: (err) => {
          console.log(err.message);
        }
      });  
}
    ngOnInit(): void {  
    this.initMap(); // Llamar al método para inicializar el mapa
    }
 
    public rutaapi: string ="VerSaldoPartida/GetEvalPresPorUnidad?codemp="+ this.ParamSessiones.codemp+"&anio="+this.ParamSessiones.anio;

    inicializa() {
      return new Observable<any>((observer) => {
  
        // Llamar al endpoint del backend para obtener los datos
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
        this.ServicioClienteHttp.Obtener_Lista().subscribe({
          next: (data: { success: any; result: string; message: any; }) => {
            if (data.success) {
              let resultado: any[] = JSON.parse(data.result);
               
              // Emitir el valor de 'fila' al observable
              observer.next(resultado);
              observer.complete();
            } else {
              this.alertas.MensajeError(data.message);
              observer.error(data.message); // En caso de que haya error, se emite un error al observable
            }
          },
          error: (err: { message: any; }) => {
            console.log(err.message);
            observer.error(err.message); // En caso de error en la solicitud HTTP
          }
        });
      });
    }

    initMap(): void {
      // Uso del json de viaticos
      this.generarViatico().subscribe({
        next: (resultado) => {
          // Guarda el resultado de la respuesta
          let res = resultado;   
          // Crear el mapa y configurarlo
          const map = L.map('map').setView([-1.8312, -78.1835], 6); // Coordenadas de Ecuador, con zoom 6
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }).addTo(map);
              // Estilo para las provincias
          const estiloDivisiones = {
            color: '#3388ff',   // Color del borde
            weight: 2,          // Grosor del borde
            opacity: 1,         // Opacidad del borde
            fillColor: '#66ccff',  // Color de relleno
            fillOpacity: 0.5    // Opacidad del relleno
          };
          // Cargar el archivo GeoJSON con la división política de Ecuador
          fetch('assets/ecuador.geojson')
            .then(response => response.json())
            .then(data => {
              // Guardar las divisiones en una variable global
              const geojsonLayer = L.geoJSON(data, {
                style: estiloDivisiones
              }).addTo(map);
    
              // Manejar el evento de clic en el mapa
              map.on('click', (event: any) => {
                const { lat, lng } = event.latlng;
    
                // Verificar qué provincia se encuentra en las coordenadas del clic
                geojsonLayer.eachLayer((layer: any) => {
                  if (layer instanceof L.Polygon && layer.getBounds().contains(event.latlng)) {
                    const provinceCodigo = layer.feature?.properties.dpa_provin; // Ajusta el nombre según tu archivo GeoJSON
                   
                    // Encontrar el 'total' correspondiente a la provincia clickeada
                    const provinciaData = res.find((item: any) => item.provincia === provinceCodigo);
                      const provinceName = layer.feature?.properties.nombre;                     
                    if (provinciaData) {                
                      const total = provinciaData.total;
                      const anio = provinciaData.dpa_anio;
                      // Crear un marcador en el lugar donde el usuario hizo clic
                      L.marker([lat, lng]).addTo(map).bindPopup(`Provincia: ${provinceName} <br> Total Sol. Aprobadas: ${total}`).openPopup();
                    } else {
                      // Si no se encuentra la provincia en los datos
                      L.marker([lat, lng]).addTo(map).bindPopup(`Provincia: ${provinceName} <br> Total Sol. Aprobadas: No disponible`).openPopup();
                    }
                  }
                });
              });
            })
            .catch(error => {
              console.error('Error al cargar el archivo GeoJSON:', error);
            });
        },
        error: (error) => {
          console.error("Hubo un error: ", error);
        }
      });
    }

public rutaapi1:string ="Mapa?periodo_vigente=2024";
generarViatico(): Observable<any> {
  // Retornar un Observable que emitirá los datos
  return new Observable<any>((observer) => {

    // Llamar al endpoint del backend para obtener los datos
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi1);
   
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data: { success: any; result: string; message: any; }) => {
        if (data.success) {
         
          let resultado: any[] = JSON.parse(data.result);
 
          // Emitir el valor de 'resultado' al observable
          observer.next(resultado);  // Aquí emites los datos
          observer.complete();  // Completa el Observable
        } else {
          this.alertas.MensajeError(data.message);
          observer.error(data.message);  // En caso de error, emite un error
        }
      },
      error: (err: { message: any; }) => {
        console.log(err.message);
        observer.error(err.message);  // Si hay error en la solicitud HTTP, emite un error
      }
    });
  });
}

}
