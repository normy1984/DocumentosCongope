import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '@core';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';
import { configapp } from '@config/configapp';

@Component({
    selector: 'app-signin',
    templateUrl: './signin.component.html',
    styleUrls: ['./signin.component.scss'],
    imports: [
        RouterLink,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatButtonModule,
        RecaptchaModule,
        RecaptchaFormsModule,
    ]
})
export class SigninComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  authForm!: UntypedFormGroup;
  submitted = false;
  loading = false;
  error = '';
  hide = true;

  captchaResolved = false;
  captchaToken: string | null = null;
  recaptcha_Code: string = configapp.Recaptcha_Code;

  mensajeInicio = "Sistema Financiero de Gobiernos Provinciales (SFGProv)";

  constructor(
    private formBuilder: UntypedFormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {
    super();
    sessionStorage.clear(); // Limpiar todas las variables de sessionStorage
  }

  ngOnInit(): void {
    this.authService.logout();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.authForm = this.formBuilder.group({
      username: ['0401030523001', Validators.required],
      password: ['yOFj3s58', Validators.required],
    });
  }

  get f() {
    return this.authForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;
    this.loading = true;
    this.error = '';

    if (this.authForm.invalid) {
      this.error = 'Usuario o Contraseña Inválido!';
      this.loading = false;
      return;
    }

    this.authService.login(this.f['username'].value, this.f['password'].value)
      .subscribe({
        next: (res: any) => {
          if (res && res.body && res.body.token) {
            this.router.navigate(['inicio']);
          } else {
            this.error = 'Ingreso no válido!';
            this.loading = false;
          }
        },
        error: (error: any) => {
          this.error = error;
          this.loading = false;
        }
      });
  }

  onCaptchaResolved(token: string | null) {
  if (token) {
    this.captchaResolved = true;
  } else {
    console.warn('Captcha no resuelto');
  }
}
}
