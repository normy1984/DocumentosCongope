import { Component, OnInit, inject } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators, FormsModule, ReactiveFormsModule, AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';

import Swal from 'sweetalert2';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { ParamSessionMo } from 'app/models/param-session';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { AuthService } from '@core';
import { UnsubscribeOnDestroyAdapter } from '@shared';


// Validador personalizado para comprobar que las contraseñas coinciden
export function passwordMatchValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const password = control.get('password');
    const cpassword = control.get('cpassword');

    if (!password || !cpassword) {
      return null;
    }

    return password.value === cpassword.value ? null : { passwordMismatch: true };
  };
}


@Component({
    selector: 'app-signup',
    templateUrl: './cambiar-contrasena.component.html',
    imports: [
    BreadcrumbComponent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule
]
})

export class CambiarContrasenaComponent extends UnsubscribeOnDestroyAdapter
implements OnInit  {
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public alertas = inject(AlertasSrvService);
  FormularioDatos!: UntypedFormGroup;
  submitted = false;
  returnUrl!: string;
  ahide = true;
  hide = true;
  chide = true;
  constructor(
    private formBuilder: UntypedFormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private authService: AuthService,
  ) {
    super();
  }
  ngOnInit() {
    this.FormularioDatos = this.formBuilder.group({
      apassword: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^\S+$/)]],
      cpassword: ['', [Validators.required, Validators.minLength(8)]]
    }, { validators: passwordMatchValidator() });
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  get f() {
    return this.FormularioDatos.controls;
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.FormularioDatos.invalid) {
      return;
    } else {
      
        Swal.fire({
          title: "¿Está seguro de cambiar la contraseña?",
          showDenyButton: true,
          confirmButtonText: "Sí, Cambiar",
          denyButtonText: "No, Cancelar"
        }).then((result) => {
          if (result.isConfirmed) {

            let datosGuardar = this.FormularioDatos.getRawValue();

            const objeto = {
              codUsu: this.ParamSessiones.codusu,
              contrasenaAnterior: datosGuardar.apassword,
              contrasenaNueva: datosGuardar.cpassword
            };

            this.ServicioClienteHttp.SeteoRuta("Usuarios/CambiarContrasena");
            this.ServicioClienteHttp.Actualizar(this.ParamSessiones.codusu, objeto).subscribe({
              next: (data) => {
                if (data.success) {
                  
                    this.subs.sink = this.authService.logout().subscribe((res) => {
                      if (!res.success) {
                        this.alertas.MensajeExito('/authentication/signin', 'Contraseña cambiada existosamente!');
                      }
                    });
                  
                 } else {
                  this.alertas.MensajeError(data.message);
                }
              },
              error: (err) => {
                console.log(err.message);
              }
            });
          }
        });
     
      
    }
  }
}
