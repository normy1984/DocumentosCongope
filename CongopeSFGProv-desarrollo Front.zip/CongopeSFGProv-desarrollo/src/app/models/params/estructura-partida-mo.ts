import { ParamSessionMo } from "../param-session";

export class EstructuraPartidaMO {
  public niv_est: number;
  public identifi: number;
  public des_est: string;
  public lon_est: number;
  public cre_por: string;
  public con_est: number;
  public item_aso: number;
  public foce: number;
  public orienta_gas: number;
  public niv_ug: number;
  public niv_proy: number;
  public estado: number;
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  constructor(datos: EstructuraPartidaMO) {
    {
      this.niv_est = datos.niv_est || 0;
      this.identifi = datos.identifi || 0;
      this.des_est = datos.des_est || '';
      this.lon_est = datos.lon_est || 0;
      this.cre_por = datos.cre_por || '';
      this.con_est = datos.con_est || 0;
      this.item_aso = datos.item_aso || 0;
      this.foce = datos.foce || 0;
      this.orienta_gas = datos.orienta_gas || 0;
      this.niv_ug = datos.niv_ug || 0;
      this.niv_proy = datos.niv_proy || 0;
      this.estado = datos.estado || 1;
    }
  }
}
