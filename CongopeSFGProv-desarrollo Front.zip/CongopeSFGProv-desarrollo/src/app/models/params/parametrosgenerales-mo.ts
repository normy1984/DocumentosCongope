export class ParametrosGeneralesMO {

  codigo:number;
  descrip:string;
  activo:number;
  dato_adi:string;
  constructor(datos: ParametrosGeneralesMO) {
      {
        this.codigo = datos.codigo || 0;
        this.descrip = datos.descrip || '';
        this.activo = datos.activo || 0;
        this.dato_adi = datos.dato_adi || '';
      }
  }
}
