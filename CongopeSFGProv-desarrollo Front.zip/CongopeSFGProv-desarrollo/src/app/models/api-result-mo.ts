export interface ApiResultMo {

    success:boolean,
    message:string,
    result:any
}

export interface ApiResultMoPhp {
error:string,
    success:boolean,
    message:string,
    result:any
}
