export class ParamSessionMo {
    codemp!:string;
    anio!:number;
    sistema!:number;
    codusu!:number;
  }

  export class SistemaMenuMO {
    nombreSistema!:string; 
  }
  