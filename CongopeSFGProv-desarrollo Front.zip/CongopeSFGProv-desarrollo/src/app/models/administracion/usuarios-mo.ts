import { ParamSessionMo } from "../param-session";

export interface UsuariosMo {
    CodUsu: number;
    Cedruc: string;
    EsAdministrador: number;
    UsuarioConsulta: boolean;
    PerfilesMenu: string[];
}

export class ConsultaAprobarDocumentosMo {
    CodUsu: number;
    CodSistema: number;
    VarSesion: ParamSessionMo; 
    constructor() {
        {
            this.CodUsu = 0;
            this.CodSistema = 0;
            this.VarSesion = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
        }
    }
}


export class AprobarDocumentosMo {

public CodUsu:number;
public CodSistema:number;
public Aprueba:number;
public Desaprueba:number;
public SigTip:string;
public VarSesion: ParamSessionMo; 
    constructor() {
        {
            this.CodUsu = 0;
            this.CodSistema = 0;
            this.Aprueba = 0;
            this.Desaprueba = 0;
            this.SigTip = '';
            this.VarSesion = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
        }
    }
}
