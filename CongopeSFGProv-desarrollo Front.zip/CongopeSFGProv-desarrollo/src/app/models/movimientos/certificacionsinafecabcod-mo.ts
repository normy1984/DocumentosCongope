import { ParamSessionMo } from "../param-session";

export class CertificacionSinAfeCabCodMO {
     accion:string;
     estado:number;
     n_estado:string;
     acu_tip:string;
     des_cab:string;
     valor_total:number;
     VarSesion!: ParamSessionMo; 
     fec_asi: string;
     fec_apr: string;
     departam_desc:string;
     departam:number;
     solicita_desc:string;
     solicita:string;
     creado_por:string;
     modificado_por:string;


     constructor(datos: CertificacionSinAfeCabCodMO) {
        {
            this.accion = datos.accion || '';
            this.estado = datos.estado || 0;
            this.n_estado =datos.n_estado || ''; 
            this.acu_tip = datos.acu_tip || '';
            this.des_cab = datos.des_cab || '';
            this.valor_total = datos.valor_total || 0;     
            this.VarSesion=datos.VarSesion;  
            this.fec_asi = datos.fec_asi || '';
            this.fec_apr = datos.fec_apr || '';  
            this.departam_desc=datos.departam_desc||'';
            this.departam=datos.departam||0;
            this.solicita_desc=datos.solicita_desc||'';
            this.solicita=datos.solicita||'';
            this.creado_por=datos.creado_por||'';
            this.modificado_por=datos.modificado_por||'';
            this.creado_por=datos.creado_por||'';
        }
    }
  }