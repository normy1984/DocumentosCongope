import { ParamSessionMo } from "../param-session";

export class CertificacionMo {

    public sig_tip: string;
    public acu_tip: number;
    VarSesion!: ParamSessionMo; 
    
    constructor(datos: CertificacionMo) {
        {
            this.sig_tip = datos.sig_tip || '';
            this.acu_tip = datos.acu_tip || 0;
            this.VarSesion=datos.VarSesion; 
        }
    }
}

export class AprobCertificacionMo {

    public out_var_msg: string;
    
    constructor(datos: AprobCertificacionMo) {
        {
            this.out_var_msg = datos.out_var_msg || '';
            
        }
    }
}
