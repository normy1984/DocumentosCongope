export class BotonesMo {

    public aprobar: number;
    public desaprobar: number;
    public anular: number;
    public liquidar: number;
    public duplicar: number;
    public distribuir: number;
    public carchivos: number;
    public asociado: number;

	 constructor(datos: BotonesMo) {
        {
		this.aprobar = datos.aprobar || 1;
        this.desaprobar = datos.desaprobar || 1;
        this.anular = datos.anular || 1;
        this.liquidar = datos.liquidar || 1;
        this.duplicar = datos.duplicar || 1;
        this.distribuir = datos.distribuir || 1;
        this.carchivos = datos.carchivos || 1;
        this.asociado = datos.asociado || 1;
        }
    }
}