import { ParamSessionMo } from "../param-session";

export class CertificacionesSinAfeCabMO {

    out_documento:string;
    sig_acu_tip:string;
    fecha:string;
    descripcion:string;
    valor:number;
    VarSesion!: ParamSessionMo; 
  
    constructor(datos: CertificacionesSinAfeCabMO) {
        {
            this.out_documento = datos.out_documento || '';
            this.sig_acu_tip = datos.sig_acu_tip || '';
            this.fecha = datos.fecha || '';
            this.descripcion = datos.descripcion || '';
            this.valor = datos.valor || 0;     
            this.VarSesion=datos.VarSesion;    
        }
    }
  }