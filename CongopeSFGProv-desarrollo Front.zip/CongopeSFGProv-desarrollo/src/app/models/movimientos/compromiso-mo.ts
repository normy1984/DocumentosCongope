import { ParamSessionMo } from "../param-session";

export class CompromisoCabeceraMo {

    public sig_tip: string;
    public acu_tip: number;
    public num_com: string;
    public des_cab: string;
    public tot_deb: number;
    public tot_cre: number;
    public totinid: number;
    public totinic: number;
    public fec_asi: string;
    public fec_apr: string;
    public fec_anu: string;
    public estado: number;
    public periodo: number;
    public nropagos: number;
    public pagosre: number;
    public incremen: number;
    public comprom: number;
    public sig_tip1: string;
    public acu_tip1: number;
    public estadono: number;
    public liquida: number;
    public departam: number;
    public solicita: number;
    public cedruc: string;
    public tipopro: number;
    public retfte: number;
    public retiva: number;
    public cur: string;
    public pagado: number;
    public recaudad: number;
    public sig_tipce: string;
    public acu_tipce: number;
    public cod_proceso: string;
    public arrastre: number;
    public tipo_contrato: number;
    public admin_contrato: string;
    public valor_contrato: number;
    public observacion: string;
    public desagrupar: number;
    public sessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');;
    

    // acu_tip:number;
    constructor(datos: CompromisoCabeceraMo) {
        {
            this.sig_tip = datos.sig_tip || '';
            this.acu_tip = datos.acu_tip || 0;
            this.num_com = datos.num_com || '';
            this.des_cab = datos.des_cab || '';
            this.tot_deb = datos.tot_deb || 0;
            this.tot_cre = datos.tot_cre || 0;
            this.totinid = datos.totinid || 0;
            this.totinic = datos.totinic || 0;
            this.fec_asi = datos.fec_asi || '';
            this.fec_apr = datos.fec_apr || '';
            this.fec_anu = datos.fec_anu || '';
            this.estado = datos.estado || 0;
            this.periodo = datos.periodo || 0;
            this.nropagos = datos.nropagos || 0;
            this.pagosre = datos.pagosre || 0;
            this.incremen = datos.incremen || 0;
            this.comprom = datos.comprom || 0;
            this.sig_tip1 = datos.sig_tip1 || '';
            this.acu_tip1 = datos.acu_tip1 || 0;
            this.estadono = datos.estadono || 0;
            this.liquida = datos.liquida || 0;
            this.departam = datos.departam || 0;
            this.solicita = datos.solicita || 0;
            this.cedruc = datos.cedruc || '';
            this.tipopro = datos.tipopro || 0;
            this.retfte = datos.retfte || 0;
            this.retiva = datos.retiva || 0;
            this.cur = datos.cur || '';
            this.pagado = datos.pagado || 0;
            this.recaudad = datos.recaudad || 0;
            this.sig_tipce = datos.sig_tipce || '';
            this.acu_tipce = datos.acu_tipce || 0;
            this.cod_proceso = datos.cod_proceso || '';
            this.arrastre = datos.arrastre || 0;
            this.tipo_contrato = datos.tipo_contrato || 0;
            this.admin_contrato = datos.admin_contrato || '';
            this.valor_contrato = datos.valor_contrato || 0;
            this.observacion = datos.observacion || '';
            this.desagrupar = datos.desagrupar || 0;

        }
    }
}


export class CompromisoDetalleMo {

    public sig_tip: string;
    public acu_tip: number;
    public sec_det: number;
    public cuenta: string;
    public val_deb: number;
    public val_cre: number;
    public fec_det: string;
    public cod_cli: string;
    public fec_pos: string;
    public nroctac: string;
    public nro_che: number;
    public tip_com: number;
    public des_det: string;
    public estado: number;
    public periodo: number;
    public factura: string;
    public asociac: number;
    public devengad: number;
    public saldo: number;
    public pagado: number;
    public recaudad: number;
    public val_cert: number;
    public acu_tip_ce: number;
    public sessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');;
     

    constructor(datos: CompromisoDetalleMo) {
        {
            this.sig_tip = datos.sig_tip || '';
            this.acu_tip = datos.acu_tip || 0;
            this.sec_det = datos.sec_det || 0;
            this.cuenta = datos.cuenta || '';
            this.val_deb = datos.val_deb || 0;
            this.val_cre = datos.val_cre || 0;
            this.fec_det = datos.fec_det || '';
            this.cod_cli = datos.cod_cli || '';
            this.fec_pos = datos.fec_pos || '';
            this.nroctac = datos.nroctac || '';
            this.nro_che = datos.nro_che || 0;
            this.tip_com = datos.tip_com || 0;
            this.des_det = datos.des_det || '';
            this.estado = datos.estado || 0;
            this.periodo = datos.periodo || 0;
            this.factura = datos.factura || '';
            this.asociac = datos.asociac || 0;
            this.devengad = datos.devengad || 0;
            this.saldo = datos.saldo || 0;
            this.pagado = datos.pagado || 0;
            this.recaudad = datos.recaudad || 0;
            this.val_cert = datos.val_cert || 0;
            this.acu_tip_ce = datos.acu_tip_ce || 0;
            
     
        }
    }
}
