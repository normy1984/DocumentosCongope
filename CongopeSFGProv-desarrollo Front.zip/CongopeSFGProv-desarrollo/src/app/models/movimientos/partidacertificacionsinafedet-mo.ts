import { ParamSessionMo } from "../param-session";

export class PartidaCertificacionSinAfeDetMO {
    accion:string; 
    acutip: number; 
    partida: string; 
    VarSesion!: ParamSessionMo;    
    valor?:number;
    /**/

    constructor(datos: PartidaCertificacionSinAfeDetMO) {
        {
            this.accion=datos.accion||'';
            this.acutip=datos.acutip||0;
            this.partida=datos.partida||'';
            this.VarSesion=datos.VarSesion;  
            this.valor=datos.valor||0;
        }
    }
  }