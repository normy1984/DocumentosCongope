export class VerSaldoPartidaMO {

  codigo:number;
  concepto:string;
  monto:number;
  partida:string;
  nombre:string;
  constructor(datos: VerSaldoPartidaMO) {
      {
          this.codigo = datos.codigo || 0;
          this.concepto = datos.concepto || '';
          this.monto = datos.monto || 0;
          this.partida = datos.partida || '';
          this.nombre = datos.nombre || '';
      }
  }
}
