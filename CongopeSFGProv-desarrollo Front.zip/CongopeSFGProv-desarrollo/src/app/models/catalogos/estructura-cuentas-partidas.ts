import { ParamSessionMo } from "../param-session";

export interface EstructuraCuentasPartidasMo {

    Cuenta: string;
    Nom_cue: string;
    Ult_cue: number;
    Niv_cue: string;
    Totalhijos: number;
    Submenu: EstructuraCuentasPartidasMo[];
}

export class EstructuraPlanCuentasContabilidadMo {

    public cuenta: string;
    public nom_cue: string;
    public ult_cue: string;
    public niv_cue: number;
    public con_mov: number;
    public sal_deb: number;
    public sal_cre: number;
    public sal_inid: number;
    public sal_inic: number;
    public cod_p: number;
    public cod_h: number;
    public cuenta_p: string;
    public cre_por: string;
    public aux_cue: string;
    public ban_cue: string;
    public estado: number;
    public tipo_cue: number;
    public aso_pre: number;
    public tipocuec: number;
    public por_iva: number;
    public por_ret: number;
    public nivbal: number;
    public auxiliar: string;
    public renta: number;
    public ctapeaje: number;
    public ctatrans: number;
    public ruc: string;
    public ctapago: number;
    public ctapasateso: number;
    public cta_evol: number;
    public cta_repcom: number;
    public cta_iess: number;
    public cxc_iva_ret100_lrti: number;
    public nom_cue_p: string;
    public sessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');;

    constructor(datos: EstructuraPlanCuentasContabilidadMo) {
        {
            this.cuenta = datos.cuenta || '';
            this.nom_cue = datos.nom_cue || '';
            this.ult_cue = datos.ult_cue || '';
            this.niv_cue = datos.niv_cue || 0;
            this.con_mov = datos.con_mov || 0;
            this.sal_deb = datos.sal_deb || 0;
            this.sal_cre = datos.sal_cre || 0;
            this.sal_inid = datos.sal_inid || 0;
            this.sal_inic = datos.sal_inic || 0;
            this.cod_p = datos.cod_p || 0;
            this.cod_h = datos.cod_h || 0;
            this.cuenta_p = datos.cuenta_p || '';
            this.cre_por = datos.cre_por || '';
            this.aux_cue = datos.aux_cue || '';
            this.ban_cue = datos.ban_cue || '';
            this.estado = datos.estado || 0;
            this.tipo_cue = datos.tipo_cue || 0;
            this.aso_pre = datos.aso_pre || 0;
            this.tipocuec = datos.tipocuec || 0;
            this.por_iva = datos.por_iva || 0;
            this.por_ret = datos.por_ret || 0;
            this.nivbal = datos.nivbal || 0;
            this.auxiliar = datos.auxiliar || '';
            this.renta = datos.renta || 0;
            this.ctapeaje = datos.ctapeaje || 0;
            this.ctatrans = datos.ctatrans || 0;
            this.ruc = datos.ruc || '';
            this.ctapago = datos.ctapago || 0;
            this.ctapasateso = datos.ctapasateso || 0;
            this.cta_evol = datos.cta_evol || 0;
            this.cta_repcom = datos.cta_repcom || 0;
            this.cta_iess = datos.cta_iess || 0;
            this.cxc_iva_ret100_lrti = datos.cxc_iva_ret100_lrti || 0;
            this.nom_cue_p = datos.nom_cue_p || '';
        }
    }
}
export class IU_EstructuraPartidaCuentaMo {

    public cuenta: string;
    public identifi: number;
    public nom_cue: string;
    public ult_cue: string;
    public niv_cue: number;
    public cuenta_p: string;
    public sessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');;

    constructor(datos: IU_EstructuraPartidaCuentaMo) {
        this.cuenta = datos.cuenta || '';
        this.identifi = datos.identifi || 0;
        this.nom_cue = datos.nom_cue || '';
        this.ult_cue = datos.ult_cue || '';
        this.niv_cue = datos.niv_cue || 0;
        this.cuenta_p = datos.cuenta_p || '';

    }

}