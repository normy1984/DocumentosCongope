export class FuentesFinanciamientoDeleteMo {
    
    ffn_id:string;
    ffn_nombre:string;
    anio:number;
    codemp:string;
   
    constructor(datos: FuentesFinanciamientoDeleteMo) {
        {
            this.ffn_id = datos.ffn_id || '';
            this.ffn_nombre = datos.ffn_nombre || '';
            this.anio = datos.anio || 0;   
            this.codemp = datos.codemp || '';         
        }
    }
}