import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { configapp } from '@config/configapp';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { ParamSessionMo } from 'app/models/param-session';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-firmaelectronica-list',
    imports: [ListModule],
    templateUrl: './firmaelectronica-list.component.html'
})
export class FirmaelectronicaListComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  public ParamSessiones: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public nombreSistema: string = sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  // Inyecciones de servicios


  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);

  public usuarioConsulta: boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  // Configuración de la paginación
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource!: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  // Rutas de la API y navegación
  public pagina: string = "Procesos/FirmaElectronica";
  public rutaapi: string = "DocumentoBpm";

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService
  ) {
    super();
  }

  ngOnInit() {
    this.CargarGrid();
  }


  // Columnas mostradas en la tabla
  public displayedColumns: string[] = [
    "accion", "siglasnum",
    "descrip", "asignadoa", "fec_asi"
  ];
  /**
   * Función que genera la lista de datos para los grids de las pantallas.
   */
  CargarGrid() {


    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any = data.result;
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.sort = this.sort;
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * Función que dirige a la pantalla para el nuevo registro.
   */
  NuevoRegistro() {
    const numero = this.getRandomNumber();
     let parametro = this.ServicioCrypt.encryptString("NUEVO||CO" + numero);
    this.router.navigate(['/' + this.pagina, parametro]);
  }

  // FUNCION PARA GENERAR UN NUMERO RANDOMICO

  getRandomNumber(): number {
    return Math.floor(Math.random() * 9999) + 1;
  }

  /**
   * Función que envía los datos para editar un registro.
   * @param objeto Objeto de tipo MovimientosPresupuestariosMo que se va a editar.
   */
  EditarRegistro(objeto: String) {

    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + objeto);
    this.router.navigate(['/' + this.pagina, parametro]);
  }


  /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
  ImprimirReporte(fila: any) {
    const str_siglasnum = fila.siglasnum;
    const parts_siglasnum = str_siglasnum.split(" ");
    let DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT205_COMPROMISO";
    //DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
    DatosPdf.param1 = parts_siglasnum[0];
    DatosPdf.param2 = parts_siglasnum[1];

    this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });
  }


  /**
* Función que realiza los filtrados de los grids.
* @param event Evento de entrada del filtro.
*/
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
