import { JsonPipe } from '@angular/common';
import { Component, Input, mergeApplicationConfig, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ApiResultMo } from 'app/models/api-result-mo';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { SignalrService } from 'app/servicios/generico/signalr.service';
import { FormBuilder, FormsModule, UntypedFormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AuthService } from '@core';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { ParamSessionMo } from 'app/models/param-session';
import { EditModule } from 'app/paginas/generico/edit.module';
import { Router } from '@angular/router';


@Component({
    selector: 'app-firmaelectronica',
    imports: [ListModule, FormsModule, EditModule],
    templateUrl: './firmaelectronica.component.html'
})
export class FirmaelectronicaComponent
  extends UnsubscribeOnDestroyAdapter implements OnInit {
  @Input('param') param!: string;
  public FormularioDatos!: UntypedFormGroup;
  public ocultar_documento: boolean = true;
  public ocultar_firma: boolean = true;
  public nombreSistema: string = sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public VarSesion: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')

  public rutaapi: string = "Bpm";
  public pagina: string = "Procesos/FirmaElectronica";

  /**BOTONES PARA LAS FIRMAS Y APROBACIONES */
  public IniciarProceso: boolean = false;
  public CreaDocumento: boolean = false;
  public EnviaRevision: boolean = false;
  public RevisaDocumento: boolean = false;
  public VerFirma: boolean = false;
  public VerPdf: boolean = true;

  /** ASIGNADO A Y ESTADO ACTUAL */
  public AsignadoA: boolean = false;
  public DocumentoId: string = "CO310";
  public EstadoDocumento: string = "";

  public NombreDocumento: number = 123456;
  public TareaId: string = "";
  public ProcesoId: string = "";

  public documento_pdf: any;


  usuario = '';
  mensaje = '';
  mensajesistema = '';


  public usuarioActual = this.authService.currentUserValue?.username;



  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService,
    public dialog: MatDialog,
    private signalRService: SignalrService,
    private authService: AuthService,
    private ServicioCrypt: CryptService,
    public formBuild: FormBuilder,
  ) {

    super();
    this.FormularioDatos = this.CrearFormulario();
  }

  ngOnInit(): void {
    let datos = this.ServicioCrypt.decryptString(this.param);
    
    let arrayResultado = datos.split('||');

    this.DocumentoId = arrayResultado[1];
    if (arrayResultado[0] === "EDITAR") {

      this.ObtenerIdProceso();

      this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
      this.ObtenerDocumentoBase64();
    }
    else{
      this.IniciarProceso = true;
      this.VerPdf = false;
    }

          this.EsperarMensaje();
  }


  /**
   * Funcion que crea el formulario
   * @returns 
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      username: ['1712928272'],
      analista: ['0401030523001'],
      director: ['1715490148001'],
      coordinador: ['1725648545001']
    });
  }

  ObtenerIdProceso() {
    const rutaapi_temp = this.rutaapi + "/" + this.DocumentoId.toString() + "?Anio=" + this.VarSesion.anio;
    this.ServicioClienteHttp.SeteoRuta(rutaapi_temp);

    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any = data.result;
          this.ProcesoId = resultado.processInstanceId;
          this.mensajesistema += "Proceso Id:" + this.ProcesoId;
          this.ObtenerTareaProceso();
        }
        else {
          this.mensajesistema += "Proceso sin inicio" + this.ProcesoId;
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  //Obtener el estado del documento

  ObtenerTareaProceso(): void {
    const rutaapi_temp = this.rutaapi + "/TareasDocumento/" + this.ProcesoId.toString();
    this.ServicioClienteHttp.SeteoRuta(rutaapi_temp);

    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any = data.result;
          this.EstadoDocumento = resultado[0].taskDefinitionKey;
          this.AsignadoA = resultado[0].assignee;
          this.TareaId = resultado[0].id;
          this.mensajesistema += "\n Estado Documento:" + this.EstadoDocumento;
          this.mensajesistema += " - AsignadoA:" + this.AsignadoA;
          this.mensajesistema += " - Tarea Id:" + this.TareaId;
          this.EstadoBotones();
        }
        else {
          this.resetBotones();
        }



      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  enviar() {
    //this.signalRService.enviarMensaje(this.usuario, this.mensaje);
  }

  private resetBotones() {
    this.VerPdf = true;
    this.IniciarProceso = false;
    this.CreaDocumento = false;
    this.EnviaRevision = false;
    this.RevisaDocumento = false;
    this.VerFirma = false;
  }

  EstadoBotones() {
    // Si el usuario no es el asignado, desactiva todo
    if (this.usuarioActual?.toString() !== this.AsignadoA.toString()) {
      this.resetBotones();
      return;
    }

    // Estado inicial (todo en false)
    this.resetBotones();

    // Activa solo según el estado del documento
    switch (this.EstadoDocumento) {
      case "CreaDocumento":
        this.CreaDocumento = true;
        break;

      case "EnviaRevision":
        this.EnviaRevision = true;
        break;

      case "RevisaDocumento":
        this.RevisaDocumento = true;
        break;

      case "FirmaAnalista":
      case "FirmaDirector":
      case "FirmaCoordinador":
        this.VerFirma = true;
        break;
    }
  }

  IniciarFlujoFirma(): void {
    const rutaapi_temp = this.rutaapi + "/IniciarBpm";
    this.ServicioClienteHttp.SeteoRuta(rutaapi_temp);


    // VARIABLES PARA EL INICIO DE LA SESION
    const VariablesInicio =
    {
      creador: this.FormularioDatos.get('analista')?.value,
      aprobadorN1: this.FormularioDatos.get('director')?.value,
      aprobadorN2: this.FormularioDatos.get('coordinador')?.value,
      idDocumento: this.DocumentoId
    }

    // VARIABLES DEL DOCUMENTO QUE SE ESTA CREANDO
    let DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "FIRMA_RPT207_COMPROMISOS";
    DatosPdf.param3 = this.DocumentoId;

    const Objetos = { VariablesInicio, DatosPdf };

    ///RECIBE LOS DOS OBJETOS

    this.ServicioClienteHttp.Insertar(Objetos).subscribe({
      next: (data) => {
        if (!data.success) {
          console.log(data.message);
        }

      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  CompletarTarea(valAprobado: boolean): void {
    const rutaapi_temp = this.rutaapi + "/CompletarTarea";
    this.ServicioClienteHttp.SeteoRuta(rutaapi_temp);

    const TareaCompletada =
    {
      TaskId: this.TareaId,
      ProcessId: this.ProcesoId,
      Aprobado: valAprobado
    }

    this.ServicioClienteHttp.Insertar(TareaCompletada).subscribe({
      next: (data) => {
        if (!data.success) {
          console.log(data.message);
        }

      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }


  EsperarMensaje(): void {

    // se conecta para esperar el mensaje
    this.signalRService.iniciarConexion();
    // Se suscribe al evento para recibir el mensaje
    this.signalRService.registrarEvento('DocumentoFirmado')
      .subscribe(data => {

        if (this.DocumentoId === data.result.documento) {
          this.ProcesoId = data.result.processId;
          this.ObtenerTareaProceso();
          this.ObtenerDocumentoBase64();
        }

      });
  }




  FirmarElectronicamente(): void {
    const InformacionFirma = {
      "cedula": this.FormularioDatos.get('username')?.value
    };

    const filtro = {
      "Referencia": this.DocumentoId,
    };

    const Objetos = { InformacionFirma, filtro };

    this.ServicioClienteHttp.SeteoRuta("FirmaEc/CargaArchivoFirma");
    this.ServicioClienteHttp.Insertar(Objetos, true).subscribe({
      next: (data) => {
        if (data.success) {

          const firmaecUrl = data.result;
          window.location.href = firmaecUrl;
        } else {
          this.alertas.MensajeAlerta(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }


  /**
   * Método para obtener un documento en base64 desde el servidor
   */
  ObtenerDocumentoBase64(): void {
    // Definir el filtro con los parámetros necesarios para la consulta
    const filtro = {
      "Referencia": this.DocumentoId  // Referencia para la solicitud
    };

    // Establecer la ruta del servicio que se va a consumir
    this.ServicioClienteHttp.SeteoRuta("FirmaEc/ObtenerBase64");

    // Realizar la llamada HTTP para insertar los parámetros y obtener el documento
    this.ServicioClienteHttp.Insertar(filtro, true).subscribe({
      // Respuesta exitosa del servidor
      next: (data) => {
        // Ocultar o mostrar el documento según el resultado
        this.ocultar_documento = !data.success;

        // Si la operación fue exitosa
        if (data.success) {
          // Desestructurar el resultado para hacerlo más claro
          const { stringBase64, totalDocumentos } = data.result;

          // Crear un objeto ApiResultMo con los datos obtenidos
          const datos: ApiResultMo = {
            success: true,
            message: '',
            result: stringBase64  // El documento base64 obtenido del servidor
          };

          // Establecer que se puede mostrar la firma
          this.ocultar_firma = false;

          // Asignar los datos del documento junto con la nueva propiedad 'esfirma'
          this.documento_pdf = { ...datos, esfirma: true };

          // Si hay más de un documento, no ocultar la firma
          if (totalDocumentos === 1) {
            this.ocultar_firma = true;  // Ocultar firma si es solo un documento
          }


        } else {
          // Si la operación no fue exitosa, ocultar tanto el documento como la firma
          this.ocultar_documento = true;
          this.ocultar_firma = true;
        }
      },
      // Manejo de errores en caso de fallo en la llamada HTTP
      error: (err) => {
        console.error("Error al obtener el documento:", err.message);
        // Ocultar ambos elementos en caso de error
        this.ocultar_documento = true;
        this.ocultar_firma = true;
      }
    });
  }



  /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
  ImprimirDocumento() {
    const DatosPdf = this.documento_pdf;

    this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });
  }



  /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
  GenerarPdf() {
    //const str_siglasnum = fila.siglasnum;
    //const parts_siglasnum = str_siglasnum.split(" ");
    let DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "FIRMA_RPT207_COMPROMISOS";
    //DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
    //DatosPdf.param1=parts_siglasnum[0];
    //DatosPdf.param2=parts_siglasnum[1];
    DatosPdf.param3 = this.DocumentoId;
    const rutaapi: string = "Pdf";

    this.ServicioClienteHttp.SeteoRuta(rutaapi);
    this.ServicioClienteHttp.Insertar(DatosPdf, true).subscribe({
      next: (data) => {
        if (data.success) {
          this.ObtenerDocumentoBase64();
        } else {
          console.log(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
* Funcion que dirige a la pantalla para el nuevo registro
*/
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }

  override ngOnDestroy(): void {
    // primero llama al padre para que haga su limpieza
    super.ngOnDestroy();

    // luego tu código adicional (si lo necesitas)
    this.signalRService.desuscribirse('DocumentoFirmado');
    // Desconectar del hub
    this.signalRService.desconectar();
  }
}
