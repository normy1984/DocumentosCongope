import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr';
import { configapp } from '@config/configapp';
import { ApiResultMo } from 'app/models/api-result-mo';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {

  private hubConnection!: signalR.HubConnection;
  public UrlServicios: string = configapp.UrlServicios;
  public HubMensajes: string = configapp.hubMensajes;

  // Diccionario para almacenar Subjects por evento
  private subjects: { [evento: string]: Subject<any> } = {};


  constructor() { }

  // Inicializar conexión
  public iniciarConexion(): void {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(this.UrlServicios + this.HubMensajes, { withCredentials: false }) // tu backend
      .withAutomaticReconnect()
      .build();

    this.hubConnection.start()
      .then(() => console.log('Conectado a SignalR 🚀 Esperando respuesta'))
      .catch(err => console.error('Error de conexión:', err));

    // Evento: DocumentoFirmado
  }

  /** Registra un nuevo evento dinámico y retorna un Subject para suscribirse */
  public registrarEvento(evento: string): Subject<any> {
    if (!this.subjects[evento]) {
      const subject = new Subject<any>();
      this.subjects[evento] = subject;

      // Suscripción al hub
      this.hubConnection.on(evento, (data: any) => {
        subject.next(data);
      });
    }
    return this.subjects[evento];
  }

  /** Desuscribirse de un evento */
  public desuscribirse(evento: string): void {
    if (this.subjects[evento]) {
      this.hubConnection.off(evento); // Remueve la suscripción del hub
      this.subjects[evento].complete(); // Completa el Subject
      delete this.subjects[evento]; // Elimina del diccionario
    }
  }

  /** Desconectar del hub */
  public desconectar(): void {
    this.hubConnection.stop()
      .then(() => console.log('Desconectado de SignalR'))
      .catch(err => console.error('Error al desconectar:', err));
  }

  // Método para enviar mensajes al servidor
  public enviarMensaje(usuario: string, mensaje: string): void {
    this.hubConnection.invoke('EnviarMensaje', usuario, mensaje)
      .catch(err => console.error(err));
  }
}
