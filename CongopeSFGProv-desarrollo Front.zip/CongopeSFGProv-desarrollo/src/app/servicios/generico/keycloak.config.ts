import { configapp } from '@config/configapp';
import { KeycloakOnLoad, KeycloakPkceMethod } from 'keycloak-js';


export const keycloakConfig = {
  config: {
    url: configapp.Keycloack_url,
    realm: configapp.Keycloack_realm,
    clientId: configapp.Keycloack_clientid,
  },
  initOptions: {
    //onLoad:  'check-sso' as KeycloakOnLoad,
    onLoad:  'login-required' as KeycloakOnLoad,
    silentCheckSsoRedirectUri: window.location.origin + '/assets/silent-check-sso.html',
    checkLoginIframe: false,
    checkLoginIframeInterval: 0,
    //silentCheckSsoRedirectUri: '',
    pkceMethod: 'S256' as KeycloakPkceMethod,
    useNonce: false,
    enableLogging: true, // Para debugging
    responseMode: 'query' as const,
  },
  loadUserProfileAtStartUp: true,
  enableBearerInterceptor: true,
  bearerExcludedUrls: ['/assets', '/public']
};