import { Injectable } from '@angular/core';
import { EmpleadosMo } from 'app/models/catalogos/empleados-mo';
import { ClienthttpCongopeService } from '../generico/clienthttp-congope.service';
import { ApiResultMo } from 'app/models/api-result-mo';

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {

  private rutaapi: string = 'Empleados';


  constructor(
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) { }

/**
 * Funcion tipo promesa para traer los datos del empleado por codigo
 * @param cedruc 
 * @returns 
 */
  CargarEmpleadoPorCodigo(cedruc: string): Promise<ApiResultMo> {
    const EmpleadosPorCodigoMo = {
      Cedruc: cedruc,
      sessionMo: JSON.parse(
        sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'
      ),
    };

    this.ServicioClienteHttp.SeteoRuta(
      this.rutaapi + '/EmpleadoPersonalesPorCodigo'
    );
    return new Promise((resolve, reject) => {
      this.ServicioClienteHttp.Insertar(EmpleadosPorCodigoMo).subscribe({
        next: (data) => {
          resolve(data); // Aquí resuelves la promesa con el valor obtenido
        },
        error: (err) => {
          reject('Error: '+ err.message);
        },
      });
    });

  }

  /**
   * Funcion generica que trae los datos de las tablas generales
   * @param codtab
   * @returns
   */
  CargarTablasGenerales(codtab: string): Promise<any[]> {
    const TablasPorCodigo = {
      Cedruc: codtab,
      sessionMo: JSON.parse(
        sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'
      ),
    };
    this.ServicioClienteHttp.SeteoRuta(
      this.rutaapi + '/TablasGeneralesPorCodigo'
    );

    return new Promise((resolve, reject) => {
      this.ServicioClienteHttp.Insertar(TablasPorCodigo).subscribe({
        next: (data) => {
          if (data.success) {
            resolve(JSON.parse(data.result)); // Aquí resuelves la promesa con el valor obtenido
          } else {
            reject('Error: No regresaron datos');
          }
        },
        error: (err) => {
          reject(err.message); // En caso de error, rechazas la promesa
        },
      });
    });
  }

}
