import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CustomValidators {
  static nonEmpty(control: AbstractControl): ValidationErrors | null {
    const value = control.value?.trim();
    return value ? null : { nonEmpty: true };
  }

  static numbersOnly(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    const regex = /^[0-9]*$/;
    return regex.test(value) ? null : { numbersOnly: true };
  }
}