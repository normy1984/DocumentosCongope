declare global {
  interface JQuery<TElement = HTMLElement> {
    pivotUI(input: any, options?: any, overwrite?: boolean, locale?: string): JQuery;
  }
  interface JQueryStatic {
    pivotUtilities: any; // Aquí puedes especificar un tipo más preciso si tienes las definiciones exactas
  }
}

export {}; // Para convertir este archivo en un módulo