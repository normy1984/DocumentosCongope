import * as $ from 'jquery';

// Declara la ampliación de jQuery para incluir vectorMap
declare global {
  interface JQuery {
    vectorMap(options: JQvmapOptions): JQuery<HTMLElement>;
  }
}

interface JQvmapOptions {
  map: string;
  backgroundColor?: string;
  color?: string;
  hoverColor?: string;
  selectedColor?: string;
  enableZoom?: boolean;
  showTooltip?: boolean;
  onRegionClick?: (event: any, code: string, region: string) => void;
}

// En caso de que quieras que se exporte el vectorMap (aunque no es necesario)
/*declare module 'jqvmap' {
  export function vectorMap(options: JQvmapOptions): JQuery<HTMLElement>;
}
*/