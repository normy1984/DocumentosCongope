import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar'; // Importar el módulo
import { LoadingService } from '@core/service/loading.service';
import { LoadingBarModule } from '@ngx-loading-bar/core';


@Component({
    selector: 'app-page-loading',
    imports: [MatProgressBarModule, CommonModule, LoadingBarModule],
    templateUrl: './page-loading.component.html',
    styleUrl: './page-loading.component.scss'
})
export class PageLoadingComponent {

  loading$ = this.loadingService.loading$;

  constructor(private loadingService: LoadingService) {}

}


