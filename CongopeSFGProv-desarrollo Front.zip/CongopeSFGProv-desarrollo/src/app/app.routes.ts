import { Route } from '@angular/router';
import { MainLayoutComponent } from './layout/app-layout/main-layout/main-layout.component';
import { AuthGuard } from '@core/guard/auth.guard';
import { AuthLayoutComponent } from './layout/app-layout/auth-layout/auth-layout.component';
import { Page404Component } from './authentication/page404/page404.component';
import { InicioComponent } from './authentication/inicio/inicio.component';
import { CambiarContrasenaComponent } from './authentication/cambiar-contrasena/cambiar-contrasena.component';
import { configapp } from '@config/configapp';


let defaultRoute : Route;

if (configapp.Keycloack_login) {
  defaultRoute = { path: '', component: InicioComponent, canActivate: [AuthGuard] };
} else {
  defaultRoute = { path: '', redirectTo: '/authentication/signin', pathMatch: 'full' };
}


export const APP_ROUTE: Route[] = [
    {
        path: '',
        component: MainLayoutComponent,
        canActivate: [AuthGuard],
        children: [
            defaultRoute,
            { path: 'inicio', component: InicioComponent },
            { path: 'cambiarContrasena', component: CambiarContrasenaComponent },
            {
                path: 'Parametrizacion',
                loadChildren: () =>
                    import('./paginas/params/params.routes').then((m) => m.PARAMS_ROUTE),
            },
            {
                path: 'Catalogos',
                loadChildren: () =>
                    import('./paginas/catalogos/catalogos.routes').then((m) => m.CATALOGOS_ROUTE),

            },
            {

                path: 'Movimientos',
                loadChildren: () =>
                    import('./paginas/movimientos/movimientos.routes').then((m) => m.MOVIMIENTOS_ROUTE),
            },
            {
                path: 'Reportes',
                loadChildren: () =>
                    import('./paginas/reportes/reportes.routes').then((m) => m.REPORTES_ROUTE),
            },
            {

                path: 'administracion',
                loadChildren: () =>
                    import('./paginas/administracion/administracion.routes').then((m) => m.ADMINISTRACION_ROUTE),
            },
            {

                path: 'Procesos',
                loadChildren: () =>
                    import('./paginas/procesos/procesos.routes').then((m) => m.PROCESOS_ROUTE),
            },
            {
                path: 'Sistema',
                loadChildren: () =>
                import('./paginas/administracion/administracion.routes').then((m) => m.ADMINISTRACION_ROUTE),
          
            },
            {
                path: 'Datos Generales',
                loadChildren: () =>
                    import('./paginas/generico.routes').then((m) => m.GENERICO_ROUTE),
            }

        ],
    },
    {
        path: 'authentication',
        component: AuthLayoutComponent,
        loadChildren: () =>
            import('./authentication/auth.routes').then((m) => m.AUTH_ROUTE),
    },
    { path: '**', component: Page404Component },

];
