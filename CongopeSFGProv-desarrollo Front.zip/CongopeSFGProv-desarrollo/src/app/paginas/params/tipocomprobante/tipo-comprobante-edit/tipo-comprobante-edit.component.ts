import { Component, Input, inject } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { TipoComprobanteMo } from 'app/models/params/tipo-comprobante-mo';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';


@Component({
    selector: 'app-tipo-comprobante-edit',
    imports: [EditModule],
    templateUrl: './tipo-comprobante-edit.component.html'
})
export class TipoComprobanteEditComponent {
  @Input('param') param!: string;
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: string = "";
  objeto: any;
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
 

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */  
  public pagina: string = "Parametrizacion/TiposdeComprobantes";
  public rutaapi: string = "TipoComprobante";

  blankObject = {} as TipoComprobanteMo;
  ModeloDatos: TipoComprobanteMo = new TipoComprobanteMo(this.blankObject);

  constructor(
    private router: Router,
    public dialog: MatDialog) {
      this.FormularioDatos = this.CrearFormulario();
  }

  ngOnInit(): void {
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.CargarForm();
  }


  CargarForm():void{
    const Val_MovimientosPresupuestarios = {
      siglas_num: this.pk_identificador,
      VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    }
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"/PorCodigo");
    if (this.evento == "EDITAR") {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO";
      this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
        next: (data) => {
          if (data.success) {
            let result: any = data.result;
            this.ModeloDatos = new TipoComprobanteMo(result[0]);
            this.FormularioDatos = this.CrearFormulario();
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  }


  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      sigla: [{value: this.ModeloDatos.sigla, disabled: this.isReadOnly },[Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.maxLength(2)]],
      secuencia: [this.ModeloDatos.secuencia,[Validators.required]],
      descripcion: [this.ModeloDatos.descripcion, [Validators.required]],
      opcionPagado: [this.ModeloDatos.opcionPagado],
      comprobanteRol: [this.ModeloDatos.comprobanteRol],
      reiniciaSecuencia: [this.ModeloDatos.reiniciaSecuencia],
      comprobanteGarantia: [{value:this.ModeloDatos.comprobanteGarantia, disabled: this.isReadOnly}],
    });
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  GuardarInformacion() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    Swal.fire({
      title: "Esta seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        let datosGuardar = this.FormularioDatos.getRawValue();
        const objeto: TipoComprobanteMo = new TipoComprobanteMo(datosGuardar);

        if (this.pk_identificador == "-1") {
          this.ServicioClienteHttp.Insertar(objeto).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        } else {
          this.ServicioClienteHttp.Actualizar(this.pk_identificador, objeto).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        }

      }
    });
  }

  
}
