import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { TipocomprobanteListComponent } from "./tipocomprobante/tipocomprobante-list/tipocomprobante-list.component";
import { TipoComprobanteEditComponent } from "./tipocomprobante/tipo-comprobante-edit/tipo-comprobante-edit.component";
import { TablasGeneralesListComponent } from "./tablasgenerales/tablas-generales-list/tablas-generales-list.component";
import { TablasGeneralesDetalleListComponent } from "./tablasgeneralesdetalle/tablas-generales-detalle-list/tablas-generales-detalle-list.component";
import { DepartamentosListComponent } from "./tablasgeneralesdetalle/departamentos-list/departamentos-list.component";
import { DepartamentosEditComponent } from "./tablasgeneralesdetalle/departamentos-edit/departamentos-edit.component";
import { TablasGeneralesDetalleEditComponent } from "./tablasgeneralesdetalle/tablas-generales-detalle-edit/tablas-generales-detalle-edit.component";
import { EmpresasEditComponent } from "../administracion/empresas/empresas-edit/empresas-edit.component";
import { EstructuraPartidaComponent } from "./estructura-partida/estructura-partida.component";
import { ParametrosgeneralesListComponent } from "./parametrosgenerales-list/parametrosgenerales-list.component";

export const PARAMS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "dashboard1",
    pathMatch: "full",
  },
  {
    path: "tipocomprobante",
    component: TipocomprobanteListComponent,
  },
    {
    path: "tipocomprobante/:param",
    component: TipoComprobanteEditComponent,
  },
  {
    path: "TablasGenerales",
    component: TablasGeneralesListComponent,
  },
    {
    path: "TablasGenerales/:param",
    component: TablasGeneralesListComponent,
  },
  {
    path: "TablasGenerales/tablasgeneralesdetalle/:param",
    component: TablasGeneralesDetalleListComponent,
  },
  {
    path: "TablasGenerales/tablasgenerales_edetalle/:param",
    component: TablasGeneralesDetalleEditComponent,
  },
  {
    path: "TablasGenerales/tg_departamento/:param",
    component: DepartamentosListComponent,
  },
  {
    path: "TablasGenerales/tg_edepartamento/:param",
    component: DepartamentosEditComponent,
  },
  {
    path: "DatosdelaEmpresa",
    component: EmpresasEditComponent,
  
  },
  {
    path: "TablasGenerales/tg_edepartamento/:param",
    component: DepartamentosEditComponent,
  },
  {
    path: "DatosdelaEmpresa",
    component: EmpresasEditComponent,
  
  },
 
  {
    path: "TiposdeComprobantes",
    component: TipocomprobanteListComponent,
  
  },
  {
    path: "TiposdeComprobantes/:param",
    component: TipoComprobanteEditComponent,
  },
  {
    path: "EstructuraPartidadeGastos",
    component: EstructuraPartidaComponent,
  },
  {
    path: "EstructuraPartidadeIngresos",
    component: EstructuraPartidaComponent,
  },
  {
    path: "EstructuraPlandeCuentas",
    component: EstructuraPartidaComponent,
  },
  {
    path: "EstructuraCodigo",
    component: EstructuraPartidaComponent,
  },
  {
    path: "Parametros",
    component: ParametrosgeneralesListComponent,
  },
  
  { path: "**", component: Page404Component },
  
];

