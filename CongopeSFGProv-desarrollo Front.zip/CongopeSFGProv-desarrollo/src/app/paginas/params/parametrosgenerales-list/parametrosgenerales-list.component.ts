import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, FormsModule, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import Swal from 'sweetalert2'
import {MatRadioModule} from '@angular/material/radio';
import { _isNumberValue } from '@angular/cdk/coercion';
import { ParamSessionMo } from 'app/models/param-session';
import { ParametrosGeneralesMO } from 'app/models/params/parametrosgenerales-mo';

@Component({
    selector: 'app-parametrosgenerales-list',
    templateUrl: './parametrosgenerales-list.component.html',
    imports: [EditModule, ListModule, MatRadioModule, FormsModule
    ]
})


export class ParametrosgeneralesListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  
  public activardesactivar: boolean = false;
  public TxtDatoAdi: string = "";
  public nCodtab:number = 0 ;
  public nCodSistema:number = 0;
  checked = false;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */

public pagina:string = "Sistema/Configuracion";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "codigo",
  "descrip",
  "activo",
  "dato_adi",
];

public nivel: number = 0;

blankObjectDetalle = {} as ParametrosGeneralesMO;
ModeloDatos: ParametrosGeneralesMO = new ParametrosGeneralesMO(this.blankObjectDetalle);

constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nCodSistema = this.ParamSessiones.sistema;
    //15  PARAMETROS GENERALES
    //55 PARAMETROS NOMINA
    //94 PARAMETROS PRESUPUESTO

    if(this.ParamSessiones.sistema == 50){
      this.nCodtab = 15;
    }
    if(this.ParamSessiones.sistema == 2){
      this.nCodtab = 94;
    }
    if(this.ParamSessiones.sistema == 4){
      this.nCodtab = 55;
    }

    this.FormularioDatos = this.CrearFormulario();
    this.FiltrarAsociacion();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      codigo: [this.ModeloDatos.codigo],
      descrip: [this.ModeloDatos.descrip],
      activo: [this.ModeloDatos.activo],
      dato_adi: [this.ModeloDatos.dato_adi],
   });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
      }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({

      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {

    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  FiltrarAsociacion() {
    this.rutaapi = "ParametrosGenerales?nCodtab=" + this.nCodtab +" ";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
  }


  //RERPORTE
  ImprimirReporte(): void {
    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT223_CLASIFICADOR";
    DatosPdf.param1 = "sFechaHasta";
    DatosPdf.param2 = ""
    DatosPdf.param3 = "sPartida";
    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }

 ActivarParametro(datos: any) {
  console.log (datos);
  const ncodigo = datos.codigo;
  let sDatoadi = datos.dato_adi;

  // if(sDatoadi.trim.length === 0){
  //   alert(sDatoadi)
  // }


  let sMensajeActiva = "Activado";
  let sMensajeActivaDesac = "activar";
  let nActivaDesactiva = 1; 
  if(datos.activo == 1){
    sMensajeActivaDesac = "desactivar";
    sMensajeActiva = "Desactivado";
    nActivaDesactiva = 0;
    sDatoadi = "''";
    if(this.ParamSessiones.sistema == 50 && ncodigo == 36){
      sDatoadi = "15";
    }

    if(this.ParamSessiones.sistema == 4){
      if(ncodigo == 1){
        sDatoadi = "<=";
      }
      if(ncodigo == 2){
        sDatoadi = "22";
      }
      if(ncodigo == 11){
        sDatoadi = "2";
      }
      if(ncodigo == 12){
        sDatoadi = "28";
      }
    }
  }

  let sMensaje = "¿Está seguro de " + sMensajeActivaDesac +" el parámetro?";

  Swal.fire({
    title: sMensaje,
    showDenyButton: true,
    confirmButtonText: "Sí, " + sMensajeActivaDesac,
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.rutaapi = "ParametrosGenerales";
      this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/ActivarDesactivarParametro')
      this.ServicioClienteHttp.Actualizar(this.nCodtab +"," + ncodigo +"," + nActivaDesactiva +","+ sDatoadi +"").subscribe({
        next: (data) => { 
          if (data.success) {
            this.alertas.MensajeConTimer("Parámetro " +  sMensajeActiva + " existosamente!!", true);
            this.FiltrarAsociacion();
          }
          else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
    else{
      this.FiltrarAsociacion();
    }
  });
}

CheckChangeHandler(event: any){
  const isChecked = event.checked;
  this.activardesactivar = isChecked;
}

}



