import { Component, OnInit, ViewChild } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { FormsModule } from '@angular/forms';
import { EstructuraPartidaMO } from 'app/models/params/estructura-partida-mo';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';

import { ParamSessionMo } from 'app/models/param-session';

@Component({
    selector: 'app-estructura-partida',
    imports: [ListModule, MatRadioModule, EditModule, FormsModule],
    templateUrl: './estructura-partida.component.html',
    styleUrls: ['./estructura-partida.component.scss']
})
export class EstructuraPartidaComponent extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  public tituloOpcionAdicional: string = '';
  public tituloPagina: string = 'Estructura de Código';
  public identifi: number = 0;
  public isEditing: boolean = false;
  public EditarNombres: boolean = true;
  public OcultarEdit: boolean = true;
  public dataSource !: MatTableDataSource<any>;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  public rutaapi: string = "EstructuraPartida";
  public isValidItemAso: boolean = true;
  public displayedColumns: string[] = [];
  public ObjetoEstructura: EstructuraPartidaMO[] = [];
  public ComboItemAsociado: any[] = [];
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  


  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    public alertas: AlertasSrvService
  ) {
    super();
    const rutaActual = this.router.url;
    switch (this.paramSessionMo.sistema) {
      case 1:
        this.tituloPagina = "Estructura Plan de Cuentas";
        this.displayedColumns = this.ColumnasGenerales;
        this.tituloOpcionAdicional = 'ASOCIACIÓN';
        break;

      case 2:
        const esGastos = rutaActual && rutaActual.includes('Gastos');
        this.tituloPagina = esGastos ? "Estructura Partida de Gastos" : "Estructura Partida de Ingresos";
        this.identifi = esGastos ? 1 : 2;
        this.displayedColumns = esGastos ? this.ColumnasGastos : this.ColumnasIngresos;
        this.ComboItemAsociado = esGastos ? this.ComboItemAsociado_Gasto : this.ComboItemAsociado_Ingreso;
        this.tituloOpcionAdicional = 'NIVEL PROYECTO';
        this.ValidarGprd().then((result) => {
          this.EditarNombres = !result;
        }).catch((error) => {
          console.log('Error:', error);
        });
        break;

      case 4:
        this.displayedColumns = this.ColumnasNomina;
      break;
      case 3:
      case 5:
        this.displayedColumns = this.ColumnasGenerales;
        this.tituloOpcionAdicional = 'ITEM ASOCIADO';
        break;
    }
  }

  ngOnInit() {
    this.CargarGrid();

    this.ValidarMovimientos().then((result) => {
      this.OcultarEdit = result;
    }).catch((error) => {
      console.log('Error:', error);
    });

  }


  /**COLUMNAS MOSTRADAS PARA GASTOS*/
  private ColumnasGastos: string[] = [
    "niv_est",
    "des_est",
    "lon_est",
    "item_aso",
    "foce",
    "orienta_gas",
    "niv_ug",
    "con_est",
    "niv_proy"];


  /**COLUMNAS MOSTRADAS PARA INGRESOS*/
  private ColumnasIngresos: string[] = [
    "niv_est",
    "des_est",
    "lon_est",
    "item_aso",
  ];

  /**COLUMNAS MOSTRADAS PARA INGRESOS*/
  private ColumnasNomina: string[] = [
    "niv_est",
    "des_est",
    "lon_est",
  ];

  /**COLUMNAS MOSTRADAS PARA INGRESOS*/
  private ColumnasGenerales: string[] = [
    "niv_est",
    "des_est",
    "lon_est",
    "niv_proy",
  ];

  public ComboOrientaGasto: any[] = [
    { codigo: 0, descripcion: "" },
    { codigo: 1, descripcion: "ORIENTACIÓN DEL GASTO" },
    { codigo: 2, descripcion: "DIRECCIONAMIENTO DEL GASTO" },
    { codigo: 3, descripcion: "CATEGORÍA" },
    { codigo: 4, descripcion: "SUBCATEGORÍA" },
  ];
  // Función para obtener la descripción basada en el valor de row.foce
  getOrientaGastoDescription(codigo: number): string {
    const found = this.ComboOrientaGasto.find(combo => combo.codigo === codigo);
    return found ? found.descripcion : '';
  }


  public ComboFOCE: any[] = [
    { codigo: 0, descripcion: "" },
    { codigo: 1, descripcion: "FUENTE" },
    { codigo: 2, descripcion: "ORGANISMO" },
    { codigo: 3, descripcion: "CORRELATIVO" },
    { codigo: 4, descripcion: "ECONÓMICO" },
  ];

  // Función para obtener la descripción basada en el valor de row.foce
  getFoceDescription(codigo: number): string {
    const found = this.ComboFOCE.find(combo => combo.codigo === codigo);
    return found ? found.descripcion : '';
  }

  public ComboItemAsociado_Gasto: any[] = [
    { codigo: 0, descripcion: "" },
    { codigo: 1, descripcion: "GRUPO" },
    { codigo: 2, descripcion: "SUBGRUPO" },
    { codigo: 3, descripcion: "ITEM" },
    { codigo: 80, descripcion: "ACTIVIDAD" },
    { codigo: 91, descripcion: "FUENTE DE FINANCIAMIENTO" },
  ];

  public ComboItemAsociado_Ingreso: any[] = [
    { codigo: 0, descripcion: "" },
    { codigo: 1, descripcion: "GRUPO" },
    { codigo: 2, descripcion: "SUBGRUPO" },
    { codigo: 3, descripcion: "ITEM" },
  ];


  // Función para obtener la descripción basada en el valor de row.foce
  getItemAsociadoDescription(codigo: number): string {
    const found = this.ComboItemAsociado.find(combo => combo.codigo === codigo);
    return found ? found.descripcion : '';
  }



  /**
   * FUNCION PARA CARGAR EL GRID EN LA PANTALLA
   */
  CargarGrid() {
    const Sel_EstructuraPartidaMo = {
      sessionMo: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'),
      identifi: this.identifi // Asignar el valor de tipo a la propiedad liquidar
    };

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ListarEstructura");
    this.ServicioClienteHttp.Insertar(Sel_EstructuraPartidaMo).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: EstructuraPartidaMO[] = JSON.parse(data.result);
          this.ObjetoEstructura = resultado.map(element => {
            let nuevoDetalle = new EstructuraPartidaMO(element); // Suponiendo que el constructor de CompromisoDetalleMo acepta un objeto como parámetro
            nuevoDetalle.identifi = this.identifi;
            return nuevoDetalle;
          });
          this.dataSource = new MatTableDataSource<EstructuraPartidaMO>(this.ObjetoEstructura);
        }
        else {
          this.dataSource = new MatTableDataSource<EstructuraPartidaMO>([]);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  /**
    * 
    * @param event Funcion que realiza los fitrados de los grids
    */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  /**
   * Inicia el modo de edición para un elemento del grid.
   * @param element El elemento a editar.
   */
  iniciaEditList(): void {
    //this.editedElement = element;
    this.isEditing = true; // Indicar que estamos en modo edición
  }

  /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
  finEditList(): void {
    let ValidacionIngresos = true;
    let Contador: number = 1;
    let Errores: number[] = [];

    this.dataSource.data.forEach(row => {
      if (row.lon_est === null || row.lon_est > 15 || row.lon_est === 0) {
        ValidacionIngresos = false;
      }
      if (row.des_est.trim() === "") {
        ValidacionIngresos = false;
      }

      if (!ValidacionIngresos) {
        Errores.push(Contador);
      }
      Contador++;
    });

    if (!ValidacionIngresos) {
      this.alertas.MensajeError("La descripción o longitud de los niveles " + Errores.slice() + " están incorrectos!!");
    }
    else {
      this.isEditing = false; // Finaliza el modo edición
      this.GuardarRegistros();
    }
  }

  /**
   * FUNCION QUE CANCELA LA EDICION DE LOS REGISTROS
   */
  CancelarEditList(): void {
    this.isEditing = false; // Finaliza el modo edición
    this.CargarGrid();
  }


  /**
   * FUNCION QUE PERMITE LA EDICION DE LA COLUMNA ITEM ASOCIADO
   * @param element 
   */
  EditItemAsociado(element: any): void {
    let valor = element.item_aso;
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.item_aso = valor; // Actualiza el nivel de proyecto del elemento seleccionado
      } else if (item.item_aso === valor) {
        item.item_aso = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });

    this.CargarDatosGrid();
  }

  /**
   * FUNCION QUE PERMITE LA EDICION DE LA COLUMNA NIVEL FOCE DE LA OPCION DE GASTOS
   * @param element 
   */
  EditNivelFoce(element: any): void {
    let valor = element.foce;
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.foce = valor; // Actualiza el nivel de proyecto del elemento seleccionado
      } else if (item.foce === valor) {
        item.foce = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });
    this.CargarDatosGrid();
  }

  /**
   * FUNCION QUE PERMITE LA EDICION DE LA OPCION DE ORIENTADORES DE GASTO
   * @param element 
   */
  EditOrientadorGasto(element: any): void {
    let valor = element.orienta_gas;
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.orienta_gas = valor; // Actualiza el nivel de proyecto del elemento seleccionado
      } else if (item.orienta_gas === valor) {
        item.orienta_gas = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });
    this.CargarDatosGrid();
  }


  /**
   * FUNCION QUE PERMITE LA EDICION DE LA OPCIN DE UNIDAD DE GESTION
   * @param element 
   */
  EditUnidadGestion(element: any): void {
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.niv_ug = 1; // Actualiza el nivel de proyecto del elemento seleccionado
      } else {
        item.niv_ug = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });
    this.CargarDatosGrid();
  }


  /**
   * FUNCION QUE PERMITE LA EDICION DE LA PAGINA DE NIVEL DE COMPETENCIA
   * @param element 
   */
  EditNivelCompetencia(element: any): void {
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.con_est = 1; // Actualiza el nivel de proyecto del elemento seleccionado
      } else {
        item.con_est = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });
    this.CargarDatosGrid();
  }

  /**
   * FUNCION QUE PERMITE LA EDICION DE LA COLUMNA NIVEL DE PROYECTO
   * @param element 
   */

  EditNivelProyecto(element: any): void {
    this.ObjetoEstructura.forEach(item => {
      if (item === element) {
        item.niv_proy = 1; // Actualiza el nivel de proyecto del elemento seleccionado
      } else {
        item.niv_proy = 0; // Restaura el nivel de proyecto de otros elementos
      }
    });

    this.CargarDatosGrid();
  }

  /**
   * FUNCION QUE PERMITE AGREGAR UNA FILA AL FINAL PARA CREAR UNA NUEVA ESTRUCTURA
   */
  AgregarNivel() {

    let datosFiltrados = this.ObjetoEstructura.filter(item => item.estado === 1);

    if (this.ObjetoEstructura.length > datosFiltrados.length) {
      // Cambiar el campo 'estado' de la última fila a 0
      let ultimaFila = this.ObjetoEstructura[datosFiltrados.length];
      ultimaFila.estado = 1;
    }
    else {
      let nuevoRegistro = new EstructuraPartidaMO({} as EstructuraPartidaMO);
      nuevoRegistro.niv_est = this.dataSource.data.length + 1;
      nuevoRegistro.identifi = this.identifi;
      this.ObjetoEstructura.push(nuevoRegistro);
    }
    // Agrega el nuevo registro a la dataSource
    this.CargarDatosGrid();
  }


  /**
   * FUNCION QUE PERMITE EL BORRADO DE LA ULTIMA FILA PARA PODER ELIMINAR EL REGISTRO
   */
  QuitarNivel() {
    // Obtener los datos actuales
    let datosFiltrados = this.ObjetoEstructura.filter(item => item.estado === 1);

    // Verificar que hay datos en el array
    if (this.ObjetoEstructura.length > 0) {
      // Cambiar el campo 'estado' de la última fila a 0
      const ultimaFila = this.ObjetoEstructura[datosFiltrados.length - 1];
      ultimaFila.estado = 0;
    }

    this.CargarDatosGrid();

  }


  /***
   * FUNCION QUE SE UTILIZA PARA GUARDAR LOS REGISTROS EN LA BASE DE DATOS
   */
  GuardarRegistros() {

    /// GARANTIZO DE QUE EL OBJETO NO ME VAYA CON ERRORES
    this.ObjetoEstructura.forEach(row => {
      if (row.lon_est === null) {
        row.lon_est = 0;
      }
    });

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/InsertarActualizarEstructura");
    this.ServicioClienteHttp.Insertar(this.ObjetoEstructura).subscribe({
      next: (data) => {
        if (data.success) {
          this.alertas.MensajeConTimer("Estructura Guardada Exitosamente!!", true);
          this.CargarGrid();
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * FUNCION QUE ACTUALIZA LOS DATOS QUE SE MUESTRAN EN EL GRID PARA LA EDICION
   */
  CargarDatosGrid() {
    let datosFiltrados = this.ObjetoEstructura.filter(item => item.estado === 1);
    this.dataSource = new MatTableDataSource<EstructuraPartidaMO>(datosFiltrados);
  }

  /***
   * ESTA FUNCION VALIDA QUE LOS DATOS SI YA FUERON CARGADOS DESDE EL GPRD NO PERMITA MODIFICAR LOS NIVELES, LA DESCRIPCION O LONGITUD DEL CAMPO
   */
  ValidarGprd(): Promise<boolean> {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ValidaGprd");
    return new Promise((resolve, reject) => {
      this.ServicioClienteHttp.Insertar(this.paramSessionMo).subscribe({
        next: (data) => {
          if (data.success) {
            resolve(data.result[0].validacion); // Devuelve el resultado si data.success es true
          } else {
            resolve(true); // Devuelve true si data.success es false
          }
        },
        error: (err) => {
          reject(err); // Rechaza el Promise en caso de error
        }
      });
    });
  }


  /**
   * FUNCION QUE VALIDA SI EXISTE MOVIMIENTOS NO PERMITA VISUALIZAR LOS BOTONES DE EDICION
   * @returns 
   */

  ValidarMovimientos(): Promise<boolean> {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ValidaHayMovimientos");
    return new Promise((resolve, reject) => {
      this.ServicioClienteHttp.Insertar(this.paramSessionMo).subscribe({
        next: (data) => {
          if (data.success) {
            resolve(data.result[0].validacion); // Devuelve el resultado si data.success es true
          } else {
            resolve(true); // Devuelve true si data.success es false
          }
        },
        error: (err) => {
          reject(err); // Rechaza el Promise en caso de error
        }
      });
    });
  }
}
