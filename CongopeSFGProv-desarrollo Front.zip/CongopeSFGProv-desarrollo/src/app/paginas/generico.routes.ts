import { Route } from "@angular/router";
import { Page404Component } from "app/authentication/page404/page404.component";
import { UsuariosListComponent } from "./administracion/usuarios/usuarios-list/usuarios-list.component";
import { UsuariosEditComponent } from "./administracion/usuarios/usuarios-edit/usuarios-edit.component";
import { EmpresasEditComponent } from "./administracion/empresas/empresas-edit/empresas-edit.component";
import { TablasGeneralesListComponent } from "./params/tablasgenerales/tablas-generales-list/tablas-generales-list.component";
import { TablasGeneralesDetalleListComponent } from "./params/tablasgeneralesdetalle/tablas-generales-detalle-list/tablas-generales-detalle-list.component";
import { TablasGeneralesDetalleEditComponent } from "./params/tablasgeneralesdetalle/tablas-generales-detalle-edit/tablas-generales-detalle-edit.component";
import { DepartamentosListComponent } from "./params/tablasgeneralesdetalle/departamentos-list/departamentos-list.component";
import { DepartamentosEditComponent } from "./params/tablasgeneralesdetalle/departamentos-edit/departamentos-edit.component";
import { ListaCiuListComponent } from "./generico/lista-ciu-list/lista-ciu-list.component";
import { ListaCiuEditComponent } from "./generico/lista-ciu-edit/lista-ciu-edit.component";
import { UsuariosNuevoComponent } from "./administracion/usuarios/usuarios-nuevo/usuarios-nuevo.component";
import { ParametrosgeneralesListComponent } from "./params/parametrosgenerales-list/parametrosgenerales-list.component";

export const GENERICO_ROUTE: Route[] = [
  {
    path: "AdministraciondeUsuarios",
    component: UsuariosListComponent,
  },
  {
    path: "AdministraciondeUsuarios/usuariosNuevo",
    component: UsuariosNuevoComponent,
  },
    {
    path: "AdministraciondeUsuarios/:param",
    component: UsuariosEditComponent,
  },
  {
    path: "Empresa",
    component: EmpresasEditComponent,
  },
  {
    path: "TablasGenerales",
    component: TablasGeneralesListComponent,
  },
  {
    path: "TablasGenerales/:param",
    component: TablasGeneralesListComponent,
  },
  {
    path: "TablasGenerales/tablasgeneralesdetalle/:param",
    component: TablasGeneralesDetalleListComponent,
  },
  {
    path: "TablasGenerales/tablasgenerales_edetalle/:param",
    component: TablasGeneralesDetalleEditComponent,
  },
  {
    path: "TablasGenerales/tg_departamento/:param",
    component: DepartamentosListComponent,
  },
  {
    path: "TablasGenerales/tg_edepartamento/:param",
    component: DepartamentosEditComponent,
  },
  {
    path: "CodigodeIdentificacionUnica",
    component: ListaCiuListComponent,
  },
  {
    path: "CodigodeIdentificacionUnica/:param",
    component: ListaCiuEditComponent,

  },
  {
    path: "Configuracion",
    component: ParametrosgeneralesListComponent,
  },
  { path: "**", component: Page404Component },

];

