import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { CargarPresupuestoComponent } from "./cargar-presupuesto/cargar-presupuesto.component";
import { FirmaelectronicaListComponent } from "app/ejemplo/firmaelectronica-list/firmaelectronica-list.component";
import { FirmaelectronicaComponent } from "app/ejemplo/firmaelectronica/firmaelectronica.component";


export const PROCESOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "inicio",
    pathMatch: "full",
  },
  {
    path: "CargarPresupuesto",
    component: CargarPresupuestoComponent,
  },
  {
    path: "FirmaElectronica",
    component: FirmaelectronicaListComponent,
  },
  {
    path: "FirmaElectronica/:param",
    component: FirmaelectronicaComponent,
  },

  { path: "**", component: Page404Component },

];

