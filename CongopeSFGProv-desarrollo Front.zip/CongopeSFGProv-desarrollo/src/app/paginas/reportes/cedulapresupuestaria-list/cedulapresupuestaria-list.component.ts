import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { VersaldopartidaListComponent } from '../versaldopartida-list/versaldopartida-list.component';
import { MatRadioModule } from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';
import { ApexchartComponent } from '../cedulapresupuestaria-chart/apexchart.component';


@Component({
    selector: 'app-cedulapresupuestaria-list',
    templateUrl: './cedulapresupuestaria-list.component.html',
    imports: [EditModule, ListModule, MatRadioModule
    ]
})

export class CedulapresupuestariaListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public nTipoPresupuesto = 1;
  public tot_asig_ini = 0;
  public tot_reformas = 0;
  public tot_codificado = 0;
  public tot_certificado = 0;
  public tot_certificado_real = 0;
  public tot_comprometido = 0;
  public tot_devengado = 0;
  public tot_por_comprometer = 0;
  public tot_por_comprometer_real = 0;
  public tot_por_devengar = 0;
  public tot_comprometido_mes = 0;
  public tot_devengado_mes = 0;
  public tot_recaudado = 0;
  public tot_pagado = 0;
  public tot_anticipo = 0;
  public sUltimoNivel = "";

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('Cmbnivel01') Cmbnivel01!: ElementRef<HTMLInputElement>;


/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/CedulaPresupuestaria";
public rutaapi:string = "CedulaPresupuestaria?codemp=0004&fecha_hasta=" + this.fechaAct +"&ing_gas=1&nTodos=0&nNivel=20&sOperador=%3C%3D";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "niv_cue",
  "partida",
  "nombre",
  "asig_ini",
  "reformas",
  "codificado",
  "comprometido",
  "devengado",
  "por_comprometer_real",
  "por_devengar",
  "pagado",
  "versaldo",
];

public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public EstructuraNivelesIngresos!: any[];
public OpcionesNivelesIngresos!: any[];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {

    const ffecha = new Date(this.fechaAct);
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }

    this.rutaapi = "CedulaPresupuestaria?codemp=0004&fecha_hasta=" + this.fechaAct +"&ing_gas=1&nTodos=0&nNivel=20&sOperador=%3C%3D";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
    this.CargarNivelesGastos(this.nTipoPresupuesto);
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Opting: 1,
      Txtpartida:"",
      Txtfecha: this.fechaAct,
      Cmbnivel01: ["",[Validators.required]],
      Chktodos:0,
      Cmdoperador:"1",
    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.tot_asig_ini = this.resultado[0].tot_asig_ini;
          this.tot_reformas = this.resultado[0].tot_reformas;
          this.tot_codificado = this.resultado[0].tot_codificado;
          this.tot_certificado = this.resultado[0].tot_certificado;
          this.tot_certificado_real = this.resultado[0].tot_certificado_real;
          this.tot_comprometido = this.resultado[0].tot_comprometido;
          this.tot_devengado = this.resultado[0].tot_devengado;
          this.tot_por_comprometer = this.resultado[0].tot_por_comprometer;
          this.tot_por_comprometer_real = this.resultado[0].tot_por_comprometer_real;
          this.tot_por_devengar = this.resultado[0].tot_por_devengar;
          this.tot_comprometido_mes = this.resultado[0].tot_comprometido_mes;
          this.tot_devengado_mes = this.resultado[0].tot_devengado_mes;
          this.tot_recaudado = this.resultado[0].tot_recaudado;
          this.tot_pagado = this.resultado[0].tot_pagado;
          this.tot_anticipo= this.resultado[0].tot_anticipo;

          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'PARTIDA': x.partida,
        'DESCRIPCION': x.nombre,
        'ASIG. INICIAL': x.asig_ini,
        'REFORMAS': x.reformas,
        'CODIFICADO': x.codificado,
        'COMPROMETIDO': x.comprometido,
        'DEVENGADO': x.devengado,
        'POR COMPROMETER': x.por_comprometer_real,
        'POR DEVENGAR': x.por_devengar,
        'PAGADO': x.pagado,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  FiltrarCedula() {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel;
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }
    const sPartida = this.FormularioDatos.get('Txtpartida')?.value;
    if(nNivel == 0){
      this.alertas.MensajeError("Debe seleccionar el nivel");
      return;
    }
    this.rutaapi = "CedulaPresupuestaria?codemp=0004&fecha_hasta=" + sFechaHasta +"&ing_gas=" + this.nTipoPresupuesto +"&nTodos=" + nVerTodos +"&nNivel=" + nNivel +"&sOperador="+ sOperador +"&spartida="+sPartida+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid();
  }

  radioChangeHandler(value: any){
    this.nTipoPresupuesto = value;
 }

  CargarNivelesGastos(nTipoPresu: number): void {
    let nUltimoNivel = 0;
    this.ServicioClienteHttp.SeteoRuta("EstructuraPartidaGastos/detalle?anio=2024&tipopresu="+nTipoPresu+"");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) =>
      {
        if (data.success)
        {
          this.EstructuraNivelesGastos = JSON.parse(data.result);
          this.OpcionesNivelesGastos = this.EstructuraNivelesGastos.slice();
          nUltimoNivel = this.EstructuraNivelesGastos.length - 1;
          this.nivel = this.EstructuraNivelesGastos[nUltimoNivel].out_niv;
          this.sUltimoNivel = this.EstructuraNivelesGastos[nUltimoNivel].out_niv + " - " + this.EstructuraNivelesGastos[nUltimoNivel].out_descripcion;
        }
        else
        {
          this.alertas.MensajeError(data.message);
        }

        this.FormularioDatos.patchValue({
          Cmbnivel01: this.sUltimoNivel.trim(),
        });

      },
      error: (err) =>
      {
        console.log(err.message);
        //alert(err.message);
      }
    });
  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
    switch (opcion)
    {
      case "Cmbnivel01":
        filterValue = this.Cmbnivel01.nativeElement.value.toLowerCase();
        this.OpcionesNivelesGastos = this.EstructuraNivelesGastos.filter(option => option.out_descripcion.toLowerCase().includes(filterValue));
        this.nivel = this.OpcionesNivelesGastos[0]?.out_niv || 0;
        break;
    }
  }

  ClicRadioButton(opcion: number): void {
    this.CargarNivelesGastos(opcion);
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel.toString();
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    const sPartida = this.FormularioDatos.get('Txtpartida')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte="RPT_CEDULA_GASTOS";
    DatosPdf.param1 = sFechaHasta;
    DatosPdf.param2 = this.nTipoPresupuesto.toString();
    DatosPdf.param3 = nVerTodos.toString();
    DatosPdf.param4 = nNivel.toString();
    DatosPdf.param5 = sOperador;
    DatosPdf.param6 = sPartida;

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE

  VerSaldoPartida(fila: any) {
    const str_partida = fila.partida;
    const DatosArchivo: any = {
      tipo_reporte: "SALDO DE PARTIDA",
      partida: str_partida
    };

    this.dialog.open(VersaldopartidaListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });
  }
  selectedNivel: any; // Aquí almacenamos el valor seleccionado
  GraficarEjecucion(nivelSeleccionado: any) {
    console.log('Nivel seleccionado:', nivelSeleccionado); 
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel;
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }
    const sPartida = this.FormularioDatos.get('Txtpartida')?.value;
    if(nNivel == 0){
      this.alertas.MensajeError("Debe seleccionar el nivel");
      return;
    }

    this.rutaapi = "CedulaPresupuestaria?codemp=0004&fecha_hasta=" + sFechaHasta +"&ing_gas=" + this.nTipoPresupuesto +"&nTodos=" + nVerTodos +"&nNivel=" + nNivel +"&sOperador="+ sOperador +"&spartida="+sPartida+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
   
 
     this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {        
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
          const DatosArchivo: any = {
           // tipo_reporte: "CO ASOCIADO",
            resultado:JSON.parse(data.result)
           // str_codigo_certificacion: str_codigo_certificacion
          };
      
          this.dialog.open(ApexchartComponent, {
            data: {
              DatosArchivo
            },
            width: '90%',
            height: '80%'
          });
          
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })


  }
}


