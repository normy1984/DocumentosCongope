import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, FormGroup, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';

import {MatRadioModule} from '@angular/material/radio';
import { ListabuscarpartidaListComponent } from 'app/paginas/generico/listabuscarpartida-list/listabuscarpartida-list.component';
import { ParamSessionMo } from 'app/models/param-session';


@Component({
    selector: 'app-movimientoporpartida-list',
    templateUrl: './movimientoporpartida-list.component.html',
    imports: [EditModule, ListModule, MatRadioModule
    ]
})



export class MovimientoporpartidaListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public nAnio = 2024;
  public fechaDesde = this.nAnio + "-01-01";
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public TxtpartidaSeleccionada = "";
  public TxtNombrepartidaSeleccionada = "";
  public sUltimoNivel = "";

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('Cmbpartida') Cmbpartida!: ElementRef<HTMLInputElement>;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/EjecucionPresupuestaria";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "fec_det",
  "sig_acu_tip",
  "des_cab",
  "inicial",
  "reforma",
  "codificado",
  "certificado",
  "comprometido",
  "devengado",
  "por_comprometer",
  "por_devengar",
  "num_com",
];

public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public nTipoPresupuestoID = 1;
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    const ffecha = new Date(this.fechaAct);
    this.nAnio = this.ParamSessiones.anio;
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }
    this.fechaDesde = this.nAnio + "-01-01";

    this.rutaapi = "MovimientoPorPartida?codemp=0004&anio="  + this.nAnio + "&sFechaDesde="+ this.fechaDesde +"&sFechaHasta=" + this.fechaAct +"&sPartida=''";

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Txtfecha: this.fechaAct,
      TxtfechaDesde: this.fechaDesde,
      TxtpartidaSeleccionada:"",
      TxtNombrepartidaSeleccionada:"",

    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
          this.TxtNombrepartidaSeleccionada = this.resultado[0].nombre_partida;
        }
        else {
          //this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'FECHA': x.fec_det,
        'CPBTE': x.sig_acu_tip,
        'DESCRIPCIÓN': x.des_cab,
        'INICIAL': x.inicial,
        'REFORMAS': x.reforma,
        'CODIFICADO': x.codificado,
        'CERTIFICADO': x.certificado,
        'COMPROMETIDO': x.comprometido,
        'DEVENGADO': x.devengado,
        'POR COMPROM.': x.por_comprometer,
        'POR DEVENG.': x.por_devengar,
        'NRO.CP': x.num_com,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  EjecutarConsulta() {
    const sFechaDesde = this.FormularioDatos.get('TxtfechaDesde')?.value;
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;

    if(sPartida.trim().length == 0){
      this.alertas.MensajeError("Debe seleccionar una Partida Presupuestria");
      return;
    }
    this.rutaapi = "MovimientoPorPartida?codemp=0004&anio="  + this.nAnio + "&sFechaDesde="+ sFechaDesde +"&sFechaHasta=" + sFechaHasta +"&sPartida=" + sPartida +"";

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    this.FormularioDatos.patchValue({
      TxtnobrepartidaSeleccionada:this.TxtNombrepartidaSeleccionada.toString().trim()
    });


  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
    filterValue = this.Cmbpartida.nativeElement.value.toLowerCase();
    this.OpcionesNivelesGastos = this.EstructuraNivelesGastos.filter(option => option.cuenta.toLowerCase().includes(filterValue));
    this.nivel = this.OpcionesNivelesGastos[0]?.cuenta || 0;
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaDesde = this.FormularioDatos.get('TxtfechaDesde')?.value;
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;
    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT217_MOVIMIENTO_PARTIDA";
    DatosPdf.param1=  this.nTipoPresupuestoID.toString();
    DatosPdf.param2 = sFechaDesde;
    DatosPdf.param3 = sFechaHasta;
    DatosPdf.param4 = sPartida;
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE
  TotalReformas() {
    return this.resultado.map(t => t.reforma).reduce((acc, value) => acc + value, 0);
  }

  TotalCertificado() {
    return this.resultado.map(t => t.certificado).reduce((acc, value) => acc + value, 0);
  }

  TotalComprometido() {
    return this.resultado.map(t => t.comprometido).reduce((acc, value) => acc + value, 0);
  }

  TotalDevengado() {
    return this.resultado.map(t => t.devengado).reduce((acc, value) => acc + value, 0);
  }


  BuscarPartida() {
    const DatosArchivo: any = {
      tipo_reporte: "BUSCAR PARTIDA",
      TxtpartidaSeleccionada: "",
      nTipoPresupuesto:this.nTipoPresupuestoID,
    };

    const DialogRef = this.dialog.open(ListabuscarpartidaListComponent, {
      data: {
        DatosArchivo
      },
      width: '95%',
      height: '100%'
    });

     DialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log(result);
        this.FormularioDatos.patchValue({
          TxtpartidaSeleccionada: result,
        });
      }
    });

  }

  radioChangeHandler(value: any){
    this.nTipoPresupuestoID = value;
    this.FormularioDatos.patchValue({
      TxtpartidaSeleccionada: "",
      TxtNombrepartidaSeleccionada:"",
    });
 }


}


