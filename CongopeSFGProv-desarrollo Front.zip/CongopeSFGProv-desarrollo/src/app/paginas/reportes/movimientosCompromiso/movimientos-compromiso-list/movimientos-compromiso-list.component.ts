import { animate, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { configapp } from '@config/configapp';
import { TableElement, TableExportUtil,UnsubscribeOnDestroyAdapter } from '@shared';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { ParamSessionMo } from 'app/models/param-session';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';


@Component({
    selector: 'app-movimientos-compromiso-list',
    styleUrls: ['./movimientos-compromiso-list.component.scss'],
    animations: [
        trigger('detailExpand', [
            state('collapsed,void', style({ height: '0px', minHeight: '0' })),
            state('expanded', style({ height: '*' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ],
    imports: [ListModule, EditModule,
        MatDatepickerModule
    ],
    // ESTA PARTE DE LOS PROVIDERS CAMBIA LOS OBJETOS DE ANGULAR MATERIAL A ESPAÑOL
    providers: [DatePipe,
        { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
        {
            provide: DateAdapter,
            useClass: MomentDateAdapter,
        },
    ],
    templateUrl: './movimientos-compromiso-list.component.html'
})
export class MovimientosCompromisoListComponent
extends UnsubscribeOnDestroyAdapter 
implements OnInit{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public dataSource: MatTableDataSource<any>= new MatTableDataSource<any>([]);
  public dataSourceDetalle: MatTableDataSource<any>= new MatTableDataSource<any>([]);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public FormularioDatos!: UntypedFormGroup;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('picker_fecha_inicial') picker_fecha_inicial!: MatDatepicker<Date>;
  @ViewChild('picker_fecha_final') picker_fecha_final!: MatDatepicker<Date>;

  protected anioActual = parseInt(new Date().getFullYear().toString(),10);
  protected anioSeleccionado: number = parseInt(sessionStorage.getItem('codigoAnio') || new Date().getFullYear().toString(), 10);

  public minDate_inicio = new Date(this.anioSeleccionado, 0, 1);
  public maxDate_inicio = (this.anioSeleccionado == this.anioActual) ? new Date() : new Date(this.anioSeleccionado, 11, 31);
  public minDate_fin = new Date(this.anioSeleccionado, 0, 1);
  public maxDate_fin = (this.anioSeleccionado == this.anioActual) ? new Date() : new Date(this.anioSeleccionado, 11, 31);
  
  
  public expandedElement!: any | null;
  protected datosDetalle: any[] = [];

     // Rutas de la API y navegación
     private rutaapi: string = "MovimientosCompromiso";

/**
 * COLUMNAS A MOSTRAR EN EL LISTADO PRINCIPAL
 */
  public displayedColumns: string[] = [
    "accion", "siglasnum",
    "fecha", "documento", "concepto", "valor", "devengado",
    "saldo", "estado"
  ];

  /**
   * COLUMNAS PARA EL DETALLE
   */
  public displayedColumnsDetalle: string[] = [
    "asiento", "comprobante",
    "fecha", "descripcion", "valor"
  ];

 

  constructor(
    private ServicioClienteHttp: ClienthttpCongopeService,
    public alertas : AlertasSrvService,
    public formBuild :FormBuilder,
    public dialog: MatDialog,
  )  {
    super();
    this.FormularioDatos = this.CrearFormulario();
  }

  ngOnInit() {
   
    this.CargarGrid();
    this.CambiarFechas();
  }



    /**
   * Función que realiza los filtrados de los grids.
   * @param event Evento de entrada del filtro.
   */
    FiltrarRegistros(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();
  
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }
/**
 * Funcion que carga el listado principal de datos
 */
  CargarGrid()
    {

      

      const ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
      const DatosCarga = {
        sig_tip: "CO",
        estado: 3,
        fec_asi_inicio: this.minDate_fin,
        fec_asi_fin: this.maxDate_inicio,
        codemp: ParamSessiones.codemp
      };

      this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/List")
      this.ServicioClienteHttp.Insertar(DatosCarga).subscribe({
        next: (data) => {
          if (data.success) {
            let resultado: any = JSON.parse(data.result);
            this.dataSource = new MatTableDataSource(resultado);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
          } else {
            this.dataSource = new MatTableDataSource<any>([]);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }

/**
 * Funcion que carga los datos del detalle de la información
 * @param fila 
 */
    CargarDetalle(fila: any)
    {
      this.dataSourceDetalle = new MatTableDataSource<any>([]);
      
      const ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
      const DatosCarga = {
        compromiso: fila.acu_tip,
        anio: fila.anio,
        codemp: ParamSessiones.codemp
      };

      this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ListDetalle")
      this.ServicioClienteHttp.Insertar(DatosCarga).subscribe({
        next: (data) => {
          if (data.success) {
            this.datosDetalle = JSON.parse(data.result);
            this.dataSourceDetalle = new MatTableDataSource(this.datosDetalle);
          } else {
           
            this.datosDetalle = [];
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }

/**
 * Abre el selector de fecha de asignación.
 */
AbrirPickerFechaInicial(): void {
  this.picker_fecha_inicial.open();
}

/**
 * Abre el selector de fecha de aprobación.
 */
AbrirPickerFechaFinal(): void {
  this.picker_fecha_final.open();
}

/***
 * Funcion que crea el formulario inicial utilizado para este reporte
 */
CrearFormulario(): UntypedFormGroup {
  return this.formBuild.group({
    fecha_inicial: [this.minDate_inicio],
    fecha_final: [this.maxDate_fin],
  });
}

/**
 * Funcion que valida que las fechas no se desborden entre los calendarios
 */
CambiarFechas(): void {
  this.FormularioDatos.get('fecha_inicial')?.valueChanges.subscribe((fecha_inicial: Date) => {
    const currentFinalDate = this.FormularioDatos.get('fecha_final')?.value;
    if (fecha_inicial && (!this.minDate_fin || fecha_inicial !== this.minDate_fin)) {
      this.minDate_fin = fecha_inicial;
      this.FormularioDatos.get('fecha_final')?.updateValueAndValidity(); // Trigger validation on fecha_final
    }
    if (currentFinalDate && fecha_inicial > currentFinalDate) {
      this.FormularioDatos.get('fecha_final')?.setValue(null);
    }
  });

  this.FormularioDatos.get('fecha_final')?.valueChanges.subscribe((fecha_final: Date) => {
    if (fecha_final && (!this.maxDate_inicio || fecha_final !== this.maxDate_inicio)) {
      this.maxDate_inicio = fecha_final;
      this.FormularioDatos.get('fecha_inicial')?.updateValueAndValidity(); // Trigger validation on fecha_inicial
    }
  });
}

/**
 * Funcion que realiza la suma del total para el detalle
 * @returns 
 */
TotalDevengado(): number {
  return this.datosDetalle
    .map(transaccion => transaccion.valor)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}


/**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
ImprimirReporte(fila: any) {
  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT241_MOVIMIENTO_COMPROMISO";
  //DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
  DatosPdf.param1=fila.acu_tip.toString();
  DatosPdf.param2=fila.sig_tip;
 
  this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}


/**
   * Función llamada para la exportación a Excel del formulario.
   */
ExportarExcel() {
  const exportData: Partial<TableElement>[] =
    this.dataSource.filteredData.map((x) => ({
      'NUMERO': x.siglasnum,
      'FECHA': x.fecha,
      'DOCUMENTO': x.documento,
      'CONCEPTO': x.concepto,
      'VALOR': x.valor,
      'DEVENGADO': x.devengado,
      'SALDO': x.saldo,
      'ESTADO': x.estado,
    }));

  TableExportUtil.exportToExcel(exportData, 'excel');
}


}