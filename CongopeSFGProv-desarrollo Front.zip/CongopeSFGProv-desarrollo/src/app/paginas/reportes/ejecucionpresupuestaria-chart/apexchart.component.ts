import { Component, inject, ViewChild } from '@angular/core';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexFill,
  ApexTooltip,
  ApexTitleSubtitle,
  ApexGrid,
  ApexMarkers,
  ApexNonAxisChartSeries,
  ApexResponsive,
  NgApexchartsModule,
} from 'ng-apexcharts';
import { Observable } from 'rxjs/internal/Observable';

export type ChartOptions = {
  series?: ApexAxisChartSeries;
  series2?: ApexNonAxisChartSeries;
  chart?: ApexChart;
  dataLabels?: ApexDataLabels;
  plotOptions?: ApexPlotOptions;
  yaxis?: ApexYAxis;
  xaxis?: ApexXAxis;
  fill?: ApexFill;
  tooltip?: ApexTooltip;
  stroke?: ApexStroke;
  legend?: ApexLegend;
  title?: ApexTitleSubtitle;
  colors?: string[];
  grid?: ApexGrid;
  markers?: ApexMarkers;
  labels: string[];
  responsive: ApexResponsive[];
};

@Component({
    selector: 'app-apexchart',
    templateUrl: './apexchart.component.html',
    imports: [NgApexchartsModule]
})
export class ApexchartComponent {
  @ViewChild('chart', { static: true }) chart!: ChartComponent;

  public barChartOptions: Partial<ChartOptions>= {}; ;
 /* public barChart2Options: Partial<ChartOptions>;
  public lineChartOptions: Partial<ChartOptions>;
  public lineChart2Options: Partial<ChartOptions>;
  public scatterChartOptions: Partial<ChartOptions>;

  public pieChartOptions: Partial<ChartOptions>;
  public columnChartOptions: Partial<ChartOptions>;
  public areaChartOptions: Partial<ChartOptions>;*/

  alertas: any;

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  constructor(private ServicioClienteHttp: ClienthttpCongopeService) {
  
    this.inicializa().subscribe({
      next: (fila) => {
    // Bar chart chart 1
    this.barChartOptions = {
      series: [
        {
          name: 'Codificado',
          data: fila.map((item: { codificado: any; }) => item.codificado), //[44, 55, 57, 56, 61, 58, 63, 60, 66],
        },
        {
          name: 'Devengado',
          data: fila.map((item: { devengado: any; }) => item.devengado),//[76, 85, 101, 98, 87, 105, 91, 114, 94],
        },
        {
          name: 'Diferencia',
          data: fila.map((item: { diferencia: any; }) => item.diferencia),//[35, 41, 36, 26, 45, 48, 52, 53, 41],
        },
      ],
      chart: {
        type: 'bar',
        height: 350,
        foreColor: '#9aa0ac',
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '55%',
          borderRadius: 5,
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent'],
      },
      xaxis: {
        categories: fila.map((item: { descripcion: any; }) => item.descripcion),  /*[
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
        ],*/
        labels: {
          style: {
            colors: '#9aa0ac',
          },
        },
      },
      yaxis: {
        title: {
          text: '$ (Dólares)',
        },
      },
      grid: {
        show: true,
        borderColor: '#9aa0ac',
        strokeDashArray: 1,
      },
      fill: {
        opacity: 1,
      },
      tooltip: {
        theme: 'dark',
        marker: {
          show: true,
        },
        x: {
          show: true,
        },
      },
    };
  }
});
 
  }

  inicializa() {
    return new Observable<any>((observer) => {
      // Llamar al endpoint del backend para obtener los datos
      this.ServicioClienteHttp.Obtener_Lista().subscribe({
        next: (data: { success: any; result: string; message: any; }) => {
          if (data.success) {
            let resultado: any[] = JSON.parse(data.result);
            console.log("ejecucion pres" + resultado);
  
            // Emitir el valor de 'fila' al observable
            observer.next(resultado);
            observer.complete();
          } else {
            this.alertas.MensajeError(data.message);
            observer.error(data.message); // En caso de que haya error, se emite un error al observable
          }
        },
        error: (err: { message: any; }) => {
          console.log(err.message);
          observer.error(err.message); // En caso de error en la solicitud HTTP
        }
      });
    });
  }
}
