import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import {MatRadioModule} from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';
import { MatExpansionModule } from '@angular/material/expansion';
import { Pipe, PipeTransform } from '@angular/core';
//import { ApexchartComponent } from '../proyectosinversion-chart/apexchart.component';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
@Component({
    selector: 'app-proyectosdeinversion-list',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './proyectosdeinversion-list.component.html',
    imports: [EditModule, ListModule, MatRadioModule, MatDatepickerModule, MatExpansionModule, ScrollingModule, MatProgressSpinnerModule
    ]
})
/*
export class ProyectosdeInversionListComponent implements AfterViewInit {
  ngAfterViewInit(): void {
    console.log('¡Todos los recursos del componente terminaron de cargar!');
  }
}*/
export class ProyectosdeInversionListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit,AfterViewInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  //public dataSource !:  MatTableDataSource<any>;
 // public dataSource1 !:  MatTableDataSource<any>;
  public dataSource2 !:  MatTableDataSource<any>;
  public dataSourceDTTHH !:  MatTableDataSource<any>;
  dataSource = new MatTableDataSource<any>();  // MatTableDataSource es para tablas de Angular Material
  dataSource1 = new MatTableDataSource<any>();  // Otra instancia de MatTableDataSource
  dataSourceDirecGrupoPoa = new MatTableDataSource<any>();
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public fechaDesde = "";
  public nAnio = 2024;
  public sUltimoNivel = "";

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('Cmbnivel01') Cmbnivel01!: ElementRef<HTMLInputElement>;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/ProyectosdeInversion";
public rutaapi:string = "ProyectosInversion?codemp="+this.ParamSessiones.codemp.toString()+"&anio="+this.ParamSessiones.anio+"&fecha="+this.fechaAct;
public rutaapi1:string = "ProyectosInversion/CargarPresupuestoxDireccion?codemp="+this.ParamSessiones.codemp.toString()+"&anio="+this.ParamSessiones.anio+"&fecha="
                        +this.fechaAct+"&prt_tthh_param=";
                      
/**COLUMNAS MOSTRADAS PRIMER GRID*/
public displayedColumns:string[] = [
  "grupo",
  "codificado",
  "certificado",
  "porcen_certificado",
  "comprometido",
  "porcen_comprometido",
  "devengado",
  "porcen_devengado",
  "pagado",
  "porcen_pagado",
];
columnTitles : { [key: string]: string } = {
  "grupo":"DENOMINACION",
  "porcen_certificado":"%EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "porcen_devengado":"%EJE. DEVEN.",
  "porcen_pagado":"%EJE. PAG.",
};

/**COLUMNAS MOSTRADAS SEGUNDO GRID*/
public displayedColumns1:string[] = [//"out_niv_ug",
  "ugs_nombre",
 // "out_cuenta",
 // "out_contador",
  "codificado",
  "certificado",
  "porcen_certificado",
  "comprometido",
  "porcen_comprometido",
  "devengado",
  "porcen_devengado",
  "disponible",
  "porcen_disponible",
  "pagado",
  "porcen_pagado",
];
nonSummableColumns: string[] = ["grupo","ugs_nombre","out_cuenta"];
columnTitles1 : { [key: string]: string } = {
  "ugs_nombre":"DENOMINACION",
  "porcen_certificado":"%EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "porcen_devengado":"%EJE. DEVEN.",
  "porcen_disponible":"%EJE. DISP.",
  "porcen_pagado":"%EJE. PAG.",
};
 

public displayedColumns2:string[] = [
  "ugs_nombre",
  "out_cuenta",
  "codificado",
  "certificado",
  "porcen_certificado",
  "comprometido",
  "porcen_comprometido",
  "devengado",
  "porcen_devengado",
  "disponible",
  "porcen_disponible",
  "pagado",
  "porcen_pagado",
];
columnTitles2 : { [key: string]: string } = {
  "ugs_nombre":"UNIDAD DE GESTIÓN",
  "out_cuenta":"GRUPO",
  "porcen_certificado":"%EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "porcen_devengado":"%EJE. DEVEN.",
  "porcen_disponible":"%EJE. DISP.",
  "porcen_pagado":"%EJE. PAG.",
};
/**/ 
public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public EstructuraNivelesIngresos!: any[];
public OpcionesNivelesIngresos!: any[];
public nTipoPresupuestoID = 1;
isLoading = true;  // Indicador de carga
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }
  ngAfterViewInit(): void {
    console.log('¡Todos los recursos del componente terminaron de cargar!');
  }
  ngOnInit() {   
    this.nAnio = this.ParamSessiones.anio;
    const ffecha = new Date(this.fechaAct);
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }

    this.fechaDesde =  this.nAnio + "-01-01";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid(0);
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi1);
    this.CargarGrid(1);

   /* this.ServicioClienteHttp.SeteoRuta(this.rutaapi1+0+"&grupo=G");
    this.CargarGrid(2);*/
  //  this.onPanelOpen(2);
      console.log("Bandera1:"+this.rutaapi1);
  this.onPanelOpen();
  //this.isLoading = false;
      console.log("Bandera2:"+this.rutaapi1);
    this.FormularioDatos = this.CrearFormulario();
 
  }

  
trackByColumn(index: number, column: string): string {
  return column;
}

asignarValorFila(fila: any,subtotal: any,column: any,grupo: any,grupoI: any,certi: any,comp:any,dev:any,disp:any,pag:any): any {//grupo: any, grupoI: any,disp:any

  if (subtotal && column=="out_cuenta"){  
    if (grupo  )   //&& grupo.includes("Subtotal")
    fila=` ${grupo}`;}
    if (subtotal && column=="tipo")
      fila= 'SUBTOTAL';

    if (column=="tipo"){
        if (!(typeof fila !== 'number' || isNaN(fila) || fila === null))
          {
            fila="0%"; // Retorna '0' si no es un número
            }
    }
 
 if (column=="porcen_certificado" )
  {   fila=parseFloat(certi.toFixed(2))+"%";  }
 if (column=="porcen_comprometido" )
  { 
   fila=parseFloat(comp.toFixed(2))+"%"; 
  } 
  if (column=="porcen_devengado" )
    { 
     fila=parseFloat(dev.toFixed(2))+"%"; 
    } 
    if (column=="porcen_disponible" )
      { 
       fila=parseFloat(pag.toFixed(2))+"%"; 
      }
  if (column=="porcen_pagado" )
      { 
       fila=parseFloat(pag.toFixed(2))+"%"; 
      }
  return fila;
}


asignarValorFila1(fila: any,subtotal: any,column: any,grupo: any,grupoI: any,certi: any,comp:any,dev:any,disp:any,pag:any): any {//grupo: any, grupoI: any,disp:any
//console.log("certi:"+certi) 

  
    if (subtotal && column=="out_cuenta")
      fila= 'SUBTOTAL';

    if (column=="tipo"){
        if (!(typeof fila !== 'number' || isNaN(fila) || fila === null))
          {
            fila="0%"; // Retorna '0' si no es un número
            }
    }
 
 if (column=="porcen_certificado" )
  {   fila=parseFloat(certi.toFixed(2))+"%";  }
 if (column=="porcen_comprometido" )
  { 
   fila=parseFloat(comp.toFixed(2))+"%"; 
  } 
  if (column=="porcen_devengado" )
    { 
     fila=parseFloat(dev.toFixed(2))+"%"; 
    } 
    if (column=="porcen_disponible" )
      { 
       fila=parseFloat(pag.toFixed(2))+"%"; 
      }
  if (column=="porcen_pagado" )
      { 
       fila=parseFloat(pag.toFixed(2))+"%"; 
      }
  return fila;
}



codificado: number = 0;
campo: string = "";


  getTotal(column: string,dataSourceIndex:number): number|string {
   // console.log("calcula total:"+column+"data source:"+dataSourceIndex);
     // Definir las fuentes de datos en un arreglo para evitar repetir el switch
     this.campo = column;  // Verificar si la columna no es sumable
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==0) {
       return column === this.nonSummableColumns[0] ? "TOTAL GENERAL" : "";
     }
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==1) {
      return column === this.nonSummableColumns[1] ? "TOTAL GENERAL" : "";
    }
    
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==2) {
      return column === this.nonSummableColumns[2] ? "TOTAL GENERAL" : "";
    }
 
    // Definir las fuentes de datos
    const dataSources = [
      this.dataSource.data,
      this.dataSource1.data,
     // this.dataSource2.data,
     /* this.dataSourceDTTHH.data,*/
    this.dataSourceDirecGrupoPoa.data,
    ];
    
//console.log("este si funciona"+JSON.stringify(this.dataSource.data));
    // Filtra las filas que no son subtotales
    // Verificar si el índice de la fuente de datos es válido
    if (dataSourceIndex < 0 || dataSourceIndex >= dataSources.length) {
      return 0; // O puedes lanzar un error si prefieres
    }
    // Calcular el total
   const currentDataSource = dataSources[dataSourceIndex];
  
    // Si la columna no es un porcentaje, calcular la suma directamente
    if (!["porcen_certificado", "porcen_comprometido", "porcen_devengado", "porcen_disponible", "porcen_pagado"].includes(column)) {   
      const total = currentDataSource.reduce((sum, row) => sum + (parseFloat(row[column]) || 0), 0);    
      return  Math.floor(total * 100) / 100 ;
    }
   
    // Definir el mapeo de columnas de porcentaje
    type ColumnMappingType = {
      porcen_certificado: string;
      porcen_comprometido: string;
      porcen_devengado: string;
      porcen_disponible: string;
      porcen_pagado: string;
    };
  
    const columnMapping: ColumnMappingType = {
      porcen_certificado: "certificado",
      porcen_comprometido: "comprometido",
      porcen_devengado: "devengado",
      porcen_disponible: "disponible",
      porcen_pagado: "pagado",
      
    };
  
    // Verificar si la columna es válida para calcular porcentajes
    if (column in columnMapping) {
      const targetColumn = columnMapping[column as keyof ColumnMappingType];
   //   console.log("columna:"+targetColumn);// no hay esto       porcen_disponible: "disponible",
      const dividendo = currentDataSource.reduce((sum, row) => sum + (row[targetColumn] || 0), 0);
     // console.log("columna:"+dividendo);
      this.codificado = currentDataSource.reduce((sum, row) => sum + (row["codificado"] || 0), 0);
     
      if (this.codificado !== 0) {
        const total = (dividendo / this.codificado) * 100;
        //console.log("total:"+total);   
        return Math.floor(total * 100) / 100+"%"; //+
       this.isLoading=false; 
      } else {
        console.log("No se recorrió todo el dataSet o el valor de 'codificado' es 0.1");
        return 0;
      }
    } else {
      console.error(`La columna ${column} no es válida para calcular porcentajes.`);
      return 0;
    }
  }

  isNumber(value: any): boolean {
    return !isNaN(value) && value !== null && value !== undefined;
  }


  getFormattedValue(value: any): string {
    // Verificar si es un número
    if (typeof value !== 'number' || isNaN(value) || value === null) {
      return value;  // Retorna '0' si no es un número
    }
    // Retorna el valor truncado formateado como moneda
    return (Math.floor(value * 100) / 100).toFixed(2);
  }

  getFormattedValue1(value: any,column: any,certi: any,comp: any,dev: any,disp: any,pag: any): string {
   let fila =""; // Verificar si es un número
    if (typeof value !== 'number' || isNaN(value) || value === null) {
      return value;  // Retorna '0' si no es un número
    }
//console.log("Esta es:"+column);

    switch(column){
      case "porcen_certificado":
        fila=parseFloat(certi.toFixed(2))+"%"; 
      break;
      case "porcen_comprometido":
          fila=parseFloat(comp.toFixed(2))+"%"; 
      break;
      case "porcen_devengado":
          fila=parseFloat(dev.toFixed(2))+"%"; 
       break;
       case "porcen_disponible":
          fila=parseFloat(disp.toFixed(2))+"%"; 
       break;
       case "porcen_pagado":
          fila=parseFloat(pag.toFixed(2))+"%"; 
       break;
      default:
        fila=(Math.floor(value * 100) / 100).toFixed(2);
        break;
    }
    /*if (column=="porcen_certificado" )
      { 
 
       fila=parseFloat(certi.toFixed(2))+"%"; 
      }
      else fila=(Math.floor(value * 100) / 100).toFixed(2);*/
    // Retorna el valor truncado formateado como moneda
    return fila ;//(Math.floor(value * 100) / 100).toFixed(2);
  }
  

  CrearFormulario(): UntypedFormGroup {
  
    return this.formBuild.group({
      Txtfecha: this.fechaAct,
    });
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid(dataSourceIndex:number) {//param: number | null
    //console.log("dataSourceIndex: "+dataSourceIndex);
   // this.dataSourceDirecGrupoPoa = ;

    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        this.resultado = [];
        if (data.success) {
          if (data.message === "No existen registros") {
         }else{ 
          this.resultado = JSON.parse(data.result);  
          //console.log("llego"+dataSourceIndex+" :"+JSON.stringify( this.resultado));    
          switch(dataSourceIndex){
              case 0:
                this.dataSource = new MatTableDataSource(this.resultado);
                this.dataSource.sort = this.sort;
              break;
              case 1:
                //console.log("dataSourceIndex 1:"+JSON.stringify(this.resultado));         
                this.dataSource1 = new MatTableDataSource(this.resultado);
                this.dataSource1.sort = this.sort;
                

              break;
              case 2:
               // console.log("dataSourceIndex 1:"+this.resultado);
           //   this.dataSourceDirecGrupoPoa = new MatTableDataSource(this.resultado);
          /*    console.log("Para subtotales:"+JSON.stringify( this.resultado));*/
            /*    this.dataSourceDirecGrupoPoa = new MatTableDataSource(this.agregarSubtotales(this.resultado));
                this.dataSourceDirecGrupoPoa.sort = this.sort;
                console.log("dataSource llega:");*/
               // console.log("dataSource:"+JSON.stringify( this.dataSourceDirecGrupoPoa));
              break;
              default:
                break;
          }       
        }
      }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }
  public resultadoUltimo: any[] = [];
  public subtotales: any[] = [];

/*
  getTotalUltimo(column: string,dataSourceIndex:number): number|string {
    console.log("calcula total:"+column+"data source:"+dataSourceIndex);
     // Definir las fuentes de datos en un arreglo para evitar repetir el switch
     this.campo = column;  // Verificar si la columna no es sumable
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==0) {
       return column === this.nonSummableColumns[0] ? "TOTAL GENERAL" : "";
     }
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==1) {
      return column === this.nonSummableColumns[1] ? "TOTAL GENERAL" : "";
    }
    
     if (this.nonSummableColumns.includes(column) && dataSourceIndex==2) {
      return column === this.nonSummableColumns[2] ? "TOTAL GENERAL" : "";
    }

    // Definir las fuentes de datos
    const dataSources = [
    this.dataSourceDirecGrupoPoa.data,
    ];
    

    // Filtra las filas que no son subtotales
    // Verificar si el índice de la fuente de datos es válido
    if (dataSourceIndex < 0 || dataSourceIndex >= dataSources.length) {
      return 0; // O puedes lanzar un error si prefieres
    }
    // Calcular el total
   const currentDataSource = dataSources[dataSourceIndex];
  
    // Si la columna no es un porcentaje, calcular la suma directamente
    if (!["porcen_certificado", "porcen_comprometido", "porcen_devengado", "porcen_disponible", "porcen_pagado"].includes(column)) {   
      const total = currentDataSource.reduce((sum, row) => sum + (parseFloat(row[column]) || 0), 0);    
      return  Math.floor(total * 100) / 100 ;
    }
   
    // Definir el mapeo de columnas de porcentaje
    type ColumnMappingType = {
      porcen_certificado: string;
      porcen_comprometido: string;
      porcen_devengado: string;
      porcen_disponible: string;
      porcen_pagado: string;
    };
  
    const columnMapping: ColumnMappingType = {
      porcen_certificado: "certificado",
      porcen_comprometido: "comprometido",
      porcen_devengado: "devengado",
      porcen_disponible: "disponible",
      porcen_pagado: "pagado",
      
    };
  
    // Verificar si la columna es válida para calcular porcentajes
    if (column in columnMapping) {
      const targetColumn = columnMapping[column as keyof ColumnMappingType];
   //   console.log("columna:"+targetColumn);// no hay esto       porcen_disponible: "disponible",
      const dividendo = currentDataSource.reduce((sum, row) => sum + (row[targetColumn] || 0), 0);
     // console.log("columna:"+dividendo);
      this.codificado = currentDataSource.reduce((sum, row) => sum + (row["codificado"] || 0), 0);
     
      if (this.codificado !== 0) {
        const total = (dividendo / this.codificado) * 100;
        //console.log("total:"+total);   
        return Math.floor(total * 100) / 100+"%"; //+
        
      } else {
        console.log("No se recorrió todo el dataSet o el valor de 'codificado' es 0.");
        return 0;
      }
    } else {
      console.error(`La columna ${column} no es válida para calcular porcentajes.`);
      return 0;
    }
  }*/
  
  onPanelOpen() {
   // alert('Panel abierto, cargando el reporte...'); 
     this.ServicioClienteHttp.SeteoRuta(this.rutaapi1+"0&grupo=G");
   
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
    
      next: (data) => {
       // this.resultado = [];
        if (data.success) {
          console.log("Viendo errores:");
         
          this.resultadoUltimo = JSON.parse(data.result); 
          console.dir(this.resultadoUltimo);
          console.log("Ultimo resultado:"+JSON.stringify(this.resultadoUltimo, null, 2) );
          this.dataSourceDirecGrupoPoa = new MatTableDataSource(this.agregarSubtotales(this.resultadoUltimo));
        //  this.isLoading = false; 
          console.log("DAtaset:"+JSON.stringify(this.resultadoUltimo)); 
       /*  this.subtotales=this.agregarSubtotales(this.resultadoUltimo);
         console.log("Subtotales:"+JSON.stringify( this.subtotales));        
                this.dataSourceDirecGrupoPoa = new MatTableDataSource(this.subtotales);
                */
                this.dataSourceDirecGrupoPoa.sort = this.sort;    
             //   console.log("Subtotales:"+this.isLoading );  
               // Termina la carga
               this.isLoading = false;
      }
        else {
          this.alertas.MensajeError(data.message);
        //  this.isLoading = false;  // Termina la carga en caso de error
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

  agregarSubtotales(datos: any[]): any[] {
    console.log("datosConSubtotales:"+datos);
    console.log("datosConSubtotales:"+JSON.stringify(datos));
    const datosConSubtotales: any[] = [];
    let grupoActual: string | null = null;
    let subtotalGrupo: any = {};

    datos.forEach((fila, index) => {
        // Si cambia el grupo, agregar el subtotal del grupo anterior
        if (grupoActual !== fila.ugs_nombre) {
            if (grupoActual !== null) {
                datosConSubtotales.push(subtotalGrupo); // Agregar subtotal
            }
 
            // Iniciar un nuevo subtotal
            grupoActual = fila.ugs_nombre;
            subtotalGrupo = {
                grupo:  `SUBTOTAL`,
                codificado: 0,
                certificado: 0,
                porcen_certificado: 0,
                comprometido:0,
                porcen_comprometido:0,
                devengado:0,
                porcen_devengado:0,
                disponible:0,
                porcen_disponible:0,
                pagado:0,
                porcen_pagado:0,
                isSubtotal: true // Marcar como fila de subtotal
            };
            
            // Agregar la fila actual
           // datosConSubtotales.push({ ...fila});
           const filaSinUgsNombre = { ...fila,  };  // Limpiar el nombre del grupo para las filas internas
            datosConSubtotales.push(filaSinUgsNombre);
           // console.log();
        }else {
            // Para las filas siguientes del grupo, eliminar el ugs_nombre
            const filaSinUgsNombre = { ...fila, ugs_nombre: '' };
            datosConSubtotales.push(filaSinUgsNombre);
          // datosConSubtotales.push(this.asignarValorFila(filaSinUgsNombre));
        }

        // Sumar al subtotal
        subtotalGrupo.codificado += fila.codificado;
        subtotalGrupo.certificado += fila.certificado;
        subtotalGrupo.porcen_certificado = subtotalGrupo.certificado/subtotalGrupo.codificado
        subtotalGrupo.comprometido += fila.comprometido;
        subtotalGrupo.porcen_comprometido = subtotalGrupo.comprometido/subtotalGrupo.codificado
        subtotalGrupo.devengado += fila.devengado;
        subtotalGrupo.porcen_devengado = subtotalGrupo.devengado/subtotalGrupo.codificado
        subtotalGrupo.disponible += fila.disponible;
        subtotalGrupo.porcen_disponible = subtotalGrupo.disponible/subtotalGrupo.codificado
        subtotalGrupo.pagado += fila.pagado;
        subtotalGrupo.porcen_pagado = subtotalGrupo.pagado/subtotalGrupo.codificado
        if (index === datos.length - 1) {
         // console.log("para sub"+index);
           // datosConSubtotales.push(this.asignarValorFila(subtotalGrupo));
           datosConSubtotales.push(subtotalGrupo);
           
        }
    });
//console.log("Datos con subtotales"+JSON.stringify(datosConSubtotales));
    return datosConSubtotales;
}


/**
 * Funcion llamada para la exportacion a excel del formulario
 */
 /* ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'GRUPO': x.grupo,
        'DESCRIPCIÓN': x.descripcion,
        'CODIFICADO': x.codificado,
        'DEVENGADO': x.devengado,
        'DIFERENCIA': x.diferencia,
        'PORCENTAJE': x.porcentaje,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }*/

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */
/*
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }*/


  FiltrarAsociacion() {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    this.rutaapi = "ProyectosInversion?sFechaHasta="+ sFechaHasta+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    //console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    //this.CargarGrid();
  }

 /* GraficarEjecucion() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
          const DatosArchivo: any = {
            tipo_reporte: "CO ASOCIADO",
            resultado:JSON.parse(data.result)
           // str_codigo_certificacion: str_codigo_certificacion
          };
      
          this.dialog.open(ApexchartComponent, {
            data: {
              DatosArchivo
            },
            width: '90%',
            height: '80%'
          });
          
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  /*  const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    this.rutaapi = "EjecucionPresupuestaria?sFechaHasta="+ sFechaHasta+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();*/
    //const str_codigo_certificacion =  this.codigoCertificacion;
   

 // }
  FiltroAutocomplete(opcion: string): void {
    switch (opcion)
    {
      case "Cmbnivel01":
      break;
    }
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT220_ESTADOEJEPRE";
    DatosPdf.param1=  sFechaHasta;
    DatosPdf.param2 = "";
    DatosPdf.param3 = "";
    DatosPdf.param4 = "";
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE


}


