import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';

import {MatRadioModule} from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
    selector: 'app-cedulagastosgrupo-list',
    templateUrl: './cedulagastosgrupo-list.component.html',
    styleUrl: './cedulagastosgrupo-list.component.scss',
    imports: [EditModule, ListModule, MatRadioModule
    ]
})


export class CedulagastosgrupoListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public fechaDesde = "";
  public nAnio = 2024;
  public sUltimoNivel = "";
  public total_asig_ini = 0;
  public total_reformas = 0;
  public total_codificado = 0;
  public total_comprometido = 0;
  public total_devengado = 0;
  public total_por_comprometer = 0;
  public total_por_devengar = 0;
  public total_pagado = 0;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/CeduladeGastosporGrupo";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "grupo",
  "descripcion",
  "asig_ini",
  "reformas",
  "codificado",
  "comprometido",
  "devengado",
  "por_comprometer",
  "por_devengar",
  "pagado",
  "porcen_eje",
];

public nivel: number = 0;
public nTipoPresupuestoID = 1;
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nAnio = this.ParamSessiones.anio;
    this.fechaDesde =  this.nAnio + "-01-01";
    const ffecha = new Date(this.fechaAct);
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }
    this.rutaapi = "CedulaGastosGrupo?sFechaHasta="+ this.fechaAct+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Txtfecha: this.fechaAct,
    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);

          this.total_asig_ini = this.resultado[0].total_asig_ini;
          this.total_reformas = this.resultado[0].total_reformas;
          this.total_codificado = this.resultado[0].total_codificado;
          this.total_comprometido = this.resultado[0].total_comprometido;
          this.total_devengado = this.resultado[0].total_devengado;
          this.total_por_comprometer = this.resultado[0].total_por_comprometer;
          this.total_por_devengar = this.resultado[0].total_por_devengar;
          this.total_pagado = this.resultado[0].total_pagado;

          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'GRUPO': x.grupo,
        'DESCRIPCIÓN': x.descripcion,
        'ASIG. INICIAL': x.asig_ini,
        'REFORMAS': x.reformas,
        'CODIFICADO': x.codificado,
        'COMPROMETIDO': x.comprometido,
        'DEVENGADO': x.devengado,
        'POR COMPROMETER': x.por_comprometer,
        'POR DEVENGAR': x.por_devengar,
        'PORCENTAJE': x.porcen_eje,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  FiltrarAsociacion() {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    this.rutaapi = "CedulaGastosGrupo?sFechaHasta="+ sFechaHasta+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }

  FiltroAutocomplete(opcion: string): void {
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT234_CEDULAGASTOS_POR_GRUPO";
    DatosPdf.param1=  sFechaHasta;
    DatosPdf.param2 = "";
    DatosPdf.param3 = "";
    DatosPdf.param4 = "";
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE


}


