import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import {MatRadioModule} from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';
import { ApexchartComponent } from '../ejecucionpresupuestaria-chart/apexchart.component';
import { MatExpansionModule } from '@angular/material/expansion';

@Component({
    selector: 'app-ejecucionpresupuestaria-list',
    templateUrl: './ejecucionpresupuestaria-list.component.html',
    imports: [EditModule, ListModule, MatRadioModule, MatDatepickerModule, MatExpansionModule,
    ]
})

export class EjecucionpresupuestariaListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  //public dataSource !:  MatTableDataSource<any>;
  public dataSource1 !:  MatTableDataSource<any>;
  public dataSource2 !:  MatTableDataSource<any>;
  public dataSource3 !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public fechaDesde = "";
  public nAnio = 2024;
  public sUltimoNivel = "";

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('Cmbnivel01') Cmbnivel01!: ElementRef<HTMLInputElement>;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/EjecucionPresupuestaria";
public rutaapi:string = "EjecucionPresupuestaria?codemp="+this.ParamSessiones.codemp.toString()+"&anio="+this.ParamSessiones.anio+"&fecha="+this.fechaAct+"&nivel=";
public rutaapigrupo:string = "EjecucionPresupuestaria/ListarPorGupoNaturaleza?codemp="+this.ParamSessiones.codemp.toString()+"&anio="+this.ParamSessiones.anio+"&fecha="+this.fechaAct;
/**COLUMNAS MOSTRADAS PRIMER GRID*/
public displayedColumns:string[] = [
  "out_cuenta",
  "out_nom_cue",
  "out_codificado",
  "out_certificado",
  "porcen_certificado",
  "out_comprometido",
  "porcen_comprometido",
  "out_devengado",
  "porcen_devengado",
  "disponible",
  "porcen_disponible",
  "out_pagado",
  "porcen_pagado",
];
columnTitles : { [key: string]: string } = {
  "out_cuenta":"CUENTA",
  "out_nom_cue":"DENOMINACIÓN",
  "out_codificado":"CODIFICADO",
  "out_certificado":"CERTIFICADO",
  "out_comprometido":"COMPROMETIDO",
  "porcen_pagado":"%EJE. PAG.",
  "porcen_certificado":"%EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "out_devengado":"DEVENGADO",
  "porcen_devengado":"%EJE. DEVEN.",
  "porcen_disponible":"%EJE. DISP.",
  "out_pagado":"PAGADO",
};

/**COLUMNAS MOSTRADAS SEGUNDO GRID*/
/*
public displayedColumns1:string[] = [
  "ugs_nombre",
  "codificado",
  "certificado",
  "porcen_certificado",
  "comprometido",
  "porcen_comprometido",
  "devengado",
  "porcen_devengado",
  "disponible",
  "porcen_disponible",
  "pagado",
  "porcen_pagado",
];

columnTitles1 : { [key: string]: string } = {
  "ugs_nombre":"DENOMINACION",
  "porcen_certificado":"%EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "porcen_devengado":"%EJE. DEVEN.",
  "porcen_disponible":"%EJE. DISP.",
  "porcen_pagado":"%EJE. PAG.",
};*/


/**COLUMNAS MOSTRADAS TERCER GRID*/
public displayedColumns2:string[] = [
  //"tipo",
  //"nom_tipo",
  "cuenta",
  "nom_cue",
  "asig_ini",
  "reformas",
  "codificado",
  "certificado",
  "porcen_certificado",
  "comprometido",
  "porcen_comprometido",
  "devengado",
  "porcen_devengado",
  "pagado",
  "porcen_pagado"
];


columnTitles2 : { [key: string]: string } = {
  "cuenta":"GRUPO",
  "nom_cue":"NOMBRE",
  "asig_ini":"ASIG. INI.",
  "porcen_certificado":"% EJE. CERT.",
  "porcen_comprometido":"%EJE. COMP.",
  "porcen_devengado":"%EJE. DEVEN.",
  //"porcen_disponible":"%EJE. DISP.",
  "porcen_pagado":"%EJE. PAG.",
};
public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public EstructuraNivelesIngresos!: any[];
public OpcionesNivelesIngresos!: any[];
public nTipoPresupuestoID = 1;
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nAnio = this.ParamSessiones.anio;
    const ffecha = new Date(this.fechaAct);
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }

    this.fechaDesde =  this.nAnio + "-01-01";
    //this.ServicioClienteHttp.SeteoRuta(this.rutaapi+1);  
    // toca ver que consuma el api 
    console.log("Buscando el api"+this.rutaapigrupo);

    this.ServicioClienteHttp.SeteoRuta(this.rutaapigrupo);
    this.CargarGrid1(2);//null
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+2);
    this.CargarGrid1(0);//null
  
    this.FormularioDatos = this.CrearFormulario();
  }

  nonSummableColumns: string[] = ["out_cuenta", "out_nom_cue","cuenta","nom_cue"];
  certificado: number = 0;
  codificado: number = 0;
  comprometido: number = 0;
  devengado: number = 0;
  disponible: number = 0;
  pagado: number = 0;
  campo: string = "";
  
  getTotal(column: string, dataSourceIndex: number): number | string {
    console.log("datasource nuevo"+dataSourceIndex+" "+column)
    this.campo = column;
  
    // Verificar si la columna no es sumable
    if (this.nonSummableColumns.includes(column)) {
      return column === this.nonSummableColumns[1] ? "TOTAL GENERAL" : "";
    }
  
    // Definir las fuentes de datos
    const dataSources = [
      this.dataSource1.data,
       this.dataSource2.data,
    ];
  
    // Verificar si el índice de la fuente de datos es válido
    if (dataSourceIndex < 0 || dataSourceIndex >= dataSources.length) {
      return 0;
    }
  
    const currentDataSource = dataSources[dataSourceIndex];
  
    // Si la columna no es un porcentaje, calcular la suma directamente
    if (!["porcen_certificado", "porcen_comprometido", "porcen_devengado", "porcen_disponible", "porcen_pagado"].includes(column)) {
      const total = currentDataSource.reduce((sum, row) => sum + (parseFloat(row[column]) || 0), 0);
      console.log("pruebas "+total);
      return Math.floor(total * 100) / 100;
    }
  
    // Definir el mapeo de columnas de porcentaje
    type ColumnMappingType = {
      porcen_certificado: string;
      porcen_comprometido: string;
      porcen_devengado: string;
      porcen_disponible: string;
      porcen_pagado: string;
    };
  
    const columnMapping: ColumnMappingType = {
      porcen_certificado: "out_certificado",
      porcen_comprometido: "out_comprometido",
      porcen_devengado: "out_devengado",
      porcen_disponible: "disponible",
      porcen_pagado: "out_pagado",
      
    };
  
    // Verificar si la columna es válida para calcular porcentajes
    if (column in columnMapping) {
      const targetColumn = columnMapping[column as keyof ColumnMappingType];
      const dividendo = currentDataSource.reduce((sum, row) => sum + (row[targetColumn] || 0), 0);
      this.codificado = currentDataSource.reduce((sum, row) => sum + (row["out_codificado"] || 0), 0);
  
      if (this.codificado !== 0) {
        const total = (dividendo / this.codificado) * 100;
             
        return  Math.floor(total * 100) / 100+"%";
      } else {
        console.log("No se recorrió todo el dataSet o el valor de 'codificado' es 0.");
        return 0;
      }
    } else {
      console.error(`La columna ${column} no es válida para calcular porcentajes.`);
      return 0;
    }
  }

  
  getTotal1(column: string, dataSourceIndex: number): number | string {
    this.campo = column;
  
    // Verificar si la columna no es sumable
    if (this.nonSummableColumns.includes(column)) {
      return column === this.nonSummableColumns[3] ? "TOTAL GENERAL" : "";
    }
  
    // Definir las fuentes de datos
    const dataSources = [
      this.dataSource1.data,
       this.dataSource2.data,
    ];
  
    // Verificar si el índice de la fuente de datos es válido
    if (dataSourceIndex < 0 || dataSourceIndex >= dataSources.length) {
      return 0;
    }
  
    const currentDataSource = dataSources[dataSourceIndex];
  
    // Si la columna no es un porcentaje, calcular la suma directamente
    if (!["porcen_certificado", "porcen_comprometido", "porcen_devengado", "porcen_disponible", "porcen_pagado"].includes(column)) {
      const total = currentDataSource.reduce((sum, row) => sum + (parseFloat(row[column]) || 0), 0);
      console.log("pruebas "+total);
      return Math.floor(total * 100) / 100;
    }
  
    // Definir el mapeo de columnas de porcentaje
    type ColumnMappingType = {
      porcen_certificado: string;
      porcen_comprometido: string;
      porcen_devengado: string;
      porcen_disponible: string;
      porcen_pagado: string;
    };
  
    const columnMapping: ColumnMappingType = {
      porcen_certificado: "certificado",
      porcen_comprometido: "comprometido",
      porcen_devengado: "devengado",
      porcen_disponible: "disponible",
      porcen_pagado: "pagado",
      
    };
  
    // Verificar si la columna es válida para calcular porcentajes
    if (column in columnMapping) {
      const targetColumn = columnMapping[column as keyof ColumnMappingType];
      const dividendo = currentDataSource.reduce((sum, row) => sum + (row[targetColumn] || 0), 0);
      this.codificado = currentDataSource.reduce((sum, row) => sum + (row["codificado"] || 0), 0);
  
      if (this.codificado !== 0) {
        const total = (dividendo / this.codificado) * 100;
        
      
        return  Math.floor(total * 100) / 100+"%";
      } else {
        console.log("No se recorrió todo el dataSet o el valor de 'codificado' es 0.");
        return 0;
      }
    } else {
      console.error(`La columna ${column} no es válida para calcular porcentajes.`);
      return 0;
    }
  }
  
  getFormattedValue(value: any): string {
    // Verificar si es un número
    if (typeof value !== 'number' || isNaN(value)) {
      return value;  // Retorna '0' si no es un número
    }

    // Retorna el valor truncado formateado como moneda
    return (Math.floor(value * 100) / 100).toFixed(2);
  }

  

  CrearFormulario(): UntypedFormGroup {
  
    return this.formBuild.group({
      Txtfecha: this.fechaAct,
    });
  }

  CargarGrid1(dataSourceIndex:number) {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
          switch(dataSourceIndex){
            case 0:

            this.dataSource1 = new MatTableDataSource(this.resultado);
            this.dataSource1.sort = this.sort;
          break; 
              case 2:              
                this.dataSource2 = new MatTableDataSource(this.agregarSubtotales(this.resultado));
                this.dataSource2.sort = this.sort;
              break;
              default:
                break;
          } 
        }
        else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }
  
  agregarSubtotales(datos: any[]): any[] {
    const datosConSubtotales: any[] = [];
    let grupoActual: string | null = null;
    let grupoI: string | null = null;
    let subtotalGrupo: any = {};

    datos.forEach((fila, index) => {
        // Si cambia el grupo, agregar el subtotal del grupo anterior
        if (grupoActual !== fila.nom_tipo) {
            if (grupoActual !== null) {
                datosConSubtotales.push(subtotalGrupo); // Agregar subtotal
            }
 
            // Iniciar un nuevo subtotal
            grupoActual = fila.nom_tipo;
            grupoI=fila.tipo;

            subtotalGrupo = {
                grupoI:` ${grupoI}`,
                grupo:  ` ${grupoActual}`,
                asig_ini:0,
                reformas:0,
                codificado: 0,
                certificado: 0,
                porcen_certificado: 0,
                comprometido:0,
                porcen_comprometido:0,
                devengado:0,
                porcen_devengado:0,
                disponible:0,
                porcen_disponible:0,
                pagado:0,
                porcen_pagado:0,
                isSubtotal: true // Marcar como fila de subtotal
            };
            
            // Agregar la fila actual
           const filaSinUgsNombre = { ...fila,  };  // Limpiar el nombre del grupo para las filas internas
            datosConSubtotales.push(filaSinUgsNombre);
        }else {
            // Para las filas siguientes del grupo, eliminar el ugs_nombre
            const filaSinUgsNombre = { ...fila, nom_tipo: '' };
            datosConSubtotales.push(filaSinUgsNombre);
        }

        // Sumar al subtotal
        subtotalGrupo.asig_ini+=fila.asig_ini;
        subtotalGrupo.reformas += fila.reformas;
        subtotalGrupo.codificado += fila.codificado;
        subtotalGrupo.certificado += fila.certificado;
        subtotalGrupo.porcen_certificado = subtotalGrupo.certificado/subtotalGrupo.codificado
        subtotalGrupo.comprometido += fila.comprometido;
        subtotalGrupo.porcen_comprometido = subtotalGrupo.comprometido/subtotalGrupo.codificado
        subtotalGrupo.devengado += fila.devengado;
        subtotalGrupo.porcen_devengado = subtotalGrupo.devengado/subtotalGrupo.codificado
        subtotalGrupo.disponible += fila.disponible;
        subtotalGrupo.porcen_disponible = subtotalGrupo.disponible/subtotalGrupo.codificado
        subtotalGrupo.pagado += fila.pagado;
        subtotalGrupo.porcen_pagado = subtotalGrupo.pagado/subtotalGrupo.codificado
       
        // Si es la última fila, agregar el subtotal del último grupo
        if (index === datos.length - 1) {
           datosConSubtotales.push(subtotalGrupo);
           
        }
    });

    return datosConSubtotales;
}

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  /*
  CargarGrid(dataSourceIndex:number) {//param: number | null

    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
    
        if (data.success) {
          this.resultado = JSON.parse(data.result);
              
          switch(dataSourceIndex){

              case 0:

                this.dataSource1 = new MatTableDataSource(this.resultado);
                this.dataSource1.sort = this.sort;
              break;           
              default:
                break;
          }        
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }
*/
/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource1.filteredData.map((x) => ({
        'GRUPO': x.grupo,
        'DESCRIPCIÓN': x.descripcion,
        'CODIFICADO': x.codificado,
        'DEVENGADO': x.devengado,
        'DIFERENCIA': x.diferencia,
        'PORCENTAJE': x.porcentaje,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */
/*
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }*/


  FiltrarAsociacion() {
    this.ngOnInit();  
  }
  RealizarEjecucionPresupuestaria() {
    const partes = this.fechaAct.split('-'); // Divide la cadena en partes
    const anio = parseInt(partes[2]);   
    this.rutaapi = "EjecucionPresupuestaria?codemp="+this.ParamSessiones.codemp.toString()+"&anio="+anio+"&fecha="+this.fechaAct+"&nivel=";
    this.rutaapigrupo = "EjecucionPresupuestaria/ListarPorGupoNaturaleza?codemp="+
    this.ParamSessiones.codemp.toString()+"&anio="+anio+"&fecha="+this.fechaAct;

    this.ServicioClienteHttp.SeteoRuta(this.rutaapigrupo);
    this.CargarGrid1(2);//null
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+2);
    this.CargarGrid1(0);//null
  
    this.FormularioDatos = this.CrearFormulario();
  }



  FiltroAutocomplete(opcion: string): void {
    switch (opcion)
    {
      case "Cmbnivel01":
      break;
    }
  }
// estoy buscando el contenido de la fila de subtotal
asignarValorFila(fila: any,subtotal: any,column: any,grupo: any,
  grupoI: any,certi: any,comp:any,dev:any,pag:any): any {
  console.log("dataset1: "+certi+" "+comp);
     if (subtotal && column=="nom_cue"){  
       if (grupo  )   //&& grupo.includes("Subtotal")
       fila=` ${grupo}`;}

       if (subtotal && column=="cuenta"){  
        if (grupoI  )   //&& grupo.includes("Subtotal")
        fila=` ${grupoI}`;
      }
    
     if (column=="porcen_certificado" )
     { 

      fila=parseFloat(certi.toFixed(2))+"%"; 
     }  
     if (column=="porcen_comprometido" )
      { 
       fila=parseFloat(comp.toFixed(2))+"%"; 
      } 
      if (column=="porcen_devengado" )
        { 
         fila=parseFloat(dev.toFixed(2))+"%"; 
        } 
      if (column=="porcen_pagado" )
          { 
           fila=parseFloat(pag.toFixed(2))+"%"; 
          } 
          if (column=="porcen_disponible" )
            { 
             fila=parseFloat(dev.toFixed(2))+"%"; 
            }
      return fila;
    }
 
  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT220_ESTADOEJEPRE";
    DatosPdf.param1=  sFechaHasta;
    DatosPdf.param2 = "";
    DatosPdf.param3 = "";
    DatosPdf.param4 = "";
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE
}


