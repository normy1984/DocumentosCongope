import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { configapp } from '@config/configapp';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { ParamSessionMo } from 'app/models/param-session';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';

@Component({
    selector: 'app-certificacion-compromiso-no-utilizados',
    imports: [
        ListModule,
        EditModule,
        MatDatepickerModule
    ],
    // ESTA PARTE DE LOS PROVIDERS CAMBIA LOS OBJETOS DE ANGULAR MATERIAL A ESPAÑOL
    providers: [DatePipe,
        { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
        {
            provide: DateAdapter,
            useClass: MomentDateAdapter,
        },
    ],
    templateUrl: './certificacion-compromiso-no-utilizados.component.html'
})
export class CertificacionCompromisoNoUtilizadosComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public tituloPagina: string = "";
  private SigTip: string = "";
  public dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public FormularioDatos!: UntypedFormGroup;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('picker_fecha_inicial') picker_fecha_inicial!: MatDatepicker<Date>;
  @ViewChild('picker_fecha_final') picker_fecha_final!: MatDatepicker<Date>;

  protected anioActual = parseInt(new Date().getFullYear().toString(), 10);
  protected anioSeleccionado: number = parseInt(sessionStorage.getItem('codigoAnio') || new Date().getFullYear().toString(), 10);

  public minDate_inicio = new Date(this.anioSeleccionado, 0, 1);
  public maxDate_inicio = (this.anioSeleccionado == this.anioActual) ? new Date() : new Date(this.anioSeleccionado, 11, 31);
  public minDate_fin = new Date(this.anioSeleccionado, 0, 1);
  public maxDate_fin = (this.anioSeleccionado == this.anioActual) ? new Date() : new Date(this.anioSeleccionado, 11, 31);

     // Rutas de la API y navegación
  private rutaapi: string = "CertificacionCompromisoNoUtilizados";
  

  public listDepartamentos: any[] = [];
  public listEstados: any[] = [];
  
/**
 * COLUMNAS A MOSTRAR EN EL LISTADO PRINCIPAL
 */
public displayedColumns: string[] = [
 "siglasnum", "fecha", "estado",
   "documento", "concepto", "valor", 
];


  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    public alertas: AlertasSrvService,
    public formBuild: FormBuilder,
    public dialog: MatDialog,
  ) {

    super();
    this.FormularioDatos = this.CrearFormulario();
    // Suscripción a eventos del router para manejar la navegación de la página
    const rutaActual = this.router.url;
    this.tituloPagina = rutaActual && rutaActual.includes('Compromiso') ? "Compromisos" : "Certificados";
    this.SigTip = rutaActual && rutaActual.includes('Compromiso') ? "CO" : "CE";
  }

  ngOnInit(): void {
    this.CargarGrid();
    this.CambiarFechas();
  }

  /**
   * Función llamada para la exportación a Excel del formulario.
   */
  ExportarExcel() {
     const exportData: Partial<TableElement>[] =
       this.dataSource.filteredData.map((x) => ({
         'NUMERO': x.siglasnum,
         'FECHA': x.fecha,
         'ESTADO': x.estado,
         'DOCUMENTO': x.documento,
         'DESCRIPCION': x.concepto,
         'VALOR': x.valor,
       }));
   
     TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
    * Función que realiza los filtrados de los grids.
    * @param event Evento de entrada del filtro.
    */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  /**
   * Abre el selector de fecha de asignación.
   */
  AbrirPickerFechaInicial(): void {
    this.picker_fecha_inicial.open();
  }

  /**
   * Abre el selector de fecha de aprobación.
   */
  AbrirPickerFechaFinal(): void {
    this.picker_fecha_final.open();
  }


  /***
   * Funcion que crea el formulario inicial utilizado para este reporte
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      fecha_inicial: [this.minDate_inicio],
      fecha_final: [this.maxDate_fin],
      departamento: [0],
      estado: [0],
    });
  }

  

  /**
 * Funcion que carga el listado principal de datos
 */
  CargarGrid()
    {

      const ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
      const DatosCarga = {
        fecha_inicio: this.minDate_fin,
        fecha_final: this.maxDate_inicio,
        codemp: ParamSessiones.codemp,
        departamento : this.FormularioDatos.get('departamento')?.value,
        estado : this.FormularioDatos.get('estado')?.value,
        tipo: this.SigTip
      };

      this.ServicioClienteHttp.SeteoRuta(this.rutaapi)
      this.ServicioClienteHttp.Insertar(DatosCarga).subscribe({
        next: (data) => {
          if (data.success) {
            let resultado: any = data.result;
            this.dataSource = new MatTableDataSource(resultado);

            /**ESTOS IF CARGAN LOS FILTROS SOLO CON LOS QUE EXISTEN EN LA CONSULTA */
            if(this.listDepartamentos.length === 0)
            {
              this.CargarDepartamentos(resultado);
            }
            if(this.listEstados.length === 0)
              {
                this.CargarEstados(resultado);
              }
            
            
         
          } else {
            this.dataSource = new MatTableDataSource<any>([]);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }

    /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
ImprimirReporte() {

  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT_CO_CE_NO_UTILIZADO";
  DatosPdf.param1= this.minDate_fin.toISOString();
  DatosPdf.param2=this.maxDate_inicio.toISOString();
  DatosPdf.param3= this.FormularioDatos.get('departamento')?.value.toString();
  DatosPdf.param4=this.FormularioDatos.get('estado')?.value.toString();
  DatosPdf.param5=this.SigTip.toString();

  this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}


/**
 * Funcion que valida que las fechas no se desborden entre los calendarios
 */
CambiarFechas(): void {
  this.FormularioDatos.get('fecha_inicial')?.valueChanges.subscribe((fecha_inicial: Date) => {
    const currentFinalDate = this.FormularioDatos.get('fecha_final')?.value;
    if (fecha_inicial && (!this.minDate_fin || fecha_inicial !== this.minDate_fin)) {
      this.minDate_fin = fecha_inicial;
      this.FormularioDatos.get('fecha_final')?.updateValueAndValidity(); // Trigger validation on fecha_final
    }
    if (currentFinalDate && fecha_inicial > currentFinalDate) {
      this.FormularioDatos.get('fecha_final')?.setValue(null);
    }
  });

  this.FormularioDatos.get('fecha_final')?.valueChanges.subscribe((fecha_final: Date) => {
    if (fecha_final && (!this.maxDate_inicio || fecha_final !== this.maxDate_inicio)) {
      this.maxDate_inicio = fecha_final;
      this.FormularioDatos.get('fecha_inicial')?.updateValueAndValidity(); // Trigger validation on fecha_inicial
    }
  });
}

/**
 * Funcion que carga unicamente los departamentos que existen en las consultas
 * @param data 
 */
CargarDepartamentos(data: any) {
  this.listDepartamentos = Array.from(new Set(data.map((item: any) => item.cod_departamento)))
    .map((cod_departamento: any) => {
      const item = data.find((item: any) => item.cod_departamento === cod_departamento);
      if (item.cod_departamento > 0) {
        return { codigo: item.cod_departamento, descrip: item.departamento };
      }
      return null; // Handle the case where item is undefined
    })
    .filter((item: any) => item !== null); // Remove any null values
  }

  /**
   * Funcion que carga solo los estados presentes en las consultas
   * @param data 
   */
  CargarEstados(data: any) {
    this.listEstados = Array.from(new Set(data.map((item: any) => item.cod_estado)))
      .map((cod_estado: any) => {
        const item = data.find((item: any) => item.cod_estado === cod_estado);
        if (item.cod_estado > 0) {
          return { codigo: item.cod_estado, descrip: item.estado };
        }
        return null; // Handle the case where item is undefined
      })
      .filter((item: any) => item !== null); // Remove any null values
    }

}
