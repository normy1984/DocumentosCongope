import { Component, Inject, Input, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
    selector: 'app-vercertificadocompromiso-list',
    templateUrl: './vercertificadocompromiso-list.component.html',
    imports: [EditModule, ListModule,
    ]
})

export class VercertificadocompromisoListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  @Input('param') param!: string;
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public evento: string = "";
  //public sPartida = "";
  public sCertificacion="";
  public sCertificado = 0;
  public sUtilizado = 0;
  public sPorUtilizar = 0;
  public nAnio = 0;
  //public pk_identificador: number = 0;
  objetoArchivo!: any;


  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/VerSaldoPartida";
public rutaapi:string = "";

//
/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [

  "fecha",
  "compromiso",
  "partida",
  "nombre",
  "descripcion",
  "valor",
];

public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public EstructuraNivelesIngresos!: any[];
public OpcionesNivelesIngresos!: any[];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<VercertificadocompromisoListComponent>,
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nAnio = this.ParamSessiones.anio;
    this.objetoArchivo = this.data.DatosArchivo;
    
    this.sCertificacion = this.objetoArchivo.str_codigo_certificacion;
    let arrayCertificacion=this.sCertificacion.split(" ");
    
    this.rutaapi ="Certificacion?codemp="+this.ParamSessiones.codemp+
    "&sigtip=CE&acutip="+ arrayCertificacion[1]+"&anio="+this.ParamSessiones.anio;
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Opting: 1,
      Txtpartida:"",
      Txtfecha: this.fechaAct,
      Chktodos:0,
      Cmdoperador:"1",
    });
  }

  /** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.valor)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {

          this.resultado = JSON.parse(data.result);       
          this.sCertificacion = this.objetoArchivo.str_codigo_certificacion;
          this.sCertificado =this.resultado[0].out_val_cert;
          this.sUtilizado = this.resultado[0].var_utilizado;
          this.sPorUtilizar = this.resultado[0].out_por_utilizar;
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'PARTIDA': x.partida,
        'DESCRIPCION': x.nombre,
        'ASIG. INICIAL': x.asig_ini,
        'REFORMAS': x.reformas,
        'CODIFICADO': x.codificado,
        'COMPROMETIDO': x.comprometido,
        'DEVENGADO': x.devengado,
        'POR COMPROMETER': x.por_comprometer_real,
        'POR DEVENGAR': x.por_devengar,
        'PAGADO': x.pagado,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  /*FiltrarCedula() {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nTipoPresupuesto = this.FormularioDatos.get('Opting')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel; //this.FormularioDatos.get('Cmbnivel')?.value;
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }
    const sPartida = this.FormularioDatos.get('Txtpartida')?.value;

    if(nNivel == 0){
      this.alertas.MensajeError("Debe seleccionar el nivel");
      return;
    }
    this.rutaapi = "CedulaPresupuestaria?codemp=0004&fecha_hasta=" + sFechaHasta +"&ing_gas=" + nTipoPresupuesto +"&nTodos=" + nVerTodos +"&nNivel=" + nNivel +"&sOperador="+ sOperador +"&spartida="+sPartida+"";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }
*/

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nTipoPresupuesto = this.FormularioDatos.get('Opting')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel.toString();
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT_CEDULA_GASTOS";
    DatosPdf.param1 = sFechaHasta;
    DatosPdf.param2 = nTipoPresupuesto.toString();
    DatosPdf.param3 = nVerTodos.toString();
    DatosPdf.param4 = nNivel.toString();
    DatosPdf.param5 = sOperador;

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE
}


