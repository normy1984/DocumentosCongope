import { Component } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { FileUploadComponent } from '@shared/components/file-upload/file-upload.component';
import { EmpresasMo } from 'app/models/administracion/empresas-mo';
import { ParamSessionMo } from 'app/models/param-session';
import { EditModule } from 'app/paginas/generico/edit.module';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import Swal from 'sweetalert2';

@Component({
    selector: 'app-empresas-edit',
    imports: [EditModule, FileUploadComponent],
    templateUrl: './empresas-edit.component.html'
})
export class EmpresasEditComponent {

  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  private rutaapi: string = "Empresa";

  private VarSesion: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  public FormularioDatos!: UntypedFormGroup;
  private ModeloDatos: EmpresasMo = new EmpresasMo({} as EmpresasMo);
  public EstructuraProvincias:any[] = [];
  public EstructuraCantones:any[] = [];
  public EstructuraTipoEmpleador:any[] = [];
  public EstructuraEnteSeguridad:any[] = [];
  blobUrl !: any;
  pdfSrc!: SafeResourceUrl;

  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService,
    private formBuild: FormBuilder,
    private sanitizer: DomSanitizer
  ) {
    this.FormularioDatos = this.CrearFormulario();
  }

  ngOnInit() {
    this.CargarFormInicial();
    this.CargarDemografico();
    this.CargarEnteSeguridad();
    this.CargarTipoEmpleador();
  }


  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      ruc_emp: [this.ModeloDatos.ruc_emp, [Validators.required]],
      nom_emp: [this.ModeloDatos.nom_emp, [Validators.required]],
      nomcomercial: [this.ModeloDatos.nomcomercial, [Validators.required]],
      region: [this.ModeloDatos.region, [Validators.required]],
      provincia: [this.ModeloDatos.provincia, [Validators.required]],
      ciudad: [this.ModeloDatos.ciudad, [Validators.required]],
      dir_emp: [this.ModeloDatos.dir_emp, [Validators.required]],
      email1: [this.ModeloDatos.email1, [Validators.required]],
      contrib_espe: [this.ModeloDatos.contrib_espe],
      tel1_emp: [this.ModeloDatos.tel1_emp, [Validators.required]],
      tel2_emp: [this.ModeloDatos.tel2_emp],
      fax1_emp: [this.ModeloDatos.fax1_emp],
      rep_emp: [this.ModeloDatos.rep_emp, [Validators.required]],
      rep_ruc: [this.ModeloDatos.rep_ruc, [Validators.required]],
      dfin_emp: [this.ModeloDatos.dfin_emp, [Validators.required]],
      dfin_ruc: [this.ModeloDatos.dfin_ruc, [Validators.required]],
      cont_emp: [this.ModeloDatos.cont_emp, [Validators.required]],
      cont_ruc: [this.ModeloDatos.cont_ruc, [Validators.required]],
      nodeviva: [this.ModeloDatos.nodeviva, [Validators.required]],
      t_factura: [this.ModeloDatos.t_factura, [Validators.required]],
      obligado_conta: [this.ModeloDatos.obligado_conta, [Validators.required]],
      tipoemplea: [this.ModeloDatos.tipoemplea, [Validators.required]],
      ente_ss: [this.ModeloDatos.ente_ss, [Validators.required]],
      serieret: [this.ModeloDatos.serieret, [Validators.required]],
      autoret: [this.ModeloDatos.autoret, [Validators.required]],
      aut_liq_comp: [this.ModeloDatos.aut_liq_comp, [Validators.required]],
      uploadFile: [''],
    });
  }

CargarFormInicial() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.ServicioClienteHttp.Obtener_x_Codigo(this.VarSesion.codemp).subscribe({
      next: (data) => {
        if (data.success) {
          this.ModeloDatos = new EmpresasMo(data.result[0]);
          this.FormularioDatos = this.CrearFormulario();
          const base64Pdf = data.result[0].imagenBase64;
          this.CargarDemografico(this.ModeloDatos.provincia);
          //const ContentType = data.ContentType;
          const blob = this.base64toBlob(base64Pdf, "image/png", "logo");
          this.blobUrl = URL.createObjectURL(blob);
          this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(this.blobUrl);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    });
  }


  CargarDemografico(CodigoPadre:any = '001'):void {
    CodigoPadre = (CodigoPadre === "001") ? CodigoPadre : "001."+ ('00' + CodigoPadre).slice(-2);
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"/DatosDemograficos");
    this.ServicioClienteHttp.Obtener_x_Codigo(CodigoPadre).subscribe({
      next: (data) => {
        if (data.success) {
          if(CodigoPadre==='001')
            {
              this.EstructuraProvincias = JSON.parse(data.result);
            }
          else{
            
             this.EstructuraCantones = JSON.parse(data.result);
             // Actualiza los campos del formulario con los datos obtenidos
             /* this.FormularioDatos.patchValue({
                num_com: this.ModeloDatos.ciudad,
              });*/
          }
          
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    });
  }


  CargarTipoEmpleador():void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"/TipoEmpleador");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.EstructuraTipoEmpleador= JSON.parse(data.result);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    });
  }

  CargarEnteSeguridad():void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"/EnteSeguridad");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.EstructuraEnteSeguridad= JSON.parse(data.result);
          console.log(this.EstructuraEnteSeguridad);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    });
  }

  
  /**
   * Funcion que retorna un blob a partir de un string en base 64
   * @param base64String 
   * @param contentType 
   * @returns 
   */
  base64toBlob(base64String: string, contentType: string, fileName: string): Blob {
    const byteCharacters = atob(base64String);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    // Crear un Blob a partir de los bloques de bytes y asignarle el nombre del archivo
    return new Blob(byteArrays, { type: contentType });
  }


  GuardarInformacion(): void {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    Swal.fire({
      title: "¿Está seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        const datosGuardar = this.FormularioDatos.getRawValue();

        // Esto reemplazará solo las propiedades que existen en both, myObject y formValues
        this.ModeloDatos = { ...this.ModeloDatos, ...datosGuardar };
        this.ModeloDatos = { ...this.ModeloDatos, ...this.VarSesion };
        // Convierto toda la informacion en un formData ya que este modelo de datos tiene un file
        const formData = this.objectToFormData(this.ModeloDatos);

        //formData.append('file', datosGuardar.uploadFile);
              
        this.ServicioClienteHttp.Insertar(formData).subscribe({
          next: (data) => {
           
            if (data.success) {
              this.CargarFormInicial();
               const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.onmouseenter = Swal.stopTimer;
                  toast.onmouseleave = Swal.resumeTimer;
                }
              });
              Toast.fire({
                icon: "success",
                title: "Registros actualizados exitosamente"
              });
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
    
        });
        
        
 

      }
    });
  }


  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const validImageTypes = ['image/jpeg', 'image/png'];
      if (!validImageTypes.includes(file.type)) {
        this.alertas.MensajeAlerta('Por favor seleccione una imagen válida (JPG o PNG)')
        this.FormularioDatos.get('uploadFile')?.setValue(''); // Clear the form control value
      } 
    }
  }

  // Función para agregar las propiedades de un objeto a FormData
  objectToFormData(obj: any, form: FormData = new FormData(), namespace: string = ''): FormData {
    for (let propertyName in obj) {
      if (!obj.hasOwnProperty(propertyName) || obj[propertyName] === null || obj[propertyName] === undefined) {
        continue;
      }
  
      const formKey = namespace ? `${namespace}[${propertyName}]` : propertyName;
      if (typeof obj[propertyName] === 'object' && !(obj[propertyName] instanceof File)) {
        // Si la propiedad es un objeto (pero no un File), llamar recursivamente
        this.objectToFormData(obj[propertyName], form, formKey);
      } else {
        // Si la propiedad es un valor simple o un File, añadirlo a FormData
        form.append(formKey, obj[propertyName]);
      }
    }
    return form;
  }
  
  
  
}
