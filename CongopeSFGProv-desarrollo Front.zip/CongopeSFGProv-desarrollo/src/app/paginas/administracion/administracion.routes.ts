import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { UsuariosListComponent } from "./usuarios/usuarios-list/usuarios-list.component";
import { UsuariosEditComponent } from "./usuarios/usuarios-edit/usuarios-edit.component";
import { EmpresasEditComponent } from "./empresas/empresas-edit/empresas-edit.component";
import { UsuariosNuevoComponent } from "./usuarios/usuarios-nuevo/usuarios-nuevo.component";
import { ParametrosgeneralesListComponent } from "../params/parametrosgenerales-list/parametrosgenerales-list.component";

export const ADMINISTRACION_ROUTE: Route[] = [
  {
    path: "AdministraciondeUsuarios",
    component: UsuariosListComponent,
  },
  
  {
    path: "AdministraciondeUsuarios/usuariosNuevo",
    component: UsuariosNuevoComponent,
  },
  {
    path: "AdministraciondeUsuarios/:param",
    component: UsuariosEditComponent,
  }
  ,
  {
    path: "empresa",
    component: EmpresasEditComponent,
  },
  {
    path: "Configuracion",
    component: ParametrosgeneralesListComponent,
  },
  { path: "**", component: Page404Component },
  
];

