
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { MatDialog } from '@angular/material/dialog';
import { EditModule } from 'app/paginas/generico/edit.module';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';


@Component({
    selector: 'app-usuarios-list',
    templateUrl: './usuarios-list.component.html',
    imports: [
        ListModule, EditModule
    ]
})
export class UsuariosListComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource !: MatTableDataSource<any>;
  public TipoLoginLdap:boolean = true;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  public FormularioDatos: UntypedFormGroup = this.CrearFormulario();
  private datosOriginales: any[] = []; // Variable para guardar los datos originales


  /**
   * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public pagina: string = "Sistema/AdministraciondeUsuarios";
  public rutaapi: string = "Usuarios";

  /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [
    "accion",
    "cedruc",
    "descripcion",
    "email1",
    "es_admin",
    "estado"];

  constructor(
    private router: Router,
    public dialog: MatDialog,// Agrega MatDialog aquí,
    public formBuild: FormBuilder,
  ) {
    super();
  }


  ngOnInit() {

    this.CargarTipoAutenticacion();
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      filtro_estado: [1],
    });
  }

  CargarGrid() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any[] = JSON.parse(data.result);
          this.datosOriginales = resultado; // Guardar datos originales
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.sort = this.sort;
          this.AplicarFiltro();
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  AplicarFiltro() {
    let datosFormulario = this.FormularioDatos.getRawValue();
    if (datosFormulario.filtro_estado === 0) {
      // Si no hay filtro, mostrar todos los datos
      this.dataSource.data = this.datosOriginales;
    } else {
      // Aplicar el filtro localmente
      this.dataSource.data = this.datosOriginales.filter(item => item.estado_registro === datosFormulario.filtro_estado);
    }
  }


  CargarTipoAutenticacion() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+ '/ValidarTipoIngreso');
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.TipoLoginLdap = data.result;
          this.CargarGrid();
        }
        else {
          console.log(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    this.router.navigate([this.pagina + '/usuariosNuevo']);
  }




  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto 
   */

  EditarRegistro(CodUsu: number) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + CodUsu)
    this.router.navigate(['/' + this.pagina, parametro]);
  }


  ActivarUsuario(datos: any) {
    Swal.fire({
      title: "¿Está seguro de activar a " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Activar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/ActivarUsuario')
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Usuario activado existosamente!!", true);
              this.CargarGrid();
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });



  }

  InactivarUsuario(datos: any) {
    Swal.fire({
      title: "¿Está seguro de inactivar a " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Inactivar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/InactivarUsuario')
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Usuario inactivado existosamente", true);
              this.CargarGrid();
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }


  ResetearContrasena(datos: any) {
    Swal.fire({
      title: "¿Está seguro de resetear la contraseña de " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Resetear",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/ResetearContrasena');
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario,{},true).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Se envio un correo electrónico con la contraseña a "+ datos.email1, true);
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }



  /**
   * Funcion llamada para la exportacion a excel del formulario
   */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CODIGO': x.codtab,
        'DESCRIPCION': x.descrip,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   * 
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}