import { Component, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListModule } from 'app/paginas/generico/list.module';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-usuarios-nuevo',
    imports: [ListModule, EditModule],
    templateUrl: './usuarios-nuevo.component.html'
})
export class UsuariosNuevoComponent 
extends UnsubscribeOnDestroyAdapter
implements OnInit {

  public FormularioDatos: UntypedFormGroup = this.CrearFormulario();
  public rutaapi: string = "Usuarios";
  private pagina = "Sistema/AdministraciondeUsuarios";

constructor(
  public formBuild: FormBuilder,
  private ServicioClienteHttp: ClienthttpCongopeService,
  private alertas: AlertasSrvService,
  private ServicioCrypt : CryptService,
  private router: Router,
)
{
super();
}

ngOnInit(): void {
  
}

CrearFormulario(): UntypedFormGroup {
  return this.formBuild.group({
    nombres: ['', [Validators.required]],
    apellidos: ['', [Validators.required]],
    cedruc: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]*$')]],
    correo_origen: ['', [Validators.required, Validators.email, Validators.minLength(5)]],
  });
}

/**
 * FUNCION QUE GUARDA EL NUEVO USUARIO
 */

GuardarUsuario():void{

  let datosGuardar = this.FormularioDatos.getRawValue();

  const InsertarUsuario = {
    Descrip: datosGuardar.nombre.toUpperCase() + ' ' + datosGuardar.apellidos.toUpperCase(),
    Cedruc: datosGuardar.cedruc,
    Correo_origen : datosGuardar.correo_origen
  }
  this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/InsertarUsuario");
    this.ServicioClienteHttp.Insertar(InsertarUsuario, true).subscribe({
      next: (data) => {
        if (data.success) {

          let result = data.result;
          let parametro = this.ServicioCrypt.encryptString("EDITAR||" + result.codusu)
          this.alertas.MensajeExito(this.pagina, result.mensaje, parametro);
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
}

 /**
 * Funcion que dirige a la pantalla para el nuevo registro
 */
 VolverPagina() {
  this.router.navigate(['/' + this.pagina]);
}

}
