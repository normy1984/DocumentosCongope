import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { FuentesfinanciamientoListComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-list/fuentesfinanciamiento-list.component";
import { FuentesfinanciamientoEditComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-edit/fuentesfinanciamiento-edit.component";
import { ListaCiuListComponent } from "../generico/lista-ciu-list/lista-ciu-list.component";
import { ListaCiuEditComponent } from "../generico/lista-ciu-edit/lista-ciu-edit.component";
import { EstructuraCuentasPartidasListComponent } from "./estructura-cuentas-partidas/estructura-cuentas-partidas-list/estructura-cuentas-partidas-list.component";
import { ContabilidadPlanCuentasEditComponent } from "./estructura-cuentas-partidas/contabilidad-plan-cuentas-edit/contabilidad-plan-cuentas-edit.component";
import { NuevaCuentasPartidasComponent } from "./estructura-cuentas-partidas/nueva-cuentas-partidas/nueva-cuentas-partidas.component";
import { EmpleadosListComponent } from "./empleados/empleados-list/empleados-list.component";
import { EmpleadosEditComponent } from "./empleados/empleados-edit/empleados-edit.component";


export const CATALOGOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "dashboard1",
    pathMatch: "full",
  },
  {
    path: "FuentesFinanciamiento",
    component: FuentesfinanciamientoListComponent,
  },
  {
    path: "FuentesFinanciamiento/:ffn_id",
    component: FuentesfinanciamientoEditComponent,
  },
  {
    path: "CodigodeIdentificacionUnica",
    component: ListaCiuListComponent,
  },
  {
    path: "CodigodeIdentificacionUnica/:param",
    component: ListaCiuEditComponent,

  },
  {
    path: "PartidasdeGasto",
    component: EstructuraCuentasPartidasListComponent
  },
  {
    path: "PartidasdeIngreso",
    component: EstructuraCuentasPartidasListComponent
  },
  {
    path: "PlandeCuentas",
    component: EstructuraCuentasPartidasListComponent
  },
  
  {
    path: "MaestroArticulos",
    component: EstructuraCuentasPartidasListComponent
  }
  ,
  {
    path: "EstructuraOrganizacional",
    component: EstructuraCuentasPartidasListComponent
  },
  {
    path: "PlanCuentasContabilidad/:param",
    component: ContabilidadPlanCuentasEditComponent
  },
  {
    path: "NuevaEstructuraCuentaPartida/:param",
    component: NuevaCuentasPartidasComponent
  },
  {
    path: "Empleados",
    component: EmpleadosListComponent
  },
  {
    path: "Empleados/:param",
    component: EmpleadosEditComponent
  },
  { path: "**", component: Page404Component },

];

