import { Component } from '@angular/core';

@Component({
  selector: 'app-empleados-controles',
  standalone: true,
  imports: [],
  templateUrl: './empleados-controles.component.html'
})
export class EmpleadosControlesComponent {

}
