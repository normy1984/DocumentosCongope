import { Component } from '@angular/core';

@Component({
  selector: 'app-empleados-laborales',
  standalone: true,
  imports: [],
  templateUrl: './empleados-laborales.component.html'
})
export class EmpleadosLaboralesComponent {

}
