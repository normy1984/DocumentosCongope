import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatTabGroup, MatTabsModule } from '@angular/material/tabs';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { EditModule } from 'app/paginas/generico/edit.module';
import { EmpleadosPersonalesComponent } from "../empleados-personales/empleados-personales.component";
import { CryptService } from 'app/servicios/generico/crypt.service';
import { Route, Router } from '@angular/router';
import { EmpleadosBancariosComponent } from "../empleados-bancarios/empleados-bancarios.component";

@Component({
    selector: 'app-empleados-edit',
    imports: [EditModule, MatTabsModule, EmpleadosPersonalesComponent, EmpleadosBancariosComponent],
    templateUrl: './empleados-edit.component.html'
})
export class EmpleadosEditComponent extends UnsubscribeOnDestroyAdapter implements OnInit {

  @Input('param') param!: string;
  @ViewChild('tabGroup', { static: true }) tabGroup!: MatTabGroup;
  selectedTabIndex: number = 0; // Índice inicial
  selectedTabLabel: string = ''; // Variable para guardar el label del tab
  
  public pagina: string = "Catalogos/Empleados";
  public rutaapi: string = "Empleados";

  public cedruc:string = '';
  public NombreEmpleado:string = '';

  constructor(
    private cdr: ChangeDetectorRef,
    private ServicioCrypt :CryptService,
    private router: Router,
  ) {
    super();
  }

  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.cedruc = arrayResultado[1];
  }

  ngAfterViewInit() {
    this.setSelectedTabLabel();
    this.cdr.detectChanges();
  }

  // Función para manejar el cambio de pestaña
  setSelectedTabLabel() {
    const selectedTab = this.tabGroup._tabs?.toArray()[this.selectedTabIndex];
    if (selectedTab) {
      this.selectedTabLabel = ' > '+selectedTab.textLabel;
    } else {
      this.selectedTabLabel = '';
    }
  }

/**
 *  DATOS RECIBIDOS DESDE EL HIJO DATOS PERSONALES
 * 
 */
  actualizarValorHijo(valor: any) {
    this.NombreEmpleado = valor.descrip;
    this.cedruc = valor.cedruc;
  }


  
  /**
  * Funcion que dirige a la pantalla para el nuevo registro
  */
  VolverPagina() {
    this.router.navigate(['/' + this.pagina]);
  }


}
