import { JsonPipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-empleados-list',
    imports: [ListModule, EditModule],
    templateUrl: './empleados-list.component.html'
})
export class EmpleadosListComponent extends UnsubscribeOnDestroyAdapter implements OnInit {


  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  public usuarioConsulta: boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  private datosOriginales: any[] = []; // Variable para guardar los datos originales
  public dataSource: MatTableDataSource<any> = new MatTableDataSource<any>(this.datosOriginales);
  public filtroEstado: number = 1;


  public displayedColumns: string[] = [
    "accion", "cedruc", "descripcion",
    "email1", "regimen_descrip", "estado_texto"
  ];

  constructor(
    private ServicioClienteHttp: ClienthttpCongopeService,
    private ServicioCrypt: CryptService,
    private router: Router
  ) {
    super();
  }


  public pagina: string = "Catalogos/Empleados";
  public rutaapi: string = "Empleados";


  ngOnInit(): void {
    this.CargarGrid();
  }

  /**
     * Función que genera la lista de datos para los grids de las pantallas.
     */
  CargarGrid() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.datosOriginales = JSON.parse(data.result);
          this.AplicarFiltro();
        } else {
          this.dataSource = new MatTableDataSource<any>(this.datosOriginales);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * Función llamada para la exportación a Excel del formulario.
   */
  ExportarExcel() {
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CÉDULA': x.cedruc.slice(0, 10), // CORTA EL STRING PARA MOSTRAR SOLO LOS DIGITOS DE LA CEDULA
        'EMPLEADO': x.descripcion,
        'CORREO': x.email1,
        'RÉGIMEN': x.regimen_descrip,
        'ESTADO': x.estado_texto
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }


  /**
  * Función que realiza los filtrados de los grids.
  * @param event Evento de entrada del filtro.
  */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }

    

  }

  /***
   * Funcion para filtrar los datos de los empleados
   */
  AplicarFiltro() {

    if (this.filtroEstado === 0) {
      // Si no hay filtro, mostrar todos los datos
      this.dataSource.data = this.datosOriginales;
    } else {
      // Aplicar el filtro localmente
      this.dataSource.data = this.datosOriginales.filter(item => item.estado === this.filtroEstado);
    }
  }



  /**
   * Funcion que envia el registro padre para la edicion de los empleados
   * @param objeto 
   */
  EditarRegistro(objeto: any) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + objeto.cedruc);
    this.router.navigate(['/' + this.pagina, parametro]);
  }


    /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
    NuevoRegistro() {
      let parametro = this.ServicioCrypt.encryptString("NUEVO||-1")
      this.router.navigate(['/'+this.pagina, parametro]);
    } 
  

}
