import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MatCardModule } from '@angular/material/card';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { FileUploadComponent } from '@shared/components/file-upload/file-upload.component';
import { EmpleadosMo } from 'app/models/catalogos/empleados-mo';
import { EditModule } from 'app/paginas/generico/edit.module';
import { EmpleadosService } from 'app/servicios/catalogos/empleados.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';

@Component({
    selector: 'app-empleados-personales',
    imports: [
        EditModule,
        MatCardModule,
        MatDatepickerModule
    ],
    // ESTA PARTE DE LOS PROVIDERS CAMBIA LOS OBJETOS DE ANGULAR MATERIAL A ESPAÑOL
    providers: [DatePipe,
        { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
        {
            provide: DateAdapter,
            useClass: MomentDateAdapter,
        },
    ],
    templateUrl: './empleados-personales.component.html'
})
export class EmpleadosPersonalesComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  @Input() param!: string;
  // Variable nombre que sera reenviado al padre
  @Output() OutputNombreEmpleado = new EventEmitter<any>();

  public cedruc: string = '';
  public rutaapi: string = 'Empleados';
  public datosFormulario: EmpleadosMo = new EmpleadosMo({} as EmpleadosMo);
  public FormularioGeneral: UntypedFormGroup = this.CrearFormulario();

  public EstructuraTipoSangre!: any[];
  public EstructuraPaises!: any[];
  public EstructuraEtnico!: any[];
  public EstructuraEstadoCivil!: any[];
  public EstructuraGenero!: any[];
  public EstructuraTitulo!: any[];

  public EstructuraProvincias: any[] = [];
  public EstructuraCantones: any[] = [];

  ///LAS PERSONAS QUE SE REGISTRAN ESTAN ENTRE 18 Y 85 AÑOS
  public minDate = new Date(new Date().getFullYear() - 85, new Date().getMonth(), new Date().getDate());
  public maxDate = new Date(new Date().getFullYear() - 18, new Date().getMonth(), new Date().getDate());

  blobUrl!: any;
  pdfSrc!: SafeResourceUrl;

  constructor(
    private fb: FormBuilder,
    private ServicioCrypt: CryptService,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private sanitizer: DomSanitizer,
    private alertas: AlertasSrvService,
    private datePipe: DatePipe,
    private ServEmpleados: EmpleadosService
  ) {
    super();
  }

  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.cedruc = arrayResultado[1];
    if (arrayResultado[0] === 'EDITAR') {
      this.CargarForm();
    }

    this.CargarEstructuraDatos();
    this.CargarDemografico();

  }

  /**
   * Metodo que me permite emitir valores al padre
   */
  emitirValoresPadre() {
    const retorno = {
      cedruc: this.datosFormulario.cedruc,
      descrip: this.datosFormulario.descrip
    }
    this.OutputNombreEmpleado.emit(retorno);
  }

  /**
   * Funcion que carga la estructura de datos
   */
  CargarEstructuraDatos(): void {
    // ESTRUCTURAS DE DATOS
    const tablas = [
      { codigo: '84', estructura: 'EstructuraTipoSangre' },
      { codigo: '112', estructura: 'EstructuraPaises' },
      { codigo: '114', estructura: 'EstructuraEtnico' },
      { codigo: '86', estructura: 'EstructuraEstadoCivil' },
      { codigo: '87', estructura: 'EstructuraGenero' },
      { codigo: '107', estructura: 'EstructuraTitulo' },
    ];

    const promesas = tablas.map((tabla) =>
      this.ServEmpleados.CargarTablasGenerales(tabla.codigo).then((result) => ({
        estructura: tabla.estructura,
        result,
      }))
    );

    Promise.all(promesas)
      .then((results) => {
        results.forEach((item) => {
          (this as any)[item.estructura] = item.result;
        });
      })
      .catch((error) => console.log('Error:', error));
  }

  /**
   * Funcion que crea el formulario de datos
   * @returns
   */
  CrearFormulario(): UntypedFormGroup {
    return this.fb.group({
      grado: [this.datosFormulario.grado, [this.ValidacionRequiredSelect]],
      cedruc: [
        this.datosFormulario.cedruc
          ? this.datosFormulario.cedruc.slice(0, 10)
          : '',
        [
          Validators.required,
          Validators.maxLength(10),
          Validators.minLength(10),
        ],
      ],
      descrip: [this.datosFormulario.descrip, Validators.required],
      direcci: [this.datosFormulario.direcci, Validators.required],
      email1: [
        this.datosFormulario.email1.trim(),
        [Validators.required, Validators.email],
      ],
      email2: [
        this.datosFormulario.email2.trim(),
        [Validators.required, Validators.email],
      ],
      sexo: [this.datosFormulario.sexo, [this.ValidacionRequiredSelect]],
      telefon1: [this.datosFormulario.telefon1, [Validators.required]],
      telefon2: [this.datosFormulario.telefon2, [Validators.required]],
      estciv: [this.datosFormulario.estciv, [this.ValidacionRequiredSelect]],
      provincia: [this.datosFormulario.provincia, [Validators.required]],
      ciudad: [this.datosFormulario.ciudad, Validators.required],
      fecnac: [this.datosFormulario.fecnac, Validators.required],
      nacionalidad: [this.datosFormulario.nacionalidad, [this.ValidacionRequiredSelect]],
      etnico: [this.datosFormulario.etnico, [this.ValidacionRequiredSelect]],
      tiposan: [this.datosFormulario.tiposan, [this.ValidacionRequiredSelect]],
    });
  }

  /***
   * FUNCION PARA VALDAR QUE EL SELECT NO ESTE EN 0
   */
  ValidacionRequiredSelect(control: any) {
    return control.value === 0 ? { required: true } : null;
  }


  /**
   * Funcion que carga los datos de la forma
   */
  CargarForm(): void {

    this.ServEmpleados.CargarEmpleadoPorCodigo(this.cedruc)
      .then((data) => {
        if (data.success) {
          const parsedData = JSON.parse(data.result);
          this.datosFormulario = { ...this.datosFormulario, ...parsedData?.[0] };
          this.CargarDemografico(this.datosFormulario.provincia);
          this.FormularioGeneral = this.CrearFormulario();
          /// CARGA DE LA FOTO
          this.base64toBlob(this.datosFormulario.cedruc);
          /// VALORES AL PADRE
          this.emitirValoresPadre()
        }
      });
  }


  /**
   * Funcion que trae la informacion de las provincias y cantones para cargarlo en la forma que hace referencia en el empleado
   * @param CodigoPadre
   */
  CargarDemografico(CodigoPadre: any = '001'): void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/DatosDemograficos');
    this.ServicioClienteHttp.Obtener_x_Codigo(CodigoPadre).subscribe({
      next: (data) => {
        if (data.success) {
          if (CodigoPadre === '001') {
            this.EstructuraProvincias = JSON.parse(data.result);
          } else {
            this.EstructuraCantones = JSON.parse(data.result);
          }
        }
      },
      error: (err) => {
        console.log(err.message);
      },
    });
  }

  /**
   * Funcion que construye una imagen a partir del blob
   * @param cedulaImagen
   */
  base64toBlob(cedulaImagen: string): void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/CargarFotos');
    this.ServicioClienteHttp.Obtener_x_Codigo(cedulaImagen).subscribe({
      next: (data) => {
        if (data.success) {
          const byteCharacters = atob(data.result);
          const byteArrays = [];

          for (let offset = 0; offset < byteCharacters.length; offset += 512) {
            const slice = byteCharacters.slice(offset, offset + 512);

            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
              byteNumbers[i] = slice.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }

          // Crear un Blob a partir de los bloques de bytes y asignarle el nombre del archivo

          const blob = new Blob(byteArrays, { type: 'image/png' });
          this.blobUrl = URL.createObjectURL(blob);
          this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(
            this.blobUrl
          );
        }
      },
      error: (err) => {
        console.log(err.message);
      },
    });
  }

  /**
   * Funcion que se ejecuta en la accion clic de la foto para cambiarla dinamicamente
   */
  triggerFileInput() {
    const fileInput = document.getElementById('uploadFile') as HTMLElement;
    fileInput.click(); // Dispara el clic del input de archivo
  }

  /**
   * Cuando se carga el archivo se puede cambiar dinamicamente la foto
   * @param event
   */
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const validImageTypes = ['image/jpeg', 'image/png'];
      if (!validImageTypes.includes(file.type)) {
        this.alertas.MensajeAlerta(
          'Por favor seleccione una imagen válida (JPG o PNG)'
        );
      } else {
        const EmpleadosSubirFotoMo = {
          Cedruc: this.datosFormulario.cedruc,
          uploadFile: file,
        };
        this.SubirFoto(EmpleadosSubirFotoMo);
      }
    }
  }

  /**
   * Funcion que se encarga de transformar los datos en un objeto tipo form para llevarlo al backend
   * @param obj
   * @param form
   * @param namespace
   * @returns
   */
  objectToFormData(
    obj: any,
    form: FormData = new FormData(),
    namespace: string = ''
  ): FormData {
    for (let propertyName in obj) {
      if (
        !obj.hasOwnProperty(propertyName) ||
        obj[propertyName] === null ||
        obj[propertyName] === undefined
      ) {
        continue;
      }

      const formKey = namespace
        ? `${namespace}[${propertyName}]`
        : propertyName;
      if (
        typeof obj[propertyName] === 'object' &&
        !(obj[propertyName] instanceof File)
      ) {
        // Si la propiedad es un objeto (pero no un File), llamar recursivamente
        this.objectToFormData(obj[propertyName], form, formKey);
      } else {
        // Si la propiedad es un valor simple o un File, añadirlo a FormData
        form.append(formKey, obj[propertyName]);
      }
    }
    return form;
  }

  /**
   * Funcion que permite subir y actualizar la foto
   * @param CambiarFoto
   */
  SubirFoto(CambiarFoto: any): void {
    // Convierto toda la informacion en un formData ya que este modelo de datos tiene un file
    const formData = this.objectToFormData(CambiarFoto);

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/SubirFotoEmpleado');

    this.ServicioClienteHttp.Insertar(formData).subscribe({
      next: (data) => {
        if (data.success) {
          this.base64toBlob(this.datosFormulario.cedruc);
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      },
    });
  }

  /**
   * FUNCION PARA GUARDAR LOS DATOS DE LOS EMPLEADOS
   */
  GuardarInformacion(): void {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/InsertarActualizarEmpleado");

    Swal.fire({
      title: "¿Está seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        let datosGuardar = this.FormularioGeneral.getRawValue();
        // la cedula se completa para que se transforme a ruc
        datosGuardar.cedruc = datosGuardar.cedruc + '001';
        datosGuardar.fecnac = this.datePipe.transform(datosGuardar.fecnac, 'yyyy-MM-dd') ?? '';

        // Esto reemplazará solo las propiedades que existen en both, myObject y formValues
        this.datosFormulario = { ...this.datosFormulario, ...datosGuardar };

        this.ServicioClienteHttp.Insertar(this.datosFormulario).subscribe({
          next: (data) => {

            if (data.success) {

              const respuesta = JSON.parse(data.result);

              if (respuesta[0].out_cedruc.includes('Error')) {
                this.alertas.MensajeConTimer(respuesta[0].out_cedruc, false);
              }
              else {
                this.cedruc = respuesta[0].out_cedruc;
                this.CargarForm();
                this.alertas.MensajeConTimer("Registro actualizado exitosamente!!", true);
              }
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }

        });




      }
    });
  }

}
