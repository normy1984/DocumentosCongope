import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { EmpleadosMo } from 'app/models/catalogos/empleados-mo';
import { EditModule } from 'app/paginas/generico/edit.module';
import { EmpleadosService } from 'app/servicios/catalogos/empleados.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-empleados-bancarios',
    imports: [EditModule],
    templateUrl: './empleados-bancarios.component.html'
})
export class EmpleadosBancariosComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  @Input() param!: string;

  public cedruc: string = '';
  public datosFormulario: EmpleadosMo = new EmpleadosMo({} as EmpleadosMo);
  public FormularioBancario: UntypedFormGroup = this.CrearFormulario();
  public rutaapi: string = 'Empleados';

  public EstructuraBancos!: any[];
  public EstructuraTipoCuenta!: any[];

  ngOnInit(): void {
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.cedruc = arrayResultado[1];
    if (arrayResultado[0] === 'EDITAR') {
      this.CargarForm();
    }

    this.CargarEstructuraDatos();
    
  }

  constructor(
    private fb: FormBuilder,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private ServicioCrypt: CryptService,
    private alertas: AlertasSrvService,
    private ServEmpleados: EmpleadosService
  ) {
    super();
  }



   /**
   * Funcion que carga la estructura de datos
   */
   CargarEstructuraDatos(): void {
    // ESTRUCTURAS DE DATOS
    const tablas = [
      { codigo: '80', estructura: 'EstructuraBancos' },
      { codigo: '9', estructura: 'EstructuraTipoCuenta' },
    ];

    const promesas = tablas.map((tabla) =>
      this.ServEmpleados.CargarTablasGenerales(tabla.codigo).then((result) => ({
        estructura: tabla.estructura,
        result,
      }))
    );

    Promise.all(promesas)
      .then((results) => {
        results.forEach((item) => {
          (this as any)[item.estructura] = item.result;
        });
      })
      .catch((error) => console.log('Error:', error));
  }

/**
   * Funcion que carga los datos de la forma
   */
CargarForm(): void {

  this.ServEmpleados.CargarEmpleadoPorCodigo(this.cedruc)
    .then((data) => {
      if (data.success) {
        const parsedData = JSON.parse(data.result);
        this.datosFormulario = { ...this.datosFormulario, ...parsedData?.[0] };
        this.FormularioBancario = this.CrearFormulario();
      }
    });
}
  /**
   * Funcion que crea el formulario de datos
   * @returns
   */
  CrearFormulario(): UntypedFormGroup {
    return this.fb.group({
      banco: [this.datosFormulario.banco.trim(), Validators.required],
      tipocta: [this.datosFormulario.tipocta, Validators.required],
      cuentaco: [this.datosFormulario.cuentaco, [Validators.required]],
    });
  }


  /**
 * FUNCION PARA GUARDAR LOS DATOS DE LOS EMPLEADOS
 */
  GuardarInformacion(): void {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/InsertarActualizarEmpleado");


    let datosGuardar = this.FormularioBancario.getRawValue();
    // la cedula se completa para que se transforme a ruc
   
    // Esto reemplazará solo las propiedades que existen en both, myObject y formValues
    this.datosFormulario = { ...this.datosFormulario, ...datosGuardar };

    this.ServicioClienteHttp.Insertar(this.datosFormulario).subscribe({
      next: (data) => {

        if (data.success) {

          const respuesta = JSON.parse(data.result);

          if (respuesta[0].out_cedruc.includes('Error')) {
            this.alertas.MensajeConTimer(respuesta[0].out_cedruc, false);
          }
          else {
            this.alertas.MensajeConTimer("Registro actualizado exitosamente!!", true);
          }
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }

    });




  }



}
