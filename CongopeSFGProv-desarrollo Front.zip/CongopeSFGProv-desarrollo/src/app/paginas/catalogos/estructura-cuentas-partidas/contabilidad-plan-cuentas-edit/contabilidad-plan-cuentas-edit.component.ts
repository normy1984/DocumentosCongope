import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { EstructuraPlanCuentasContabilidadMo } from 'app/models/catalogos/estructura-cuentas-partidas';
import { ParamSessionMo } from 'app/models/param-session';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ListaBuscaCiuComponent } from 'app/paginas/generico/lista-busca-ciu/lista-busca-ciu.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-contabilidad-plan-cuentas-edit',
    imports: [EditModule, MatCheckboxModule],
    templateUrl: './contabilidad-plan-cuentas-edit.component.html',
    styleUrl: './contabilidad-plan-cuentas-edit.component.scss'
})
export class ContabilidadPlanCuentasEditComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {

  @Input('param') param!: string;

  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public accion: string = "";
  public usuarioConsulta: boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  public colorEstado: string = 'label-default';
  public FormularioDatos!: UntypedFormGroup;
  public ModeloDatos: EstructuraPlanCuentasContabilidadMo = new EstructuraPlanCuentasContabilidadMo({} as EstructuraPlanCuentasContabilidadMo);
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');

  private pagina = "Catalogos/PlandeCuentas";
  public rutaapi = "EstructuraCuentasPartidas";

  readonly hideRequiredControl1 = new FormControl(false);
  readonly hideRequiredControl2 = new FormControl(false);
  readonly hideRequiredControl3 = new FormControl(false);

  constructor(
    public formBuild: FormBuilder,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService,
    private ServicioCrypt: CryptService,
    private router: Router,
    public dialog: MatDialog,
  ) {
    super();
    this.FormularioDatos = this.CrearFormulario();
  }

  ngOnInit(): void {

    this.CargarDatos();
  }


  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      cuenta: [this.ObtenerUltimaParteCuenta(this.ModeloDatos.cuenta), [Validators.required]],
      nom_cue: [this.ModeloDatos.nom_cue, [Validators.required]],
      ult_cue: [this.ModeloDatos.ult_cue, [Validators.required]],
      niv_cue: [this.ModeloDatos.niv_cue, [Validators.required]],
      con_mov: [this.ModeloDatos.con_mov, [Validators.required]],
      sal_deb: [this.ModeloDatos.sal_deb, [Validators.required]],
      sal_cre: [this.ModeloDatos.sal_cre, [Validators.required]],
      sal_inid: [this.ModeloDatos.sal_inid, [Validators.required]],
      sal_inic: [this.ModeloDatos.sal_inic, [Validators.required]],
      cod_p: [this.ModeloDatos.cod_p, [Validators.required]],
      cod_h: [this.ModeloDatos.cod_h, [Validators.required]],
      cuenta_p: [this.ModeloDatos.cuenta_p, [Validators.required]],
      cre_por: [this.ModeloDatos.cre_por, [Validators.required]],
      aux_cue: [this.ModeloDatos.aux_cue, [Validators.required]],
      ban_cue: [this.ModeloDatos.ban_cue, [Validators.required]],
      estado: [this.ModeloDatos.estado, [Validators.required]],
      tipo_cue: [this.ModeloDatos.tipo_cue, [Validators.required]],
      aso_pre: [this.ModeloDatos.aso_pre, [Validators.required]],
      tipocuec: [this.ModeloDatos.tipocuec, [Validators.required]],
      por_iva: [this.ModeloDatos.por_iva, [Validators.required]],
      por_ret: [this.ModeloDatos.por_ret, [Validators.required]],
      nivbal: [this.ModeloDatos.nivbal, [Validators.required]],
      auxiliar: [this.ModeloDatos.auxiliar, [Validators.required]],
      renta: [this.ModeloDatos.renta, [Validators.required]],
      ctapeaje: [this.ModeloDatos.ctapeaje, [Validators.required]],
      ctatrans: [this.ModeloDatos.ctatrans, [Validators.required]],
      ruc: [this.ModeloDatos.ruc, [Validators.required]],
      ctapago: [this.ModeloDatos.ctapago, [Validators.required]],
      ctapasateso: [this.ModeloDatos.ctapasateso, [Validators.required]],
      cta_evol: [this.ModeloDatos.cta_evol, [Validators.required]],
      cta_repcom: [this.ModeloDatos.cta_repcom, [Validators.required]],
      cta_iess: [this.ModeloDatos.cta_iess, [Validators.required]],
      cxc_iva_ret100_lrti: [this.ModeloDatos.cxc_iva_ret100_lrti, [Validators.required]],
    });
  }


  CargarDatos(): void {

    const datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    console.log(datos);


    const Sel_ArbolEstructuraCuentasPartidasMo =
    {
      cuenta: arrayResultado[1],
      sessionMo: this.paramSessionMo
    }

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/CargarCoPlactaXcodigo");
    this.ServicioClienteHttp.Insertar(Sel_ArbolEstructuraCuentasPartidasMo, true).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado = JSON.parse(data.result);
          this.ModeloDatos = resultado[0];
          this.FormularioDatos = this.CrearFormulario();
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  ObtenerUltimaParteCuenta(cuenta: string): string {
    const parts = cuenta.split('.'); // Divide la cadena por los puntos
    return parts[parts.length - 1];  // Devuelve el último elemento
  }

  /**
* Funcion que dirige a la pantalla para el nuevo registro
*/
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }


  CargarEntesContables() {
    const dialogRef = this.dialog.open(ListaBuscaCiuComponent, {
      width: '95%',
      height: '100%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.ruc !== "") {
        this.FormularioDatos.patchValue({
          cuenta: result.cedruc
        });
      }
    });


  }

  CargarRUC() {
    const dialogRef = this.dialog.open(ListaBuscaCiuComponent, {
      width: '95%',
      height: '100%'
    });

    dialogRef.afterClosed().subscribe(result => {
     if (result.ruc !== "") {
        this.FormularioDatos.patchValue({
          ruc: result.cedruc
        });
      }
    });


  }


  LimpiarRUC():void{
    this.FormularioDatos.patchValue({
      ruc: ""
    });
  }
}
