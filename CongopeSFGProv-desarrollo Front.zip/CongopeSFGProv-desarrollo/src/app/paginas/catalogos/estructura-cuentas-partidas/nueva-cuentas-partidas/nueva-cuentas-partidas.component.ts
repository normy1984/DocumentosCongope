import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import Swal from 'sweetalert2'
import { ParamSessionMo } from 'app/models/param-session';
import { ListModule } from 'app/paginas/generico/list.module';
import { ListaBuscaCiuComponent } from 'app/paginas/generico/lista-busca-ciu/lista-busca-ciu.component';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { isEmpty } from 'rxjs';
import { IU_EstructuraPartidaCuentaMo } from 'app/models/catalogos/estructura-cuentas-partidas';

@Component({
    selector: 'app-nueva-cuentas-partidas',
    imports: [ListModule, FormsModule],
    templateUrl: './nueva-cuentas-partidas.component.html'
})
export class NuevaCuentasPartidasComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {

  @Input('param') param!: string;

  public tituloPagina: string = 'Estructura de Código';
  public dataSource !: MatTableDataSource<any>;
  public identifi: number = 0;
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  private rutaapi: string = "EstructuraCuentasPartidas";
  private pagina = "Catalogos/PlandeCuentas";

  public displayedColumns =
    ["niv_cue", "cuenta", "nom_cue"];


  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService,
    private ServicioCrypt: CryptService,
    public dialog: MatDialog,
  ) {
    super();
    this.CargarVariables();
  }

  ngOnInit() {

    this.CargarGrid();
  }

  private CargarVariables(): void {
    const rutaActual = this.router.url;
    switch (this.paramSessionMo.sistema) {
      case 1:
        this.tituloPagina = "Plan de Cuentas";
        break;
      case 2:
        const esGastos = rutaActual && rutaActual.includes('Gasto');
        this.tituloPagina = esGastos ? "Partidas de Gasto" : "Partidas de Ingreso";
        
        break;
      case 3:
      case 5:
        this.tituloPagina = "Maestro Artículos";
        break;
      case 4:
        this.tituloPagina = "Estructura Organizacional";
        break;
    }
  }

  CargarGrid(): void {


    const datos = this.ServicioCrypt.decryptString(this.param);
    const arrayResultado = datos.split('||');

    this.identifi = parseInt(arrayResultado[2]);

    const Sel_SelectEstructuraNuevoGenericoMo =
    {
      identifi: arrayResultado[2],
      cuenta: arrayResultado[1],
      sessionMo: this.paramSessionMo
    }

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/SelectEstructuraNuevoGenerico");
    this.ServicioClienteHttp.Insertar(Sel_SelectEstructuraNuevoGenericoMo, true).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(resultado);
          console.log(resultado);
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  CargarRUC(fila: any) {
    const dialogRef = this.dialog.open(ListaBuscaCiuComponent, {
      width: '95%',
      height: '100%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.ruc !== "") {
        fila.cuenta = result.cedruc;
        fila.nombre = result.descrip

      }
    });


  }

  VolverPagina() {
    this.router.navigate([this.pagina]);
  }


  GuardarRegistro() {

    var datos_IU_EstructuraPartidaCuentaMo: IU_EstructuraPartidaCuentaMo[] = [];

    if (this.dataSource.data[this.dataSource.data.length - 1].nombre.trim() === "") {
      this.alertas.MensajeError("Debe poner el nombre en el último nivel!!");
    }
    else {

      let campos_vacios: boolean = false;
      let cuenta_final: string = "";
      let nombre: string = "";

      this.dataSource.data.forEach(row => {

        row.cuenta_p = cuenta_final;

        row.ult_niv_cue = this.dataSource.data.length === row.nivel ? 'S' : 'N';

        if (row.nombre.trim() === "") {
          campos_vacios = true;
        }
        if (cuenta_final === "") {
          cuenta_final = row.cuenta;
        }
        else {
          cuenta_final += "." + row.cuenta
        }
        row.cuenta_final = cuenta_final;
      });


      let mensaje = campos_vacios ? 'No todos los niveles tienen nombre, se colocará un nombre automático. ' : '';
      mensaje += 'Se creará la cuenta ' + cuenta_final + '. ¿Desea Continuar?.'
      Swal.fire({
        title: mensaje,
        showDenyButton: true,
        confirmButtonText: "Si, Continuar",
        denyButtonText: "No, Cancelar"
      }).then((result) => {
        if (result.isConfirmed) {
          for (let i = this.dataSource.data.length - 1; i >= 0; i--) {
            let row = this.dataSource.data[i];

            if (row.nombre.trim() !== "") {
              nombre = row.nombre;
            }
            else {
              row.nombre = nombre;
            }

            let fila: IU_EstructuraPartidaCuentaMo = new IU_EstructuraPartidaCuentaMo({} as IU_EstructuraPartidaCuentaMo);
            fila.cuenta = row.cuenta_final;
            fila.cuenta_p = row.cuenta_p;
            fila.identifi = this.identifi;
            fila.niv_cue = row.nivel;
            fila.nom_cue = row.nombre;
            fila.ult_cue = row.ult_niv_cue;

            datos_IU_EstructuraPartidaCuentaMo.push(fila);

          }

          this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/IU_EstructuraPartidaCuentaMo");
          this.ServicioClienteHttp.Insertar(datos_IU_EstructuraPartidaCuentaMo).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeConTimer("Estructura Guardada Exitosamente!!", true);
                //this.CargarGrid();
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message);
            }
          });
        }

      });


    }

  }


}
