import { FlatTreeControl } from '@angular/cdk/tree';
import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener, MatTreeModule } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ParamSessionMo } from 'app/models/param-session';
import { Router } from '@angular/router';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { EstructuraCuentasPartidasMo } from 'app/models/catalogos/estructura-cuentas-partidas';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';


/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}
/**
 * @title Tree with flat nodes (childrenAccessor)
 */
@Component({
  selector: 'estructura-cuentas-partidas.component',
  templateUrl: 'estructura-cuentas-partidas.component.html',
  styleUrl: './estructura-cuentas-partidas.component.scss',
  standalone: true,
  imports: [ListModule, MatTreeModule, MatButtonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EstructuraCuentasPartidasComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
    public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}'; 
  public tituloOpcionAdicional: string = '';
  public tituloPagina: string = 'Estructura de Código';
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  public selectedNode: any;
  private identifi = 0;
  private rutaapi: string = "EstructuraCuentasPartidas";
  private TREE_DATA: EstructuraCuentasPartidasMo[] = [];



  private _transformer = (node: EstructuraCuentasPartidasMo, level: number) => {
    return {
      expandable: !!node.Submenu && node.Submenu.length > 0,
      name: "N" + node.Niv_cue + " - " + node.Cuenta + ".-" + node.Nom_cue,
      level: level,
    };
  };

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level,
    node => node.expandable,
  );

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    node => node.level,
    node => node.expandable,
    node => node.Submenu,
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService
  ) {
    super();
    this.CargarVariables();

  }

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;


  ngOnInit() {
    this.CargarDatosArbol();
  }

  private CargarVariables(): void {
    const rutaActual = this.router.url;
    switch (this.paramSessionMo.sistema) {
      case 1:
        this.tituloPagina = "Plan de Cuentas";
        break;
      case 2:
        const esGastos = rutaActual && rutaActual.includes('Gasto');
        this.tituloPagina = esGastos ? "Partidas de Gasto" : "Partidas de Ingreso";
        this.identifi = esGastos ? 2 : 1;

        break;
      case 3:
      case 5:
        this.tituloPagina = "Maestro Artículos";
        break;
      case 4:
        this.tituloPagina = "Estructura Organizacional";
        break;
    }
  }


  selectNode(node: any): void {
    this.selectedNode = node;
  }


  CargarDatosArbol() {
    const Sel_ArbolEstructuraCuentasPartidasMo =
    {
      identifi: this.identifi,
      sessionMo: this.paramSessionMo
    }

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/GenerarArbol");
    this.ServicioClienteHttp.Insertar(Sel_ArbolEstructuraCuentasPartidasMo, true).subscribe({
      next: (data) => {
        if (data.success) {
          this.TREE_DATA = JSON.parse(data.result);
          this.dataSource.data = this.TREE_DATA;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  FiltrarRegistros(event: string) {
    const filterValue = event.trim().toLowerCase();

    console.log(filterValue);
  
    if (filterValue === '') {
      // Si el filtro está vacío, colapsar todo
      this.treeControl.collapseAll();
      return;
    }
  
    // Expandir todos los nodos que coincidan con el filtro
    this.expandFilteredNodes(filterValue);
  }
  
  expandFilteredNodes(filterValue: string) {
    this.treeControl.dataNodes.forEach(node => {
      const nodeName = node.name.toLowerCase();
      
      // Verificar si el nodo o algún descendiente coincide con el filtro
      if (nodeName.includes(filterValue)) {
        this.expandParents(node);
      }
    });
  }
  
  expandParents(node: any) {
    // Expandir los nodos ancestros del nodo filtrado
    let parent = this.getParentNode(node);
    while (parent) {
      this.treeControl.expand(parent);
      parent = this.getParentNode(parent);
    }
  }
  
  getParentNode(node: any): any | null {
    const currentLevel = this.treeControl.getLevel(node);
    
    if (currentLevel < 1) {
      return null; // Si no tiene nivel, no tiene padre
    }
  
    const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
    
    // Buscar el nodo padre recorriendo hacia atrás
    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.treeControl.dataNodes[i];
      if (this.treeControl.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
  
    return null;
  }
  

}