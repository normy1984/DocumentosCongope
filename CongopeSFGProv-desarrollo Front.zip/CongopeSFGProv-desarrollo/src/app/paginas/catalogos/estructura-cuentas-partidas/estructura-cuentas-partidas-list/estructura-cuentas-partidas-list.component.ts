import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { List } from 'angular-feather/icons';
import { ParamSessionMo } from 'app/models/param-session';
import { ListModule } from 'app/paginas/generico/list.module';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';

@Component({
    selector: 'app-estructura-cuentas-partidas-list',
    imports: [ListModule],
    templateUrl: './estructura-cuentas-partidas-list.component.html',
    styleUrl: './estructura-cuentas-partidas-list.component.scss'
})
export class EstructuraCuentasPartidasListComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public tituloPagina: string = 'Estructura de Código';
  public pagina: string = 'Catalogos';
  public paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  public dataSource !: MatTableDataSource<any>;
  public usuarioConsulta: boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  public selectedRow: any;  // Propiedad para almacenar la fila seleccionada
  public OcultarNuevoSubnivel: boolean = true;  // Propiedad para almacenar la fila seleccionada
  public OcultarEditar: boolean = true;  // Propiedad para almacenar la fila seleccionada

  /**COLUMNAS MOSTRADAS */
  public displayedColumns =  
    ["niv_cue", "cuenta", "nom_cue"];

  private identifi = 0;
  private rutaapi: string = "EstructuraCuentasPartidas";

  constructor(
    private router: Router,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private alertas: AlertasSrvService,
    private ServicioCrypt : CryptService
  ) {
    super();
    this.CargarVariables();

  }

  ngOnInit() {
    this.CargarGrid();
  }

  private CargarVariables(): void {
    const rutaActual = this.router.url;
    switch (this.paramSessionMo.sistema) {
      case 1:
        this.tituloPagina = "Plan de Cuentas";
        this.pagina = this.pagina + "/PlanCuentasContabilidad";
        break;
      case 2:
        const esGastos = rutaActual && rutaActual.includes('Gasto');
        this.tituloPagina = esGastos ? "Partidas de Gasto" : "Partidas de Ingreso";
        this.identifi = esGastos ? 2 : 1;

        break;
      case 3:
      case 5:
        this.tituloPagina = "Maestro Artículos";
        break;
      case 4:
        this.tituloPagina = "Estructura Organizacional";
        break;
    }
  }

  /**
   * Función que realiza los filtrados de los grids.
   * @param event Evento de entrada del filtro.
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  CargarGrid(): void {
    const Sel_ArbolEstructuraCuentasPartidasMo =
    {
      identifi: this.identifi,
      sessionMo: this.paramSessionMo
    }

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/GenerarListCuentas");
    this.ServicioClienteHttp.Insertar(Sel_ArbolEstructuraCuentasPartidasMo, true).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  seleccionarFila(row: any) {
    this.OcultarEditar = false;
    this.OcultarNuevoSubnivel = row.ult_cue.toLowerCase() === 's' ? true : false; 
    this.selectedRow = row;  // Almacena la fila seleccionada
  }


   /**
   * Función que dirige a la pantalla para el nuevo registro.
   */
   NuevoRegistro(objeto: any) {
    let parametro = this.ServicioCrypt.encryptString("NUEVO||" + objeto.cuenta + "||" + this.identifi);
    this.router.navigate(['/Catalogos/NuevaEstructuraCuentaPartida', parametro]);
  }

  /**
   * Función que envía los datos para editar un registro.
   * @param objeto Objeto de tipo MovimientosPresupuestariosMo que se va a editar.
   */
  EditarRegistro(objeto: any) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + objeto.cuenta);
    this.router.navigate(['/' + this.pagina, parametro]);
  }


}
