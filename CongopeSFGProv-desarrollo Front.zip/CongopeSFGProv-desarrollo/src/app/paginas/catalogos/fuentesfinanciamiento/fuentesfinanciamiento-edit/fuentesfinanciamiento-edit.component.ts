import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2';
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { FuentesFinanciamientoMo } from 'app/models/catalogos/fuentesfinanciamiento-mo';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

import { CustomValidators } from 'app/shared/validators/custom-validators'; // Importación de validadores personalizados

@Component({
    selector: 'app-fuentesfinanciamiento-edit',
    imports: [EditModule, MatDatepickerModule, MatAutocompleteModule],
    styleUrls: ['./fuentesfinanciamiento-edit.component.css'], // Ruta al archivo CSS del componente
    templateUrl: './fuentesfinanciamiento-edit.component.html'
})
export class FuentesfinanciamientoEditComponent implements OnInit {
  @Input('ffn_id') ffn_id!: string;
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: string = "";
  objeto: any;
  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;

  public mostrarCargador: boolean = false; // Agregar variable para controlar la visualización del cargador

  public pagina: string = "Catalogos/FuentesFinanciamiento";
  public rutaapi: string = "FuentesFinanciamiento";
  public OptionsEstructura: any[] = [];
  blankObject = {} as FuentesFinanciamientoMo;
  ModeloDatos: FuentesFinanciamientoMo = new FuentesFinanciamientoMo(this.blankObject);

  @ViewChild('cuenta_debito') cuenta_debito!: ElementRef<HTMLInputElement>;
  OpcionesCuentaDebito!: any[];

  public isFfnIdEditable: boolean = true;

  // Para cargador de datos en lista (con miles de registros)
  public cargandoDatos: boolean = true; // Inicialmente establecerlo en true

  constructor(
    private router: Router,
    public dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.cargandoDatos = true; // Establecer a true antes de cargar los datos
    
    this.FormularioDatos = this.CrearFormulario();
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi); 
    let datos = this.ServicioCrypt.decryptString(this.ffn_id);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.codtab = parseInt(arrayResultado[2]);
    this.active_item = arrayResultado[3];

    this.FormularioDatos = this.CrearFormulario();

    this.limpiarFfnId();
    if (this.pk_identificador !== "-1") {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO";
      this.isFfnIdEditable = false;

      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
        next: (data) => {
          if (data.success) {
            let result: any = data.result;
            let resultado: FuentesFinanciamientoMo = result[0];
            this.FormularioDatos.patchValue({
              ffn_id: resultado.ffn_id,
              ffn_nombre: resultado.ffn_nombre,
              ffn_ctapago: resultado.ffn_ctapago,
            });
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      ffn_id: [
        { value: this.ffn_id, disabled: this.isReadOnly },
        this.pk_identificador === "-1" ? [Validators.required, CustomValidators.numbersOnly] : [],
      ],
      ffn_nombre: [
        this.ModeloDatos.ffn_nombre, 
        [Validators.required, CustomValidators.nonEmpty]
      ],
      ffn_ctapago: [
        this.ModeloDatos.ffn_ctapago, 
        [Validators.required, CustomValidators.nonEmpty]
      ],
    });
  }

  GuardarInformacion() {
    Swal.fire({
      title: "Está seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        let datosGuardar = this.FormularioDatos.getRawValue();

        const objeto: FuentesFinanciamientoMo = {
          ffn_id: datosGuardar.ffn_id,
          ffn_nombre: datosGuardar.ffn_nombre,
          ffn_ctapago: datosGuardar.ffn_ctapago,
        };

        if (this.pk_identificador == "-1") {
          this.ServicioClienteHttp.SeteoRuta("FuentesFinanciamiento");

          this.ServicioClienteHttp.Insertar(objeto).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message);
              if (err.status === 400) {
                const errorMessage = err.error.messages ? err.error.messages[0] : "Error desconocido";
                this.alertas.MensajeError(errorMessage);
              } else {
                this.alertas.MensajeError("Error desconocido");
              }
            }
          })
        } else {
          this.ServicioClienteHttp.SeteoRuta("FuentesFinanciamiento");

          this.ServicioClienteHttp.Actualizar(this.pk_identificador, objeto).subscribe({            
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message);
              if (err.status === 400) {
                const errorMessage = err.error.messages ? err.error.messages[0] : "Error desconocido";
                this.alertas.MensajeError(errorMessage);
              } else {
                this.alertas.MensajeError("Error desconocido");
              }
            }
          })
        }
      }
    });
  }


  CargarSelectEstructura() {
    this.mostrarCargador = true; // Habilitar el cargador antes de la consulta

    this.ServicioClienteHttp.SeteoRuta("CuentasContables");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.OptionsEstructura = data.result;
          this.CargarAutocomplete();
          this.ban_CargaEstructura = 1;
        } else {
          this.alertas.MensajeError(data.message);
        }
        this.mostrarCargador = false; // Deshabilitar el cargador después de la consulta
      },
      error: (err) => {
        console.log(err.message);
        this.mostrarCargador = false; // Deshabilitar el cargador en caso de error
      }
    })
  }

  CargarAutocomplete() {
    this.ban_CargaEstructura = 1;
    this.OpcionesCuentaDebito = this.OptionsEstructura.slice();
  }

  FiltroAutocomplete(opcion: string) {
    if (this.ban_CargaEstructura === 0) {
      this.CargarSelectEstructura();
    }
    var filterValue = '';
    switch (opcion) {
      case "cuenta_debito":
        filterValue = this.cuenta_debito.nativeElement.value.toLowerCase();
        this.OpcionesCuentaDebito = this.CargarDatosFiltrados(filterValue);
        break;
    }
  }

  CargarDatosFiltrados(filterValue: string | null) {
    return this.OptionsEstructura.filter(
      option => {
        const valueMatch = option.cuenta.toLowerCase().includes(filterValue);
        const textMatch = option.nom_cue.toLowerCase().includes(filterValue);
        return valueMatch || textMatch;
      }
    );
  }

  limpiarFfnId() {
    this.FormularioDatos.get('ffn_id')?.setValue('');
  }
}
