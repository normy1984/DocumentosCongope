import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';

import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { FuentesFinanciamientoMo } from 'app/models/catalogos/fuentesfinanciamiento-mo';
import { FuentesFinanciamientoDeleteMo } from 'app/models/catalogos/fuentesfinanciamientodelete-mo';
import { FuentesFinanciamientoSrvService } from 'app/servicios/catalogos/fuentesfinanciamiento-srv.service'; 
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { Direction } from '@angular/cdk/bidi';
import { MatDialog } from '@angular/material/dialog';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { ParamSessionMo } from 'app/models/param-session';



@Component({
    selector: 'app-fuentesfinanciamiento-list',
    templateUrl: './fuentesfinanciamiento-list.component.html',
    imports: [
        ListModule
    ]
})
export class FuentesfinanciamientoListComponent
extends UnsubscribeOnDestroyAdapter
implements OnInit
{

  blankObject = {} as FuentesFinanciamientoDeleteMo;
  ModeloDatosDelete: FuentesFinanciamientoDeleteMo = new FuentesFinanciamientoDeleteMo(this.blankObject);

  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  
  // Inyectar los servicios
  private ServicioFuenteFinanciamiento = inject(FuentesFinanciamientoSrvService);
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */  
public pagina:string = "Catalogos/FuentesFinanciamiento";
public rutaapi:string = "FuentesFinanciamiento";
//public paginaNuevo:string = "params/movimientos";

/**COLUMNAS MOSTRADAS */   
public displayedColumns:string[] = [
  "ffn_id",
  "ffn_nombre","ffn_ctapago","accion"];

  constructor(
    private router: Router,
    public dialog: MatDialog,
  ) {
    super();
  }


  ngOnInit() {
    console.log(this.rutaapi);
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
  
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    console.log(this.ParamSessiones);
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CargarGrid() {
   
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
         // let resultado: any[] = JSON.parse(data.result);
          let resultado: any = data.result;
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


 

  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    let catalogo = this.ServicioCrypt.encryptString("NUEVO||-1")
    this.router.navigate(['/'+this.pagina, catalogo]);
  } 




  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto 
   */

  EditarRegistro(objeto: FuentesFinanciamientoMo) {
    let catalogo = this.ServicioCrypt.encryptString("EDITAR||"+objeto.ffn_id)
    this.router.navigate(['/'+this.pagina, catalogo]);
  }


/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
  EliminarRegistro(objeto: FuentesFinanciamientoDeleteMo) {

    this.ModeloDatosDelete.ffn_id = objeto.ffn_id;
    this.ModeloDatosDelete.anio = this.ParamSessiones.anio;
    this.ModeloDatosDelete.codemp = this.ParamSessiones.codemp;


    let textoEliminar:string = objeto.ffn_nombre;
    let codigo:string = objeto.ffn_id;

    Swal.fire({
      title: "Está seguro de eliminar "+ textoEliminar + "?",
      showDenyButton: true,
      confirmButtonText: "Eliminar",
      denyButtonText: "Cancelar"
    }).then((result) => {
  //Read more about isConfirmed, isDenied below 
      if (result.isConfirmed) {

        this.ServicioFuenteFinanciamiento.Eliminar_x_Anio(this.ModeloDatosDelete).subscribe({
          next: (data) => {
            if (data.success) {
              this.CargarGrid();
              this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
            } else {
              this.alertas.MensajeError(data.message);
              console.log("Esto es un error:" + data.message)
            }
          },
          error: (err) => {
            console.log(err.message);

            // si el estado de la respuesta es 400 (Bad Request). Si lo es, tomará el primer mensaje de la lista
            // de mensajes de error (si existe) y lo mostrará utilizando this.alertas.MensajeError(). Si no hay 
            // mensajes de error disponibles, se mostrará un mensaje genérico. 
            if (err.status === 400) {
              const errorMessage = err.error.messages ? err.error.messages[0] : "Error desconocido";
              this.alertas.MensajeError(errorMessage);
            } else {
              this.alertas.MensajeError("Error desconocido");
            }
          }
        })
      }
    });
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CÓDIGO': x.ffn_id,
        'NOMBRE': x.ffn_nombre,
        'CUENTA PAGO': x.ffn_ctapago,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }
 
  /**
   * 
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


/**
 * Funcion para enviar la impresion de los pdf
 * @param row 
 */
ImprimirReporte(fila: any) {
  const str_siglasnum = fila.siglasnum;
  const parts_siglasnum = str_siglasnum.split(" ");
  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_COMPROMISO";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];
 
  this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}

}