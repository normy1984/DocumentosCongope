import { ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ListModule } from '../list.module';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { MatDialogRef } from '@angular/material/dialog';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';

@Component({
    selector: 'app-lista-busca-ciu',
    imports: [ListModule],
    templateUrl: './lista-busca-ciu.component.html'
})
export class ListaBuscaCiuComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {

  public dataSource!: MatTableDataSource<any>;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  public SelectedRow: any = 0;
  private ServicioClienteHttp = inject(ClienthttpCongopeService);

  private apiurl = 'ListaCiu';


  // Columnas mostradas en la tabla
  public displayedColumns: string[] = [
    "cedruc",
    "descrip",
    "grupo"
  ];

  constructor(
    public dialogRef: MatDialogRef<ListaBuscaCiuComponent>,
    private alertas: AlertasSrvService
  ) {
    super();
  }

  ngOnInit(): void {
    this.CargarGrid(); // Llamar a la carga de datos aquí
  }

 


  CargarGrid() {
    this.ServicioClienteHttp.SeteoRuta(this.apiurl)
    this.ServicioClienteHttp.Obtener_Lista(true).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.sort = this.sort;
        
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  seleccionarFila(row: any) {
    this.SelectedRow = row;  // Almacena la fila seleccionada
  }


  CargarCiu() {
    this.dialogRef.close(this.SelectedRow);
  }

  
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


}
