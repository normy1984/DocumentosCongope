import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
//import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { FormBuilder,  FormsModule,  UntypedFormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ListModule } from 'app/paginas/generico/list.module';
import { MatTableDataSource } from '@angular/material/table';
import { configapp } from '@config/configapp';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { CompromisoDetalleMo } from 'app/models/movimientos/compromiso-mo';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { ParamSessionMo } from 'app/models/param-session';
import { MatTabsModule } from '@angular/material/tabs';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CiuMO } from 'app/models/params/ciu-mo';
import { Numeric } from 'd3';

@Component({
    selector: 'app-lista-ciu-edit',
    templateUrl: './lista-ciu-edit.component.html',
    imports: [EditModule, ListModule,
        MatAutocompleteModule, MatSlideToggleModule, MatDatepickerModule, FormsModule,
        MatTabsModule, MatCheckboxModule
    ],
    providers: [DatePipe,
        { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
        {
            provide: DateAdapter,
            useClass: MomentDateAdapter,
        },]
})


export class ListaCiuEditComponent implements OnInit{
  @Input('param') param!: string;
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  // Enlaces con las vistas
  @ViewChild('picker_fechanac') picker_fechanac!: MatDatepicker<Date>;
  @ViewChild('CmbGruposCiu') CmbGruposCiu!: ElementRef<HTMLInputElement>;
  @ViewChild('CmbCiudad') CmbCiudad!: ElementRef<HTMLInputElement>;
  @ViewChild('CmbTitulo') CmbTitulo!: ElementRef<HTMLInputElement>;
  @ViewChild('CmbBancos') CmbBancos!: ElementRef<HTMLInputElement>;

  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource !: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  private ServicioCrypt = inject(CryptService);

  public isGPRD: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: string = "";
  public active_item!: string;
  public codtab!: number;
  public codigo_ciudad!: number;
  public codigo_titulo!: number;
  public codigo_banco!: string;
  public ban_CargaEstructura: number = 0;
  public NroDocumento: number = 0;
  public sCreadoPor : string = "";
  public sModificadoPor: string = '';
  public OcultarError: boolean = true;
  public MensajeError: string = '';
  public bAprobar: boolean = true;
  public bDesaprobar: boolean = false;
  public anio: number = 0;
  public editedElement: any | null = null;
  public editedElementG: any | null = null;
  public isEditing: boolean = false;
  public resultado: any[] = [];
  public nEstado = 0;
  public out_nombre_estado = "";
  public colorEstado: string = 'label-default';
  public creadoPor: string = '';
  objeto: unknown;
  public EstructuraGruposCiu!: any[];
  public OpcionesGruposCiu!: any[];
  public EstructuraCiudad!: any[];
  public OpcionesCiudad!: any[];
  public EstructuraTitulo!: any[];
  public OpcionesTitulo!: any[];

  public EstructuraBancos!: any[];
  public OpcionesBancos!: any[];

  public checkedDiscapacidad: boolean = false;
  public Discapacidad = 0;
  public Contribespe = 0;
  public ObligadoConta = 0;

  public ChkRucoCed: boolean = false;
  public ChkObligadoConta: boolean = false;
  public NoValidar: boolean = false;
  public nRetornaValidacion  = 0;


  checked = false;
  public minDate_inicio = new Date(1900, 0, 1);
  public maxDate_inicio = new Date();

   /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [
  ];
/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public pagina: string = "Catalogos/CodigodeIdentificacionUnica";
  public rutaapi: string = "ListaCiu/seleccionar_ciu";
  public paginaA: string = "movimientos/proforma";
  public OptionsEstructura: any[] = [];

  bNuevoEditar: boolean = false;
  // Modelos para los datos del formulario
  blankObject = {} as CiuMO;
  ModeloDatos: CiuMO  = new CiuMO(this.blankObject);
  blankObjectCabecera = {} as CiuMO;
  ModeloDatosCabecera: CiuMO = new CiuMO(this.blankObjectCabecera);
  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private datePipe: DatePipe,
  ){
      this.FormularioDatos = this.formBuild.group({
        ChkDiscapacidad: [false],
        ChkContribespe: [false],
        ChkObligado_Conta: [false],  // Valor por defecto: false
    })
  }
  ngOnInit(): void {
    const datos = this.ServicioCrypt.decryptString(this.param);
    const arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.CargarGruposCiu();
    this.CargarCiudades();
    this.CargarTitulos();
    this.CargarBancos();
    this.active_item = arrayResultado[3];
    //this.CargarGrid();
    this.CargarForm();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      CmbGruposCiu: ["",[Validators.required]],
      codtab: [this.ModeloDatos.codtab],
      cedruc: [this.ModeloDatos.cedruc, [Validators.required]],
      descrip: [this.ModeloDatos.descrip, [Validators.required]],
      direcci: [this.ModeloDatos.direcci],
      telefon1: [this.ModeloDatos.telefon1],
      email1: [this.ModeloDatos.email1],
      ciudad: [this.ModeloDatos.ciudad],
      CmbCiudad: [this.ModeloDatos.nombre_ciudad],
      titulo: [this.ModeloDatos.titulo],
      CmbTitulo: [this.ModeloDatos.nombre_titulo],
      fechanac:[this.ModeloDatos.fechanac],
      ChkDiscapacidad: [this.ModeloDatos.discapacidad],
      ChkContribespe: [this.ModeloDatos.contribespe],
      ChkObligado_conta: [this.ModeloDatos.obligado_conta],
      porcen_disca: [this.ModeloDatos.porcen_disca],
      ChkRucoCed:[this.ModeloDatos.rucoced],
      contesp_nrores:[this.ModeloDatos.contesp_nrores],
      CmbBancos:[this.ModeloDatos.nombre_banco],
      nrocta:[this.ModeloDatos.nrocta],
      tipocta:[this.ModeloDatos.tipocta],
      numero_iden:[this.ModeloDatos.numero_iden],
      nombre_iden:[this.ModeloDatos.nombre_iden],
      serie:[this.ModeloDatos.serie],
    });
  }

    /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
    VolverPagina() {
      const parametro = this.ServicioCrypt.encryptString(this.codtab + "||" + this.active_item)
        this.router.navigate(['/' + this.pagina, parametro]);
    }

/**
 * Funcion que carga los valores iniciales del autocoomplete
 */
  /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion
   */


  /**
   * Funcion para cargar el filtro de informacion a partir de la estructyra de las partidas de gastos
   * @param filterValue
   * @returns
   */
    CargarDatosFiltrados(filterValue:string | null){
      return this.OptionsEstructura.filter(
        option =>
          {
            option.cuenta.toLowerCase().includes(filterValue)
            const valueMatch = option.cuenta.toLowerCase().includes(filterValue);
            const textMatch = option.nom_cue.toLowerCase().includes(filterValue);
            return valueMatch || textMatch;
          }
      );
    }

  /**
  * Funcion que genera la lista de datos para los grids de las pantallas
  */
  CargarForm():void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi)
    if (this.evento == "EDITAR") {
      this.bNuevoEditar = true;
      this.accion = "MANTENIMIENTO";
      this.ServicioClienteHttp.Obtener_x_Codigo(""+this.pk_identificador+"").subscribe({
        next: (data) => {
          if (data.success) {
            const result: any[] = JSON.parse(data.result);
            const datosForm: any = result[0];
            this.FormularioDatos.patchValue({
              CmbGruposCiu: datosForm.codtab + " - " + datosForm.grupo ,
              codtab: datosForm.codtab,
              cedruc: datosForm.cedruc,
              rucoced:datosForm.rucoced,
              descrip: datosForm.descrip,
              direcci: datosForm.direcci,
              telefon1: datosForm.telefon1,
              email1: datosForm.email1,
              ciudad: datosForm.ciudad,
              CmbCiudad: datosForm.nombre_ciudad,
              titulo: datosForm.titulo,
              CmbTitulo: datosForm.nombre_titulo,
              fechanac: datosForm.fechanac,
              ChkDiscapacidad: datosForm.discapacidad,
              porcen_disca:datosForm.porcen_disca,
              ChkContribespe:datosForm.contribespe,
              contesp_nrores:datosForm.contesp_nrores,
              ChkObligado_conta:datosForm.obligado_conta,
              CmbBancos:datosForm.banco + " - " + datosForm.nombre_banco ,
              nrocta:datosForm.nrocta,
              tipocta:datosForm.tipocta,
              numero_iden:datosForm.numero_iden,
              nombre_iden:datosForm.nombre_iden,
              serie:datosForm.serie,
              NoValidar:datosForm.ChkNoValida,
            });
          }


          this.AccionesBotones(this.nEstado);
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }

    if(this.evento == "NUEVO"){
      this.bNuevoEditar = false;
      this.FormularioDatos.patchValue({
        CmbGruposCiu: "" ,
        codtab: 0,
        cedruc: "",
        rucoced:0,
        descrip: "",
        direcci: "",
        telefon1: "",
        email1: "",
        ciudad: 0,
        CmbCiudad: "",
        titulo: 0,
        CmbTitulo: "",
        fechanac: "",
        ChkDiscapacidad: 0,
        porcen_disca:0,
        ChkContribespe:0,
        contesp_nrores:0,
        ChkObligado_conta:0,
        CmbBancos:"",
        nrocta:"",
        tipocta:0,
        numero_iden:"",
        nombre_iden:"",
        serie:"",
      });
    }
    this.FormularioDatos = this.CrearFormulario();

  }

  // CargarGrid():void {
  //   this.ServicioClienteHttp.SeteoRuta("ListaCiu/seleccionar_ciu/");
  //   this.ServicioClienteHttp.Obtener_x_Codigo("?cedruc="+this.pk_identificador+"").subscribe({
  //     next: (data) => {
  //       if (data.success) {
  //         this.resultado = JSON.parse(data.result);
  //       }
  //       this.dataSource = new MatTableDataSource(this.resultado);
  //       this.dataSource.sort = this.sort;
  //     },
  //     error: (err) => {
  //       console.log(err.message)
  //     }
  //   })
  // }

  /**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
  ImprimirReporte(): void {

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT227_PROFORMA";
    DatosPdf.param1 = "PR";
    DatosPdf.param2 = this.anio.toString();
    DatosPdf.param3 = this.NroDocumento.toString();
    DatosPdf.param4 = "";
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }

  AbrirPickerFecAprob(): void {
    this.picker_fechanac.open();
  }

  iniciaEditList(element: any): void {
      this.isEditing = true; // Indicar que estamos en modo edición
  }

  /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
  finEditList(element: any): void {
    element.val_sal = 0; // Calcula el saldo
    this.editedElement = null; // Desactiva la edición
    this.editedElementG = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
    // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
  }


  /**
 * Guarda la información ingresada en el grid.
 */

  GuardarInformacion(): void {

    const sCedRuc = this.FormularioDatos.get('cedruc')?.value;
    if(sCedRuc == ''){
      this.alertas.MensajeError("Debe digitar una Cédula ó RUC");
      return;
    }

    if(this.FormularioDatos.get('descrip')?.value == ''){
      this.alertas.MensajeError("Debe digitar Apellidos y Nombres");
      return;
    }


    Swal.fire({
      title: "¿Está seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        const datosGuardar = this.FormularioDatos.getRawValue();
        const fechanacim = new Date(this.FormularioDatos.get('fechanac')?.value);

        this.Discapacidad = ((this.FormularioDatos.get('ChkDiscapacidad')?.value))?1:0;
        this.Contribespe = ((this.FormularioDatos.get('ChkContribespe')?.value))?1:0;
        this.ObligadoConta = ((this.FormularioDatos.get('ChkObligado_conta')?.value))?1:0;
        this.ModeloDatosCabecera.codtab = this.codtab;
        this.ModeloDatosCabecera.grupo = datosGuardar.CmbGruposCiu;
        this.ModeloDatosCabecera.cedruc = datosGuardar.cedruc;
        this.ModeloDatosCabecera.descrip = datosGuardar.descrip;
        this.ModeloDatosCabecera.direcci = datosGuardar.direcci;
        this.ModeloDatosCabecera.telefon1 = datosGuardar.telefon1;
        this.ModeloDatosCabecera.email1 = datosGuardar.email1;
        this.ModeloDatosCabecera.ciudad = this.codigo_ciudad.toString();
        this.ModeloDatosCabecera.nombre_ciudad = '';//datosGuardar.nombre_ciudad;
        this.ModeloDatosCabecera.titulo = this.codigo_titulo;
        this.ModeloDatosCabecera.nombre_titulo  = '';//datosGuardar.nombre_titulo;
        this.ModeloDatosCabecera.rucoced = datosGuardar.rucoced;
        this.ModeloDatosCabecera.discapacidad = this.Discapacidad;
        this.ModeloDatosCabecera.contribespe = this.Contribespe;
        this.ModeloDatosCabecera.banco = this.codigo_banco;
        this.ModeloDatosCabecera.nombre_banco = '';//datosGuardar.nombre_banco;
        this.ModeloDatosCabecera.nrocta = datosGuardar.nrocta;
        this.ModeloDatosCabecera.tipocta = datosGuardar.tipocta;
        this.ModeloDatosCabecera.nombre_tipocta = '';//datosGuardar.nombre_tipocta;
        this.ModeloDatosCabecera.numero_iden = datosGuardar.numero_iden;
        this.ModeloDatosCabecera.nombre_iden = datosGuardar.nombre_iden;
        this.ModeloDatosCabecera.fechanac = fechanacim.toISOString().substring(0,10);
        this.ModeloDatosCabecera.porcen_disca = datosGuardar.porcen_disca;
        this.ModeloDatosCabecera.contesp_nrores = datosGuardar.contesp_nrores;
        this.ModeloDatosCabecera.obligado_conta = this.ObligadoConta;
        this.ModeloDatosCabecera.serie = datosGuardar.serie;

        this.GuardarCabecera();
      }
    });
  }


/**
 * Guarda la cabecera en el servidor.
 */

  GuardarCabecera(): void {

    this.ServicioClienteHttp.SeteoRuta("ListaCiu/inserta_actualiza_ciu");
    console.log(this.ModeloDatosCabecera);
    this.ServicioClienteHttp.Insertar(this.ModeloDatosCabecera).subscribe({
      next: (data) => {
        if (data.success) {
          //const retorno: any[] = JSON.parse(data.result);
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }
/**
 * Guarda el detalle en el servidor.
 */
  CargarArchivos(): void {
  }

  AccionesBotones(estado: number) {

    this.colorEstado = 'label-default';
    if(estado == 2){
      this.colorEstado = 'label-danger';
    }
    if(estado == 3){
      this.colorEstado = 'label-info';
    }
  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
    switch (opcion)
    {
      case "CmbGruposCiu":
        filterValue = this.CmbGruposCiu.nativeElement.value.toLowerCase();
        this.OpcionesGruposCiu = this.EstructuraGruposCiu.filter(option => option.grupo.toLowerCase().includes(filterValue));
        this.codtab = this.OpcionesGruposCiu[0]?.codtab || 0;
      break;
      case "CmbCiudad":
        filterValue = this.CmbCiudad.nativeElement.value.toLowerCase();
        this.OpcionesCiudad = this.EstructuraCiudad.filter(option => option.nombre_ciudad.toLowerCase().includes(filterValue));
        this.codigo_ciudad = this.OpcionesCiudad[0]?.codigo_ciudad || 0;
      break;
      case "CmbTitulo":
        filterValue = this.CmbTitulo.nativeElement.value.toLowerCase();
        this.OpcionesTitulo = this.EstructuraTitulo.filter(option => option.nombre_titulo.toLowerCase().includes(filterValue));
        this.codigo_titulo= this.OpcionesTitulo[0]?.codigo_titulo || 0;
      break;
      case "CmbBancos":
        filterValue = this.CmbBancos.nativeElement.value.toLowerCase();
        this.OpcionesBancos = this.EstructuraBancos.filter(option => option.nombre_banco.toLowerCase().includes(filterValue));
        this.codigo_banco= this.OpcionesBancos[0]?.codigo_banco || 0;
      break;
    }
  }

    CargarGruposCiu(): void {
      this.ServicioClienteHttp.SeteoRuta("ListaCiu/grupos_ciu");
      this.ServicioClienteHttp.Obtener_Lista().subscribe({
        next: (data) =>
        {
          if (data.success)
          {
            this.EstructuraGruposCiu = JSON.parse(data.result);
            this.OpcionesGruposCiu = this.EstructuraGruposCiu.slice();
            this.codtab = this.EstructuraGruposCiu[0].codtab;
          }
          else
          {
            this.alertas.MensajeError(data.message);
          }

          this.FormularioDatos.patchValue({
            CmbGruposCiu: this.codtab + " - " + this.EstructuraGruposCiu[0].grupo,
          });

        },
        error: (err) =>
        {
          //console.log(err.message);
          //alert(err.message);
        }
      });
    }

    CargarCiudades(): void {
      this.ServicioClienteHttp.SeteoRuta("ListaCiu/ciudades");
      this.ServicioClienteHttp.Obtener_Lista().subscribe({
        next: (data) =>
        {
          if (data.success)
          {
            this.EstructuraCiudad = JSON.parse(data.result);
            this.OpcionesCiudad = this.EstructuraCiudad.slice();
            this.codigo_ciudad = this.EstructuraCiudad[0].codigo_ciudad;
          }
          else
          {
            this.alertas.MensajeError(data.message);
          }

          this.FormularioDatos.patchValue({
            CmbCiudad: this.codigo_ciudad + " - " + this.EstructuraCiudad[0].nombre_ciudad,
          });

        },
        error: (err) =>
        {
          console.log(err.message);
          //alert(err.message);
        }
      });
    }

    CargarTitulos(): void {
      this.ServicioClienteHttp.SeteoRuta("ListaCiu/titulos");
      this.ServicioClienteHttp.Obtener_Lista().subscribe({
        next: (data) =>
        {
          if (data.success)
          {
            this.EstructuraTitulo = JSON.parse(data.result);
            this.OpcionesTitulo = this.EstructuraTitulo.slice();
            this.codigo_titulo = this.EstructuraTitulo[0].codigo_titulo;
          }
          else
          {
            //this.alertas.MensajeError(data.message);
          }

          this.FormularioDatos.patchValue({
            CmbTitulo: this.codigo_titulo + " - " + this.EstructuraTitulo[0].nombre_titulo,
          });

        },
        error: (err) =>
        {
          //console.log(err.message);
        }
      });
    }

    CargarBancos(): void {
      this.ServicioClienteHttp.SeteoRuta("ListaCiu/bancos");
      this.ServicioClienteHttp.Obtener_Lista().subscribe({
        next: (data) =>
        {
          if (data.success)
          {
            this.EstructuraBancos = JSON.parse(data.result);
            this.OpcionesBancos = this.EstructuraTitulo.slice();
            this.codigo_banco= this.EstructuraBancos[0].codigo_banco;
          }
          else
          {
            this.alertas.MensajeError(data.message);
          }

          this.FormularioDatos.patchValue({
            CmbBancos: this.codigo_banco + " - " + this.EstructuraBancos[0].nombre_banco,
          });

        },
        error: (err) =>
        {
          console.log(err.message);
        }
      });
    }

    AbrirPickerFechaNac(): void {
      this.picker_fechanac.open();
    }

    focusOutFunction() : void{
      let  sCedRuc = this.FormularioDatos.get('cedruc')?.value;
      
      if(sCedRuc.length == 0 || this.bNuevoEditar == true){
        return;
      }

      if(sCedRuc.length < 13){
        sCedRuc = this.padR(sCedRuc, '0', 12) + "1"
      }

      this.ServicioClienteHttp.SeteoRuta("ListaCiu/seleccionar_ciu")
      this.ServicioClienteHttp.Obtener_x_Codigo(sCedRuc).subscribe({
          next: (data) => {
            if (data.success == true) {
              this.alertas.MensajeError("La Cédula/RUC ya existe");
              this.FormularioDatos.patchValue({
                cedruc: "",
              });
            }
            else{
                if(this.NoValidar == false){
                  this.ValidaIdentificacion("R",sCedRuc); 
                }
                else{
                  this.FormularioDatos.patchValue({
                    cedruc: sCedRuc,
                  });
              }
            }
          },
        })
    }
    
    ValidaIdentificacion(sTipoDoc:string, sCedRuc:string) {

      this.ServicioClienteHttp.SeteoRuta("ListaCiu/Validar_identificacion")
      this.ServicioClienteHttp.Obtener_x_Codigo(sTipoDoc + "," + sCedRuc).subscribe({
          next: (data) => {
            if (data.success == true) {
              const vEjemplo = data.result.split(":") ;
              if(vEjemplo[1].substring(0,1) == 0) {
                this.alertas.MensajeError("La Cédula/RUC ingresada es incorrecta");
                this.FormularioDatos.patchValue({
                  cedruc: "",
                }); 
              }
              else{
                this.FormularioDatos.patchValue({
                  cedruc: sCedRuc,
                }); 
              }
            }
            else{
              this.nRetornaValidacion = 0;  
            }
          },
        })
    }

    CheckChangeHandler(event: any){
      const isChecked = event.checked;
      this.NoValidar = isChecked;
   }

   padL(text:string, padChar:string, size:number): string {
    return (String(padChar).repeat(size) + text).substring( (size * -1), size) ;
  }

  padR(text:string, padChar:string, size:number): string {
    size = size - text.length;
    return (text + String(padChar).repeat(size));
  }


}

