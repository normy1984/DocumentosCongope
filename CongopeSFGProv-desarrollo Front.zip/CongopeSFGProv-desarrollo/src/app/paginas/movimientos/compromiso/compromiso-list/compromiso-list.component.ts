import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';

import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { MatDialog } from '@angular/material/dialog';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { configapp } from '@config/configapp';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
    selector: 'app-compromiso-list',
    templateUrl: './compromiso-list.component.html',
    imports: [
        ListModule
    ]
})
export class CompromisoListComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  // Inyecciones de servicios

  
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);

  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  // Configuración de la paginación
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource!: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  // Rutas de la API y navegación
  public pagina: string = "Movimientos/CompromisosPresupuestarios";
  public rutaapi: string = "Compromiso";

  // Columnas mostradas en la tabla
  public displayedColumns: string[] = [
    "accion", "siglasnum",
    "num_com", "descrip", "fec_asi", "des_cab", "tot_cre",
    "tot_deb"
  ];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService
  ) {
    super();
  }

  ngOnInit() {
     this.CargarGrid();
  }

  /**
   * Función que genera la lista de datos para los grids de las pantallas.
   */
  CargarGrid() {

    const Val_MovimientosPresupuestarios = {
      siglas_num: 'CO',
      VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    }


    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ListarCompromisos");
  
    this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.sort = this.sort;
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * Función que dirige a la pantalla para el nuevo registro.
   */
  NuevoRegistro() {
    this.router.navigate(['/' + this.pagina + '/nuevo']);
  }

  /**
   * Función que envía los datos para editar un registro.
   * @param objeto Objeto de tipo MovimientosPresupuestariosMo que se va a editar.
   */
  EditarRegistro(objeto: MovimientosPresupuestariosMo) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + objeto.siglasnum);
    this.router.navigate(['/' + this.pagina, parametro]);
  }

  /**
   * Función llamada para la exportación a Excel del formulario.
   */
  ExportarExcel() {
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'SIGLA': x.siglasnum,
        'COMPROMISO': x.num_com,
        'ESTADO': x.descrip,
        'FECHA': x.fec_asi,
        'DESCRIPCION': x.des_cab,
        'VALOR': x.tot_cre,
        'DEVENGADO': x.tot_deb,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   * Función que realiza los filtrados de los grids.
   * @param event Evento de entrada del filtro.
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
  ImprimirReporte(fila: any) {
    const str_siglasnum = fila.siglasnum;
    const parts_siglasnum = str_siglasnum.split(" ");
    let  DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte="RPT205_COMPROMISO";
    //DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
    DatosPdf.param1=parts_siglasnum[0];
    DatosPdf.param2=parts_siglasnum[1];
    
    this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });
  }

  /**
   * Función para cargar archivos asociados a una fila seleccionada.
   * @param fila Fila seleccionada de la tabla.
   */
  CargarArchivos(fila: any) {
    const str_siglasnum = fila.siglasnum;
    const parts_siglasnum = str_siglasnum.split(" ");
    let DatosArchivo: CargaArchivoMo = {
      tipo_documento: parts_siglasnum[0],
      codigo_documento: parts_siglasnum[1],
      anio: fila.out_anio.toString(),
      codsistema: 0,
      descripcion: ""
    };

    this.dialog.open(CargarArchivosComponent, {
      data: {
        DatosArchivo
      },
      width: '95%',
      height: '100%'
    });
  }
}
