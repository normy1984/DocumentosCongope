import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { TipoComprobanteMo } from 'app/models/params/tipo-comprobante-mo';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ParamSessionMo } from 'app/models/param-session';
import { Observable, catchError, map, of } from 'rxjs';
import { PartidaPresupuestariaDetMo } from 'app/models/movimientos/partidapresupuesriadet-mo';
import { ListabuscarpartidaListComponent } from 'app/paginas/generico/listabuscarpartida-list/listabuscarpartida-list.component';
import { VercertificadocompromisoListComponent } from 'app/paginas/reportes/vercertificadocompromiso-list/vercertificadocompromiso-list.component';
import { FormsModule } from '@angular/forms';  // Asegúrate de importar FormsModule
import { ConsultaAprobarDesaprobarService } from 'app/servicios/generico/consulta-aprobar-desaprobar.service';
import { BotonesMo } from 'app/models/movimientos/botones-mo';
import { CertificacionSinAfeCabCodMO } from 'app/models/movimientos/certificacionsinafecabcod-mo';
import { PartidaCertificacionSinAfeDetMO } from 'app/models/movimientos/partidacertificacionsinafedet-mo';

@Component({
    selector: 'app-certificadosinaf-edit',
    imports: [ListModule, EditModule, MatDatepickerModule, MatAutocompleteModule,
        FormsModule],
    templateUrl: './certificadosinaf-edit.component.html'
})
export class CertificadoSinAfEditComponent implements OnInit {[x: string]: any;

  /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    // Variables de visualización
    public anio: number = 0;
    public titulo: string =  "Certificaciones Sin Afectación Presupuestaria"
  @Input('param') param!: string;
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  public dataSource !: MatTableDataSource<any>;

  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = true;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "";
  public evento: string = "";
  public pruebas: string = "";
  public pk_identificador: string = "";
  public codigoCertificacion: string = '';
  public copiaresult:  any[]= []; 
   /**COLUMNAS MOSTRADAS */
   public displayedColumns: string[] = [
      "accion",
    "partida",
    "nom_cue",
    "valor",
    "val_dist" ,
    ];

  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */  
  public pagina: string =  "Movimientos/Certificacionessinafectacionpresupuestaria"
 
  public rutaapi: string = "CertificacionesSinAfeCab/CertificacionSinAfeCabCod";

  resultado: any[] = [];
  arrayCodigo: any[] = [];
  public OpcionesPartidas!: any[] ;
  public OpcionesDepartamentos!: any[];
  public OpcionesResponsables!: any[];

  public EstructuraPartidas: any[] = [];
  public EstructuraDepartamentos!: any[];
  public EstructuraResponsables!: any[];
  public EstructuraMaximo: any[]= [];
  public Maximo!: number;
  public opcion!: number;

  blankObject = {} as CertificacionSinAfeCabCodMO;
  blankObjectPartida = {} as PartidaCertificacionSinAfeDetMO ;
  blankObjectUno = {} as PartidaCertificacionSinAfeDetMO;
  blankObjectBotones = {} as BotonesMo;
  ModeloDatosBotones: BotonesMo = new BotonesMo(this.blankObjectBotones);
  ModeloDatos: CertificacionSinAfeCabCodMO = new CertificacionSinAfeCabCodMO(this.blankObject);
  ModeloDatosPartidaDetalle: PartidaCertificacionSinAfeDetMO = new PartidaCertificacionSinAfeDetMO(this.blankObjectUno);
  ModeloDatosPartida: PartidaCertificacionSinAfeDetMO = new PartidaCertificacionSinAfeDetMO(this.blankObjectPartida);
  

  //Para select combo
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('partida_desc') partida_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('departam_desc') departam_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fec_apr') picker_fec_apr!: MatDatepicker<Date>;
  @ViewChild('des_cab') des_cab!: ElementRef;

  // Variables de visualización
  public colorEstado: string = 'label-default';
  public acu_tip: string = '';
   public n_estado:string='';
  public estado: number = 0 ;
  public creado_por: string = '';
  public modificado_por: string = '';
  public anula_liquida: string='';
  public en_proceso: string='';
  public asoc: string='';
  public anulado_siglasnum: string='';
  public departam: number = 0;
  public accionbotones:boolean =false;

   // Flags de visibilidad para botones
  public OcultarBtnImprimir: boolean = false;
  /*
  public OcultarBtnAnular: boolean = true;
  public OcultarBtnLiquidar: boolean = true;
  public OcultarBtnDuplicar: boolean = false;
  public OcultarBtnDistribuir: boolean = true;
  public OcultarBtnVerSaldo: boolean = false;
  public OcultarBtnCargarArchivos: boolean = false;*/
  public OcultarBtnGuardar: boolean = false;
public OcultarBtnCancelar: boolean = false;
 /* 
   public OcultarLiqAnular: boolean = false;
  public OcultarAsociado: boolean = false;
  public OcultarPanelSecundario: boolean = false;
  public ActivarAgregar: boolean = true;
  public ActivarAsociado: boolean = false;*/
  public EditableDetalle: boolean = false;
  public ActivarSelectorPartida:  boolean = false;
 /* public OcultarBtnAprobar: boolean = true;
  public OcultarBtnDesaprobar: boolean = true;
  
  public bandera:  boolean = false;*/
    // Modelos para los datos del formulario
    blankObjectCabecera = {} as MovimientosPresupuestariosMo;
    ModeloDatosCabecera: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObjectCabecera);
    public nTipoPresupuestoID = 1;
  // Variable para guardar el valor seleccionado
  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServApruebaDesaprueba: ConsultaAprobarDesaprobarService  
  ) {
  }
  
/*
get num_com(){
  return this.FormularioDatos.controls['num_com'];
}

get cod_proceso(){
  return this.FormularioDatos.controls['cod_proceso'];
}
get valor_contrato(){
  return this.FormularioDatos.controls['valor_contrato'];
}
get val_cre(){
  return this.FormularioDatos.controls['val_cre'];
}
*/
public count:number=0;
  ngOnInit(): void {
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.arrayCodigo= this.pk_identificador.split(" "); 
    this.CargarDatosDepartamento();
    this.CargarDatosResponsables();
    this.CargarForm() ;   
  }

/**
 * Funcion que carga la informacion de la forma
 */
  CargarForm():void {
    console.log("Para ver Edicion2",this.evento);
    switch (this.evento) {  
      case "EDITAR":  
     // this.bandera=true;    
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
        this.AccionesAlEditar();
        console.log("Ruta Api1",this.rutaapi);
      break;
        case "DUPLICAR":
                 this.rutaapi="Certificacion/Liquidacion";    
          break;
      case "NUEVO":

      this.GuardarInformacion(0); 
      
        break;
    }  
    this.FormularioDatos = this.CrearFormulario();
  }


  AccionesAlEditar(){
        console.log("Para ver Edicion3",this.evento);
     if (this.evento == "EDITAR" ) {
      console.log("acutip1",this.pk_identificador);
      const Val_CertificadoSinAf = {
    
        VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'),
        acutip:this.pk_identificador,
      }
      this.isReadOnly = true;

     
      console.log("identificador1",Val_CertificadoSinAf); 
      this.ServicioClienteHttp.Insertar(Val_CertificadoSinAf).subscribe({
        next: (data) => {
          if (data.success) {   
            
            let result: any = JSON.parse(data.result); 
           
            let resultado: CertificacionSinAfeCabCodMO = result[0]; 
            this.FormularioDatos = this.CrearFormulario();
            this.acu_tip =resultado.acu_tip;
            this.estado=resultado.estado;
            this.n_estado =resultado.n_estado;
            this.departam_desc=this.departam_desc ;
            this.creado_por =resultado.creado_por;
            this.modificado_por =resultado.modificado_por; 
            this.CargarGrid(resultado);
            this.FormularioDatos.patchValue({
                  acu_tip :"CT "+resultado.acu_tip,
                  des_cab: resultado.des_cab,
                  fec_asi: resultado.fec_asi,
                  fec_apr: resultado.fec_apr,
                  departam:resultado.departam,
                  departam_desc:resultado.departam_desc,              
                  solicita_desc:resultado.solicita_desc,
              solicita:resultado.solicita,                
            });         
          }  
        },
        error: (err) => {
          console.log(err.message)
        }
      })
  
  }

  }
  /**
 * Carga información de departamentos desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosDepartamento(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/19");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraDepartamentos = data.result;
        this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Carga información de responsables desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosResponsables(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/54");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraResponsables = data.result;
        this.OpcionesResponsables = this.EstructuraResponsables.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}


  /**
    * Funcion que dirige a la pantalla para el nuevo registro
    */
  VolverPagina() {
    console.log("this.pagina",this.pagina);
    //this.pagina="Movimientos/Certificacionessinafectacionpresupuestaria";
    this.router.navigate([this.pagina]);
  }

  CrearFormulario(): UntypedFormGroup {
   /* let validacion=",[Validators.required]";
    if(this.evento="EDITAR"){
      validacion="";
    }*/
  const parts_siglasnum ="CT"+this.ModeloDatos.acu_tip;

    return this.formBuild.group({
      TxtpartidaSeleccionada:[""],//value: this.ModeloDatosPartida.partida
      acu_tip : [{value: this.ModeloDatos.acu_tip , disabled: this.isReadOnly }],
      des_cab: [{value: this.ModeloDatos.des_cab  }], 
      fec_asi: [this.ModeloDatos.fec_asi],
      fec_apr: [this.ModeloDatos.fec_apr],
      departam_desc: [this.ModeloDatos.departam_desc,[Validators.required]],
      certificado: ["",[Validators.required]],
      solicita_desc: ["",[Validators.required]],
      departam: [0],
      solicita: [0], 
    });
  }


  CargarModelo(){
   // let datosGuardar = this.FormularioDatos.getRawValue();  
       /*
    this.ModeloDatos.in_cod_proceso=datosGuardar.in_cod_proceso;    
    this.ModeloDatos.departam_desc=datosGuardar.departam_desc;
    this.ModeloDatos.solicita_desc=datosGuardar.solicita_desc;
    this.ModeloDatos.partida_desc=datosGuardar.partida_desc;
    this.ModeloDatos.siglasnum=datosGuardar.siglasnum;
    this.ModeloDatos.num_com=datosGuardar.num_com.trim();
    this.ModeloDatos.descrip=String(this.ParamSessiones.codemp)+"|"+String(this.ParamSessiones.anio)+"|"+String(this.ParamSessiones.codusu);
    this.ModeloDatos.fec_asi=datosGuardar.fec_asi;
    this.ModeloDatos.fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.out_fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.des_cab=datosGuardar.des_cab;
    this.ModeloDatos.tot_cre=datosGuardar.tot_cre;
    this.ModeloDatos.val_cre=datosGuardar.val_cre.length === 0?0:datosGuardar.val_cre; 
    this.ModeloDatos.creado_por= datosGuardar.creado_por;
    this.ModeloDatos.modificado_por = String(this.ParamSessiones.codusu);
    this.ModeloDatos.estado_desc=datosGuardar.estado_desc;
    this.ModeloDatos.estado=datosGuardar.estado;
    this.ModeloDatos.out_cre_por_desc="";
    this.ModeloDatos.out_mod_por_desc="";
    this.ModeloDatos.valor_contrato=datosGuardar.valor_contrato;   //.length === 0?0:this.ModeloDatos.valor_contrato;
    this.ModeloDatos.departam=datosGuardar.departam;
    this.ModeloDatos.solicita=datosGuardar.solicita;
    this.ModeloDatos.cod_proceso=datosGuardar.cod_proceso;
    this.ModeloDatos.out_anio=this.ParamSessiones.anio;
    this.ModeloDatos.VarSesion=this.ParamSessiones;
    if(datosGuardar.anulado_siglasnum!=0)
      this.ModeloDatos.anula_liquida=datosGuardar.anulado_siglasnum;*/
  }

CargarModelo1(accion:string,element:any): CertificacionSinAfeCabCodMO{
  
  console.log("this.editedElement",this.editedElement);
  //console.log("accion",accion);
  let datosGuardar = this.FormularioDatos.getRawValue(); 
  return datosGuardar;
}

CargarModeloPartidaDetalle(accion:string,element:any): PartidaCertificacionSinAfeDetMO{
  let datosGuardar = this.FormularioDatos.getRawValue(); 
    //Carga Modelo de datos
  this.ModeloDatosPartida.accion=accion;

  if (accion=='EDITAR'||accion=='ELIMINAR'){
    this.ModeloDatosPartida.valor=element.valor;
    this.ModeloDatosPartida.partida=element.partida;
  }else{
  this.ModeloDatosPartida.valor=parseFloat(datosGuardar.certificado);
  this.ModeloDatosPartida.partida=datosGuardar.TxtpartidaSeleccionada;}
  this.ModeloDatosPartida.VarSesion=this.ParamSessiones;
  this.arrayCodigo= datosGuardar.acu_tip.split(" ");
  this.ModeloDatosPartida.acutip=parseInt(this.arrayCodigo[1]);
    return this.ModeloDatosPartida;
}
 getDescripcion(): string {
    return this.FormularioDatos.get('des_cab')?.value || '';
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  AccionEnNuevo(alternativa:number) {
    this.ServicioClienteHttp.SeteoRuta("CertificacionesSinAfeCab/PartidaSinAfeCabecera");
   this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
        next: (data: { success: any; result: string; message: any; }) => 
        {
          if (data.success) 
          {

                let resultado = JSON.parse(data.result);   
                console.log("Para ver edicion1"+resultado);    
                this.pk_identificador=resultado[0].out_acu_tip;                
                if(alternativa==1)             
                  this.alertas.MensajeAlerta("Registro CT "+ this.pk_identificador+" actualizado exitosamente");
                this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
                this.ngOnInit();
          } else {
                this.alertas.MensajeError(data.message);
          }
        },
        error: (err: { message: any; }) => {
              console.log(err.message)
        }
      })       
  }


  VerificarPartidaDuplicada(partida:string):Observable<any[]> {
    this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/PartidaDuplicada/"+  this.ParamSessiones.anio+
      "/"+partida +"?in_codemp=" + this.ParamSessiones.codemp + "&in_acutip="+ this.pk_identificador 
    );

  return this.ServicioClienteHttp.Obtener_Lista().pipe(
    map((data) => {
      if (data.success) {
        return JSON.parse(data.result) as any[];
      } else {
        throw new Error("Error en la respuesta del servidor");
      }
    }),
    catchError((err) => {
      console.error(err.message);
      return of([]); // Devuelve un arreglo vacío en caso de error
    })
  );
}
   
/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
GuardarInformacionDetallePartida(variablepartida:string ) {
  //Validar si hay duplicado
  this.VerificarPartidaDuplicada(variablepartida).subscribe((resultado) => {
  if(resultado[0].existe>0){
    this.alertas.MensajeAlerta("La Partida ya existe en este Movimiento, verifique por favor");
  }
  else{
      Swal.fire({
        title: "Esta seguro de realizar los cambios?",
        showDenyButton: true,
        confirmButtonText: "Guardar",
        denyButtonText: "Cancelar",
        customClass: {
          confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
          denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
          title: 'swal-title' ,
          popup: 'swal-popup-custom'   
        }
      }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        console.log("result.isConfirmed",result.isConfirmed);
        this.InsertaPartida('NUEVO',null);
        this.ngOnInit();  
      }
    });
    }
  });
}
 

  InsertaPartida(accion:string,element:any){
 this.ServicioClienteHttp.SeteoRuta("CertificacionesSinAfeCab/PartidaSinAfeDetalle/");
 
  this.CargarModeloPartidaDetalle(accion,element);

          this.ServicioClienteHttp.Insertar(this.ModeloDatosPartida).subscribe({
            next: (data) => {
              if (data.success) {
                //console.log("REsultado Servicio:"+data.result);
               // this.pk_identificador=data.result[0].siglasnum;
            //    this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
          //  this.router.navigate(['/' + this.pagina, this.param]);
            //this.alertas.MensajeConTimer("Partida creada exitosamente",true);
           // this.ngOnInit();           
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
}
/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
GuardarInformacion(alternativa:number) {

    console.log("Para ver Edicion4s",this.evento);
if(this.evento=="NUEVO"){
   this.ModeloDatos.VarSesion=this.ParamSessiones;
    this.ModeloDatos.acu_tip= this.arrayCodigo.toString();
    this.ModeloDatos.accion=this.evento;
    this.ModeloDatos.estado=this.estado;
    const date = new Date();
    const formattedDate = date.toISOString().split('T')[0];
    this.ModeloDatos.fec_asi=formattedDate ;
}else{
let datosGuardar = this.FormularioDatos.getRawValue();

        Object.keys(this.ModeloDatos).forEach(key => {
          if (key in datosGuardar) {
            (this.ModeloDatos as any)[key] = (datosGuardar as any)[key];
          }
        });

        this.ModeloDatos.VarSesion=this.ParamSessiones;
        this.ModeloDatos.acu_tip= this.arrayCodigo.toString();
        this.ModeloDatos.accion=this.evento;
        this.ModeloDatos.estado=this.estado;

    Swal.fire({
        title: "Esta seguro de realizar los cambios?",
        showDenyButton: true,
        confirmButtonText: "Guardar",
        denyButtonText: "Cancelar",
        customClass: {
          confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
          denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
          title: 'swal-title' ,
          popup: 'swal-popup-custom'   
        }
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          // Reemplazo los valores del objeto inicial por los del formulario
        

               }

    });}

                      this.AccionEnNuevo(alternativa);
  }

  AbrirPickerFecAsi(): void {
    this.picker_fec_asi.open();
  }
  
  AbrirPickerFecAprob():void{
    this.picker_fec_apr.open();
  }
 
  public editedElement: any | null = null;
  public editedElementG: any | null = null;
  public isEditing: boolean = false;

  iniciaEditList(element: any): void {
    this.isEditing = true;
    this.OcultarBtnGuardar=true;
    this.OcultarBtnCancelar=true;
    this.editedElement = element;
    if(element.out_asociac == 1){
      this.editedElementG = element;
    }
  }

   /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
   finEditList(element: any): void {
  console.log("element",element)
    element.val_sal = 0; // Calcula el saldo
    this.editedElement = null; // Desactiva la edición
    this.editedElementG = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
     this.InsertaPartida('EDITAR',element);
    this.OcultarBtnGuardar=false;
    this.OcultarBtnCancelar=false;
  }


  VerCOAsociado(){
    const str_codigo_certificacion =  this.codigoCertificacion;
    const DatosArchivo: any = {
      tipo_reporte: "CO ASOCIADO",
      str_codigo_certificacion: str_codigo_certificacion
    };

    this.dialog.open(VercertificadocompromisoListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });

  }
  

   /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion 
   */
  
   FiltroAutocomplete(opcion: string) {
    console.log("opcion"+opcion);
    var filterValue = '';

    switch (opcion) {
      
      case "partida_desc":
          filterValue = this.partida_desc.nativeElement.value.toLowerCase();
          this.OpcionesPartidas = 
          this.EstructuraPartidas.filter(
            option=>
              {
                const textMatch=option.out_nom_cu.toLowerCase().includes(filterValue);
                return textMatch;
            }
        );
    
     
        this.FormularioDatos.patchValue({
          partida1: "prueba1",//this.OpcionesPartidas[0].out_cuenta.toString(),
        });
       break;

      case "departam_desc": 

          filterValue = this.departam_desc.nativeElement.value.toLowerCase();
          this.OpcionesDepartamentos = 
          this.EstructuraDepartamentos.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );
          console.log("departamento"+this.OpcionesDepartamentos[0].codigo.toString());
          this.FormularioDatos.patchValue({
            departam: this.OpcionesDepartamentos[0].codigo.toString(),
          });
      break;
      case "solicita_desc":
          filterValue = this.solicita_desc.nativeElement.value.toLowerCase();
          this.OpcionesResponsables = 
          this.EstructuraResponsables.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );

          this.FormularioDatos.patchValue({
          
            solicita: this.OpcionesResponsables[0].codigo.toString(),
          });
      break;
    }
  }

  /**
   * Carga informacion de departamento
   */
  CargarCatalogos(rutaA:string)
  {
    let opcion:string;
    if (rutaA.indexOf("/") >0){
    let arrayResultado = rutaA.split('/');
     opcion=arrayResultado[2];
    }
    else{
      opcion='0';
    }
    this.ServicioClienteHttp.SeteoRuta(rutaA);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {

          switch (opcion) {
            case '19':
              this.EstructuraDepartamentos= data.result;
              this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
              break;
              case '54':
                this.EstructuraResponsables= data.result;
                this.OpcionesResponsables = this.EstructuraResponsables.slice();

              break;
              case '0':
                this.EstructuraPartidas= data.result;
                this.OpcionesPartidas = this.EstructuraPartidas.slice();

              break;
              default:
                break;
          }         
        }
        else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  // Método para iniciar la edición de una fila
  editRow(row: any) {
    this.editedElement = row;
  }

  // Método para guardar cambios y salir del modo de edición
  saveChanges() {
    this.editedElement = null;
  }

  // Método para cancelar cambios y salir del modo de edición
  cancelEdit() {
    this.editedElement = null;
  }

     /**
   * Funcion que genera la lista de datos para los grids de las pantallas
   */

  CargarGrid( prueba:CertificacionSinAfeCabCodMO): void {
     console.log("this.evento",this.evento);
    switch (this.evento) {
     
      case "EDITAR":
     // case "DUPLICAR":
       this.ServicioClienteHttp.SeteoRuta("CertificacionesSinAfeCab/ListarPartidasCerSinAfe");
       console.log("Esta pasando");
        break;

      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Movimientos/CertificacionesPresupuestarias");
        break;
    }

//this.CargarModeloPartidaDetalle();
  this.ModeloDatosPartida.acutip=parseInt(prueba.acu_tip);

  this.ModeloDatosPartida.VarSesion=this.ParamSessiones;
    this.ServicioClienteHttp.Insertar(this.ModeloDatosPartida).subscribe({
      next: (data) => {
        if (data.success) {
          //this.resultado =  data.result;//esto cambie
          this.resultado =  JSON.parse(data.result);
          console.log("this.resultado",this.resultado);
        }
        else{
          this.resultado =[];
        }
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;
      },

      error: (err) => {
        console.log(err.message)
      }
    })

  }

   /** 
 * Calcula el total certificado de todas las transacciones.
 * @returns {number} El total comprometido.
 */
TotalCertificado(): number {
  return this.resultado
  .map(transaccion => transaccion.valor)
.reduce((valor, valorActual) => valor + valorActual, 0);
}
/** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.val_devengado)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total del saldo de todas las transacciones.
 * @returns {number} El total del saldo.
 */
TotalSaldo(): number {

  return this.resultado
    .map(transaccion => transaccion.saldo)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
ImprimirReporte(): void {
  const str_siglasnum = "CT "+this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  console.log("parts_siglasnum",parts_siglasnum);
  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_CERTIFICACION_SINAF";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];
  DatosPdf.VarSesion=this.ParamSessiones;
console.log("DatosPdf.VarSesion",DatosPdf.VarSesion);
  const dialogRef = this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}


/**
 * Función para cargar archivos.
 */

CargarArchivos(): void { 
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: Number(parts_siglasnum[1]),
    anio: this.ParamSessiones.anio,
    //fila.out_anio.toString(),
    codsistema: 0,
    descripcion: ""
  };

  this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}


/**
 * Controla las acciones de los botones según el estado del registro.
 * @param estado El estado del registro.
 */
/*
AccionesBotones(estado: number) {

    this.FormularioDatos.get('val_cre')?.valueChanges.subscribe(value => {
      if (value>0 && this.FormularioDatos.get('TxtpartidaSeleccionada')?.value!='')
        this.ActivarAgregar=false;
    });

    
  let arrayResultado = this.codigoCertificacion.split(' ');
  this.ServicioClienteHttp.SeteoRuta("Certificacion/AccionBotones?codemp="+this.ParamSessiones.codemp
    +"&sigtip="+arrayResultado[0]+"&acutip="+arrayResultado[1]+"&anio="+this.ParamSessiones.anio);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {

          let retorno: any[] = JSON.parse(data.result);
          this.ModeloDatosBotones.aprobar = retorno[0].aprobar;
          this.ModeloDatosBotones.desaprobar = retorno[0].desaprobar;
          this.ModeloDatosBotones.anular = retorno[0].anular;
          this.ModeloDatosBotones.liquidar = retorno[0].liquidar;
          this.ModeloDatosBotones.duplicar = retorno[0].duplicar ;
          this.ModeloDatosBotones.distribuir = retorno[0].distribuir;
          this.ModeloDatosBotones.carchivos = retorno[0].carchivos; 
          this.ModeloDatosBotones.asociado = retorno[0].asociado;        
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })

    switch (estado) {
      case 0:               
        break;
        case 1:

        break;
      case 2:
        this.OcultarBtnGuardar=false;
        this.OcultarBtnCancelar=false;
        this.EditableDetalle=false;
        break;
      case 3:  //Aprobado   
        this.OcultarBtnImprimir = false;
        this.OcultarBtnGuardar = true;
        this.OcultarBtnCancelar = true;
        this.ActivarSelectorPartida=true;
        this.ActivarAgregar=true;
        this.ActivarAsociado=true;
        this.num_com.disable();
        this.colorEstado = 'label-info';
        this.EditableDetalle=true;
        this.val_cre.disable();
        this.valor_contrato.disable();
        this.cod_proceso.disable();
  
           
        break;    
      default:
        this.OcultarBtnImprimir = true;             
        break;}
}*/

/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
EliminarRegistro(objeto: TipoComprobanteMo) {

  /*let textoEliminar:string = objeto.descripcion;
  let codigo:string = objeto.sigla;

  Swal.fire({
    title: "Esta seguro de eliminar "+ textoEliminar + "?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
  /*  if (result.isConfirmed) {

      this.ServicioClienteHttp.Eliminar(codigo).subscribe({
        next: (data) => {
          if (data.success) {
            this.CargarGrid();
            this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  });*/
}
/**
 * Funcion para eliminar un registro
 * @param objeto 
 */

EliminarRegistroPartida(element:any) {

  Swal.fire({
    title: "¿Está seguro de eliminar la partida?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar",
    customClass: {
        confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
        denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
        title: 'swal-title' ,
        popup: 'swal-popup-custom'  }
  }).then((result) => {
   
    if (result.isConfirmed) {

      this.InsertaPartida('ELIMINAR',element);
      this.ngOnInit();
    
    }
  });  
}


  
BuscarPartida() {
  const DatosArchivo: any = {
    tipo_reporte: "BUSCAR PARTIDA",
    TxtpartidaSeleccionada: "",
    nTipoPresupuesto:this.nTipoPresupuestoID,
  };

  const DialogRef = this.dialog.open(ListabuscarpartidaListComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });

   DialogRef.afterClosed().subscribe(result => {
    if (result) {
      //console.log(result);
      this.FormularioDatos.patchValue({
        TxtpartidaSeleccionada: result,
      // partida_desc:result,
      });
    }
  });

}
public TxtpartidaSeleccionada = "";
radioChangeHandler(value: any){
  this.nTipoPresupuestoID = value;
  this.FormularioDatos.patchValue({
    TxtpartidaSeleccionada: "",
    TxtNombrepartidaSeleccionada:"",
  });
}
 
}


