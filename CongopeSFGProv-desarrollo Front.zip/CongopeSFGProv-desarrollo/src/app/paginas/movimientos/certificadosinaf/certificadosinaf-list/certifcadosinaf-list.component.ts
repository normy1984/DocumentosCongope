import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { CertificacionesSinAfeCabMO } from 'app/models/movimientos/certificacionsinafecab-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { MatDialog } from '@angular/material/dialog';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ParamSessionMo } from 'app/models/param-session';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import Swal from 'sweetalert2';


@Component({
    selector: 'app-certificadosinaf-list',
    templateUrl: './certificadosinaf-list.component.html',
    imports: [
        ListModule, MatDatepickerModule,
    ]
})

export class CertificadoSinAfListComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  // Inyecciones de servicios
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource!: MatTableDataSource<any>;

  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  // Configuración de la paginación
    public FormularioDatos!: UntypedFormGroup;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fecha_ini') picker_fecha_ini!: MatDatepicker<Date>;

  // Rutas de la API y navegación
 // public pagina: string = "Movimientos/CertificacionesSinAfe";
  public rutaapi: string = "CertificacionesSinAfeCab/ListarCertificacionesSinAfeCab";
 //public rutaapi: string = "Certificacionessinafectacionpresupuestaria";
 public pagina: string = "Movimientos/Certificacionessinafectacionpresupuestaria";
  // Columnas mostradas en la tabla
  public displayedColumns: string[] = [
    "accion","out_documento","out_estado","out_fecha","out_descripcion","out_valor"
  ];

  constructor(
    private router: Router,
    public dialog: MatDialog,private fb: FormBuilder
  
  ) {
    super();
  }
  get fecha_ini(){
    return this.FormularioDatos.controls['fecha_ini'];//: resultado.fec_asi,
  }
  ngOnInit() {
    
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.FormularioDatos = this.fb.group({
      fecha_ini: [new Date()]  // <-- Valor por defecto: hoy
    });
     this.CargarGrid();
  }
 



  AbrirPickerFechaIni(): void {
    this.picker_fecha_ini.open();
  }
  

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CargarGrid() {
    
       const Val_MovimientosPresupuestarios = {
        
         VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'),
         fecha_ini: '2024-01-01',
         fecha_fin: '2024-12-31',
       }
       this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
       //if (this.evento == "EDITAR") {
      //  console.log("REsultado"+this.rutaapi);
      //  console.log("REsultado"+JSON.stringify(Val_MovimientosPresupuestarios));
         this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
           next: (data) => {
             if (data.success) {
                 
              // let result: any = data.result;
            // console.log("REsultado"+result);
             let resultado: any = JSON.parse(data.result);
             
             this.FormularioDatos.patchValue({
              
              fecha_ini: resultado.fecha_ini,
          
            }); 
             this.dataSource = new MatTableDataSource(resultado);
             this.dataSource.sort = this.sort;
             this.FormularioDatos.patchValue({
               
              
              fecha_ini: resultado.fecha_ini,}); 
             }

            /* return this.formBuild.group({
              TxtpartidaSeleccionada:[""],
              fec_asi: [this.ModeloDatos.fec_asi],
              
            });*/
             
           },
           error: (err) => {
             console.log(err.message)
           }
         })
      // }
     }
  
     public formBuild = inject(FormBuilder);
     CrearFormulario(): UntypedFormGroup {
   
       return this.formBuild.group({
         TxtpartidaSeleccionada:[""],
         fecha_ini: [new Date()],
         
       });
     }
     CargarForm():void {
      this.FormularioDatos = this.CrearFormulario();
     }
   /**
    * Funcion que dirige a la pantalla para el nuevo registro
    */
   NuevoRegistro() {
     let parametro = this.ServicioCrypt.encryptString("NUEVO||-1")
     Swal.fire({
       title: "Desea generar una nueva Certificación Sin Afectación Presupuestaria?",
       showDenyButton: true,
       confirmButtonText: "Si",
       denyButtonText: "No",
       customClass: {
         confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
         denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
         title: 'swal-title' ,
         popup: 'swal-popup-custom'   
       }
     }).then((result) => {
       if (result.isConfirmed) {
         this.router.navigate(['/'+this.pagina, parametro]);
       }   
     })
   } 
 

  /**
   * Función que envía los datos para editar un registro.
   * @param objeto Objeto de tipo MovimientosPresupuestariosMo que se va a editar.
   */
  EditarRegistro(objeto: CertificacionesSinAfeCabMO) {
    console.log("objeto"+JSON.stringify(objeto));
       let arrayCodigo= objeto.out_documento.split(" ");
    console.log("objeto"+this.pagina);//objeto.out_documento
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" +arrayCodigo[1]);
    console.log("objeto"+parametro);
    this.router.navigate(['/' + this.pagina, parametro]);
   // this.router.navigate(['/' + 'Certificacionessinafectacionpresupuestaria', parametro]);

  }

  
  /**
   * Función llamada para la exportación a Excel del formulario.
   */
  ExportarExcel() {
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'SIGLA': x.siglasnum,
        'COMPROMISO': x.num_com,
        'ESTADO': x.descrip,
        'FECHA': x.fec_asi,
        'DESCRIPCION': x.des_cab,
        'VALOR': x.tot_cre,
        'DEVENGADO': x.tot_deb,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   * Función que realiza los filtrados de los grids.
   * @param event Evento de entrada del filtro.
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  /**
   * Función para enviar la impresión del reporte en PDF.
   * @param fila Fila seleccionada de la tabla.
   */
  ImprimirReporte(fila: any) {
    const str_siglasnum = fila.siglasnum;
    const parts_siglasnum = str_siglasnum.split(" ");
    let  DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte="RPT205_COMPROMISO";
    //DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
    DatosPdf.param1=parts_siglasnum[0];
    DatosPdf.param2=parts_siglasnum[1];
    
    this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });
  }

  /**
   * Función para cargar archivos asociados a una fila seleccionada.
   * @param fila Fila seleccionada de la tabla.
   */
  CargarArchivos(fila: any) {
    const str_siglasnum = fila.siglasnum;
    const parts_siglasnum = str_siglasnum.split(" ");
    let DatosArchivo: CargaArchivoMo = {
      tipo_documento: parts_siglasnum[0],
      codigo_documento: parts_siglasnum[1],
      anio: fila.out_anio.toString(),
      codsistema: 0,
      descripcion: ""
    };

    this.dialog.open(CargarArchivosComponent, {
      data: {
        DatosArchivo
      },
      width: '95%',
      height: '100%'
    });
  }
}
