import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';

import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { Direction } from '@angular/cdk/bidi';
import { MatDialog } from '@angular/material/dialog';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { ParamSessionMo } from 'app/models/param-session';


@Component({
    selector: 'app-certificado-list',
    templateUrl: './certificado-list.component.html',
    imports: [
        ListModule
    ]
})
export class CertificadoListComponent 
extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */  
public pagina:string = "Movimientos/CertificacionesPresupuestarias";

public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  
/**COLUMNAS MOSTRADAS */   
public displayedColumns:string[] = ["accion",
  "siglasnum",
  "num_com","descrip","fec_asi", "out_fec_apr", "des_cab", "tot_cre",
  "tot_deb"];
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  public rutaapi:string = "MovimientosPresupuestarios?tipo=CE&anio="+this.ParamSessiones.anio;
  constructor(
    private router: Router,
    public dialog: MatDialog,
  ) {
    super();
  }


  ngOnInit() {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid();
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CargarGrid() {
   
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          let resultado: any = data.result;
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


 

  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    let parametro = this.ServicioCrypt.encryptString("NUEVO||-1")
    Swal.fire({
      title: "Desea generar una nueva Certificación?",
      showDenyButton: true,
      confirmButtonText: "Si",
      denyButtonText: "No",
      customClass: {
        confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
        denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
        title: 'swal-title' ,
        popup: 'swal-popup-custom'   
      }
    }).then((result) => {
      if (result.isConfirmed) {
        this.router.navigate(['/'+this.pagina, parametro]);
      }   
    })
  } 




  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto 
   */

  EditarRegistro(objeto: MovimientosPresupuestariosMo) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||"+objeto.siglasnum)
    this.router.navigate(['/'+this.pagina, parametro]);
  }


/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
  EliminarRegistro(objeto: MovimientosPresupuestariosMo) {

   // let textoEliminar:string = objeto.descrip;
   let textoEliminar:string = objeto.des_cab;
    let codigo:string = objeto.siglasnum;

    Swal.fire({
      title: "Esta seguro de eliminar "+ textoEliminar + "?",
      showDenyButton: true,
      confirmButtonText: "Eliminar",
      denyButtonText: "Cancelar",
      customClass: {
        confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
        denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
        title: 'swal-title' ,
        popup: 'swal-popup-custom'   
      }
    }).then((result) => {
  //Read more about isConfirmed, isDenied below 
      if (result.isConfirmed) {

        this.ServicioClienteHttp.Eliminar(codigo).subscribe({
          next: (data) => {
            if (data.success) {
              this.CargarGrid();
              this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'DOCUMENTO': x.siglasnum,
        'COMPROBANTE': x.num_com,
        'ESTADO': x.descrip,
        'FECHA': x.fec_asi,
        'DESCRIPCION': x.des_cab,
        'VALOR': x.tot_cre,
        'DEVENGADO': x.tot_deb,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }
 
  /**
   * 
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

/**
 * Funcion para enviar la impresion de los pdf
 * @param row 
 */
ImprimirReporte(fila: any) {
  const str_siglasnum = fila.siglasnum;
  const parts_siglasnum = str_siglasnum.split(" ");
  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];
  DatosPdf.VarSesion=this.ParamSessiones;
 
  this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}

/**
 * Función para cargar archivos asociados a una fila seleccionada.
 * @param fila Fila seleccionada de la tabla.
 */
CargarArchivos(fila: any) {
  const str_siglasnum = fila.siglasnum;
  const parts_siglasnum = str_siglasnum.split(" ");
  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: parts_siglasnum[1],
    anio: fila.out_anio.toString(),
    codsistema: 0,
    descripcion: ""
  };

  this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}
}
