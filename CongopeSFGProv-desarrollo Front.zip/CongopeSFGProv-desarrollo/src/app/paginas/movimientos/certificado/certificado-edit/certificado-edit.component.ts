import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { TipoComprobanteMo } from 'app/models/params/tipo-comprobante-mo';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ParamSessionMo } from 'app/models/param-session';
import { Observable, map } from 'rxjs';
import { PartidaPresupuestariaDetMo } from 'app/models/movimientos/partidapresupuesriadet-mo';
import { ListabuscarpartidaListComponent } from 'app/paginas/generico/listabuscarpartida-list/listabuscarpartida-list.component';
import { VercertificadocompromisoListComponent } from 'app/paginas/reportes/vercertificadocompromiso-list/vercertificadocompromiso-list.component';
import { FormsModule } from '@angular/forms';  // Asegúrate de importar FormsModule
import { VersaldopartidaListComponent } from 'app/paginas/reportes/versaldopartida-list/versaldopartida-list.component';
import { ConsultaAprobarDesaprobarService } from 'app/servicios/generico/consulta-aprobar-desaprobar.service';
import { VariablesAprobarDesaprobarMo } from 'app/models/administracion/aprobar-desaprobar-mo';
import { AprobCertificacionMo, CertificacionMo } from 'app/models/movimientos/certificacion-mo';
import { BotonesMo } from 'app/models/movimientos/botones-mo';


@Component({
    selector: 'app-certificado-edit',
    imports: [ListModule, EditModule, MatDatepickerModule, MatAutocompleteModule, ReactiveFormsModule,
        FormsModule],
    templateUrl: './certificado-edit.component.html'
})
export class CertificadoEditComponent implements OnInit {[x: string]: any;

  /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    // Variables de visualización
    public anio: number = 0;
  
  @Input('param') param!: string;
  public nombreSistema:string=  sessionStorage.getItem('NombreMenu')?.toString() ?? '{}';
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  public dataSource !: MatTableDataSource<any>;

  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = true;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "";
  public evento: string = "";
  public pruebas: string = "";
  public pk_identificador: string = "";
  public codigoCertificacion: string = '';
  public copiaresult:  any[]= []; 
   /**COLUMNAS MOSTRADAS */
   public displayedColumns: string[] = [
    "cuenta",
    "nom_cue",
    //"certificado",
    "out_val_cre",
    "val_devengado",
    "saldo",
    "val_dist" ,
    "accion",
    "versaldo",
    ];

  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */  
  //public pagina: string = "movimientos/certificados";
  public pagina: string =  "Movimientos/CertificacionesPresupuestarias"
  public rutaapi: string = "MovimientosPresupuestarios";
  public paginaA: string = "movimientos/certificados";
  resultado: any[] = [];
  arrayCodigo: any[] = [];
  public OpcionesPartidas!: any[] ;
  public OpcionesDepartamentos!: any[];
  public OpcionesResponsables!: any[];
  public titulo: string =  "Certificaciones Presupuestarias"
  public EstructuraPartidas: any[] = [];
  public EstructuraDepartamentos!: any[];
  public EstructuraResponsables!: any[];
  public EstructuraMaximo: any[]= [];
  public Maximo!: number;
  public opcion!: number;

  blankObject = {} as MovimientosPresupuestariosMo;
  blankObjectUno = {} as TipoComprobanteMo;
  blankObjectPartidas = {} as PartidaPresupuestariaDetMo;
  blankObjectCertificado = {} as CertificacionMo;
  blankObjectBotones = {} as BotonesMo;
  ModeloDatosBotones: BotonesMo = new BotonesMo(this.blankObjectBotones);
  ModeloDatos: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObject);
  ModeloDatosCert: CertificacionMo = new CertificacionMo(this.blankObjectCertificado);
  ModeloDatosPartidaDetalle: PartidaPresupuestariaDetMo = new PartidaPresupuestariaDetMo(this.blankObjectPartidas);

  //Para select combo
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('partida_desc') partida_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('departam_desc') departam_desc!: ElementRef<HTMLInputElement>;

  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fec_apr') picker_fec_apr!: MatDatepicker<Date>;

  // Variables de visualización
  public colorEstado: string = 'label-default';
  public estado_desc: string = '';
  public siglasnum: string = '';
  public creado_por: string = '';
  public modificado_por: string = '';
  public anula_liquida: string='';
  public en_proceso: string='';
  public asoc: string='';
  public estado: number=0;
  public anulado_siglasnum: string='';
public accionbotones:boolean =false;

   // Flags de visibilidad para botones
  public OcultarBtnImprimir: boolean = false;
  public OcultarBtnAnular: boolean = true;
  public OcultarBtnLiquidar: boolean = true;
  public OcultarBtnDuplicar: boolean = false;
  public OcultarBtnDistribuir: boolean = true;
  public OcultarBtnVerSaldo: boolean = false;
  public OcultarBtnCargarArchivos: boolean = false;
  public OcultarBtnGuardar: boolean = false;
  public OcultarBtnCancelar: boolean = false;
  public OcultarLiqAnular: boolean = false;
  public OcultarAsociado: boolean = false;
  public OcultarPanelSecundario: boolean = false;
  public ActivarAgregar: boolean = true;
  public ActivarAsociado: boolean = false;
  public EditableDetalle: boolean = false;
  public OcultarBtnAprobar: boolean = true;
  public OcultarBtnDesaprobar: boolean = true;
  public ActivarSelectorPartida:  boolean = false;
  //public VarApruebaDesaprueba:VariablesAprobarDesaprobarMo = new VariablesAprobarDesaprobarMo();

    // Modelos para los datos del formulario
    blankObjectCabecera = {} as MovimientosPresupuestariosMo;
    ModeloDatosCabecera: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObjectCabecera);
    public nTipoPresupuestoID = 1;
  // Variable para guardar el valor seleccionado
  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServApruebaDesaprueba: ConsultaAprobarDesaprobarService
  ) {
  }
get fec_asi(){
  return this.FormularioDatos.controls['fec_asi'];//: resultado.fec_asi,
}

get fec_apr(){
  return this.FormularioDatos.controls['fec_apr'];//: resultado.fec_asi,
}
get num_com(){
  return this.FormularioDatos.controls['num_com'];//: resultado.fec_asi,
}
get des_cab(){
  return this.FormularioDatos.controls['des_cab'];//: resultado.fec_asi,
}
get cod_proceso(){
  return this.FormularioDatos.controls['cod_proceso'];//: resultado.fec_asi,
}
get valor_contrato(){
  return this.FormularioDatos.controls['valor_contrato'];//: resultado.fec_asi,
}
get val_cre(){
  return this.FormularioDatos.controls['val_cre'];//: resultado.fec_asi,
}
get solicita_desc1(){
  return this.FormularioDatos.controls['solicita_desc'];//: resultado.fec_asi,
}
get departam_desc1(){
  return this.FormularioDatos.controls['departam_desc'];//: resultado.fec_asi,
}
public count:number=0;
  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];

      this.pk_identificador = arrayResultado[1];
      this.opcion=0;
      if(datos="NUEVO||-1")
        {         
           this.AccionEnNuevo();
        } 
       
      if(this.pk_identificador!="-1")
        this.CargarGrid();
  
      this.CargarCatalogos("TablasGenerales/DetalleSinDiccionario/19");
      this.CargarCatalogos("TablasGenerales/DetalleSinDiccionario/54"); 
      this.CargarCatalogos("PartidasPresupuestarias");
      this.CargarForm() ;
      this.AccionesBotones(this.estado); 
  }

 
  /**
 * Método para mostrar un cuadro de diálogo de confirmación y aprobar el compromiso presupuestario.
 */
AprobarCertificacion(): void {

  this.router.navigate([this.router.url]); 
 
  //this.obtenerDatos();
  
  Swal.fire({
    title: "¿Está seguro de aprobar la Certificación Presupuestaria " + this.codigoCertificacion + "?",
    showDenyButton: true,
    confirmButtonText: "Sí",
    denyButtonText: "No",
    customClass: {
      confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
      denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
      title: 'swal-title' ,
      popup: 'swal-popup-custom'   
    }
  }).then((result) => {

    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Certificacion/Aprobacion");
      this.ModeloDatosCert.VarSesion=this.ParamSessiones;
      this.ModeloDatosCert.sig_tip=this.arrayCodigo[0];
      this.ModeloDatosCert.acu_tip=this.arrayCodigo[1];

      this.ServicioClienteHttp.Insertar( this.ModeloDatosCert, true).subscribe({
        next: (data) => {                 
          if (data.success) {
     
            let resultado: any[] = JSON.parse(data.result);   
           // console.log("Al aprobar"+resultado[0].out_var_msg) ;     
            this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.codigoCertificacion);
            this.router.navigate(['/' + this.pagina, this.param]);
           // this.alertas.MensajeConTimer("Se aprobo la certificacion " + this.codigoCertificacion+" correctamente."+resultado[0].out_var_msg,true);
           this.alertas.MensajeConTimer(resultado[0].out_var_msg,true);

            this.ngOnInit();     
                     
          } else {
            this.resultado =[];       
            this.alertas.MensajeError(data.message);
          }
          console.log("Aprobar Certificacion",this.resultado);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}
/**
 * Funcion que carga la informacion de la forma
 */
  CargarForm():void {
    switch (this.evento) {
      case "EDITAR":
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
 
      break;
        case "DUPLICAR":
                 this.rutaapi="Certificacion/Liquidacion";    
          break;
      case "NUEVO":
        this.evento = "EDITAR";      
        break;
    } 

    if (this.evento == "EDITAR" ) {
      this.isReadOnly = true;
      //this.accion = "MANTENIMIENTO"; 
       if(this.pk_identificador!="-1"){
      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador+"?anio="+this.ParamSessiones.anio).subscribe({
        next: (data) => {
             
          if (data.success) {  
           //  this.AccionesBotones(this.estado);       
            let result: any = JSON.parse(data.result);
            let resultado: MovimientosPresupuestariosMo = result[0];   
            this.arrayCodigo =resultado.siglasnum.split(' ');
            this.codigoCertificacion=resultado.siglasnum; 
            this.estado_desc =resultado.estado_desc;
            this.siglasnum=resultado.siglasnum;
            this.creado_por =resultado.creado_por;
            this.modificado_por =resultado.modificado_por;     
            this.anulado_siglasnum="CE "+resultado.anulado_siglasnum;
           
           this.asoc=resultado.asoc;//quitar luego
            this.ModeloDatos.codigo_est=resultado.out_estado;
          //  this.estado=resultado.out_estado;
            this.estado=resultado.out_estado;
            this.en_proceso=resultado.en_proceso;
           //if( this.en_proceso== null)
      this.anula_liquida=resultado.anula_liquida;
                     
            resultado.departam_desc =  (resultado.departam_desc == "DEPARTAMENTOS") ? "" : resultado.departam_desc;
            resultado.solicita_desc = (resultado.solicita_desc == "RESPONSABLES") ? "" : resultado.solicita_desc;
            resultado.num_com=(resultado.num_com=="")? "" : resultado.num_com;    
            this.FormularioDatos.patchValue({
              
              siglasnum: resultado.siglasnum,
              num_com: resultado.num_com,
              fec_asi: resultado.fec_asi,
              fec_apr: resultado.fec_apr,
              des_cab: resultado.des_cab,
              tot_cre: resultado.out_tot_cre,           
              val_cre:resultado.val_cre == undefined? '':resultado.val_cre,
              estado_desc:resultado.estado_desc,
              //codigo_est:resultado.estado,            
              creado_por:resultado.creado_por,
              modificado_por:  resultado.modificado_por,
              departam:resultado.departam,
              solicita:resultado.solicita,         
              departam_desc:resultado.departam_desc,
              solicita_desc:resultado.solicita_desc,
              cod_proceso:resultado.cod_proceso,
              valor_contrato:resultado.valor_contrato,  
             // anulado_siglasnum:resultado.anula_liquida+" "+resultado.anulado_siglasnum, 

              anula_liquida: resultado.anula_liquida,
              anulado_siglasnum:"CE "+resultado.anulado_siglasnum,
         
            });         
          }  
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  }
    this.FormularioDatos = this.CrearFormulario();
  }


  /**
    * Funcion que dirige a la pantalla para el nuevo registro
    */
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }

  

  CrearFormulario(): UntypedFormGroup {
   /* let validacion=",[Validators.required]";
    if(this.evento="EDITAR"){
      validacion="";
    }*/

    return this.formBuild.group({
      TxtpartidaSeleccionada:[""],
      siglasnum: [{value: this.ModeloDatos.siglasnum
        , disabled: this.isReadOnly }],//[Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.maxLength(2)]
      num_com: [this.ModeloDatos.num_com,[Validators.required]],
      fec_asi: [this.ModeloDatos.fec_asi],
      fec_apr: [this.ModeloDatos.fec_apr],
      des_cab: [this.ModeloDatos.des_cab],
      tot_cre: [this.ModeloDatos.tot_cre],
     estado_desc:[this.ModeloDatos.estado_desc],
     // certificado: ["0",{value:this.ModeloDatos.certificado},[Validators.required]],
     val_cre: ["0",{value:this.ModeloDatos.val_cre}],
     // codigo_est: [this.ModeloDatos.codigo_est],
      partida_desc: [""],//[Validators.required]
      departam_desc: ["",[Validators.required]],
      solicita_desc: ["",[Validators.required]],
      partida: [0],
      departam: [0],
      solicita: [0], 
      creado_por:  [{value: this.ModeloDatos.creado_por}],//poner otra vez , ,disabled: this.isReadOnly 
      modificado_por:  [{value: this.ModeloDatos.modificado_por}],//, disabled: this.isReadOnly
      cod_proceso: ["",{value:this.ModeloDatos.cod_proceso}],
      valor_contrato:  ["",{value: this.ModeloDatos.valor_contrato }],
     // anula_liquida:  ["",{value: this.ModeloDatos.anula_liquida }],
      anulado_siglasnum:[{value: this.ModeloDatos.anulado_siglasnum  , disabled: this.isReadOnly }],
    });
  }



 

  CargarModelo(){
    let datosGuardar = this.FormularioDatos.getRawValue();     
    this.ModeloDatos.in_cod_proceso=datosGuardar.in_cod_proceso;    
    this.ModeloDatos.departam_desc=datosGuardar.departam_desc;
    this.ModeloDatos.solicita_desc=datosGuardar.solicita_desc;
    this.ModeloDatos.partida_desc=datosGuardar.partida_desc;
    this.ModeloDatos.siglasnum=datosGuardar.siglasnum;
    this.ModeloDatos.num_com=datosGuardar.num_com.trim();
    this.ModeloDatos.descrip=String(this.ParamSessiones.codemp)+"|"+String(this.ParamSessiones.anio)+"|"+String(this.ParamSessiones.codusu);
    this.ModeloDatos.fec_asi=datosGuardar.fec_asi;
    this.ModeloDatos.fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.out_fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.des_cab=datosGuardar.des_cab;
    this.ModeloDatos.tot_cre=datosGuardar.tot_cre;
    this.ModeloDatos.val_cre=datosGuardar.val_cre.length === 0?0:datosGuardar.val_cre;
   
    this.ModeloDatos.creado_por= datosGuardar.creado_por;
    this.ModeloDatos.modificado_por = String(this.ParamSessiones.codusu);
    this.ModeloDatos.estado_desc=datosGuardar.estado_desc;
   // this.ModeloDatos.estado=datosGuardar.estado;
    this.ModeloDatos.out_cre_por_desc="";
    this.ModeloDatos.out_mod_por_desc="";
    this.ModeloDatos.valor_contrato=datosGuardar.valor_contrato;   //.length === 0?0:this.ModeloDatos.valor_contrato;
    this.ModeloDatos.departam=datosGuardar.departam;
    this.ModeloDatos.solicita=datosGuardar.solicita;
    this.ModeloDatos.cod_proceso=datosGuardar.cod_proceso;
    this.ModeloDatos.out_anio=this.ParamSessiones.anio;
    this.ModeloDatos.VarSesion=this.ParamSessiones;
    if(datosGuardar.anulado_siglasnum!=0)
      this.ModeloDatos.anula_liquida=datosGuardar.anulado_siglasnum;
  }
/*
  cargarVariablesApruebaDesaprueba()
  {
    this.ServApruebaDesaprueba.GetVariablesAprobarDesaprobar('CO').subscribe({
      next: (result) => {
        this.VarApruebaDesaprueba = result;
        console.log( "Variable aprueba desaprueba"+this.VarApruebaDesaprueba );
      },
      error: (err) => {
        console.error('Error al obtener variables:', err);
      }
    });
  }*/

CargarModeloPartidaDetalle(){
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  this.ModeloDatosPartidaDetalle.sig_tip=parts_siglasnum[0];
  this.ModeloDatosPartidaDetalle.acu_tip=parts_siglasnum[1];
  this.ModeloDatosPartidaDetalle.varSesion=this.ParamSessiones;
}


/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  AccionEnNuevo() {

     this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
     this.ModeloDatos.VarSesion=this.ParamSessiones;
        if (this.pk_identificador == "-1") {
    
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios");
          this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
            next: (data) => {
              if (data.success) {
                this.pk_identificador=data.result[0].siglasnum;
                this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Certificación creada exitosamente",true);
            this.ngOnInit();           
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        } 
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
GuardarInformacion(opc:number) {

 this.OcultarPanelSecundario=false;
    Swal.fire({
      title: "Esta seguro de realizar los cambios1?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar",
      customClass: {
        confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
        denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
        title: 'swal-title' ,
        popup: 'swal-popup-custom'   
      }
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
     ///insertar movimiento
      this.CargarModelo();

      //  if (this.pk_identificador == "-1") {
         /*
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/Actualizar/");
          this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
            next: (data) => { 

              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          });*/
        //} else {
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/Actualizar");
       //   this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios");
       console.log("this.pk_identificador this.ModeloDatos",this.pk_identificador, this.ModeloDatos);
          this.ServicioClienteHttp.Actualizar(this.pk_identificador, this.ModeloDatos).subscribe({
            next: (data) => {
              if (data.success) {
                 //insertar detalle
              //   if (this.ModeloDatos.val_cre<=0 && this.FormularioDatos.get('TxtpartidaSeleccionada')?.value!=''){
                //  this.GuardarInformacionPartidaModel(this.ModeloDatosPartidaDetalle,1 )
             //   }  
             //esto no debe ir al guardar general
             if (opc==1) 
               { console.log("No debe ejecutar");
                this.GuardarInformacionPartida("");}
                 this.pk_identificador=data.result[0].siglasnum;

                 this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
             this.router.navigate(['/' + this.pagina, this.param]);
            // this.alertas.MensajeConTimer("Se actualizó el registro",true);
             this.ngOnInit();  
                   
              // this.alertas.MensajeConTimer("Se actualizó el registro",true);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
       // }
      }
    });
  }

  AbrirPickerFecAsi(): void {
    this.picker_fec_asi.open();
  }
  
  AbrirPickerFecAprob():void{
    this.picker_fec_apr.open();
  }
 
  public editedElement: any | null = null;
  public editedElementG: any | null = null;
  public isEditing: boolean = false;

  iniciaEditList(element: any): void {
     //while (element.out_val_cre>=element.valor_maximo)
    this.isEditing = true;
     this.OcultarBtnGuardar=true;
     this.OcultarBtnCancelar=true;
    element.out_asociac=2;
    if(element.out_asociac == 2){
      this.editedElement = element;
    }
    if(element.out_asociac == 1){
      this.editedElementG = element;
    }
     // Indicar que estamos en modo edición
  }

   /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
   finEditList(element: any): void {
  
    element.val_sal = 0; // Calcula el saldo
    this.editedElement = null; // Desactiva la edición
    this.editedElementG = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
    // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
   // this.GuardarInformacionPartidaModel(element,1);
    this.GuardarInformacionPartida(element);
    this.OcultarBtnGuardar=false;
    this.OcultarBtnCancelar=false;
  }


  VerCOAsociado(){
    const str_codigo_certificacion =  this.codigoCertificacion;
    const DatosArchivo: any = {
      tipo_reporte: "CO ASOCIADO",
      str_codigo_certificacion: str_codigo_certificacion
    };

    this.dialog.open(VercertificadocompromisoListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });

  }
  
  VerSaldoPartida(fila: any) {
    const str_partida = fila.cuenta;
    const DatosArchivo: any = {
      tipo_reporte: "SALDO DE PARTIDA",
      partida: str_partida
    };

    this.dialog.open(VersaldopartidaListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });
  }

 /* 
GuardarInformacionPartidaModel(partida:PartidaPresupuestariaDetMo, opc:number) {
    this.CargarModelo(); 
    this.CargarModeloPartidaDetalle();
    console.log("partida opc",partida," ",opc);
    partida.out_cuenta="";
    partida.out_sig_tip="";
    if (partida.certificado<=0 && partida.cuenta!="" &&opc !=1) {
      Swal.fire({
        title: "Ingrese un monto",
      })
    }else{
      const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;
      partida.varSesion=this.ParamSessiones;
      let arrayResultado =this.codigoCertificacion.split(' ');
      partida.sig_tip=arrayResultado[0];
      partida.acu_tip=arrayResultado[1];
      partida.val_devengado = partida.val_devengado ?? 0;
      partida.val_dist = partida.val_dist ?? 0;
      partida.val_cre=partida.certificado;
          this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetalleActualizar");
          this.ServicioClienteHttp.Insertar(partida).subscribe({
            next: (data) => {
              if (data.success) {
                
                if(data.message=="La partida ya existe")             
                  this.alertas.MensajeAlerta(data.message+"aqui1");     
  
                this.CargarGrid();
             
               } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          }) 
    }   
  }
*/

   /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion 
   */
  
   FiltroAutocomplete(opcion: string) {
    var filterValue = '';

    switch (opcion) {
      
      case "partida_desc":
          filterValue = this.partida_desc.nativeElement.value.toLowerCase();
          this.OpcionesPartidas = 
          this.EstructuraPartidas.filter(
            option=>
              {
                const textMatch=option.out_nom_cu.toLowerCase().includes(filterValue);
                return textMatch;
            }
        );
    
        this.FormularioDatos.patchValue({
          partida: this.OpcionesPartidas[0].out_cuenta.toString(),
        });
       break;

      case "departam_desc": 

          filterValue = this.departam_desc.nativeElement.value.toLowerCase();
          this.OpcionesDepartamentos = 
          this.EstructuraDepartamentos.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );
          this.FormularioDatos.patchValue({
            departam: this.OpcionesDepartamentos[0].codigo.toString(),
          });
      break;
      case "solicita_desc":
          filterValue = this.solicita_desc.nativeElement.value.toLowerCase();
          this.OpcionesResponsables = 
          this.EstructuraResponsables.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );

          this.FormularioDatos.patchValue({
          
            solicita: this.OpcionesResponsables[0].codigo.toString(),
          });
      break;
    }
  }

  /**
   * Carga informacion de departamento
   */
  CargarCatalogos(rutaA:string)
  {
    let opcion:string;
    if (rutaA.indexOf("/") >0){
    let arrayResultado = rutaA.split('/');
     opcion=arrayResultado[2];
    }
    else{
      opcion='0';
    }
    this.ServicioClienteHttp.SeteoRuta(rutaA);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {

          switch (opcion) {
            case '19':
              this.EstructuraDepartamentos= data.result;
              this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
              break;
              case '54':
                this.EstructuraResponsables= data.result;
                this.OpcionesResponsables = this.EstructuraResponsables.slice();

              break;
              case '0':
                this.EstructuraPartidas= data.result;
                this.OpcionesPartidas = this.EstructuraPartidas.slice();

              break;
              default:
                break;
          }         
        }
        else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  // Método para iniciar la edición de una fila
  editRow(row: any) {
    this.editedElement = row;
  }

  // Método para guardar cambios y salir del modo de edición
  saveChanges() {
    this.editedElement = null;
  }

  // Método para cancelar cambios y salir del modo de edición
  cancelEdit() {
    this.editedElement = null;
  }

     /**
   * Funcion que genera la lista de datos para los grids de las pantallas
   */
  CargarGrid(): void {
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetallePartidasCE");
        break;

      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Movimientos/CertificacionesPresupuestarias");
        break;
    }
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
      next: (data) => {
        if (data.success) {
          //this.resultado =  data.result;//esto cambie
          this.resultado =  JSON.parse(data.result);
        }
        else{
          this.resultado =[];
        }
              console.log("Aprobar Certificacion1",this.resultado);
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;
      },

      error: (err) => {
        console.log(err.message)
      }
    })

  }

   /** 
 * Calcula el total certificado de todas las transacciones.
 * @returns {number} El total comprometido.
 */
TotalCertificado(): number {
  return this.resultado
  .map(transaccion => transaccion.certificado)
.reduce((certificado, valorActual) => certificado + valorActual, 0);
  /*return this.resultado
    .map(transaccion => transaccion.out_val_cre)
     // al_cre)//certificado
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);*/
}
/** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.val_devengado)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total del saldo de todas las transacciones.
 * @returns {number} El total del saldo.
 */
TotalSaldo(): number {

  return this.resultado
    .map(transaccion => transaccion.saldo)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/**
 * Método para mostrar para liquidar Certificaciones Presupuestarias.
 */
LiquidarCertificacion(accion: string) {

  Swal.fire({
    title: "¿Está seguro/a que desea "+accion.toLowerCase()+" la Certificación Presupuestaria " + this.pk_identificador + "?",
    showDenyButton: true,
    confirmButtonText: "Si",
    denyButtonText: "No",
    customClass: {
      confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
      denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
      title: 'swal-title' ,
      popup: 'swal-popup-custom'   
    }
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
      this.CargarModelo();
    this.CargarModeloPartidaDetalle();
    this.rutaapi="Certificacion/Liquidacion";   
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"?accion="+accion);
   
   // this.ModeloDatos.anula_siglas_num=this.pk_identificador;

        this.ServicioClienteHttp.Insertar(this.ModeloDatosPartidaDetalle).subscribe({     
          next: (data) => {
            if (data.success) {
             // this.alertas.MensajeExito(this.pagina);
             // this.alertas.MensajeConTimer("Certificación duplicada exitosamente",true);
           // this.ngOnInit();
           this.pk_identificador=data.result[0].siglasnum;
                this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Certificación duplicada exitosamente",true);
            this.ngOnInit(); 
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })                  
    }
  });  
}


/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
ImprimirReporte(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];
  DatosPdf.VarSesion=this.ParamSessiones;

  const dialogRef = this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}


/**
 * Función para cargar archivos.
 */

CargarArchivos(): void { 
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: Number(parts_siglasnum[1]),
    anio: this.ParamSessiones.anio,
    //fila.out_anio.toString(),
    codsistema: 0,
    descripcion: ""
  };

  this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}

verificarCampos() {
  const valCre = this.FormularioDatos.get('val_cre')?.value;
  const partida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;

  const valCreValido =  valCre !== null &&valCre > 0 && valCre.trim() !== '' ;
  const partidaValida = typeof partida === 'string' && partida.trim() !== '';

  if( valCreValido && partidaValida)
    this.ActivarAgregar =false;
}
/**
 * Controla las acciones de los botones según el estado del registro.
 * @param estado El estado del registro.
 */

AccionesBotones(estado: number) {
//this.verificarCampos();
   // Escuchar cambios en el campo
    /*this.FormularioDatos.get('TxtpartidaSeleccionada')?.valueChanges.subscribe(value => {
       console.log("val_cre",this.FormularioDatos.get('val_cre')?.value);
      if (this.FormularioDatos.get('val_cre')?.value>0)
        this.ActivarAgregar=false;     
    });*/
      // Evaluar al iniciar también
  //this.verificarCampos();
     this.FormularioDatos.get('val_cre')?.valueChanges.subscribe(() => this.verificarCampos());
  this.FormularioDatos.get('TxtpartidaSeleccionada')?.valueChanges.subscribe(() => this.verificarCampos());


    
 // if (this.FormularioDatos.get('TxtpartidaSeleccionada')?.value === '') {
//this.ActivarAgregar=true;
//}

    
  let arrayResultado = this.codigoCertificacion.split(' ');
  console.log("arrayResultado",arrayResultado);
  this.ServicioClienteHttp.SeteoRuta("Certificacion/AccionBotones?codemp="+this.ParamSessiones.codemp
    +"&sigtip="+arrayResultado[0]+"&acutip="+arrayResultado[1]+"&anio="+this.ParamSessiones.anio);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {

          let retorno: any[] = JSON.parse(data.result);
          this.ModeloDatosBotones.aprobar = retorno[0].aprobar;
          this.ModeloDatosBotones.desaprobar = retorno[0].desaprobar;
          this.ModeloDatosBotones.anular = retorno[0].anular;
          this.ModeloDatosBotones.liquidar = retorno[0].liquidar;
          this.ModeloDatosBotones.duplicar = retorno[0].duplicar ;
          this.ModeloDatosBotones.distribuir = retorno[0].distribuir;
          this.ModeloDatosBotones.carchivos = retorno[0].carchivos; 
          this.ModeloDatosBotones.asociado = retorno[0].asociado;        
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })

    switch (estado) {
      case 0:               
        break;
        case 1:

        break;
      case 2:
        this.OcultarBtnGuardar=false;
        this.OcultarBtnCancelar=false;
        this.EditableDetalle=false;
        break;
      case 3:  //Aprobado   
        this.OcultarBtnImprimir = false;
        this.OcultarBtnGuardar = true;
        this.OcultarBtnCancelar = true;
        this.ActivarSelectorPartida=true;
      //  this.ActivarAgregar=true;
        this.ActivarAsociado=true;
        this.fec_asi.disable();
        this.fec_apr.disable();
        this.num_com.disable();
        this.departam_desc1.disable();
        this.des_cab.disable();
        this.solicita_desc1.disable();
        this.colorEstado = 'label-info';
        this.EditableDetalle=true;
        this.val_cre.disable();
        this.valor_contrato.disable();
        this.cod_proceso.disable();
      //  this.OcultarBtnGuardarCancelar = false;
  
           
        break;    
      default:
        this.OcultarBtnImprimir = true;             
        break;}
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y desaprobar el compromiso presupuestario.
 */
DesAprobarCertificacion(): void {
  Swal.fire({
    title: "¿Está seguro de desaprobar la Certificación Presupuestaria " +this.pk_identificador+ "?",
    showDenyButton: true,
    confirmButtonText: "Sí",
    denyButtonText: "No"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Certificacion/Desaprobacion");
      let arrayResultado = this.pk_identificador.split(' ');
      
      this.ModeloDatosCert.sig_tip=arrayResultado[0];
      this.ModeloDatosCert.acu_tip=parseInt(arrayResultado[1]);
      this.ModeloDatosCert.VarSesion=this.ParamSessiones;
      this.ServicioClienteHttp.Insertar(this.ModeloDatosCert).subscribe({
        next: (data) => {
          if (data.success) {
          
            this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Certificación desaprobada exitosamente",true);
            this.ngOnInit();
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y anular el compromiso presupuestario.
 */
QuitarAsociacion() {
  let arrayResultado = this.pk_identificador.split(' ');
  interface Planet{
    sig_tip: string;
    acu_tip: string;
    varSesion:ParamSessionMo 
  }
  
  //Object with properties
  let asociacion: Planet = {
    sig_tip : arrayResultado[0],
    acu_tip : arrayResultado[1],
    varSesion : this.ParamSessiones,
  };

  Swal.fire({
    title: "Se quitará la Asociación, no se podra volver a asociar nuevamente, desea continuar?",
    showDenyButton: true,
    confirmButtonText: "Si",
    denyButtonText: "No",
    customClass: {
      confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
      denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
      title: 'swal-title' ,
      popup: 'swal-popup-custom'   
    }
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
   // console.log("EL asociado0"+JSON.stringify(asociacion));
    if (result.isConfirmed) {
   
    this.ServicioClienteHttp.SeteoRuta("Certificacion/QuitarAsociacion");       
    this.ServicioClienteHttp.Insertar(asociacion).subscribe({     
          next: (data) => {
            if (data.success) {
            let resultadoQuitAsoc=JSON.parse(data.result);
          
              this.param = this.ServicioCrypt.encryptString("EDITAR||" + "CE "+resultadoQuitAsoc[0].out_acu_tip);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.ngOnInit();   
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })                  
    }
  });

}
/**
 * Método para mostrar un cuadro de diálogo de confirmación y anular el compromiso presupuestario.
 */
AnularCertificacion() {
  Swal.fire({
    title: "¿Está seguro/a que desea anular la Certificación Presupuestaria " + this.codigoCertificacion + "?",
    showDenyButton: true,
    confirmButtonText: "Si",
    denyButtonText: "No",
    customClass: {
      confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
      denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
      title: 'swal-title' ,
      popup: 'swal-popup-custom'   
    }
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
   
    this.CargarModelo();
    this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/AnulacionCertificacion");       
    this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({     
          next: (data) => {
            if (data.success) {
              this.param = this.ServicioCrypt.encryptString("EDITAR||" + data.result[0].siglasnum);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Anulación de  la Certificación realizada",true);
            this.ngOnInit();   

             // this.alertas.MensajeExito(this.pagina);
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })                  
    }
  });

  this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetallePartidasCE");
  //
  this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
    next: (data) => {

      if (data.success) {

        this.resultado = data.result;
      }
      console.log("Aprobar Certificacion2",this.resultado);
      this.dataSource = new MatTableDataSource(this.resultado);
      this.dataSource.sort = this.sort;

    },
    error: (err) => {
      console.log(err.message)
    }
  })
  
}

/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
EliminarRegistro(objeto: TipoComprobanteMo) {

  /*let textoEliminar:string = objeto.descripcion;
  let codigo:string = objeto.sigla;

  Swal.fire({
    title: "Esta seguro de eliminar "+ textoEliminar + "?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
  /*  if (result.isConfirmed) {

      this.ServicioClienteHttp.Eliminar(codigo).subscribe({
        next: (data) => {
          if (data.success) {
            this.CargarGrid();
            this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  });*/
}
/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
EliminarRegistroPartida(objeto: PartidaPresupuestariaDetMo) {

  let textoEliminar:string = objeto.cuenta;
  let arrayResultado =this.codigoCertificacion.split(' ');
  this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/Detalle");

  let codigo:string = this.ParamSessiones.codemp+"/"+this.ParamSessiones.anio+"/"+
        arrayResultado [0]+"/"+arrayResultado [1]+"/"+objeto.cuenta
        +"/"+objeto.out_sec_det  ;
  
  Swal.fire({
    title: "¿Está seguro de eliminar la partida? "+ textoEliminar + "?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar",
    customClass: {
        confirmButton: 'swal-confirm-btn',  // Clase CSS personalizada para el botón de confirmación
        denyButton: 'swal-deny-btn' ,        // Clase CSS personalizada para el botón de negación
        title: 'swal-title' ,
        popup: 'swal-popup-custom'   
      }
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {

      this.ServicioClienteHttp.Eliminar(codigo).subscribe
      ({
        next: (data) => {
          if (data.success) {
            this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.pk_identificador);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Partida eliminada exitosamente",true);
            this.ngOnInit();
          } else {
            this.alertas.MensajeError(data.message);
          }

          //this.RefrescarPantalla(data); 
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  });  
}

/*
RefrescarPantalla(data: any){
 
  if (data.success) {  
    let parametro = this.ServicioCrypt.encryptString("EDITAR||"+this.codigoCertificacion)
    this.router.navigate(['/'+this.pagina, parametro]);

    //grid
    this.ServicioClienteHttp.SeteoRuta( "PartidasPresupuestarias/DetallePartidasCE");
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe
    ({
      next: (data) => {
        if (data.success) {
        this.resultado = data.result;             
        }else{
        this.resultado= [];      
        } 
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort; 
      },
      error: (err) => {
        console.log(err.message)
      }
    })  
  } else {
    this.alertas.MensajeError(data.message);
  } 
}
*/
 /**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
//opcion:number

 GuardarInformacionPartida(element: any) {
console.log("element0",element);
    this.CargarModelo();
    this.CargarModeloPartidaDetalle();
 
    /////para
    const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value; 
    if(typeof element === 'string' && element.trim() === ''){
      console.log("element2",element);
      this.ModeloDatosPartidaDetalle.cuenta=sPartida;
      this.ModeloDatosPartidaDetalle.val_cre=this.ModeloDatos.val_cre;
      this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/Detalle");
    }else{
      console.log("element1",element);
      this.ModeloDatosPartidaDetalle.cuenta=element.cuenta;
      this.ModeloDatosPartidaDetalle.val_cre=element.certificado;
      this.ModeloDatosPartidaDetalle.out_sec_det= element.out_sec_det;
         console.log("CargarModeloPartidaDetalle",this.ModeloDatosPartidaDetalle);
      this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetalleActualizar");
    }
     // this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/Detalle");
      ///
   /* if (this.ModeloDatos.val_cre<=0 || this.FormularioDatos.get('TxtpartidaSeleccionada')?.value=='' ||this.FormularioDatos.get('val_cre')?.value ==0) {
      Swal.fire({
        title: "Ingrese un monto y partida",
      })
    }else
    {*/
     
      this.ServicioClienteHttp.Insertar(this.ModeloDatosPartidaDetalle).subscribe({
          next: (data) => {
            if (data.success) {
              //if(data.message=="La partida ya existe")
             let resultado: any[] = JSON.parse(data.result);  
             this.alertas.MensajeAlerta(resultado[0].out_message);     

             this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.codigoCertificacion);
             this.router.navigate(['/' + this.pagina, this.param]);
             this.ngOnInit();    
             } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
      }) 
    //}
    this.TxtpartidaSeleccionada ='';  
  }
  
BuscarPartida() {
  const DatosArchivo: any = {
    tipo_reporte: "BUSCAR PARTIDA",
    TxtpartidaSeleccionada: "",
    nTipoPresupuesto:this.nTipoPresupuestoID,
  };

  const DialogRef = this.dialog.open(ListabuscarpartidaListComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });

   DialogRef.afterClosed().subscribe(result => {
    if (result) {
      //console.log(result);
      this.FormularioDatos.patchValue({
        TxtpartidaSeleccionada: result,
      // partida_desc:result,
      });
    }
  });

}
public TxtpartidaSeleccionada = "";
radioChangeHandler(value: any){
  this.nTipoPresupuestoID = value;
  this.FormularioDatos.patchValue({
    TxtpartidaSeleccionada: "",
    TxtNombrepartidaSeleccionada:"",
  });
}
 
}


