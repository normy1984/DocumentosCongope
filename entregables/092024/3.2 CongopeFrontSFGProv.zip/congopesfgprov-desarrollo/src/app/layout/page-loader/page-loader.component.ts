import { Component } from '@angular/core';
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'; // Importar el módulo

@Component({
    selector: 'app-page-loader',
    templateUrl: './page-loader.component.html',
    styleUrls: ['./page-loader.component.scss'],
    standalone: true,
    imports: [LoadingBarModule,MatProgressSpinnerModule ],
})
export class PageLoaderComponent {
  constructor() {
    // constructor
  }
}
