import { DOCUMENT, NgClass } from '@angular/common';
import {
  Component,
  HostListener,
  Inject,
  ElementRef,
  OnInit,
  Renderer2,
  ChangeDetectorRef,
  inject, // Agregado para Zoom
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ConfigService } from '@config';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { InConfiguration, AuthService, LanguageService } from '@core';
import { NgScrollbar } from 'ngx-scrollbar';
import { MatMenuModule } from '@angular/material/menu';
import { FeatherIconsComponent } from '../../shared/components/feather-icons/feather-icons.component';
import { MatButtonModule } from '@angular/material/button';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { ParamSessionMo } from 'app/models/param-session';
import { MatTooltipModule } from '@angular/material/tooltip';
import { configapp } from '@config/configapp';

interface Notifications {
  mensaje: string;
  icono: string;
  color: string;
  componente: string;
  notificaciones: number;
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  standalone: true,
  imports: [
    MatButtonModule,
    FeatherIconsComponent,
    MatMenuModule,
    RouterLink,
    NgClass,
    NgScrollbar,
    MatTooltipModule
  ],
  providers: [LanguageService],
})
export class HeaderComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit{
  public config!: InConfiguration;
  public OcultarOpcionesAdmin: boolean = true;
  userImg?: string;
  homePage?: string;
  isNavbarCollapsed = true;
  flagvalue: string | string[] | undefined;
  countryName: string | string[] = [];
  langStoreValue?: string;
  defaultFlag?: string;
  isOpenSidebar?: boolean;
  docElement?: HTMLElement;
  isFullScreen = false;
  menus: any[] = [];
  EjercicioFiscal: any[] = [];
  VarEjercicioFiscal: string | null = 'EJERCICIO FISCAL ' + sessionStorage.getItem('codigoAnio');
  CodigoModulo = sessionStorage.getItem('NombreMenu');
  public NombreUsuario: string = '';
  public notifications: Notifications[] = [];
  public OcultarNotificaciones:boolean = true;
  private intervalId: any; // Variable para almacenar el ID del intervalo


  constructor(
    @Inject(DOCUMENT) private document: Document,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2,
    public elementRef: ElementRef,
    private configService: ConfigService,
    private authService: AuthService,
    private router: Router,
    public languageService: LanguageService,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {


    super();

  }
  listLang = [
    { text: 'Spanish', flag: 'assets/images/flags/spain.jpg', lang: 'es' },
  ];

  isZoomed = false; // Variable para almacenar el estado de zoom

  
  ngOnInit() {
    this.config = this.configService.configData;
    this.docElement = document.documentElement;
    this.NombreUsuario = this.authService.currentUserValue?.fullName || '';
    this.OcultarOpcionesAdmin = this.authService.currentUserValue?.esAdmin === 1 ? false : true;

    this.homePage = 'inicio';

    this.langStoreValue = 'es';
    const val = this.listLang.filter((x) => x.lang === this.langStoreValue);
    this.countryName = val.map((element) => element.text);
    if (val.length === 0) {
      if (this.flagvalue === undefined) {
        this.defaultFlag = 'assets/images/flags/us.jpg';
      }
    } else {
      this.flagvalue = val.map((element) => element.flag);
    }

    // Detectar el zoom al cargar la página
    this.detectZoom();
    this.CargarMenus();
    this.CargarEjercicioFiscal();
    this.TienePermisosNotificaciones();

   /*
   ESTAS LINEAS SE HABILITAN SI DESEAN QUE SE ACTUALICE LAS NOTIFICACIONES 
   
*/
  }


 override ngOnDestroy() {
    // Limpiar el intervalo cuando el componente se destruya
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    super.ngOnDestroy();
  }

  /**
   * Funcion que carga el menu principal con las opciones del sistema
   */

  CargarMenus() {

    this.ServicioClienteHttp.SeteoRuta("Menu");

    this.ServicioClienteHttp.Obtener_x_Codigo(this.authService.currentUserValue?.codigoUsu).subscribe({
      next: (data) => {
        if (data.success) {
          this.menus = JSON.parse(data.result);
        } else {
          console.log("Error en la respuesta del servidor");
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }


  /**
   * Funcion que carga un menu nuevo si es que el usuario se cambia de sistema
   * @param CodigoMenu 
   * @param NombreMenu 
   */

  CargarNuevoMenu(CodigoMenu: string, NombreMenu: string) {
    sessionStorage.setItem('codigoSistema', CodigoMenu);
    sessionStorage.setItem('NombreMenu', NombreMenu);

    const paramSessionesData = sessionStorage.getItem('ParamSesiones');
    let paramSessiones: ParamSessionMo;

    if (paramSessionesData) {
      paramSessiones = JSON.parse(paramSessionesData) as ParamSessionMo;
    } else {
      // Manejo del caso en que no hay datos en sessionStorage
      paramSessiones = new ParamSessionMo();
    }
    // Actualizar el campo 'anio'
    paramSessiones.sistema = parseInt(CodigoMenu);

    sessionStorage.setItem('ParamSesiones', JSON.stringify(paramSessiones));


    this.router.navigate(['inicio']).then(() => {
      window.location.reload();
    });

  }

/**
 * Carga el listado de año que tienen ejercicios fiscales
 */
  CargarEjercicioFiscal() {

    this.ServicioClienteHttp.SeteoRuta("Menu/EjercicioFiscal");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.EjercicioFiscal = JSON.parse(data.result);
        } else {
          console.log("Error en la respuesta del servidor");
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }


  /**
   * Funcion que realiza el cambio del año fiscal
   * @param EjercicioFiscal 
   * @param Anio 
   */
  CargarcodigoAnio(EjercicioFiscal: string, Anio: number) {

    /**
     * SE VALIDA SI EL ANO DEL EJERCICIO FISCAL AL QUE SE ESTA CAMBIANDO NO ES EL ACTUAL SE DESACTIVAN LAS OPCIONES DE GUARDAR
     */
    if (Anio != this.authService.currentUserValue?.AnioActivo && this.authService.currentUserValue?.usuarioConsulta === false) {
      sessionStorage.setItem('usuarioConsulta', "true");
    }

    /**
     * SI SE REGRESA AL AÑO CORRECTO SE REGRESA EL VALOR A ACTIVAR LAS OPCIONES
     */

    let usuarioConsulta: boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
    if (Anio === this.authService.currentUserValue?.AnioActivo && this.authService.currentUserValue?.usuarioConsulta === false && usuarioConsulta === true) {
      sessionStorage.setItem('usuarioConsulta', "false");
    }

    this.VarEjercicioFiscal = EjercicioFiscal;
    sessionStorage.setItem('codigoAnio', Anio.toString());
    sessionStorage.setItem('VarEjercicioFiscal', EjercicioFiscal);

    ///CAMBIANDO EL AÑO EN LAS VARIABLES 

    const paramSessionesData = sessionStorage.getItem('ParamSesiones');
    let paramSessiones: ParamSessionMo;

    if (paramSessionesData) {
      paramSessiones = JSON.parse(paramSessionesData) as ParamSessionMo;
    } else {
      // Manejo del caso en que no hay datos en sessionStorage
      paramSessiones = new ParamSessionMo();
    }
    // Actualizar el campo 'anio'
    paramSessiones.anio = Anio;

    sessionStorage.setItem('ParamSesiones', JSON.stringify(paramSessiones));
    /**FIN DE CREACION DE LAS VARIABLES DE SESION */
    window.location.reload();

  }

/**
 * Carga Notificaciones si es que un usuario tiene perfiles para mostrar notificaciones
 */
    CargarNotificaciones()
    {

    const paramSessionesData = sessionStorage.getItem('ParamSesiones');
    let paramSessiones: ParamSessionMo;

    if (paramSessionesData) {
      paramSessiones = JSON.parse(paramSessionesData) as ParamSessionMo;
      paramSessiones.anio = this.authService.currentUserValue?.AnioActivo ?? 0;
    } else {
      // Manejo del caso en que no hay datos en sessionStorage
      paramSessiones = new ParamSessionMo();
    }

      this.ServicioClienteHttp.SeteoRuta("Menu/Notificaciones");
      this.ServicioClienteHttp.Insertar(paramSessiones).subscribe({
        next: (data) => {
          if (data.success) {
            this.OcultarNotificaciones = false;
            this.notifications = data.result;
          } else {
            console.log(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });

    }

/**
 * Consulta si un usuario tiene permisos para dar atencion a las notificaciones si es asi carga las notificaciones
 * y levanta un timer que permite refrescar las notificaciones cada cierto tiempo
 */
    TienePermisosNotificaciones()
    {
      const usuario = this.authService.currentUserValue?.codigoUsu ?? 0;

      this.ServicioClienteHttp.SeteoRuta("Menu/Notificaciones");
      this.ServicioClienteHttp.Obtener_x_Codigo(usuario).subscribe({
        next: (data) => {
          if (data.success) {
            let TienePermisos = JSON.parse(data.result);
            if(TienePermisos[0].notificaciones>0)
            {
              this.CargarNotificaciones();
              this.intervalId = setInterval(() => {
                this.CargarNotificaciones();
              }, configapp.tiemponNotificacion * 60 * 1000); 
            }
            
          } else {
            console.log(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });

    }


  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.detectZoom();
  }

  detectZoom() {
    const zoomLevel = this.getZoomLevel();
    //console.log('Nivel de zoom detectado:', zoomLevel); // Verificar el nivel de zoom
    // Se establece el % de Zoom en el cual se realizará el cambio de cabecera
    this.isZoomed = zoomLevel >= 120;
    //console.log('isZoomed:', this.isZoomed); // Verificar el valor de isZoomed
    this.cdr.detectChanges(); // Forzar la detección de cambios
  }

  getZoomLevel(): number {
    let zoomLevel = 0;
    const devicePixelRatio = window.devicePixelRatio || 1;
    const screen = this.document.defaultView?.screen;
    if (screen) {
      zoomLevel = Math.round((screen.width * devicePixelRatio) / screen.availWidth * 100);
    }
    return zoomLevel;
  }

  callFullscreen() {
    if (!this.isFullScreen) {
      if (this.docElement?.requestFullscreen != null) {
        this.docElement?.requestFullscreen();
      }
    } else {
      document.exitFullscreen();
    }
    this.isFullScreen = !this.isFullScreen;
  }
  setLanguage(text: string, lang: string, flag: string) {
    this.countryName = text;
    this.flagvalue = flag;
    this.langStoreValue = lang;
    this.languageService.setLanguage(lang);
  }
  mobileMenuSidebarOpen(event: Event, className: string) {
    const hasClass = (event.target as HTMLInputElement).classList.contains(
      className
    );
    if (hasClass) {
      this.renderer.removeClass(this.document.body, className);
    } else {
      this.renderer.addClass(this.document.body, className);
    }

    const hasClass2 = this.document.body.classList.contains('side-closed');
    if (hasClass2) {
      // this.renderer.removeClass(this.document.body, "side-closed");
      this.renderer.removeClass(this.document.body, 'submenu-closed');
    } else {
      // this.renderer.addClass(this.document.body, "side-closed");
      this.renderer.addClass(this.document.body, 'submenu-closed');
    }
  }
  callSidemenuCollapse() {
    const hasClass = this.document.body.classList.contains('side-closed');
    if (hasClass) {
      this.renderer.removeClass(this.document.body, 'side-closed');
      this.renderer.removeClass(this.document.body, 'submenu-closed');
      localStorage.setItem('collapsed_menu', 'false');
    } else {
      this.renderer.addClass(this.document.body, 'side-closed');
      this.renderer.addClass(this.document.body, 'submenu-closed');
      localStorage.setItem('collapsed_menu', 'true');
    }
  }
  logout() {
    this.subs.sink = this.authService.logout().subscribe((res) => {
      if (!res.success) {
        this.router.navigate(['/authentication/signin']);
      }
    });
  }

  cambiarContrasena(): void {
    this.router.navigate(['cambiarContrasena']);
  }


  AdministrarUsuarios(): void {
    this.router.navigate(['administracion/usuarios']);
  }

  AdministrarEmpresa(): void {
    this.router.navigate(['administracion/empresa']);
  }


}
