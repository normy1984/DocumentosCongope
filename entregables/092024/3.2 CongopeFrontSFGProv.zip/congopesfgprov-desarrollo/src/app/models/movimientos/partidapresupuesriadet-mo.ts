import { ParamSessionMo } from "../param-session";

export class PartidaPresupuestariaDetMo {
    public sig_tip: string;
    public acu_tip: string;
    public out_sec_det: number;
    public cuenta:string;
    public out_cuenta:string;
    public val_cre:number;
    public asociac:number;
    public sec_det:number;
    public varSesion: ParamSessionMo;
    public nom_cue:string;
    public out_sig_tip:string;
    public out_nom_cu:string;
    public certificado:number;
    public msg:string;
    constructor(datos: PartidaPresupuestariaDetMo) {
        {
            this.sig_tip = datos.sig_tip || '';
            this.acu_tip=datos.acu_tip || '';
            this.out_sec_det=datos.out_sec_det||0;
            this.cuenta = datos.cuenta || '';
            this.out_cuenta=datos.out_cuenta|| '';
            this.val_cre=datos.val_cre||0;
            this.asociac=datos.asociac||0;
            this.sec_det=datos.sec_det||0;
            this.varSesion=datos.varSesion||'';
            this.nom_cue=datos.nom_cue||'';
            this.out_sig_tip=datos.out_sig_tip||'';
            this.out_nom_cu = datos.out_nom_cu || '';
            this.certificado=datos.certificado||0;
            this.msg = datos.msg || '';
            }      
    }
}
