import { ParamSessionMo } from "../param-session";

export class CertificacionMo {

    public sig_tip: string;
    public acu_tip: number;
    VarSesion!: ParamSessionMo; 
    
    constructor(datos: CertificacionMo) {
        {
            this.sig_tip = datos.sig_tip || '';
            this.acu_tip = datos.acu_tip || 0;
            this.VarSesion=datos.VarSesion; 
        }
    }
}
