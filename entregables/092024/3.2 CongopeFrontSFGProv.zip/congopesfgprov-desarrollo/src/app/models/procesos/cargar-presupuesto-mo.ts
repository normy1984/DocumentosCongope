import { ParamSessionMo } from "../param-session";

export class CargarPresupuestoMo {
    partida_presupuestaria: string;
    nombre: string;
    gastos: number;
    ingresos: number;
    tipo: number;
    nivel: number;
    ultimo_nivel: string;
    cuenta_padre: string;
    paramSessionMo: ParamSessionMo;
    constructor(data: any){
      this.partida_presupuestaria = data.PARTIDA_PRESUPUESTARIA || "";
      this.nombre = data.NOMBRE || "";
      this.gastos = data.GASTOS || 0;
      this.ingresos = data.INGRESOS || 0;
      this.tipo = data.TIPO || 0;
      this.nivel = data.NIVEL || 0;
      this.ultimo_nivel = data.ULTIMO_NIVEL || "";
      this.cuenta_padre = data.CUENTA_PADRE || "";
      this.paramSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
      }
}
