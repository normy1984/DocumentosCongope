import { DatePipe } from "@angular/common";
import { ParamSessionMo } from "../param-session";

export class MovimientosPresupuestariosMo {

   // public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  
    siglasnum:string;
    num_com:string;
    descrip:string;
    fec_asi:string;
    fec_apr:string;
    out_fec_apr:string;
    des_cab:string;
    tot_cre:number;
    val_cre:number
   // codigo_est:number;
    creado_por:string;
    modificado_por:string;
    estado_desc:string;
  //  estado:number;
    out_cre_por_desc: string;
    out_mod_por_desc: string;
    valor_contrato:number;
    departam:number;
    solicita:number;
    cod_proceso:string;
    in_cod_proceso:string;
    departam_desc:string;
    solicita_desc:string;
    partida_desc:string;
    cuentadb: string;
    out_anio:number;
    anulado_siglasnum:string;
    anula_siglas_num:string;
    public datePipe: DatePipe = new DatePipe('en-US'); // Aquí puedes especificar el idioma si es necesario
    admin_contrato:string;
    tipo_contrato:number;
    admin_contrato_desc: string;
    VarSesion!: ParamSessionMo; 
    anula_liquida: string;
    asoc: string;
    en_proceso:string;
    out_estado:number;
    constructor(datos: MovimientosPresupuestariosMo) {
        {
            this.siglasnum = datos.siglasnum || '';
            this.num_com = datos.num_com || '';
            this.descrip = datos.descrip || '';
            this.fec_asi = datos.fec_asi || this.datePipe.transform(new Date(), 'yyyy-MM-dd') as string;
            this.fec_apr = datos.fec_apr || this.datePipe.transform(new Date(), 'yyyy-MM-dd') as string;
            this.out_fec_apr = datos.fec_apr || this.datePipe.transform(new Date(), 'yyyy-MM-dd') as string;
            this.des_cab =  datos.des_cab || '';
            this.tot_cre = datos.tot_cre || 0;
            this.val_cre = datos.val_cre || 0;
           // this.codigo_est = datos.codigo_est || 1;
            this.partida_desc=datos.partida_desc|| '';  
            this.creado_por=datos.creado_por|| '';       
            this.out_cre_por_desc= datos.out_cre_por_desc|| '';
            this.modificado_por= datos.modificado_por||'';
            this.out_mod_por_desc= datos.out_mod_por_desc|| '';
            this.estado_desc= datos.estado_desc|| '';
            //this.estado= datos.estado|| 0;
            this.out_estado= datos.out_estado|| 0;
            this.valor_contrato= datos.valor_contrato|| 0;
            this.departam=datos.departam|| 0;
            this.solicita= datos.solicita || 0;
            this.cuentadb = datos.cuentadb || '';
            this.departam_desc=datos.departam_desc|| '';
            this.solicita_desc=datos.solicita_desc|| '';
            this.cod_proceso=datos.cod_proceso|| '';
            this.in_cod_proceso=datos.in_cod_proceso|| '';
            this.out_anio=datos.out_anio|| 0;
            this.anulado_siglasnum=datos.anulado_siglasnum|| '';
            this.anula_siglas_num=datos.anula_siglas_num|| '';
            this.admin_contrato=datos.admin_contrato|| '';
            this.tipo_contrato=datos.tipo_contrato|| 0;
            this.admin_contrato_desc = datos.admin_contrato_desc || '';
            this.VarSesion=datos.VarSesion; 
            this.anula_liquida=datos.anula_liquida;
            this.asoc=datos.asoc;
            this.en_proceso=datos.en_proceso;
        }
    }
}




