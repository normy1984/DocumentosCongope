import { ParamSessionMo } from "../param-session";

export class TipoComprobanteMo {
    sigla:string;
    secuencia:number;
    descripcion:string;
    opcionPagado:number;
    comprobanteRol:string;
    reiniciaSecuencia:number;
    comprobanteGarantia:number;
    paramSessionMo: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
     
    constructor(datos: TipoComprobanteMo) {
        {
            this.sigla = datos.sigla || '';
            this.secuencia = datos.secuencia || 0;
            this.descripcion = datos.descripcion || '';
            this.opcionPagado = datos.opcionPagado || 0;
            this.comprobanteRol =  datos.comprobanteRol || '';
            this.reiniciaSecuencia = datos.reiniciaSecuencia || 0;
            this.comprobanteGarantia = datos.comprobanteGarantia || 0;
        }
    }
}
