export class CiuMO {

  codtab:number;
  grupo:string;
  cedruc:string;
  descrip:string;
  direcci:string;
  telefon1:string;
  email1:string;
  ciudad:string;
  nombre_ciudad:string;
  titulo:number;
  nombre_titulo:string;
  rucoced:number;
  contribespe:number;
  banco:string;
  nombre_banco:string;
  nrocta:string;
  tipocta:number;
  nombre_tipocta:string;
  numero_iden:string;
  nombre_iden:string;
  fechanac:string;
  discapacidad:number;
  porcen_disca:number;
  contesp_nrores:string;
  obligado_conta:number;
  serie:string;
  constructor(datos: CiuMO) {
      {
        this.codtab = datos.codtab || 0;
        this.grupo = datos.grupo || '';
        this.cedruc = datos.cedruc || '';
        this.descrip = datos.descrip || '';
        this.direcci = datos.direcci || '';
        this.telefon1 = datos.telefon1 || '';
        this.email1 = datos.email1 || '';
        this.ciudad = datos.ciudad || '';
        this.nombre_ciudad = datos.nombre_ciudad || '';
        this.titulo = datos.titulo || 0;
        this.nombre_titulo = datos.nombre_titulo || '';
        this.rucoced = datos.rucoced || 0;
        this.contribespe = datos.contribespe || 0;
        this.banco = datos.banco || '';
        this.nombre_banco = datos.nombre_banco || '';
        this.nrocta = datos.nrocta || '';
        this.tipocta = datos.tipocta || 0;
        this.nombre_tipocta = datos.nombre_tipocta || '';
        this.numero_iden = datos.numero_iden || '';
        this.nombre_iden = datos.nombre_iden || '';
        this.fechanac = datos.fechanac || '';
        this.discapacidad = datos.discapacidad || 0;
        this.porcen_disca = datos.porcen_disca || 0;
        this.contesp_nrores = datos.contesp_nrores || '';
        this.obligado_conta = datos.obligado_conta || 0;
        this.serie = datos.serie || '';
      }
  }
}
