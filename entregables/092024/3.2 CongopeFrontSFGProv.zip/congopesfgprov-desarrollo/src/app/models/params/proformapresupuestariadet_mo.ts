export class ProformaPresupuestariaDetMO {

  out_cuenta:string;
  out_nom_cue:string;
  out_val_deb:number;
  out_val_cre:number;
  out_sec_det:number;
  constructor(datos: ProformaPresupuestariaDetMO) {
      {
          this.out_cuenta = datos.out_cuenta || '';
          this.out_nom_cue = datos.out_nom_cue || '';
          this.out_val_deb = datos.out_val_deb || 0;
          this.out_val_cre = datos.out_val_cre || 0;
          this.out_sec_det = datos.out_sec_det || 0;
      }
  }
}
