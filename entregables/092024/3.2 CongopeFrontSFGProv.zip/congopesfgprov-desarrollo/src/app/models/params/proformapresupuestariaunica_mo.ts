export class ProformaPresupuestariaUnicaMO {

  out_sig_acu_tip:string;
  out_fec_apr:string;
  out_des_cab:string;
  out_tot_deb:string;
  out_nombre_estado:string;
  out_estado:string;
  out_acu_tip:number;
  out_asociac:number;
  constructor(datos: ProformaPresupuestariaUnicaMO) {
      {
          this.out_sig_acu_tip = datos.out_sig_acu_tip || '';
          this.out_fec_apr = datos.out_fec_apr || '';
          this.out_des_cab = datos.out_des_cab || '';
          this.out_tot_deb = datos.out_tot_deb || '';
          this.out_nombre_estado = datos.out_nombre_estado || '';
          this.out_estado = datos.out_estado || '';
          this.out_acu_tip = datos.out_acu_tip || 0;
          this.out_asociac = datos.out_asociac || 0;
      }
  }
}
