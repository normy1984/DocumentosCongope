export class ParamSessionMo {
    codemp!:string;
    anio!:number;
    sistema!:number;
    codusu!:number;
  }
  