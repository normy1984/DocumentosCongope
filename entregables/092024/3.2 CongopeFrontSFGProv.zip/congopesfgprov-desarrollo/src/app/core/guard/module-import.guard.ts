import { _MatCheckboxRequiredValidatorModule } from "@angular/material/checkbox";


export function throwIfAlreadyLoaded(
  parentModule: _MatCheckboxRequiredValidatorModule,
  moduleName: string
) {
  if (parentModule) {
    throw new Error(
      `${moduleName} has already been loaded. Import ${moduleName} modules in the AppModule only.`
    );
  }
}
