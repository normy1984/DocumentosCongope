export class User {
  codigoUsu!: number;
  username!: string;
  fullName!: string;
  token!: string;
  correo!: string;
  esAdmin!: number;
  usuarioConsulta!:boolean;
  AnioActivo!: number;
}
