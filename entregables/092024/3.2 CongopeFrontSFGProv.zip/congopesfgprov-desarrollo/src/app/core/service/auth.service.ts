import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, mergeMap } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { User } from '../models/user';
import { ApiResultMo } from 'app/models/api-result-mo';
import { configapp } from '@config/configapp';
import { ParamSessionMo } from 'app/models/param-session';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;
  private apiUrl: string = configapp.UrlServicios + 'login/credenciales';
  private renewUrl: string = configapp.UrlServicios + 'login/renovar';
  

  constructor(private http: HttpClient) {
    const storedUser = localStorage.getItem('currentUser');
    this.currentUserSubject = new BehaviorSubject<User | null>(
      storedUser ? JSON.parse(storedUser) : null
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  login(username: string, password: string): Observable<HttpResponse<any>> {
    const credentials = { login: username, contrasena: password };

    return this.http.post<ApiResultMo>(this.apiUrl, credentials).pipe(
      mergeMap((data) => {
        if (data.success) {
          const user = data.result[0];
          const user2: User = {
            codigoUsu: user.codigoUsu,
            username: user.login,
            fullName: user.nombresCompletos,
            token: user.llave,
            correo: user.correo,
            esAdmin: user.esAdmin, 
            usuarioConsulta: user.usuarioConsulta,
            AnioActivo: user.codigoAnio};
          localStorage.setItem('currentUser', JSON.stringify(user2));

          // SE CREA LA VARIABLE DE SESION PARA EL CODIGO DE USUARIO

          const ParamSessiones:ParamSessionMo = {
            codemp: user.codemp,
            anio: user.codigoAnio,
            sistema: parseInt(user.codigoSistema),
            codusu: user.codigoUsu
          }

          /**FIN DE CREACION DE LAS VARIABLES DE SESION */
          
          sessionStorage.setItem('ParamSesiones', JSON.stringify(ParamSessiones));

          sessionStorage.setItem('codigoSistema', user.codigoSistema.toString());
          sessionStorage.setItem('codigoAnio', user.codigoAnio.toString());
          sessionStorage.setItem('NombreMenu', user.nombreSistema.toString());
          sessionStorage.setItem('usuarioConsulta', user.usuarioConsulta);
          
          this.currentUserSubject.next(user2);
          return this.createHttpResponse({
            codigoUsu: user.codigoUsu || null,
            username: user.login || null,
            fullName: user.nombresCompletos || null,
            token: user.llave || null,
            correo: user.correo || null,
          });
        } else {
          return this.handleError(data.message);
        }
      }),
      catchError((error) => {
        console.error('Login error:', error.message);
        return this.handleError(error.message);
      })
    );
  }


  renewToken(): Observable<HttpResponse<any>> {
    const currentUser = this.currentUserValue;
    if (currentUser && currentUser.token) {
      const token: string = currentUser.token;
      return this.http.post<ApiResultMo>(this.renewUrl, { token }).pipe(
        mergeMap((data) => {
          if (data.success) {
            const user = { ...currentUser, token: data.result};
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.currentUserSubject.next(user);
            return this.createHttpResponse({
              codigoUsu: currentUser.codigoUsu,
              username: currentUser.username,
              fullName: currentUser.fullName,
              token: data.result,
              correo: currentUser.correo
            });
          } else {
            
            return this.handleError(data.message);
          }
        }),
        catchError((error) => {
          console.error('Renew token error:', error.message);
          return this.handleError(error.message);
        })
      );
    } else {
      return throwError(() => new Error('No user or token found'));
    }
  }

  logout(): Observable<{ success: boolean }> {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    return new Observable((observer) => {
      observer.next({ success: false });
      observer.complete();
    });
  }

  private createHttpResponse(body: {
    codigoUsu: number;
    username: string;
    fullName: string;
    token: string;
    correo: string;
  }): Observable<HttpResponse<any>> {
    return new Observable((observer) => {
      observer.next(new HttpResponse({ status: 200, body }));
      observer.complete();
    });
  }

  private handleError(message: string): Observable<never> {
    return throwError(() => new Error(message));
  }
}
