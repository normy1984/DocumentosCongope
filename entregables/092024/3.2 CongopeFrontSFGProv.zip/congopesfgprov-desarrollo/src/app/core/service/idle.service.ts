import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent, merge, Observable, Subject } from 'rxjs';
import { switchMap, tap } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { configapp } from '@config/configapp';

@Injectable({
  providedIn: 'root'
})
/// CLASE QUE DETECTA LA INACTIVIDAD DEL USUARIO
export class IdleService {
  private idleTimeout$: Observable<void>;
  private userAction$ = new Subject<void>();
  private idleTime = configapp.tiempoInactividad * 60 * 1000; // TIEMPO DE INACTIVIDAD

  constructor(private router: Router, private ngZone: NgZone, 
    private authService: AuthService,
  ) {
    this.idleTimeout$ = this.userAction$.pipe(
      switchMap(() => this.startTimer(this.idleTime))
    );

    this.idleTimeout$.subscribe(() => {
      this.authService.logout();
      location.reload();
    });

    this.init();
  }

  init() {
    this.ngZone.runOutsideAngular(() => {
      const mouseEvents$ = fromEvent(document, 'mousemove');
      const clickEvents$ = fromEvent(document, 'click');
      const keyupEvents$ = fromEvent(document, 'keyup');

      merge(mouseEvents$, clickEvents$, keyupEvents$)
        .pipe(tap(() => this.resetTimer()))
        .subscribe();
    });
  }

  private resetTimer() {
    if (this.router.url !== '/authentication/signin') {
      this.userAction$.next();
    }
    
  }

  private startTimer(time: number): Observable<void> {
    return new Observable<void>(observer => {
      const timeout = setTimeout(() => {
        observer.next();
        observer.complete();
      }, time);

      return () => clearTimeout(timeout);
    });
  }


}
