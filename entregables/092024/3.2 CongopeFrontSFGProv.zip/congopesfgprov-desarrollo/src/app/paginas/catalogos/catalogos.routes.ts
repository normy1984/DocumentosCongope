import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { FuentesfinanciamientoListComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-list/fuentesfinanciamiento-list.component";
import { FuentesfinanciamientoEditComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-edit/fuentesfinanciamiento-edit.component";
import { ListaCiuListComponent } from "../generico/lista-ciu-list/lista-ciu-list.component";
import { ListaCiuEditComponent } from "../generico/lista-ciu-edit/lista-ciu-edit.component";


export const CATALOGOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "dashboard1",
    pathMatch: "full",
  },
  {
    path: "FuentesFinanciamiento",
    component: FuentesfinanciamientoListComponent,
  },
  {
    path: "FuentesFinanciamiento/:ffn_id",
    component: FuentesfinanciamientoEditComponent,
  },
  {
    path: "CodigodeIdentificacionUnica",
    component: ListaCiuListComponent,
  },
  {
    path: "CodigodeIdentificacionUnica/:param",
    component: ListaCiuEditComponent,

  },

  { path: "**", component: Page404Component },

];

