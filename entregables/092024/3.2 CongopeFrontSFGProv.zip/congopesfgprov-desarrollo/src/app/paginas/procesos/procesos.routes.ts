import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { CargarPresupuestoComponent } from "./cargar-presupuesto/cargar-presupuesto.component";


export const PROCESOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "inicio",
    pathMatch: "full",
  },
  {
    path: "CargarPresupuesto",
    component: CargarPresupuestoComponent,
  },
  { path: "**", component: Page404Component },
  
];

