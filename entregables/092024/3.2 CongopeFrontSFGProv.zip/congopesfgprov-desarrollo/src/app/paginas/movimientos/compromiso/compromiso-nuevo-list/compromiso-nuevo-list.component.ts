import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { MatDialog } from '@angular/material/dialog';
import { configapp } from '@config/configapp';
import { SelectionModel } from '@angular/cdk/collections';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'app-compromiso-nuevo-list',
  templateUrl: './compromiso-nuevo-list.component.html',
  standalone: true,
  imports: [
    ListModule, MatCheckboxModule
  ],
})
export class CompromisoNuevoListComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  // Inyecciones de servicios
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);

  // Configuración de la paginación
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource!: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  // Selección de filas en la tabla
  selection = new SelectionModel<any>(true, []);
  renderedData: any[] = [];

  public resultado!: any;
  public disableGuardar: boolean = true;
  public OcultarError: boolean = true;

   /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
   public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  

  // Rutas de la API y navegación
  public pagina: string = "Movimientos/CompromisosPresupuestarios";
  public rutaapi: string = "Compromiso/ListCertificacion";

  // Columnas mostradas en la tabla
  public displayedColumns: string[] = [
    "select",
    "siglasnum",
    "num_com",
    "fec_asi",
    "des_cab",
    "tot_cre",
    "tot_deb"
  ];

  constructor(
    private router: Router,
    public dialog: MatDialog,
  ) {
    super();
  }

  ngOnInit() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid();
  }

  /**
   * Cargar los datos en la tabla desde el servicio HTTP.
   */
  CargarGrid() {

    const Val_MovimientosPresupuestarios = {
      siglas_num: 'CE',
      VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    }
    this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * Filtrar registros en la tabla.
   * @param event Evento de entrada del filtro.
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  /**
   * Validar la selección de certificados para asegurarse de que todos pertenecen al mismo departamento.
   */
  validarSelectCertificados() {
    const totalSelect = this.selection.selected.length;
    let valorDepartamento = 0;
    this.OcultarError = true;
    this.disableGuardar = false;

    if (totalSelect > 0) {
      this.selection.selected.forEach((item, index) => {
        if (index === 0) {
          valorDepartamento = item.out_departamento;
        }
        if (valorDepartamento !== item.out_departamento) {
          this.disableGuardar = true;
          this.OcultarError = false;
        }
      });
    } else {
      this.disableGuardar = true;
    }
  }

  /**
   * Generar un compromiso presupuestario basado en las certificaciones seleccionadas.
   */
  GenerarCompromiso() {
    const totalSelect = this.selection.selected.length;
    let Certificaciones: string[] = [];
    let textoConfirm = '';

    this.selection.selected.forEach((item) => {
      let arrayResultado = item.siglasnum.split(' ');
      Certificaciones.push(arrayResultado[1]);
      textoConfirm += `<p>${item.siglasnum}</p>`;
    });

    Swal.fire({
      title: `Va a crear un compromiso presupuestario con las partidas de la(s) certificación(es) ${textoConfirm} ¿Desea continuar?`,
      showDenyButton: true,
      confirmButtonText: "Sí, Continuar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        let parametro = this.ServicioCrypt.encryptString("NUEVO||" + Certificaciones.join(','));
        this.router.navigate(['Movimientos/CompromisosPresupuestarios', parametro]);
      }
    });
  }

  VolverPagina() {
    this.router.navigate([this.pagina]);
  }

}
