import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { TipoComprobanteMo } from 'app/models/params/tipo-comprobante-mo';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { ListModule } from 'app/paginas/generico/list.module';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ParamSessionMo } from 'app/models/param-session';
import { Observable, map } from 'rxjs';
import { PartidaPresupuestariaDetMo } from 'app/models/movimientos/partidapresupuesriadet-mo';
import { ListabuscarpartidaListComponent } from 'app/paginas/generico/listabuscarpartida-list/listabuscarpartida-list.component';
import { VercertificadocompromisoListComponent } from 'app/paginas/reportes/vercertificadocompromiso-list/vercertificadocompromiso-list.component';
import { FormsModule } from '@angular/forms';  // Asegúrate de importar FormsModule
import { VersaldopartidaListComponent } from 'app/paginas/reportes/versaldopartida-list/versaldopartida-list.component';
import { ConsultaAprobarDesaprobarService } from 'app/servicios/generico/consulta-aprobar-desaprobar.service';
import { VariablesAprobarDesaprobarMo } from 'app/models/administracion/aprobar-desaprobar-mo';
import { CertificacionMo } from 'app/models/movimientos/certificacion-mo';


@Component({
  selector: 'app-certificado-edit',
  standalone: true,
  imports: [ListModule,EditModule, MatDatepickerModule,    MatAutocompleteModule,
      FormsModule ],
  templateUrl: './certificado-edit.component.html'
})
export class CertificadoEditComponent implements OnInit {[x: string]: any;

  /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    // Variables de visualización
    public anio: number = 0;
  
  @Input('param') param!: string;
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  public dataSource !: MatTableDataSource<any>;

  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = true;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: string = "";
  public codigoCertificacion: string = '';
  public copiaresult:  any[]= []; 
   /**COLUMNAS MOSTRADAS */
   public displayedColumns: string[] = [
    "cuenta",
    "nom_cue",
    //"certificado",
    "out_val_cre",
    "val_devengado",
    "saldo",
    "val_dist" ,
    "accion",
    "versaldo",
    ];

  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA PAGINA Y DE DONDE SE CARGA EL API */  
  //public pagina: string = "movimientos/certificados";
  public pagina: string =  "Movimientos/CertificacionesPresupuestarias"
  public rutaapi: string = "MovimientosPresupuestarios";
  public paginaA: string = "movimientos/certificados";
  resultado: any[] = [];
  arrayCodigo: any[] = [];
  public OpcionesPartidas!: any[] ;
  public OpcionesDepartamentos!: any[];
  public OpcionesResponsables!: any[];

  public EstructuraPartidas: any[] = [];
  public EstructuraDepartamentos!: any[];
  public EstructuraResponsables!: any[];
  public EstructuraMaximo: any[]= [];
  public Maximo!: number;
  public opcion!: number;

  blankObject = {} as MovimientosPresupuestariosMo;
  blankObjectUno = {} as TipoComprobanteMo;
  blankObjectPartidas = {} as PartidaPresupuestariaDetMo;
  blankObjectCertificado = {} as CertificacionMo;
  ModeloDatos: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObject);
  ModeloDatosCert: CertificacionMo = new CertificacionMo(this.blankObjectCertificado);
  ModeloDatosPartidaDetalle: PartidaPresupuestariaDetMo = new PartidaPresupuestariaDetMo(this.blankObjectPartidas);

  //Para select combo
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('partida_desc') partida_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('departam_desc') departam_desc!: ElementRef<HTMLInputElement>;

  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fec_apr') picker_fec_apr!: MatDatepicker<Date>;

  // Variables de visualización
  public colorEstado: string = 'label-default';
  public estado_desc: string = '';
  public creado_por: string = '';
  public modificado_por: string = '';
  public anula_liquida: string='';
  public en_proceso: string='';
  public asoc: string='';
  public estado: number=0;
  public anulado_siglasnum: string='';

   // Flags de visibilidad para botones
  public OcultarBtnImprimir: boolean = false;
  public OcultarBtnAnular: boolean = false;
  public OcultarBtnLiquidar: boolean = false;
  public OcultarBtnDuplicar: boolean = false;
  public OcultarBtnDistribuir: boolean = false;
  public OcultarBtnVerSaldo: boolean = false;
  public OcultarBtnCargarArchivos: boolean = false;
  public OcultarBtnGuardarCancelar: boolean = false;
  public OcultarLiqAnular: boolean = false;
  public OcultarAsociado: boolean = false;
  public ActivarAgregar: boolean = false;
  public OcultarBtnAprobar: boolean = false;
  public OcultarBtnDesaprobar: boolean = false;
  public ActivarSelectorPartida:  boolean = false;
  public VarApruebaDesaprueba:VariablesAprobarDesaprobarMo = new VariablesAprobarDesaprobarMo();

    // Modelos para los datos del formulario
    blankObjectCabecera = {} as MovimientosPresupuestariosMo;
    ModeloDatosCabecera: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObjectCabecera);
    public nTipoPresupuestoID = 1;
  // Variable para guardar el valor seleccionado
  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServApruebaDesaprueba: ConsultaAprobarDesaprobarService
  ) {
  }
get fec_asi(){
  return this.FormularioDatos.controls['fec_asi'];//: resultado.fec_asi,
}

get fec_apr(){
  return this.FormularioDatos.controls['fec_apr'];//: resultado.fec_asi,
}
get num_com(){
  return this.FormularioDatos.controls['num_com'];//: resultado.fec_asi,
}
get des_cab(){
  return this.FormularioDatos.controls['des_cab'];//: resultado.fec_asi,
}
get solicita_desc1(){
  return this.FormularioDatos.controls['solicita_desc'];//: resultado.fec_asi,
}
get departam_desc1(){
  return this.FormularioDatos.controls['departam_desc'];//: resultado.fec_asi,
}
  ngOnInit(): void {
   
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.opcion=0;
    this.CargarForm();
    this.CargarGrid();
    this.CargarCatalogos("TablasGenerales/DetalleSinDiccionario/19");
    this.CargarCatalogos("TablasGenerales/DetalleSinDiccionario/54"); 
    this.CargarCatalogos("PartidasPresupuestarias");   

  }
/*
  getMaxCodigo(){  
    this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/SecuencialMovimientos?empresa="
      +this.ParamSessiones.codemp+"&"+"anio="+this.ParamSessiones.anio+"&tipo=CE");

      this.ServicioClienteHttp.Obtener_Lista().subscribe({       
        next: (data) => {
         
          if (data.success) {
            this.EstructuraMaximo= JSON.parse(data.result);
            // para designar valor por JavaScrip Asíncrono
            this.FormularioDatos.patchValue({         
              siglasnum: "CE "+this.EstructuraMaximo[0].secuencia,
               });      
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      }); 
  }

  getUsuario(){
    this.ServicioClienteHttp.SeteoRuta("Usuarios/"+this.ParamSessiones.codusu);
      this.ServicioClienteHttp.Obtener_Lista().subscribe({       
        next: (data) => {
         
          if (data.success) {
            this.EstructuraMaximo= data.result;
            // para designar valor por JavaScrip Asíncrono
            this.FormularioDatos.patchValue({                  
              creado_por:this.EstructuraMaximo[0].nombresCompletos,
              modificado_por:  this.EstructuraMaximo[0].nombresCompletos,
            });      
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      }); 

  }
  */

  /**
 * Método para mostrar un cuadro de diálogo de confirmación y aprobar el compromiso presupuestario.
 */
AprobarCertificacion(): void {
  console.log(this.codigoCertificacion);
  Swal.fire({
    //this.NoCompromiso
  
    title: "¿Está seguro de aprobar la Certificación Presupuestaria " + this.codigoCertificacion + "?",
    showDenyButton: true,
    confirmButtonText: "Sí",
    denyButtonText: "No"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Certificacion/Aprobacion");
      //this.NoCompromiso="222";
   //   console.log("Certificacion en aprobaciòn"+this.codigoCertificacion);

    this.ModeloDatosCert.VarSesion=this.ParamSessiones;
  //  console.log("Array "+this.arrayCodigo);
    this.ModeloDatosCert.sig_tip=this.arrayCodigo[0];
    this.ModeloDatosCert.acu_tip=this.arrayCodigo[1];
   let resultado: PartidaPresupuestariaDetMo;
    this.ServicioClienteHttp.Insertar( this.ModeloDatosCert).subscribe({
        next: (data) => {
         // console.log("respuesta: "+JSON.stringify(data));
          if (data.success) {
           
      

           // }
           // else{
             
           // }
         //   this.dataSource = new MatTableDataSource(this.resultado);
           // this.dataSource.sort = this.sort;

            //this.CargarGrid();
 
            this.CargarForm();
            let result: any = JSON.parse(data.result);  
            resultado= result[0];   
           // this.resultado[0].out_cuenta=
         // }
       //   else{
      //      this.CargarGridAprobar();
            //let parametro = this.ServicioCrypt.encryptString("EDITAR||"+   this.arrayCodigo )          
           // this.router.navigate(['/'+this.pagina, parametro]);
            // this.FormularioDatos.patchValue({
                       
              //         siglasnum: this.arrayCodigo,
                //       estado_desc:"prueba",
                    //     this.router.navigate(['/'+this.pagina, parametro]);
                  //  }); 
            //this.RefrescarPantalla(data); 
           // let respuestaAprobar = JSON.parse(data.result)[0];
          //  console.log("respuesta1: "+JSON.stringify(respuestaAprobar));
         //   //if (respuestaAprobar.ejecutado === true) {
             // this.OcultarError = false;
           //   this.MensajeError = '<p><strong>NO SE PUEDE APROBAR EL COMPROMISO</strong><p>' + respuestaAprobar.mensaje;
          // } else {
            //  let parametro = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
           //   this.alertas.MensajeExito('/' + this.paginaA, 'Registro aprobado exitosamente', parametro);
           // }
          } else {
            console.log("respuesta2: "+data);
            this.resultado =[];
            
            this.alertas.MensajeError(data.message);
          }
          console.log("resultado"+JSON.stringify(this.resultado));
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        },
        error: (err) => {
          console.log("respuesta3: ");
          console.log(err.message);
        }
      });
    }
  });
}
/**
 * Funcion que carga la informacion de la forma
 */
  CargarForm():void {
    switch (this.evento) {
      case "EDITAR":
       //console.log("estoy en edita");
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
 
      break;
        case "DUPLICAR":
                 this.rutaapi="Certificacion/Liquidacion";    
          break;
      case "NUEVO":
        //this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/CE");
        //this.ServicioClienteHttp.SeteoRuta("Certificacion");     
        //  this.pk_identificador=this.codigoCertificacion;
          this.AccionEnNuevo();
        
        break;
    } 
//console.log("evento"+this.evento);//||this.evento == "NUEVO"
    if (this.evento == "EDITAR" ) {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO"; 
       /*if (this.evento == "NUEVO"){
        this.pk_identificador=this.codigoCertificacion;
        console.log("codigo "+this.pk_identificador);
       }  console.log("actualizar2"+this.pk_identificador);*/

       //this.pk_identificador+"?anio="+this.ParamSessiones.anio
     //  console.log("Antes de buscar por codigo")
      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador+"?anio="+this.ParamSessiones.anio).subscribe({
        next: (data) => {
          if (data.success) {
         //   console.log("Para ver resultado por codigo"+JSON.stringify(data.result))
            

            let result: any = JSON.parse(data.result);  
            let resultado: MovimientosPresupuestariosMo = result[0];   
           
            this.arrayCodigo =resultado.siglasnum.split(' ');
            this.codigoCertificacion=resultado.siglasnum; 
            this.estado_desc =resultado.estado_desc;
            //console.log("ps "+resultado.estado_desc); 
            this.creado_por =resultado.creado_por;
            this.modificado_por =resultado.modificado_por;
            this.anula_liquida= resultado.anula_liquida;
            this.asoc=resultado.asoc;

            //this.estado=resultado.estado;
            this.estado=resultado.out_estado;
            this.estado=resultado.out_estado;
            this.en_proceso=resultado.en_proceso;
            this.anulado_siglasnum=resultado.anulado_siglasnum?"CE"+resultado.anulado_siglasnum:resultado.anulado_siglasnum;
            this.AccionesBotones(this.estado);  
            this.FormularioDatos.patchValue({
              
              siglasnum: resultado.siglasnum,
              num_com: resultado.num_com,
              fec_asi: resultado.fec_asi,
              fec_apr: resultado.fec_apr,
              des_cab: resultado.des_cab,
              tot_cre: resultado.tot_cre,           
              val_cre:resultado.val_cre == undefined? 0:resultado.val_cre,
              estado_desc:resultado.estado_desc,
              //codigo_est:resultado.estado,            
              creado_por:resultado.creado_por,
              modificado_por:  resultado.modificado_por,
              departam:resultado.departam,
              solicita:resultado.solicita,         
              departam_desc:resultado.departam_desc,
              solicita_desc:resultado.solicita_desc,
              cod_proceso:resultado.cod_proceso,
              valor_contrato:resultado.valor_contrato,  
              anulado_siglasnum:"CE "+resultado.anulado_siglasnum, 
            });         
          }  
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
    this.FormularioDatos = this.CrearFormulario();
  }


  /**
    * Funcion que dirige a la pantalla para el nuevo registro
    */
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }

  

  CrearFormulario(): UntypedFormGroup {
   /* let validacion=",[Validators.required]";
   console.log("Valor event:"+this.evento) ;
    if(this.evento="EDITAR"){
      validacion="";
    }*/
    return this.formBuild.group({
      TxtpartidaSeleccionada:[""],
      siglasnum: [{value: this.ModeloDatos.siglasnum
        , disabled: this.isReadOnly }],//[Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.maxLength(2)]
      num_com: [this.ModeloDatos.num_com,[Validators.required]],
      fec_asi: [this.ModeloDatos.fec_asi],
      fec_apr: [this.ModeloDatos.fec_apr],
      des_cab: [this.ModeloDatos.des_cab],
      tot_cre: [this.ModeloDatos.tot_cre],
    
     // certificado: ["0",{value:this.ModeloDatos.certificado},[Validators.required]],
     val_cre: ["0",{value:this.ModeloDatos.val_cre}],
    //  codigo_est: [this.ModeloDatos.codigo_est],
      partida_desc: [""],//[Validators.required]
      departam_desc: ["",[Validators.required]],
      solicita_desc: ["",[Validators.required]],
      partida: [0],
      departam: [0],
      solicita: [0], 
      creado_por:  [{value: this.ModeloDatos.creado_por}],//poner otra vez , ,disabled: this.isReadOnly 
      modificado_por:  [{value: this.ModeloDatos.modificado_por}],//, disabled: this.isReadOnly
      cod_proceso: ["",{value:this.ModeloDatos.cod_proceso}],
      valor_contrato:  ["",{value: this.ModeloDatos.valor_contrato }],
      anulado_siglasnum:[{value: this.ModeloDatos.anulado_siglasnum  , disabled: this.isReadOnly }],
    });
  }



 

  CargarModelo(){
    let datosGuardar = this.FormularioDatos.getRawValue();     
    this.ModeloDatos.in_cod_proceso=datosGuardar.in_cod_proceso;    
    this.ModeloDatos.departam_desc=datosGuardar.departam_desc;
    this.ModeloDatos.solicita_desc=datosGuardar.solicita_desc;
    this.ModeloDatos.partida_desc=datosGuardar.partida_desc;
    this.ModeloDatos.siglasnum=datosGuardar.siglasnum;
    this.ModeloDatos.num_com=datosGuardar.num_com.trim();
    this.ModeloDatos.descrip=String(this.ParamSessiones.codemp)+"|"+String(this.ParamSessiones.anio)+"|"+String(this.ParamSessiones.codusu);
    this.ModeloDatos.fec_asi=datosGuardar.fec_asi;
    this.ModeloDatos.fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.out_fec_apr=datosGuardar.fec_apr;
    this.ModeloDatos.des_cab=datosGuardar.des_cab;
    this.ModeloDatos.tot_cre=datosGuardar.tot_cre;
    this.ModeloDatos.val_cre=datosGuardar.val_cre.length === 0?0:datosGuardar.val_cre;
   // this.ModeloDatos.codigo_est=datosGuardar.codigo_est;
    this.ModeloDatos.creado_por= datosGuardar.creado_por;
    this.ModeloDatos.modificado_por = String(this.ParamSessiones.codusu);
    this.ModeloDatos.estado_desc=datosGuardar.estado_desc;
   // this.ModeloDatos.estado=datosGuardar.estado;
    this.ModeloDatos.out_cre_por_desc="";
    this.ModeloDatos.out_mod_por_desc="";
    this.ModeloDatos.valor_contrato=datosGuardar.valor_contrato.length === 0?0:this.ModeloDatos.valor_contrato;
    this.ModeloDatos.departam=datosGuardar.departam;
    this.ModeloDatos.solicita=datosGuardar.solicita;
    this.ModeloDatos.cod_proceso=datosGuardar.cod_proceso;
    this.ModeloDatos.out_anio=this.ParamSessiones.anio;
    this.ModeloDatos.VarSesion=this.ParamSessiones;
  
  }

  cargarVariablesApruebaDesaprueba()
  {
    this.ServApruebaDesaprueba.GetVariablesAprobarDesaprobar('CO').subscribe({
      next: (result) => {
        this.VarApruebaDesaprueba = result;
      },
      error: (err) => {
        console.error('Error al obtener variables:', err);
      }
    });
  }

CargarModeloPartidaDetalle(){
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  this.ModeloDatosPartidaDetalle.sig_tip=parts_siglasnum[0];
  this.ModeloDatosPartidaDetalle.acu_tip=parts_siglasnum[1];
  this.ModeloDatosPartidaDetalle.varSesion=this.ParamSessiones;
}


/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  AccionEnNuevo() {
     this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
     this.ModeloDatos.VarSesion=this.ParamSessiones;
           // console.log("ps "+this.pk_identificador); 
        if (this.pk_identificador == "-1") {
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios");
          this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
                let result: any = data.result;
              //  console.log("ps "+JSON.stringify(data.result));  
                let resultado: MovimientosPresupuestariosMo = result[0];   
              //  console.log("luego del exito"+resultado.descrip);
         
                this.pagina="Movimientos/CertificacionesPresupuestarias";
                let parametro = this.ServicioCrypt.encryptString("EDITAR||"+   resultado.siglasnum )          
   this.router.navigate(['/'+this.pagina, parametro]);
    this.FormularioDatos.patchValue({
              
              siglasnum: resultado.siglasnum,
         
              estado_desc:resultado.descrip,
           //     this.router.navigate(['/'+this.pagina, parametro]);
           }); 
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        } 
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  GuardarInformacion() {

    Swal.fire({
      title: "Esta seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
     ///insertar movimiento
      this.CargarModelo();
//no hace nada al guardar
        if (this.pk_identificador == "-1") {
      
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios");
          this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
            next: (data) => { 

              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          });
        } else {
          this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios");
          
       //   console.log("en Actualizar"+this.pk_identificador+ " "+JSON.stringify(this.ModeloDatos));
          this.ServicioClienteHttp.Actualizar(this.pk_identificador, this.ModeloDatos).subscribe({
            next: (data) => {
              if (data.success) {
                 //insertar detalle
 // console.log("actualizando "+this.ModeloDatos.val_cre+" "+this.FormularioDatos.get('TxtpartidaSeleccionada')?.value);
  if (this.ModeloDatos.val_cre<=0 && this.FormularioDatos.get('TxtpartidaSeleccionada')?.value!=''){
                 this.GuardarInformacionPartidaModel(this.ModeloDatosPartidaDetalle,1 )}
                 this.RefrescarPantalla(data);
//                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        }
      }
    });
  }

  AbrirPickerFecAsi(): void {
    this.picker_fec_asi.open();
  }
  
  AbrirPickerFecAprob():void{
    this.picker_fec_apr.open();
  }
 
  public editedElement: any | null = null;
  public editedElementG: any | null = null;
  public isEditing: boolean = false;

  iniciaEditList(element: any): void {
   
   //while (element.out_val_cre>=element.valor_maximo)
    this.isEditing = true;

console.log("Es el elemento"+JSON.stringify(element));
    element.out_asociac=2;
    if(element.out_asociac == 2){
      this.editedElement = element;
    }
    if(element.out_asociac == 1){
      this.editedElementG = element;
    }
     // Indicar que estamos en modo edición
  }

  VerCOAsociado(){
    const str_codigo_certificacion =  this.codigoCertificacion;
    const DatosArchivo: any = {
      tipo_reporte: "CO ASIOCIADO",
      str_codigo_certificacion: str_codigo_certificacion
    };

    this.dialog.open(VercertificadocompromisoListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });

  }
  
  VerSaldoPartida(fila: any) {
    const str_partida = fila.cuenta;
    const DatosArchivo: any = {
      tipo_reporte: "SALDO DE PARTIDA",
      partida: str_partida
    };

    this.dialog.open(VersaldopartidaListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });
  }

  
  /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
  finEditList(element: any): void {
  //  console.log("estoy en edicion"+JSON.stringify(element));
    element.val_sal = 0; // Calcula el saldo
    this.editedElement = null; // Desactiva la edición
    this.editedElementG = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
    // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
    this.GuardarInformacionPartidaModel(element,1);
  }

  
GuardarInformacionPartidaModel(partida:PartidaPresupuestariaDetMo, opc:number) {
    this.CargarModelo();
  
    this.CargarModeloPartidaDetalle();
 
  partida.out_cuenta="";
  partida.out_sig_tip="";
    if (partida.certificado<=0 && partida.cuenta!="" &&opc !=1) {
      Swal.fire({
        title: "Ingrese un monto",
      })
    }else{

    const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;
    partida.varSesion=this.ParamSessiones;

    let arrayResultado =this.codigoCertificacion.split(' ');
    partida.sig_tip=arrayResultado[0];
    partida.acu_tip=arrayResultado[1];
    
    
          this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetalleActualizar");
          this.ServicioClienteHttp.Insertar(partida).subscribe({
            next: (data) => {
              if (data.success) {
                if(data.message=="La partida ya existe")
                  this.alertas.MensajeAlerta(data.message);     
  
                this.CargarGrid();
             
            /*    this.FormularioDatos.patchValue({           
                  partida_desc:"",               
                  //certificado: "",  
                //  val_cre="", 
                });*/
               } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          }) 
    }   
  }


   /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion 
   */
  
   FiltroAutocomplete(opcion: string) {
    var filterValue = '';

    switch (opcion) {
      
      case "partida_desc":
          filterValue = this.partida_desc.nativeElement.value.toLowerCase();
          this.OpcionesPartidas = 
          this.EstructuraPartidas.filter(
            option=>
              {
                const textMatch=option.out_nom_cu.toLowerCase().includes(filterValue);
                return textMatch;
            }
        );
    
        this.FormularioDatos.patchValue({
          partida: this.OpcionesPartidas[0].out_cuenta.toString(),
        });
       break;

      case "departam_desc": 

          filterValue = this.departam_desc.nativeElement.value.toLowerCase();
          this.OpcionesDepartamentos = 
          this.EstructuraDepartamentos.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );
          this.FormularioDatos.patchValue({
            departam: this.OpcionesDepartamentos[0].codigo.toString(),
          });
      break;
      case "solicita_desc":
          filterValue = this.solicita_desc.nativeElement.value.toLowerCase();
          this.OpcionesResponsables = 
          this.EstructuraResponsables.filter(
            option => 
              {
                const textMatch = option.descrip.toLowerCase().includes(filterValue);
                return textMatch;
              }
          );

          this.FormularioDatos.patchValue({
          
            solicita: this.OpcionesResponsables[0].codigo.toString(),
          });
      break;
    }
  }

  /**
   * Carga informacion de departamento
   */
  CargarCatalogos(rutaA:string)
  {
    let opcion:string;
    if (rutaA.indexOf("/") >0){
    let arrayResultado = rutaA.split('/');
     opcion=arrayResultado[2];
    }
    else{
      opcion='0';
    }
    this.ServicioClienteHttp.SeteoRuta(rutaA);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {

          switch (opcion) {
            case '19':
              this.EstructuraDepartamentos= data.result;
              this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
              break;
              case '54':
                this.EstructuraResponsables= data.result;
                this.OpcionesResponsables = this.EstructuraResponsables.slice();

              break;
              case '0':
                this.EstructuraPartidas= data.result;
                this.OpcionesPartidas = this.EstructuraPartidas.slice();

              break;
              default:
                break;
          }         
        }
        else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  // Método para iniciar la edición de una fila
  editRow(row: any) {
    this.editedElement = row;
  }

  // Método para guardar cambios y salir del modo de edición
  saveChanges() {
    this.editedElement = null;
  }

  // Método para cancelar cambios y salir del modo de edición
  cancelEdit() {
    this.editedElement = null;
  }

     /**
   * Funcion que genera la lista de datos para los grids de las pantallas
   */
  CargarGrid(): void {
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta( "PartidasPresupuestarias/DetallePartidasCE");
        break;

      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Movimientos/CertificacionesPresupuestarias");
        break;
    }
console.log("Al actualizar:"+this.pk_identificador);
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({

      next: (data) => {


        if (data.success) {
          //this.resultado =  data.result;//esto cambie
          this.resultado =  JSON.parse(data.result);
          console.log("partidas:"+JSON.stringify( this.resultado));
        }
        else{
          this.resultado =[];
        }
        console.log("datos grid"+JSON.stringify(this.resultado));
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;


      },

      error: (err) => {
        console.log(err.message)
      }
    })

  }


  CargarGridAprobar(): void {
    this.evento="APROBAR";
    console.log(" el evento en aprobar"+this.evento);
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta( "PartidasPresupuestarias/DetallePartidasCE");
        break;
        case "APROBAR":
        this.ServicioClienteHttp.SeteoRuta( "PartidasPresupuestarias/DetallePartidasCE");
        break;

      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Movimientos/CertificacionesPresupuestarias");
        break;
    }
console.log("Al aprobar1:"+this.pk_identificador);
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({

      next: (data) => {

        if (data.success) {
          this.resultado = data.result;
        }
        else{
          this.resultado =[];
        }
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;


      },
      error: (err) => {
        console.log(err.message)
      }
    })

  }

   /** 
 * Calcula el total certificado de todas las transacciones.
 * @returns {number} El total comprometido.
 */
TotalCertificado(): number {
  return this.resultado
    .map(transaccion => transaccion.out_val_cre)
     // al_cre)//certificado
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}
/** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.val_devengado)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total del saldo de todas las transacciones.
 * @returns {number} El total del saldo.
 */
TotalSaldo(): number {
  return this.resultado
    .map(transaccion => transaccion.saldo)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/**
 * Método para mostrar para liquidar Certificaciones Presupuestarias.
 */
LiquidarCertificacion(accion: string) {

  Swal.fire({
    title: "¿Está seguro/a que desea "+accion.toLowerCase()+" el Certificación Presupuestaria " + this.pk_identificador + "?",
    showDenyButton: true,
    confirmButtonText: "Si",
    denyButtonText: "No"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
      this.CargarModelo();
    this.CargarModeloPartidaDetalle();
    this.rutaapi="Certificacion/Liquidacion";   
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+"?accion="+accion);
   
   // this.ModeloDatos.anula_siglas_num=this.pk_identificador;

        this.ServicioClienteHttp.Insertar(this.ModeloDatosPartidaDetalle).subscribe({     
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeExito(this.pagina);
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })                  
    }
  });  
}


/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
ImprimirReporte(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_CERTIFICACION";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];
  DatosPdf.VarSesion=this.ParamSessiones;

  const dialogRef = this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}


/**
 * Función para cargar archivos.
 */

CargarArchivos(): void { 
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");
  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: Number(parts_siglasnum[1]),
    anio: this.ParamSessiones.anio,
    //fila.out_anio.toString(),
    codsistema: 0,
    descripcion: ""
  };

  this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}




/**
 * Controla las acciones de los botones según el estado del registro.
 * @param estado El estado del registro.
 */

AccionesBotones(estado: number) {
  console.log("acciones estado"+estado);
  console.log("acciones estado"+this.anula_liquida+" "+this.anulado_siglasnum);
    if(this.anula_liquida=='' ||  Number(this.anulado_siglasnum) <=0)
    this.OcultarLiqAnular=true;
   
    if(this.asoc=='' ){
      this.OcultarAsociado=true;
    }else{   this.anula_liquida=this.asoc;}

    this.FormularioDatos.get('val_cre')?.valueChanges.subscribe(value => {
      if (value>0 && this.FormularioDatos.get('TxtpartidaSeleccionada')?.value!='')
        this.ActivarAgregar=false;
        console.log(this.ActivarAgregar);
    });
   
    switch (estado) {
    case 0:
      this.OcultarBtnImprimir = true;
      this.OcultarBtnAnular = true;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = true;
      this.OcultarBtnDistribuir = true;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = true;
     
       
      break;
      case 1:
      this.OcultarBtnImprimir = false;
      this.OcultarBtnAnular = true;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = false;
      this.OcultarBtnDistribuir = true;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = false;
      this.OcultarBtnAprobar= false;
      this.OcultarBtnDesaprobar=true;
      break;
    case 2:
      this.OcultarBtnImprimir = false;
      this.OcultarBtnAnular = true;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = false;
      this.OcultarBtnDistribuir = true;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = false;
      break;
    case 3:
      console.log("ya en boton"+this.estado);
      this.OcultarBtnImprimir = false;
      this.OcultarBtnAnular = false;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = false;
      this.OcultarBtnDistribuir = true;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = false;
      this.OcultarBtnGuardarCancelar = true;
      this.OcultarBtnAprobar= true;
      this.ActivarSelectorPartida=true;
      this.ActivarAgregar=true;
  
      this.fec_asi.disable();
      this.fec_apr.disable();
      this.num_com.disable();
      this.departam_desc1.disable();
      this.des_cab.disable();
      this.solicita_desc1.disable();
      //this.OcultarBtnDesaprobar=false
      this.accion = '';
      this.colorEstado = 'label-info';

    /*  this.displayedColumns = [
        "certificacion",
        "cuenta",
        "nom_cue",
        "val_cre",
        "val_deb",
        "val_sal"];*/

      break;

    /*case 991:
      this.OcultarBtnImprimir = false;
      this.OcultarBtnAnular = true;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = false;
      this.OcultarBtnDistribuir = false;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = true;
      this.OcultarBtnGuardarCancelar = true;
     /* this.displayedColumns = [
        "certificacion",
        "cuenta",
        "nom_cue",
        "val_cre",
        "val_deb",
        "val_sal"];
      break;
      case 992:
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = false;
        this.OcultarBtnGuardarCancelar = true;
        this.colorEstado = 'label-info';
        this.displayedColumns = [
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];
        break;
        
        case 993:
          this.OcultarBtnImprimir = false;
          this.OcultarBtnAnular = true;
          this.OcultarBtnLiquidar = true;
          this.OcultarBtnDuplicar = false;
          this.OcultarBtnDistribuir = true;
          this.OcultarBtnVerSaldo = true;
          this.OcultarBtnCargarArchivos = false;
          this.OcultarBtnGuardarCancelar = true;
          this.colorEstado = 'label-info';
          this.displayedColumns = [
            "certificacion",
            "cuenta",
            "nom_cue",
            "val_cre",
            "val_deb",
            "val_sal"];
          break;       */ 
    default:
      this.OcultarBtnImprimir = true;
      this.OcultarBtnAnular = true;
      this.OcultarBtnLiquidar = true;
      this.OcultarBtnDuplicar = true;
      this.OcultarBtnDistribuir = true;
      this.OcultarBtnVerSaldo = true;
      this.OcultarBtnCargarArchivos = true;
      break;
  }
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y desaprobar el compromiso presupuestario.
 */
DesAprobarCertificacion(): void {
 /* Swal.fire({
    title: "¿Está seguro de desaprobar el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Desaprobar",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Desaprobar");
      this.ServicioClienteHttp.Insertar(this.Val_MovimientosPresupuestarios).subscribe({
        next: (data) => {
          if (data.success) {
            this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Compromiso desaprobado exitosamente",true);
            this.ngOnInit();
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });*/
}



/**
 * Método para mostrar un cuadro de diálogo de confirmación y anular el compromiso presupuestario.
 */
AnularCertificacion() {
  Swal.fire({
    title: "¿Está seguro/a que desea anular el Certificación Presupuestaria " + this.codigoCertificacion + "?",
    showDenyButton: true,
    confirmButtonText: "Si",
    denyButtonText: "No"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
   
    this.CargarModelo();
        this.ServicioClienteHttp.SeteoRuta("MovimientosPresupuestarios/AnulacionCertificacion");
        
        this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({     
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeExito(this.pagina);
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })                  
    }
  });

  ///detalle 
  this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/DetallePartidasCE");
  this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
    next: (data) => {

      if (data.success) {

        this.resultado = data.result;
      }

      this.dataSource = new MatTableDataSource(this.resultado);
      this.dataSource.sort = this.sort;

    },
    error: (err) => {
      console.log(err.message)
    }
  })
  
}

/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
EliminarRegistro(objeto: TipoComprobanteMo) {

  /*let textoEliminar:string = objeto.descripcion;
  let codigo:string = objeto.sigla;

  Swal.fire({
    title: "Esta seguro de eliminar "+ textoEliminar + "?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
  /*  if (result.isConfirmed) {

      this.ServicioClienteHttp.Eliminar(codigo).subscribe({
        next: (data) => {
          if (data.success) {
            this.CargarGrid();
            this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  });*/
}
/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
EliminarRegistroPartida(objeto: PartidaPresupuestariaDetMo) {

  let textoEliminar:string = objeto.cuenta;
  let arrayResultado =this.codigoCertificacion.split(' ');
  this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/Detalle");

  let codigo:string = this.ParamSessiones.codemp+"/"+this.ParamSessiones.anio+"/"+
        arrayResultado [0]+"/"+arrayResultado [1]+"/"+objeto.cuenta
        +"/"+objeto.out_sec_det  ;
  
  Swal.fire({
    title: "¿Está seguro de eliminar la partida? "+ textoEliminar + "?",
    showDenyButton: true,
    confirmButtonText: "Eliminar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {

      this.ServicioClienteHttp.Eliminar(codigo).subscribe
      ({
        next: (data) => {
          this.RefrescarPantalla(data); 
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
  });  
}

RefrescarPantalla(data: any){
 
  console.log("resultado despues de eliminar "+this.codigoCertificacion);
  if (data.success) {
    //this.resultado = 
    
    let parametro = this.ServicioCrypt.encryptString("EDITAR||"+this.codigoCertificacion)
    this.router.navigate(['/'+this.pagina, parametro]);

    //grid
    this.ServicioClienteHttp.SeteoRuta( "PartidasPresupuestarias/DetallePartidasCE");
    console.log ("ruta refresh"+this.pk_identificador);
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe
    ({
      next: (data) => {
        if (data.success) {
        this.resultado = data.result;             
        }else{
        this.resultado= [];      
        } 
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort; 
      },
      error: (err) => {
        console.log(err.message)
      }
    })  
  } else {
    this.alertas.MensajeError(data.message);
  } 
}

 /**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
 GuardarInformacionPartida(opcion:number) {
    this.CargarModelo();
    this.CargarModeloPartidaDetalle();
    if (this.ModeloDatos.val_cre<=0 || this.FormularioDatos.get('TxtpartidaSeleccionada')?.value=='') {
      Swal.fire({
        title: "Ingrese un monto y partida",
      })
    }else{
    const sPartida = this.FormularioDatos.get('TxtpartidaSeleccionada')?.value;

    this.ModeloDatosPartidaDetalle.cuenta=sPartida;
    this.ModeloDatosPartidaDetalle.val_cre=this.ModeloDatos.val_cre;
    this.ServicioClienteHttp.SeteoRuta("PartidasPresupuestarias/Detalle");
    this.ServicioClienteHttp.Insertar(this.ModeloDatosPartidaDetalle).subscribe({
          next: (data) => {
            if (data.success) {
              if(data.message=="La partida ya existe")
                this.alertas.MensajeAlerta(data.message);     
                this.CargarGrid();
                this.FormularioDatos.patchValue({           
                  partida_desc:"",                
                  val_cre: "",  
                  TxtpartidaSeleccionada:"",  
                });
             } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        }) 
  }
  this.TxtpartidaSeleccionada ='';  
}
  
BuscarPartida() {
  const DatosArchivo: any = {
    tipo_reporte: "BUSCAR PARTIDA",
    TxtpartidaSeleccionada: "",
    nTipoPresupuesto:this.nTipoPresupuestoID,
  };

  const DialogRef = this.dialog.open(ListabuscarpartidaListComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });

   DialogRef.afterClosed().subscribe(result => {
    if (result) {
      console.log(result);
      this.FormularioDatos.patchValue({
        TxtpartidaSeleccionada: result,
      // partida_desc:result,
      });
    }
  });

}
public TxtpartidaSeleccionada = "";
radioChangeHandler(value: any){
  this.nTipoPresupuestoID = value;
  this.FormularioDatos.patchValue({
    TxtpartidaSeleccionada: "",
    TxtNombrepartidaSeleccionada:"",
  });
}
 
}


