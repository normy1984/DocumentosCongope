import { Page404Component } from "app/authentication/page404/page404.component";
import { Route } from "@angular/router";
import { CompromisoListComponent } from "./compromiso/compromiso-list/compromiso-list.component";
import { CompromisoEditComponent } from "./compromiso/compromiso-edit/compromiso-edit.component";
import { CompromisoNuevoListComponent } from "./compromiso/compromiso-nuevo-list/compromiso-nuevo-list.component";
import { CertificadoListComponent } from "./certificado/certificado-list/certificado-list.component";
import { CertificadoEditComponent } from "./certificado/certificado-edit/certificado-edit.component";
import { ProformaListComponent } from "./proforma/proforma-list/proforma-list.component";
import { ProformaEditComponent } from "./proforma/proforma-edit/proforma-edit.component";

export const MOVIMIENTOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "dashboard1",
    pathMatch: "full",
  },
  {
    path: "ProformaPresupuestaria",
    component: ProformaListComponent,

  },
  {
    path: "ProformaPresupuestaria/:param",
    component: ProformaEditComponent,

  },

  {
    path: "CompromisosPresupuestarios",
    component: CompromisoListComponent,

  },
  {
    path: "CompromisosPresupuestarios/nuevo",
    component: CompromisoNuevoListComponent,
  },
  {
    path: "CompromisosPresupuestarios/:param",
    component: CompromisoEditComponent,

  },
  {
    path: "CompromisosPresupuestariosA/:param",
    component: CompromisoEditComponent,
  },

  {
    path: "CertificacionesPresupuestarias",
    component: CertificadoListComponent,

  },
  {
    path: "CertificacionesPresupuestarias/:param",
    component: CertificadoEditComponent,

  },

  { path: "**", component: Page404Component },

];

