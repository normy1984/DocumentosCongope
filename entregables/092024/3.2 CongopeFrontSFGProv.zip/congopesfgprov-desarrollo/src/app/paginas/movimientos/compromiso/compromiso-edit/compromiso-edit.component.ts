import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ListModule } from 'app/paginas/generico/list.module';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { CompromisoCabeceraMo, CompromisoDetalleMo } from 'app/models/movimientos/compromiso-mo';
import { DatePipe } from '@angular/common';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ConsultaAprobarDesaprobarService } from 'app/servicios/generico/consulta-aprobar-desaprobar.service';
import { VariablesAprobarDesaprobarMo } from 'app/models/administracion/aprobar-desaprobar-mo';
import { CompromisoNuevoListComponent } from '../compromiso-nuevo-list/compromiso-nuevo-list.component';
import { AsociaCompromisoListComponent } from '../asocia-compromiso-list/asocia-compromiso-list.component';

@Component({
  selector: 'app-compromiso-edit',
  templateUrl: './compromiso-edit.component.html',
  standalone: true,
  imports: [EditModule, ListModule,
    MatAutocompleteModule, MatSlideToggleModule, MatDatepickerModule, FormsModule
  ],
  // ESTA PARTE DE LOS PROVIDERS CAMBIA LOS OBJETOS DE ANGULAR MATERIAL A ESPAÑOL
  providers: [DatePipe,
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
    },

  ],
})

export class CompromisoEditComponent implements OnInit {


  @Input('param') param!: string;

  // Inyectando servicios
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);

  /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  

  // Enlaces con las vistas
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fec_aprob') picker_fec_aprob!: MatDatepicker<Date>;
  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('departam_desc') departam_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('admin_contrato_desc') admin_contrato_desc!: ElementRef<HTMLInputElement>;

  // Variables para manejo del formulario y datos
  public FormularioDatos!: UntypedFormGroup;
  public dataSource: MatTableDataSource<any> = new MatTableDataSource();
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: any = 0;
  public minDate = new Date();
  public resultado: any[] = [];
  public editedElement: any | null = null;
  public isEditing: boolean = false;
  public OcultarError: boolean = true;
  public MensajeError: string = '';

  // Variables de visualización
  public NoCompromiso: string = '';
  public estado_desc: string = '';
  public colorEstado: string = 'label-default';
  public creadoPor: string = '';
  public modificadoPor: string = '';
  public anio: number = 0;
  public estado: number = 0;
  public VerAnula_desc: string = '';
  public VerAnuladoPor_desc: string = '';
  public ValorCompromisoUtilizado:number = 0;
  public Val_MovimientosPresupuestarios = {};
  public textoAnula = '';
  public textoAnulado = '';

  // Flags de visibilidad para botones
  public OcultarBtnAprobar: boolean = false;
  public OcultarBtnDesaprobar: boolean = false;
  public OcultarBtnImprimir: boolean = false;
  public OcultarBtnAnular: boolean = false;
  public OcultarBtnLiquidar: boolean = false;
  public OcultarBtnDuplicar: boolean = false;
  public OcultarBtnDistribuir: boolean = false;
  public OcultarBtnVerSaldo: boolean = false;
  public OcultarBtnCargarArchivos: boolean = false;
  public OcultarBtnGuardarCancelar: boolean = false;
  public OcultarAnula: boolean = true;
  public OcultarAnuladoPor: boolean = true;

  // Definición de columnas para la tabla
  public displayedColumns: string[] = [
    "actions",
    "certificacion",
    "cuenta",
    "nom_cue",
    "val_cre",
    "val_deb",
    "val_sal"
  ];

  // Variables para departamentos y responsables
  public departam: number = 0;
  public solicita: number = 0;
  public admin_contrato: string = "";
  public OpcionesDepartamentos!: any[];
  public OpcionesResponsables!: any[];
  public OpcionesAdministradorContrato!: any[];
  public EstructuraDepartamentos!: any[];
  public EstructuraResponsables!: any[];
  public EstructuraTipoContratacion!: any[];
  public EstructuraAdministradorContrato!: any[];

  // Modelos para los datos del formulario
  blankObjectCabecera = {} as CompromisoCabeceraMo;
  ModeloDatosCabecera: CompromisoCabeceraMo = new CompromisoCabeceraMo(this.blankObjectCabecera);
  blankObjectDetalle = {} as CompromisoDetalleMo;
  ModeloDatosDetalle: CompromisoDetalleMo = new CompromisoDetalleMo(this.blankObjectDetalle);
  blankObject = {} as MovimientosPresupuestariosMo;
  ModeloDatos: any = new MovimientosPresupuestariosMo(this.blankObject);

   // Rutas de la API y navegación
   public pagina: string = "Movimientos/CompromisosPresupuestarios";
   public rutaapi: string = "Compromiso";

   public VarApruebaDesaprueba:VariablesAprobarDesaprobarMo = new VariablesAprobarDesaprobarMo();

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private datePipe: DatePipe,
    private ServApruebaDesaprueba: ConsultaAprobarDesaprobarService
  ) {

    // Suscripción a eventos del router para manejar la navegación de la página
    this.FormularioDatos = this.CrearFormulario();

  }

 
  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.CargarForm();
    this.CargarGrid();
    this.CargarDatosDepartamento();
    this.CargarDatosResponsables();
    this.CargarDatosAdministradorContrato();
    this.CargarDatosTipoContratacion();
    this.cargarVariablesApruebaDesaprueba();
  }

 
  

  cargarVariablesApruebaDesaprueba()
  {
    this.ServApruebaDesaprueba.GetVariablesAprobarDesaprobar('CO').subscribe({
      next: (result) => {
        this.VarApruebaDesaprueba = result;
      },
      error: (err) => {
        console.error('Error al obtener variables:', err);
      }
    });
  }
  
  /**
  * Funcion que dirige a la pantalla para el nuevo registro
  */
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }


  /**
   * Funcion que crea el formulario
   * @returns 
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      fec_asi: [this.ModeloDatos.fec_asi, [Validators.required]],
      num_com: [this.ModeloDatos.num_com, [Validators.required]],
      fec_apr: [this.ModeloDatos.fec_apr],
      departam_desc: [this.ModeloDatos.departam_desc,[Validators.required]],
      solicita_desc: [this.ModeloDatos.solicita_desc, [Validators.required]],
      des_cab: [this.ModeloDatos.des_cab, [Validators.required]],
      cod_proceso: [this.ModeloDatos.cod_proceso, [Validators.required]],
      valor_contrato: [this.ModeloDatos.valor_contrato,
        [
          Validators.required,
          Validators.pattern('^[0-9]+(\.[0-9]{1,2})?$'), // Asegura que solo se ingresen números
          Validators.min(0),     // Valor mínimo permitido
          Validators.max(this.TotalComprometido())    // Valor máximo permitido
        ]
      ],
      tipo_contrato: [this.ModeloDatos.tipo_contrato, [Validators.required]],
      admin_contrato_desc: [this.ModeloDatos.admin_contrato_desc,[Validators.required]],
    });
  }

/**
 * Funcion que realiza una validacion en el momento que se edita del total del compromiso
 */
  ActualizarValidadorMax() {
    const valorContratoControl = this.FormularioDatos.get('valor_contrato');
    if (valorContratoControl) {
      valorContratoControl.setValidators([
        Validators.required,
        Validators.pattern('^[0-9]+(\.[0-9]{1,2})?$'), // Asegura que solo se ingresen números
        Validators.min(0),     // Valor mínimo permitido
        Validators.max(this.TotalComprometido()) // Valor máximo dinámico
      ]);
  
      // Disparar la validación manualmente después de actualizar los validadores
      valorContratoControl.updateValueAndValidity();
    }
  }

  /**
   * Funcion que carga la informacion de la forma
   */
  CargarForm(): void {
    this.Val_MovimientosPresupuestarios = {
      siglas_num: this.pk_identificador,
      VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
    }

    // Determina la ruta de la API según el tipo de evento
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta("Compromiso/ListarMovimientoPresupuestariosCodigo");
        break;
      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Compromiso/CertCebecera");
        break;
    }

  
    // Solicita los datos del compromiso utilizando el identificador proporcionado
    this.ServicioClienteHttp.Insertar(this.Val_MovimientosPresupuestarios).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any[] = JSON.parse(data.result);
          let datosForm: any = resultado[0];
          this.ModeloDatos = new MovimientosPresupuestariosMo(resultado[0]);
          this.FormularioDatos = this.CrearFormulario();
          

          this.ValorCompromisoUtilizado = datosForm.utilizado;
  
          // Actualiza los campos del formulario con los datos obtenidos
          
  
          // Actualiza las propiedades del componente con los datos obtenidos
          this.departam = datosForm.departam;
          this.solicita = datosForm.solicita;
          this.admin_contrato = datosForm.admin_contrato;
          this.minDate = datosForm.fec_asi;
          this.NoCompromiso = datosForm.siglasnum ?? '';
          this.estado_desc = datosForm.estado_desc ?? '';
          this.anio = datosForm.anio ?? '';
          this.creadoPor = datosForm.creado_por ?? '';
          this.modificadoPor = datosForm.modificado_por ?? '';
          this.estado = datosForm.estado ?? '';
  
          this.ModeloDatosCabecera.acu_tipce = datosForm.acu_tipce ?? '';
          this.ModeloDatosCabecera.sig_tipce = datosForm.sig_tipce ?? '';
  
          this.VerAnula_desc = datosForm.anula_siglas_num;
          this.VerAnuladoPor_desc = datosForm.anulado_siglasnum;


          this.textoAnula = datosForm.liquida === 1 ? 'ANULA' : datosForm.liquida === 2 ? 'LIQUIDA': '';
          this.textoAnulado = this.VerAnula_desc === "1" ? 'ANULADO' : this.VerAnula_desc === "2" ? 'LIQUIDADO': '';

          // Manejo del estado según las condiciones de anulación
          if (parseInt(this.VerAnuladoPor_desc) > 0) {
            if (this.estado === 3) {
              switch(datosForm.liquida)
              {
                  case 0:
                  this.estado = 930; //"Liquidado o Anulado por ###"
                  break;
                  default:
                  this.estado = 931; //"Liquida o Anula a ###"
                  break;
              }
            } else {
              switch(datosForm.liquida){
                case 0:
                  this.estado = 990; //"Liquidado o Anulado por ###"
                  break;
                default:
                  this.estado = 991; //"Liquida o Anula a ###"
                  break;   
              }
             }
           
          }


          // Configura el estado del formulario y la acción a realizar según el evento
          switch (this.evento) {
            case "EDITAR":
              this.accion = "MANTENIMIENTO";
              this.colorEstado = 'label-danger';
              break;
            case "DUPLICAR":
              this.colorEstado ='label-default';
              this.accion = "CREAR NUEVO - DUPLICADO";
              this.NoCompromiso = "CO -1";
              this.estado_desc = 'EN EDICION - BORRADOR';
              this.estado = 0;
              break;
            case "NUEVO":
              this.colorEstado ='label-default';  
              this.estado_desc = 'EN EDICION - BORRADOR';
              this.estado = 0;
              break;
          }
  
          // Actualiza los botones según el estado del compromiso
          this.AccionesBotones(this.estado);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  
    
  }
  
  /**
   * Funcion que genera la lista de datos para los grids de las pantallas
   */
  CargarGrid(): void {

    let identificador: string;
    let tipo: number;
    let arrayResultado: any;
    this.resultado = [];
    
    switch (this.evento) {
      case "EDITAR":
        arrayResultado = this.pk_identificador.split(' ');
        identificador = arrayResultado[1];
        tipo = 2;
        break;
      case "DUPLICAR":
        arrayResultado = this.pk_identificador.split(' ');
        identificador = arrayResultado[1];
        tipo = 1;
        break;
      case "NUEVO":
        identificador = this.pk_identificador;
        tipo = 0;
        break;
      default:
        // Manejar caso por defecto si es necesario
        identificador = '';
        tipo = -1;
        break;
    }
    
    // Crear el objeto Val_MovimientosPresupuestarios utilizando las variables definidas
    const Val_MovimientosPresupuestarios = {
      siglas_num: identificador.toString(),
      VarSesion: JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}'),
      liquidar: tipo // Asignar el valor de tipo a la propiedad liquidar
    };

    this.ServicioClienteHttp.SeteoRuta("Compromiso/CertDetalle");
    this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
        }
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;
        this.ActualizarValidadorMax();
      },
      error: (err) => {
        console.log(err.message)
      }
    })


    

  }

  /** 
 * Calcula el total comprometido de todas las transacciones.
 * @returns {number} El total comprometido.
 */
TotalComprometido(): number {
  return this.resultado
    .map(transaccion => transaccion.val_cre)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.val_deb)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total del saldo de todas las transacciones.
 * @returns {number} El total del saldo.
 */
TotalSaldo(): number {
  return this.resultado
    .map(transaccion => transaccion.val_sal)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}


  /**
 * Carga información de departamentos desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosDepartamento(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/19");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraDepartamentos = data.result;
        this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Carga información de responsables desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosResponsables(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/54");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraResponsables = data.result;
        this.OpcionesResponsables = this.EstructuraResponsables.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}


/**
 * Carga información de el tipo de contratacion.
 */
CargarDatosTipoContratacion(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/57");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraTipoContratacion = data.result;
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}


/**
 * Carga información de el tipo de contratacion.
 */
CargarDatosAdministradorContrato(): void {
  this.ServicioClienteHttp.SeteoRuta( "Compromiso/ListarAdministradores");
  this.ServicioClienteHttp.Insertar(this.Val_MovimientosPresupuestarios).subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraAdministradorContrato = JSON.parse(data.result);
        this.OpcionesAdministradorContrato = this.EstructuraAdministradorContrato.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}


/**
 * Filtra las opciones de autocompletar basándose en la entrada del usuario.
 * @param opcion La opción a filtrar (solicita_desc o departam_desc).
 */
FiltroAutocomplete(opcion: string): void {
  let filterValue = '';
  switch (opcion) {
    case "solicita_desc":
      filterValue = this.solicita_desc.nativeElement.value.toLowerCase();
      this.OpcionesResponsables = this.EstructuraResponsables.filter(option => option.descrip.toLowerCase().includes(filterValue));
      this.solicita = this.OpcionesResponsables[0]?.codigo || 0;
      break;
    case "departam_desc":
      filterValue = this.departam_desc.nativeElement.value.toLowerCase();
      this.OpcionesDepartamentos = this.EstructuraDepartamentos.filter(option => option.descrip.toLowerCase().includes(filterValue));
      this.departam = this.OpcionesDepartamentos[0]?.codigo || 0;
      break;
    case "admin_contrato_desc":
        filterValue = this.admin_contrato_desc.nativeElement.value.toLowerCase();
        this.OpcionesAdministradorContrato = this.EstructuraAdministradorContrato.filter(option => option.descrip.toLowerCase().includes(filterValue));
        this.admin_contrato = this.OpcionesAdministradorContrato[0]?.cedruc || 0;
        break;  
  }
}

/**
 * Abre el selector de fecha de asignación.
 */
AbrirPickerFecAsi(): void {
  this.picker_fec_asi.open();
}

/**
 * Abre el selector de fecha de aprobación.
 */
AbrirPickerFecAprob(): void {
  this.picker_fec_aprob.open();
}


/**
 * Inicia el modo de edición para un elemento del grid.
 * @param element El elemento a editar.
 */
iniciaEditList(element: any): void {
  this.editedElement = element;
  this.isEditing = true; // Indicar que estamos en modo edición
}

/**
 * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
 * @param element El elemento editado.
 */
finEditList(element: any): void {
  element.val_sal = element.val_cre - element.val_deb; // Calcula el saldo
  this.editedElement = null; // Desactiva la edición
  this.isEditing = false; // Finaliza el modo edición
  // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
  this.ActualizarValidadorMax();
}

/**
 * Guarda la información ingresada en el grid.
 */
GuardarInformacion(): void {
  Swal.fire({
    title: "¿Está seguro de realizar los cambios?",
    showDenyButton: true,
    confirmButtonText: "Guardar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      let datosGuardar = this.FormularioDatos.getRawValue();

      const str_siglasnum = this.NoCompromiso;
      const parts_siglasnum = str_siglasnum.split(" ");

      // Reemplazo los valores del objeto inicial por los del formulario

      Object.keys(this.ModeloDatosCabecera).forEach(key => {
        if (key in datosGuardar) {
          (this.ModeloDatosCabecera as any)[key] = (datosGuardar as any)[key];
        }
      });
      this.ModeloDatosCabecera.departam = this.departam;
      this.ModeloDatosCabecera.solicita = this.solicita;
      this.ModeloDatosCabecera.tot_cre = this.TotalComprometido();
      this.ModeloDatosCabecera.tot_deb = this.TotalDevengado();
      this.ModeloDatosCabecera.sig_tip = parts_siglasnum[0];
      this.ModeloDatosCabecera.acu_tip = parseInt(parts_siglasnum[1]);
      this.ModeloDatosCabecera.fec_asi = this.datePipe.transform(datosGuardar.fec_asi, 'yyyy-MM-dd') ?? '';
      this.ModeloDatosCabecera.fec_apr = this.datePipe.transform(datosGuardar.fec_apr, 'yyyy-MM-dd') ?? '';
      this.ModeloDatosCabecera.admin_contrato = this.admin_contrato;


      this.GuardarCabecera();
    }
  });
}

/**
 * Guarda la cabecera en el servidor.
 */
GuardarCabecera(): void {
  this.ServicioClienteHttp.SeteoRuta("Compromiso/cabecera");
  this.ServicioClienteHttp.Insertar(this.ModeloDatosCabecera).subscribe({
    next: (data) => {
      if (data.success) {
        let retorno: any[] = JSON.parse(data.result);
        this.ModeloDatosCabecera.sig_tip = retorno[0].out_sig_tip;
        this.ModeloDatosCabecera.acu_tip = retorno[0].out_acu_tip;

        this.GuardarDetalle();

      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Guarda el detalle en el servidor.
 */
GuardarDetalle(): void {
  const ObjetoDetalle: CompromisoDetalleMo[] = this.resultado.map(element => {
    const str_siglasnumdet = element.certificacion;
    const parts_siglasnumdet = str_siglasnumdet.split(" ");
  
    let nuevoDetalle = new CompromisoDetalleMo(element); // Suponiendo que el constructor de CompromisoDetalleMo acepta un objeto como parámetro
  
    if (parts_siglasnumdet.length > 1) {
      nuevoDetalle.sig_tip = this.ModeloDatosCabecera.sig_tip;
      nuevoDetalle.acu_tip = this.ModeloDatosCabecera.acu_tip;
      nuevoDetalle.acu_tip_ce = parts_siglasnumdet[1];
    } else {
      console.error("La cadena str_siglasnumdet no contiene suficientes partes para dividir");
    }
  
    return nuevoDetalle;
  });

  this.ServicioClienteHttp.SeteoRuta("Compromiso/detalle");
  this.ServicioClienteHttp.Insertar(ObjetoDetalle).subscribe({
    next: (data) => {
      if (data.success) {
        this.param = this.ServicioCrypt.encryptString("EDITAR||CO " + this.ModeloDatosCabecera.acu_tip);
        this.router.navigate(['/' + this.pagina, this.param]);
        this.ngOnInit();
        this.alertas.MensajeConTimer("Compromiso guardado exitosamente!!",true);
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
  
}


/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
ImprimirReporte(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_COMPROMISO";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];

  const dialogRef = this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}

/**
 * Función para cargar archivos.
 */
CargarArchivos(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: parts_siglasnum[1],
    anio: this.anio,
    codsistema: 0,
    descripcion: ""
  };

  const dialogRef = this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}

/**
 * Duplica el registro actual.
 */
DuplicarRegistro(): void {
  this.param = this.ServicioCrypt.encryptString("DUPLICAR||" + this.pk_identificador)
  this.ngOnInit();
}


/**
 * Controla las acciones de los botones según el estado del registro.
 * @param estado El estado del registro.
 */
  AccionesBotones(estado: number) {
    switch (estado) {
      case 0:
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = true;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = true;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        this.OcultarBtnGuardarCancelar = false;
        this.displayedColumns = [
          "actions",
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];
        break;  
      case 2:
        this.OcultarBtnAprobar = false;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = false;
        this.OcultarBtnGuardarCancelar = false;
        this.displayedColumns = [
          "actions",
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];
        break;  
      case 3:
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = false;
        this.OcultarBtnAnular = this.ValorCompromisoUtilizado>0 ? true:false;
        this.OcultarBtnLiquidar = this.ValorCompromisoUtilizado>0 ? false:true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = false;
        this.OcultarBtnGuardarCancelar = true;

        this.accion = '';
        this.colorEstado = 'label-info';

        this.displayedColumns = [
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];

        break;

        case 930:

            this.OcultarAnuladoPor = false;
            this.OcultarAnula = true;

            this.OcultarBtnAprobar = true;
            this.OcultarBtnDesaprobar = true;
            this.OcultarBtnImprimir = false;
            this.OcultarBtnAnular = true;
            this.OcultarBtnLiquidar = true;
            this.OcultarBtnDuplicar = false;
            this.OcultarBtnDistribuir = true;
            this.OcultarBtnVerSaldo = true;
            this.OcultarBtnCargarArchivos = false;
            this.OcultarBtnGuardarCancelar = true;
            this.colorEstado = 'label-info';
            this.displayedColumns = [
              "certificacion",
              "cuenta",
              "nom_cue",
              "val_cre",
              "val_deb",
              "val_sal"];
            break;    
            
            case 931:

            this.OcultarAnuladoPor = true;
            this.OcultarAnula = false;

            this.OcultarBtnAprobar = true;
            this.OcultarBtnDesaprobar = true;
            this.OcultarBtnImprimir = false;
            this.OcultarBtnAnular = true;
            this.OcultarBtnLiquidar = true;
            this.OcultarBtnDuplicar = false;
            this.OcultarBtnDistribuir = true;
            this.OcultarBtnVerSaldo = true;
            this.OcultarBtnCargarArchivos = false;
            this.OcultarBtnGuardarCancelar = true;
            this.colorEstado = 'label-info';
            this.displayedColumns = [
              "certificacion",
              "cuenta",
              "nom_cue",
              "val_cre",
              "val_deb",
              "val_sal"];
            break;        
          case 990:

            this.OcultarAnuladoPor = true;
            this.OcultarAnula = false;

            this.OcultarBtnAprobar = true;
            this.OcultarBtnDesaprobar = true;
            this.OcultarBtnImprimir = false;
            this.OcultarBtnAnular = true;
            this.OcultarBtnLiquidar = true;
            this.OcultarBtnDuplicar = false;
            this.OcultarBtnDistribuir = true;
            this.OcultarBtnVerSaldo = true;
            this.OcultarBtnCargarArchivos = false;
            this.OcultarBtnGuardarCancelar = false;
            this.colorEstado = 'label-danger';
            this.displayedColumns = [
              "certificacion",
              "cuenta",
              "nom_cue",
              "val_cre",
              "val_deb",
              "val_sal"];
            break;    
            
            case 991:

        this.OcultarAnuladoPor = true;
        this.OcultarAnula = false;

        this.OcultarBtnAprobar = false;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        this.OcultarBtnGuardarCancelar = false;
        this.colorEstado = 'label-danger';
        this.displayedColumns = [
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];
        break;      
      default:
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = true;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = true;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        break;
    }
  }


/**
 * Método para mostrar un cuadro de diálogo de confirmación y aprobar el compromiso presupuestario.
 */
AprobarCompromiso(): void {
  let datosGuardar = this.FormularioDatos.getRawValue();
 
  const Val_MovimientosPresupuestarios = 
  {
    ...this.Val_MovimientosPresupuestarios,
    fecha_apr:this.datePipe.transform(datosGuardar.fec_apr, 'yyyy-MM-dd') ?? ''
  }


  Swal.fire({
    title: "¿Está seguro de aprobar el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Aprobar",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Aprobar");
      this.ServicioClienteHttp.Insertar(Val_MovimientosPresupuestarios).subscribe({
        next: (data) => {
          if (data.success) {
            let respuestaAprobar = JSON.parse(data.result)[0];
            if (respuestaAprobar.ejecutado === true) {
              this.OcultarError = false;
              this.MensajeError = '<p><strong>NO SE PUEDE APROBAR EL COMPROMISO</strong><p>' + respuestaAprobar.mensaje;
            } else {
              this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
              this.router.navigate(['/' + this.pagina, this.param]);
              this.alertas.MensajeConTimer("Compromiso aprobado exitosamente",true);
              this.ngOnInit();
             }
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y desaprobar el compromiso presupuestario.
 */
DesAprobarCompromiso(): void {
  Swal.fire({
    title: "¿Está seguro de desaprobar el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Desaprobar",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Desaprobar");
      this.ServicioClienteHttp.Insertar(this.Val_MovimientosPresupuestarios).subscribe({
        next: (data) => {
          if (data.success) {
            this.param = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Compromiso desaprobado exitosamente",true);
            this.ngOnInit();
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y anular el compromiso presupuestario.
 */
AnularCompromiso(liquidar:number): void {

  const ValAnular = {
    ...this.Val_MovimientosPresupuestarios, // Propaga las propiedades de Val_MovimientosPresupuestarios
    liquidar // Agrega la propiedad liquida al nuevo objeto
  };

  const titleSwal = liquidar === 1 ? "Anular":  "Liquidar";

  Swal.fire({
    title: "¿Está seguro de "+ titleSwal +" el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, "+ titleSwal,
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Anular");
      this.ServicioClienteHttp.Insertar(ValAnular).subscribe({
        next: (data) => {
          if (data.success) {
            let retorno: any[] = JSON.parse(data.result);
            this.param = this.ServicioCrypt.encryptString("EDITAR||CO " + retorno[0].out_acu_tip);
            this.router.navigate(['/' + this.pagina, this.param]);
            this.alertas.MensajeConTimer("Compromiso "+ titleSwal +" exitosamente",true);
            this.ngOnInit();
            } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}


/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
AsociarDesasociarCertificacion(tipo: boolean): void {
  const Val_MovimientosPresupuestarios = 
  {
    ...this.Val_MovimientosPresupuestarios,
    asociar:tipo,
    departamento: this.departam
  }

  const str_siglasnum = this.pk_identificador;
  const dialogRef = this.dialog.open(AsociaCompromisoListComponent, {
    data: {
      Val_MovimientosPresupuestarios
    },
    width: '95%',
    height: '100%'
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result > 0) {
      this.CargarGrid();
    }
  });

}


}

