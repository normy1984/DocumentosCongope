import { Component, Inject, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';

import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

import { FileUploadComponent } from "@shared/components/file-upload/file-upload.component";
import { EditModule } from "../edit.module";
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { VisualizarArchivosComponent } from '../visualizar-archivos/visualizar-archivos.component';
import { reduce } from 'd3';

@Component({
  selector: 'app-cargar-archivos',
  standalone: true,
  imports:
    [
      EditModule,
      FileUploadComponent,
      ListModule

    ],
  templateUrl: './cargar-archivos.component.html'
})

export class CargarArchivosComponent {

  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource !: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  titulo_reporte = "ARCHIVOS : ";

  formularioVisible = false;
  TablaVisible = true;
  objetoArchivo!: any;

  blankObject = {} as CargaArchivoMo;
  ModeloDatos: CargaArchivoMo = new CargaArchivoMo(this.blankObject);

  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  
  /*
   * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public rutaapi: string = "Upload";

  /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [

    "dcm_descripcion",
    "dcm_archivo_ori",
    "accion"];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<CargarArchivosComponent>,
    public dialog: MatDialog
  ) {

  }
  /**
   * Funcion que carga la informacion en el evento onInit
   */
  ngOnInit(): void {
    this.objetoArchivo = this.data.DatosArchivo;
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
    this.titulo_reporte += this.objetoArchivo.tipo_documento + " " + this.objetoArchivo.codigo_documento + " - " + this.objetoArchivo.anio;
  }



  /**
   * 
   * @returns Funcion para crear el Formulario de datos
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      uploadFile: ['', [Validators.required]],
      descripcion: ['', [Validators.required]],
    });
  }

  /**
  * Funcion que genera la lista de datos para los grids de las pantallas
  */

  CargarGrid() {
    this.ModeloDatos = this.objetoArchivo;
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/CargarList");
    this.ServicioClienteHttp.Insertar(this.ModeloDatos).subscribe({
      next: (data) => {
        let resultado: any[] = [];
        if (data.success) {
          resultado = JSON.parse(data.result);
        }
        this.dataSource = new MatTableDataSource(resultado);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }
  /**
* 
* @param event Funcion que realiza los fitrados de los grids
*/
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  /**
   * Funcion utilizada para guardar la informacion que se carga en el grid
   */
  GuardarInformacion(): void {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    let datosGuardar = this.FormularioDatos.getRawValue();
    this.ModeloDatos.descripcion = datosGuardar.descripcion;
    /***ESTE VALOR LO DEBEMOS CAMBIAR DE ACUERDO CON LO QUE SE NECESITE */
    this.ModeloDatos.codsistema = 1;


    const formData = new FormData();
    formData.append('file', datosGuardar.uploadFile);
    formData.append('descripcion', this.ModeloDatos.descripcion); // Añadir otros campos según sea necesario
    formData.append('tipo_documento', this.ModeloDatos.tipo_documento); // Añadir otros campos según sea necesario
    formData.append('codsistema', this.ModeloDatos.codsistema.toString()); // Añadir otros campos según sea necesario
    formData.append('codigo_documento', this.ModeloDatos.codigo_documento.toString()); // Añadir otros campos según sea necesario
    formData.append('anio', this.ModeloDatos.anio.toString()); // Añadir otros campos según sea necesario

    this.ServicioClienteHttp.Insertar(formData).subscribe({
      next: (data) => {
        if (data.success) {
          this.CargarGrid();
          this.formularioVisible = false;
          this.TablaVisible = true;
          const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = Swal.stopTimer;
              toast.onmouseleave = Swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            title: "Archivo Cargado exitosamente"
          });
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }

    }
    )

  }

  /**
   * Elemento vacio
   */
  submit() {
    // emppty stuff
  }

  /**
   * Funcion que muestra el archivo
   */
  CargarFormArchivo() {
    this.FormularioDatos = this.CrearFormulario();
    this.formularioVisible = true;
    this.TablaVisible = false;
  }

  /**
   * Funcion creada para Ocultar el fomulario en caso de no querer guardar nada
   */
  OcultarFormularioArchivo() {
    this.formularioVisible = false;
    this.TablaVisible = true;
  }

  /**
   * Carga de modal para enviar la informacion para mostrar el archivo cargado
   * @param fila 
   */
  VerArchivo(fila: any) {
    const dialogRef = this.dialog.open(VisualizarArchivosComponent, {
      data: {
        fila
      },
      width: '95%',
      height: '100%'
    });
  }


  /**
   * Funcion utilizada para eliminar el archivo, pide un parametro de observacion para eliminar
   * @param fila 
   */
  EliminarArchivo(fila: any): void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    (async () => {
      const { value: text } = await Swal.fire({
        title: "Ingrese una observación",
        input: "textarea",
        inputPlaceholder: "Ingrese la observación aquí...",
        showCancelButton: true,
        confirmButtonText: "Eliminar",
        cancelButtonText: "Cancelar",
        confirmButtonColor: "#F44A3E",
        preConfirm: (value) => { // Función de validación antes de confirmar
          if (!value.trim()) { // Validar que el texto no esté vacío o contenga solo espacios en blanco
            Swal.showValidationMessage('La observación es requerida!'); // Mostrar mensaje de error si el texto está vacío
          } else {
            return value; // Devolver el texto si pasa la validación
          }
        }
      });
      if (text) {

        const DatosEliminar: CargaArchivoMo = {
          anio: this.ModeloDatos.anio,
          tipo_documento: this.ModeloDatos.tipo_documento,
          codigo_documento: this.ModeloDatos.codigo_documento,
          descripcion: text.toString(),
          codsistema: fila.dcm_id.toString()
        }

        this.ServicioClienteHttp.EliminarParametros(fila.dcm_id, DatosEliminar).subscribe({
          next: (data) => {
            if (data.success) {
              let resultado: any[] = JSON.parse(data.result);
              if (resultado[0].total_eliminados > 0) {
                this.CargarGrid();
                const Toast = Swal.mixin({
                  toast: true,
                  position: "top-end",
                  showConfirmButton: false,
                  timer: 3000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                  }
                });
                Toast.fire({
                  icon: "success",
                  title: "Archivo eliminado exitosamente..."
                });
              } else {
                this.alertas.MensajeError("No se eliminaron registros...");
              }

            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }

        });

      }
    })()


  }

}