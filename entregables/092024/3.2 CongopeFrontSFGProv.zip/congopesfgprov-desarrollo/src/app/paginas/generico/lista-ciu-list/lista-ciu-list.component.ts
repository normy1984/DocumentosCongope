import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';

import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ProformaPresupuestariaMO } from 'app/models/params/proformapresupuestaria-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { ParamSessionMo } from 'app/models/param-session';
import { CiuMO } from 'app/models/params/ciu-mo';

@Component({
  selector: 'app-lista-ciu-list',
  templateUrl: './lista-ciu-list.component.html',
  standalone:true,
  imports: [
ListModule
  ]
})

export class ListaCiuListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public nExistePR: boolean = false;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Catalogos/CodigodeIdentificacionUnica";
public rutaapi:string = "ListaCiu";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "accion",
  "cedruc",
  "descrip",
  "direcci",
  "telefon1",
  "email1",
  "grupo",
];

  constructor(
    private router: Router
  ) {
    super();
  }

  ngOnInit() {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
           this.resultado = JSON.parse(data.result);
           this.dataSource = new MatTableDataSource(this.resultado);
           this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
        }
        else
        {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    const parametro = this.ServicioCrypt.encryptString("NUEVO||-1")
    this.router.navigate(['/'+this.pagina, parametro]);
  }

  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto
   */

  EditarRegistro(objeto: CiuMO) {
    const parametro = this.ServicioCrypt.encryptString("EDITAR||"+objeto.cedruc)
    this.router.navigate(['/'+this.pagina, parametro]);
  }


/**
 * Funcion para eliminar un registro
 * @param objeto
 */
  EliminarRegistro(objeto: ProformaPresupuestariaMO) {

    const textoEliminar:string = objeto.out_acu_tip.toString();
    const codigo:number = objeto.out_acu_tip;

    Swal.fire({
      title: "Esta seguro de eliminar "+ textoEliminar + "?",
      showDenyButton: true,
      confirmButtonText: "Eliminar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.ServicioClienteHttp.Eliminar(codigo).subscribe({
          next: (data) => {
            if (data.success) {
              this.CargarGrid();
              this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'SIGLA': x.sigla,
        'DESCRIPCION': x.descripcion,
        'SECUENCIA': x.secuencia,
        'REINICIA SECUENCIA ANUAL': x.reiniciasecuencia,
        'OPCION PAGADO': x.opcionpagado,
        'COMPROBANTE ROL': x.comprobanterol,
        'COMPROBANTE GARANTIA': x.comprobantegarantia,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}

