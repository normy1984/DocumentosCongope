import { Component, ElementRef, Inject, Input, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';

import {MatRadioModule} from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
  selector: 'app-listabuscarpartida-list',
  templateUrl: './listabuscarpartida-list.component.html',
  standalone:true,
  imports: [EditModule, ListModule, MatRadioModule
  ]
})


export class ListabuscarpartidaListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  @Input('param') param!: string;
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public nAnio = 0;
  public sUltimoNivel = "";
  objetoArchivo!: any;
  public nivel: number = 0;
  public nTipoPresupuestoID = 1;

  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "./listabuscapartida-list.component.html";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "partida",
  "nombre",
  "por_comprometer_real",
  "seleccionar",
];

constructor(
  @Inject(MAT_DIALOG_DATA) public data: any,

    public dialogRef: MatDialogRef<ListabuscarpartidaListComponent>,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nAnio = this.ParamSessiones.anio;
    this.objetoArchivo = this.data.DatosArchivo;
    this.objetoArchivo.nTipoPresupuesto;
    this.nTipoPresupuestoID = this.objetoArchivo.nTipoPresupuesto;

    this.rutaapi = "ListaBuscarPartida?nanio=" + this.nAnio +"&nTipoPresu=1&sPartida=";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.FiltrarAsociacion(this.nTipoPresupuestoID);
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Opting: 1,
    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;

        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CUENTA': x.cuentac,
        'NOMBRE CTA.': x.nombre_cta,
        'PARTIDA': x.cuentap,
        'NOMBRE PARTIDA': x.nombre_prt,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  FiltrarAsociacion(nTipoPresu: number) {

    this.rutaapi = "ListaBuscarPartida?nanio=" + this.nAnio +"&nTipoPresu="+nTipoPresu+"&sPartida=";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid();
  }


  SeleccionarPartida(fila: any) {
    const str_partida = fila.partida;
    this.dialogRef.close(str_partida);

  }
}


