import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';

import {MatRadioModule} from '@angular/material/radio';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
  selector: 'app-verasociacioncontabilidadpresupuesto-list',
  templateUrl: './verasociacioncontabilidadpresupuesto-list.component.html',
  standalone:true,
  imports: [EditModule, ListModule, MatRadioModule
  ]
})

export class VerasociacioncontabilidadpresupuestoListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public sUltimoNivel = "";
  public nAnio = 0;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('Cmbnivel01') Cmbnivel01!: ElementRef<HTMLInputElement>;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/VerAsociacionContabilidadPresupuesto";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "cuentac",
  "nombre_cta",
  "cuentap",
  "nombre_prt",
];

public nivel: number = 0;
public EstructuraNivelesGastos!: any[];
public OpcionesNivelesGastos!: any[];
public EstructuraNivelesIngresos!: any[];
public OpcionesNivelesIngresos!: any[];
public nTipoPresupuestoID = 1;
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    this.nAnio = this.ParamSessiones.anio;
    this.rutaapi = "AsociacionContabilidadPresupuesto?nanio="+ this.nAnio +"&nTipo_Presupuesto=1";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Opting: 1,
    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CUENTA': x.cuentac,
        'NOMBRE CTA.': x.nombre_cta,
        'PARTIDA': x.cuentap,
        'NOMBRE PARTIDA': x.nombre_prt,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  FiltrarAsociacion(nTipoPresu: number) {
    this.rutaapi = "AsociacionContabilidadPresupuesto?nanio=" + this.nAnio +"&nTipo_Presupuesto="+nTipoPresu+" ";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }

  CargarNivelesGastos(nTipoPresu: number): void {
    let nUltimoNivel = 0;
    this.ServicioClienteHttp.SeteoRuta("EstructuraPartidaGastos/detalle?anio=2024&tipopresu="+nTipoPresu+"");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) =>
      {
        if (data.success)
        {
          this.EstructuraNivelesGastos = JSON.parse(data.result);
          this.OpcionesNivelesGastos = this.EstructuraNivelesGastos.slice();
          nUltimoNivel = this.EstructuraNivelesGastos.length - 1;
          this.nivel = this.EstructuraNivelesGastos[nUltimoNivel].out_niv;
          this.sUltimoNivel = this.EstructuraNivelesGastos[nUltimoNivel].out_niv + " - " + this.EstructuraNivelesGastos[nUltimoNivel].out_descripcion;
        }
        else
        {
          this.alertas.MensajeError(data.message);
        }

        this.FormularioDatos.patchValue({
          Cmbnivel01: this.sUltimoNivel.trim(),
        });

      },
      error: (err) =>
      {
        console.log(err.message);
        //alert(err.message);
      }
    });
  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
    switch (opcion)
    {
      case "Cmbnivel01":
        filterValue = this.Cmbnivel01.nativeElement.value.toLowerCase();
        this.OpcionesNivelesGastos = this.EstructuraNivelesGastos.filter(option => option.out_descripcion.toLowerCase().includes(filterValue));
        this.nivel = this.OpcionesNivelesGastos[0]?.out_niv || 0;
        break;
    }
  }

  ClicRadioButton(opcion: number): void {
    this.CargarNivelesGastos(opcion);
  }

  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const nTipoPresupuesto = this.FormularioDatos.get('Opting')?.value;
    const nVerTodos = this.FormularioDatos.get('Chktodos')?.value;
    const nNivel = this.nivel.toString();
    const nOperador = this.FormularioDatos.get('Cmdoperador')?.value;
    let sOperador = "<=";
    if(nOperador == 2){
      sOperador = "=";
    }

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT_CEDULA_GASTOS";
    DatosPdf.param1 = sFechaHasta;
    DatosPdf.param2 = nTipoPresupuesto.toString();
    DatosPdf.param3 = nVerTodos.toString();
    DatosPdf.param4 = nNivel.toString();
    DatosPdf.param5 = sOperador;

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }
  //FIN RERPORTE


}


