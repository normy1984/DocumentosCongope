import { Component, OnInit } from '@angular/core';
import { TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { Row } from 'jspdf-autotable';

@Component({
  selector: 'app-reporte-pivot',
  standalone: true,
  imports: [ListModule],
  templateUrl: './reporte-pivot.component.html'
})
export class ReportePivotComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {

  constructor(
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit(): void {

    this.CargarReportePivot();
  }

  /**
   * Esta funcion exporta la tabla a excel
   */
  ExportarExcel() {
    TableExportUtil.ExportarTablaPivot();
  }


  /**
   * Funcion para cargar la informacion del reporte Pivot
   */
  CargarReportePivot() {

    const DatosCarga = {
      fecha_inicio: '2024-01-01',
      fecha_final: '2024-12-31',
      codemp: '0004',
      departamento: 0,
      estado: 0,
      tipo: "CO"
    };

    this.ServicioClienteHttp.SeteoRuta("CertificacionCompromisoNoUtilizados")
    this.ServicioClienteHttp.Insertar(DatosCarga).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any = data.result;
          if ($('#pivot-table').length) {
            $('#pivot-table').pivotUI(resultado, {
              rows:  ["departamento"],
              cols: ["estado"]
            }, true, 'es');
          } else {
            console.error('El contenedor #pivot-table no se encuentra en el DOM');
          }

        } else {
          console.log(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });

  }


}
