import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { SelectionModel } from '@angular/cdk/collections';
import { MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AprobarDocumentosMo, ConsultaAprobarDocumentosMo, UsuariosMo } from 'app/models/administracion/usuarios-mo';
import { MatTabsModule } from '@angular/material/tabs';
import { ListModule } from 'app/paginas/generico/list.module';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

interface MenuNodo {
  codigo: string;
  descripcion: string;
  nivel: number;
  submenu?: MenuNodo[];
  checked?: boolean; // Nueva propiedad para almacenar el estado del checkbox
}

@Component({
  selector: 'app-usuarios-edit',
  standalone: true,
  imports: [EditModule, ListModule,
    MatAutocompleteModule, MatSlideToggleModule,
    MatCheckboxModule, MatTreeModule,
    MatTabsModule
  ],
  templateUrl: './usuarios-edit.component.html',
  styleUrl: './usuarios-edit.component.scss'
})

export class UsuariosEditComponent implements OnInit {

  @Input('param') param!: string;

  TREE_DATA: MenuNodo[] = [];

  treeControl = new NestedTreeControl<MenuNodo>(node => node.submenu);
  dataSource = new MatTreeNestedDataSource<MenuNodo>();

  public dataSourceOpciones: MatTableDataSource<any> = new MatTableDataSource();

  /** The selection for checklist */
  checklistSelection = new SelectionModel<MenuNodo>(true /* multiple */);

  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);

  public isReadOnly: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: number = 0;
  public menuPerfilUsuario: string[] = [];
  public datosUsuario: UsuariosMo = {} as UsuariosMo;
  public disableFuncionario: boolean = false;
  public disableTab: boolean = true;
  public MenuApruebaDesaprueba: any[] = [];

  public editedElement: any | null = null;
  public isEditing: boolean = false;

  consultaAprobarDocumentos: ConsultaAprobarDocumentosMo = new ConsultaAprobarDocumentosMo();

  public activeButton: number = 0;
  //////////////////////////////////////////////
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  /**
   * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public pagina: string = "administracion/usuarios";
  public rutaapi: string = "Usuarios";


  public OptionsFuncionarios: any[] = [];
  OpcionesFuncionarios!: any[];

  @ViewChild('funcionario') funcionario!: ElementRef<HTMLInputElement>;


  /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [
    "actions",
    "sig_tip",
    "des_tip",
    "aprueba",
    "desaprueba",
  ];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService) {

  }
  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = parseInt(arrayResultado[1]);
    this.CargarMenuArbol(this.pk_identificador);

    this.datosUsuario.CodUsu = this.pk_identificador;


    if (this.pk_identificador > 0) {
      this.disableFuncionario = true;
      this.disableTab = false;
      this.CargarForm();
      this.CargarMenusAprobarDesaprobar()
    }
    else {
      this.CargarListadoFuncionarios();
    }
    this.FormularioDatos = this.CrearFormulario();

  }


  CargarForm(): void {
    if (this.evento == "EDITAR") {
      this.isReadOnly = true;

      this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
        next: (data) => {
          if (data.success) {
            let resultado: any = data.result;
            this.FormularioDatos.patchValue({
              funcionario: resultado[0].nombresCompletos,
              es_administrador: resultado[0].esAdmin,
              usuarioConsulta: resultado[0].usuarioConsulta,
            });
            this.datosUsuario.Cedruc = resultado[0].login;
            this.accion = "MANTENIMIENTO: " + resultado[0].nombresCompletos;
          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }

  }



  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      funcionario: [{ value: '', disabled: this.disableFuncionario }, [Validators.required]],
      es_administrador: ['', [Validators.required]],
      usuarioConsulta: [false, [Validators.required]],
    });
  }

  /**
   * Funcion utilizada para guardar la informacion que se carga en el grid
   */
  GuardarInformacion() {
    Swal.fire({
      title: "Esta seguro de guardar el usuario?",
      showDenyButton: true,
      confirmButtonText: "Sí, Guardar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        let datosGuardar = this.FormularioDatos.getRawValue();

        this.menuPerfilUsuario = [];
        this.collectCheckedItems(this.TREE_DATA);

        this.datosUsuario.EsAdministrador = datosGuardar.es_administrador;
        this.datosUsuario.UsuarioConsulta = datosGuardar.usuarioConsulta;
        this.datosUsuario.PerfilesMenu = this.menuPerfilUsuario;
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
        this.ServicioClienteHttp.Insertar(this.datosUsuario, true).subscribe({
          next: (data) => {
            if (data.success) {
              if (this.pk_identificador > 0) {
                this.alertas.MensajeExito(this.pagina, "Usuario actualizado exitosamente!!");
              }
              else {
                this.alertas.MensajeExito(this.pagina, data.message);
              }
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }


  collectCheckedItems(menu: any[]) {
    menu.forEach(element => {
      if (element.checked) {
        this.menuPerfilUsuario.push(element.codigo);
      }
      if (element.submenu) {
        this.collectCheckedItems(element.submenu);
      }
    });
  }

  /**
 * Funcion que dirige a la pantalla para el nuevo registro
 */
  VolverPagina() {
    this.router.navigate(['/' + this.pagina]);
  }

  /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion 
   */
  FiltroAutocomplete() {

    var filterValue = this.funcionario.nativeElement.value.toLowerCase();
    this.OpcionesFuncionarios = this.CargarDatosFiltrados(filterValue);
    this.datosUsuario.Cedruc = this.OpcionesFuncionarios[0]?.cedruc || "";

  }

  /**
   * Funcion para cargar el filtro de informacion a partir de la estructyra de las partidas de gastos
   * @param filterValue 
   * @returns 
   */
  CargarDatosFiltrados(filterValue: string | null) {
    return this.OptionsFuncionarios.filter(
      option => {
        option.descrip.toLowerCase().includes(filterValue)
        const valueMatch = option.descrip.toLowerCase().includes(filterValue);
        return valueMatch;
      }
    );
  }

  /**
   * Activa el Ingreso de Cuentas en tablas Generales
   */

  //////////////////////////////////////////////////////////////

  hasChild = (_: number, node: MenuNodo) => !!node.submenu && node.submenu.length > 0;

  todoItemSelectionToggle(node: MenuNodo): void {
    node.checked = !node.checked;
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.toggle(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
    descendants.forEach(child => (child.checked = node.checked));

  }

  todoLeafItemSelectionToggle(node: MenuNodo): void {
    node.checked = !node.checked;
    this.checklistSelection.toggle(node);
  }

  CargarMenuArbol(CodigoUsuario: number) {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/CargarMenuPerfil");
    this.ServicioClienteHttp.Obtener_x_Codigo(CodigoUsuario).subscribe({
      next: (data) => {
        if (data.success) {
          this.TREE_DATA = data.result;
          this.dataSource.data = this.TREE_DATA;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  CargarListadoFuncionarios() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ListarFuncionarios");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.OptionsFuncionarios = JSON.parse(data.result);
          this.OpcionesFuncionarios = this.OptionsFuncionarios.slice();
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  CargarMenusAprobarDesaprobar() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/MenuAprobarDesaprobar");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.MenuApruebaDesaprueba = JSON.parse(data.result);
          this.activeButton = this.MenuApruebaDesaprueba[0].sistema;
          this.CargarGridAprobarDesaprobar(this.MenuApruebaDesaprueba[0].sistema);
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })

  }


  CargarGridAprobarDesaprobar(CodSistema: number) {

    this.activeButton = CodSistema;
    this.consultaAprobarDocumentos.CodSistema = CodSistema;
    this.consultaAprobarDocumentos.CodUsu = this.pk_identificador;

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/CargarOpcionesAprobarDesaprobar");
    this.ServicioClienteHttp.Insertar(this.consultaAprobarDocumentos).subscribe({
      next: (data) => {
        if (data.success) {

          let resultado = JSON.parse(data.result);
          this.dataSourceOpciones = new MatTableDataSource(resultado);
          this.dataSourceOpciones.sort = this.sort;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })

  }

  /**
   * Inicia el modo de edición para un elemento del grid.
   * @param element El elemento a editar.
   */
  iniciaEditList(element: any): void {
    console.log(this.isEditing);
    if (!this.isEditing) {
      this.editedElement = element;
      this.isEditing = true; // Indicar que estamos en modo edición
    }
  }


  CancelEditList(element: any): void {
    this.editedElement = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
    this.CargarGridAprobarDesaprobar(this.activeButton);
  }

  /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
  finEditList(element: any): void {
    element.val_sal = element.val_cre - element.val_deb; // Calcula el saldo

    let vAprobarDocumentosMo: AprobarDocumentosMo = new AprobarDocumentosMo();
    vAprobarDocumentosMo.Aprueba = element.aprueba;
    vAprobarDocumentosMo.Desaprueba = element.desaprueba;
    vAprobarDocumentosMo.CodUsu = this.pk_identificador;
    vAprobarDocumentosMo.SigTip = element.sig_tip;
    vAprobarDocumentosMo.CodSistema = this.activeButton;

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ApruebaDesapruebaDocumentos");
    this.ServicioClienteHttp.Insertar(vAprobarDocumentosMo).subscribe({
      next: (data) => {
        if (data.success) {
          this.editedElement = null; // Desactiva la edición
          this.isEditing = false; // Finaliza el modo edición
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }
    })


  }

}
