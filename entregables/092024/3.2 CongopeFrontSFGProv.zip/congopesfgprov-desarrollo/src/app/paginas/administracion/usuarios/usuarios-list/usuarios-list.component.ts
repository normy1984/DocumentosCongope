
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { MatDialog } from '@angular/material/dialog';


@Component({
  selector: 'app-usuarios-list',
  standalone: true,
  templateUrl: './usuarios-list.component.html',
  imports: [
    ListModule
  ]
})
export class UsuariosListComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource !: MatTableDataSource<any>;
  public TipoLoginLdap:boolean = true;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  /**
   * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public pagina: string = "administracion/usuarios";
  public rutaapi: string = "Usuarios";

  /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [
    "accion",
    "cedruc",
    "descripcion",
    "email1",
    "es_admin",
    "estado"];

  constructor(
    private router: Router,
    public dialog: MatDialog // Agrega MatDialog aquí
  ) {
    super();
  }


  ngOnInit() {

    this.CargarTipoAutenticacion();
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CargarGrid() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any[] = JSON.parse(data.result);
          //let resultado: any = data.result;
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
          
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  CargarTipoAutenticacion() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+ '/ValidarTipoIngreso');
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.TipoLoginLdap = data.result;
          this.CargarGrid();
        }
        else {
          console.log(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    let parametro = this.ServicioCrypt.encryptString("NUEVO||-1")
    this.router.navigate(['/' + this.pagina, parametro]);
  }




  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto 
   */

  EditarRegistro(CodUsu: number) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||" + CodUsu)
    this.router.navigate(['/' + this.pagina, parametro]);
  }


  ActivarUsuario(datos: any) {
    Swal.fire({
      title: "¿Está seguro de activar a " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Activar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/ActivarUsuario')
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Usuario activado existosamente!!", true);
              this.CargarGrid();
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });



  }

  InactivarUsuario(datos: any) {
    Swal.fire({
      title: "¿Está seguro de inactivar a " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Inactivar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/InactivarUsuario')
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Usuario inactivado existosamente", true);
              this.CargarGrid();
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }


  ResetearContrasena(datos: any) {
    Swal.fire({
      title: "¿Está seguro de resetear la contraseña de " + datos.descripcion + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Resetear",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + '/ResetearContrasena');
        this.ServicioClienteHttp.Actualizar(datos.codigo_usuario,{},true).subscribe({
          next: (data) => {
            if (data.success) {
              this.alertas.MensajeConTimer("Se envio un correo electrónico con la contraseña a "+ datos.email1, true);
            }
            else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }



  /**
   * Funcion llamada para la exportacion a excel del formulario
   */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CODIGO': x.codtab,
        'DESCRIPCION': x.descrip,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   * 
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}