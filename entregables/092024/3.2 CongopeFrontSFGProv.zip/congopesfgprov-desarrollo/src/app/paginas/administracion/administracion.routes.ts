import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { UsuariosListComponent } from "./usuarios/usuarios-list/usuarios-list.component";
import { UsuariosEditComponent } from "./usuarios/usuarios-edit/usuarios-edit.component";
import { EmpresasEditComponent } from "./empresas/empresas-edit/empresas-edit.component";

export const ADMINISTRACION_ROUTE: Route[] = [
  {
    path: "usuarios",
    component: UsuariosListComponent,
  },
    {
    path: "usuarios/:param",
    component: UsuariosEditComponent,
  },
  {
    path: "empresa",
    component: EmpresasEditComponent,
  },
  { path: "**", component: Page404Component },
  
];

