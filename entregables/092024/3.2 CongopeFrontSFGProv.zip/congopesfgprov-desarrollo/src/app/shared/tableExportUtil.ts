import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import { TableElement } from './TableElement';
import autoTable from 'jspdf-autotable';

const getFileName = (name: string) => {
  const timeSpan = new Date().toISOString();
  const sheetName = name || 'ExportResult';
  const fileName = `${sheetName}-${timeSpan}`;
  return {
    sheetName,
    fileName,
  };
};
export class TableExportUtil {
  
  /**
   * Funcion para exportar a excel una tabla
   * @param arr 
   * @param name 
   */
  static exportToExcel(arr: Partial<TableElement>[], name: string) {
    const { sheetName, fileName } = getFileName(name);

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(arr);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${fileName}.xlsx`);
  }

/**
 * Funcion para exportar el contenido de una tabla Html a excel
 * @param tableId 
 * @param name 
 * @returns 
 */
  static exportTableToExcel(table: any, name: string) {
    const { sheetName, fileName } = getFileName(name);

    // Convertir la tabla HTML a una hoja de cálculo
    const ws = XLSX.utils.table_to_sheet(table);

    // Crear un nuevo libro de trabajo (workbook)
    const wb = XLSX.utils.book_new();

    // Agregar la hoja de trabajo al libro de trabajo
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    // Guardar el libro de trabajo como un archivo Excel
    XLSX.writeFile(wb, `${fileName}.xlsx`);
  }

  /**
   * Se crea una funcion generica para exportar la tabla del Pivot
   */
  static ExportarTablaPivot()
  {
    const TablaHtml = document.getElementById("TablaPivot_Export");
    this.exportTableToExcel(TablaHtml, 'excelPivot');
  }


  /**
   * Funcion para exportar a pdf una tabla
   * @param exportData 
   */
   static exportToPDF(exportData: any[]) {
     const doc = new jsPDF();
     const dataValue: any = Object.keys(exportData).map(function (
       personNamedIndex: any
     ) {
       return Object.values(exportData[personNamedIndex]);
     });
     const keys: any = Object.keys(exportData[0]);

     autoTable(doc, {
       head: [keys],
       body: dataValue,
     });

     const { fileName } = getFileName('pdf');

     doc.save(`${fileName}.pdf`);
   }
}
