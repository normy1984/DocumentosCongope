import { Injectable, inject } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ApiResultMo } from 'app/models/api-result-mo';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { configapp } from '@config/configapp';


@Injectable({
  providedIn: 'root',
})

export class MovPresupuestarioSrvService extends UnsubscribeOnDestroyAdapter {

  private http = inject(HttpClient);
  private apiUrl: string = configapp.apiUrl + "MovimientosPresupuestarios";

  /**
   * 
   * @returns Funcion para obtener el listado de datos para la construccion de un DataGrid
   */
  Obtener_Lista() {
    return this.http.get<ApiResultMo>(this.apiUrl);
  }

  /**
   * Funcion para obtener la informacion con un parametro especifico
   * @param sigla 
   * @returns 
   */
 
  /**
   * Funcion que envia los parametros para Insertar un nuevo registro
   * @param objeto 
   * @returns 
   */
  Insertar(objeto: any) {
    return this.http.post<ApiResultMo>(this.apiUrl, objeto);
  }

  /**
   * Funcion que actualiza los registros
   * @param sigla 
   * @param objeto 
   * @returns 
   */
  Actualizar(sigla: string, objeto: any) {
    return this.http.put<ApiResultMo>(`${this.apiUrl}/${sigla}`, objeto);
  }

}
