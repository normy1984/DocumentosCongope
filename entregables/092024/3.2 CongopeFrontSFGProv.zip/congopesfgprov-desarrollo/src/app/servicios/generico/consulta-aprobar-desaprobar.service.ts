import { Injectable } from '@angular/core';
import { ClienthttpCongopeService } from './clienthttp-congope.service';
import { ConsultarAprobarDesaprobarMo, VariablesAprobarDesaprobarMo } from 'app/models/administracion/aprobar-desaprobar-mo';
import { Observable, catchError, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConsultaAprobarDesaprobarService {

  private VarAprobarDesaprobar: VariablesAprobarDesaprobarMo = new VariablesAprobarDesaprobarMo();
  private VarConsApruebaDesaprueba: ConsultarAprobarDesaprobarMo = new ConsultarAprobarDesaprobarMo();

  constructor(private ServicioClienteHttp: ClienthttpCongopeService) { }

  GetVariablesAprobarDesaprobar(SigTip: string): Observable<VariablesAprobarDesaprobarMo> {
    this.VarConsApruebaDesaprueba.SigTip = SigTip;
    this.ServicioClienteHttp.SeteoRuta("AprobarDesaprobar");
    return this.ServicioClienteHttp.Insertar(this.VarConsApruebaDesaprueba).pipe(
      map((data) => {
        if (data.success) {
          this.VarAprobarDesaprobar = data.result[0];
        }
        return this.VarAprobarDesaprobar;
      }),
      catchError((err) => {
        console.error(err.message);
        return [this.VarAprobarDesaprobar]; // return an observable array with the default value
      })
    );
  }
}
