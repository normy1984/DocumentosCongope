import { Injectable, inject } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ApiResultMo } from 'app/models/api-result-mo';
import { FuentesFinanciamientoDeleteMo } from 'app/models/catalogos/fuentesfinanciamientodelete-mo';
import { configapp } from '@config/configapp';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',
})

export class FuentesFinanciamientoSrvService extends UnsubscribeOnDestroyAdapter {

  private http = inject(HttpClient);
  private apiUrl: string = configapp.apiUrl + "FuentesFinanciamiento";

    /**
   * Funcion para eliminar los registros de la base
   * @param id 
   * @param anio
   * @returns 
   */
  Eliminar_x_Anio(objeto: FuentesFinanciamientoDeleteMo): Observable<ApiResultMo> {
    return this.http.delete<ApiResultMo>(`${this.apiUrl}/${objeto.ffn_id}`, { body: objeto });
  }

}
