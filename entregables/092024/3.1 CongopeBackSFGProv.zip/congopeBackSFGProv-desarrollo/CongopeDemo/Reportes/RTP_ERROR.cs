﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;

namespace Congope.Empresas.Reportes
{
    public class RTP_ERROR
    {
            /// <summary>
            /// Funcion para obtener la informacion CatalogoPadre
            /// </summary>
            /// <returns></returns>
            public static dynamic CargarReporte()
            {
                try
                {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                        var oReporte = new PiePaginaMO();
                        return PdfBL.GenerarPDFBase64(oReporte);
                }
                catch (Exception e)
                {
                    SeguridadBL.WriteErrorLog(e);
                    return new
                    {
                        success = false,
                        message = "Error: " + e.Message,
                        result = ""
                    };
                }


            }
    

}
}
