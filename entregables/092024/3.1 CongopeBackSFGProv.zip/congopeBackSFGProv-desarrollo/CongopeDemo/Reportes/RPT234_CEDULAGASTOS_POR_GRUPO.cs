﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Ocsp;
using System.Runtime.InteropServices;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Congope.Empresas.Reportes
{
    public class RPT234_CEDULAGASTOS_POR_GRUPO
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            //string fecha_hasta = "";
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */
                var vReportes = new
                {
                    fecha_hasta = DatosReporte.param1
                };


                //string codEmpresa = Constantes.General.Empresa;
                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                int  codusu = DatosReporte.VarSesion.codUsu;
                NpgsqlCommand cmd = new NpgsqlCommand();

                string sNombreReporte = "RPT234_CEDULAGASTOS_POR_GRUPO";

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
                string sql = @"select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa;";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", sNombreReporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/
                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];

                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 12;";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];

                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA ///////////////////
                    ////////////////////////////////////////////////////

                    oReporte.numero_documento = $"AL : {Convert.ToString(vReportes.fecha_hasta)}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE  
                    ////////////////////////////////////////////////////
                    sql = @"SELECT * FROM sp_cedula_presupuetaria_gastos_grupo(@f_hasta) ;";
                    cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, vReportes.fecha_hasta);

                    cmd.CommandText = sql;

                    var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
                    Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

                    string html_detalle = "";

                    /***
                     * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
                     * para evitar la distorsion de la presentacion
                     */

                    float VALORTOTALASIGINI = 0;
                    float VALORTOTALREFORMAS = 0;
                    float VALORTOTALCODIFICADO = 0;
                    float VALORTOTALCOMPROMETIDO = 0;
                    float VALORTOTALDEVENGADO = 0;
                    float VALORTOTALPORCOMPROMETER = 0;
                    float VALORTOTALPORDEVENGAR = 0;
                    float VALORTOTALPAGADO = 0;

                    string sGrupo = "";
                    int sResultado;
                    foreach (var item in Datosprdetmov)
                    {
                        sResultado = 0;
                        sGrupo = item["grupo"];
                        if (sGrupo.Trim().Length == 1)
                        {
                            sResultado = 1;
                        }


                        if (sResultado == 0)
                        {
                            html_detalle += $@"
                                <tr>
                                    <td style=""font-size: 9px;word-break: break-all;max-width: 5%;"">{item["grupo"]}</td>
                                    <td style=""font-size: 9px;"">{item["descripcion"]}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["asig_ini"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["reformas"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["codificado"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["comprometido"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["devengado"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["por_comprometer"])}</td>
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["por_devengar"])}</td>    
                                    <td style=""font-size: 9px;text-align: right;"">{string.Format("{0:N2}", item["pagado"])}</td>
                                    <td style=""font-size: 9px;text-align: right;""></td>
                                </tr>";
                        }
                        else
                        {
                            if (sResultado == 1)
                            {
                                html_detalle += $@"
                                <tr>
                                    <td style=""font-size: 10px;""><FONT COLOR=""blue""><b>{item["grupo"]}</b></FONT></td>
                                    <td style=""font-size: 10px;""><FONT COLOR=""blue""><b>{item["descripcion"]}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["asig_ini"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["reformas"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["codificado"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["comprometido"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["devengado"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["por_comprometer"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["por_devengar"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["pagado"])}</b></FONT></td>
                                    <td style=""font-size: 10px;text-align: right;""><FONT COLOR=""blue""><b>{string.Format("{0:N2}", item["porcen_eje"])}</b></FONT></td>
                                </tr>
                                <tr>
								    <td colspan=11><hr></td>
							    </tr>";
                            }
                        }

                        VALORTOTALASIGINI = Convert.ToSingle(item["total_asig_ini"]);  
                        VALORTOTALREFORMAS = Convert.ToSingle(item["total_reformas"]);
                        VALORTOTALCODIFICADO = Convert.ToSingle(item["total_codificado"]);
                        VALORTOTALCOMPROMETIDO = Convert.ToSingle(item["total_comprometido"]);
                        VALORTOTALDEVENGADO = Convert.ToSingle(item["total_devengado"]);
                        VALORTOTALPORCOMPROMETER = Convert.ToSingle(item["total_por_comprometer"]);
                        VALORTOTALPORDEVENGAR = Convert.ToSingle(item["total_por_devengar"]);
                        VALORTOTALPAGADO = Convert.ToSingle(item["total_pagado"]);
                    }
                  
                    //REEMPLAZO DEL TOTAL
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));

                    htmlContent = htmlContent.Replace("##VALORTOTALASIGINI##", string.Format("{0:N2}", VALORTOTALASIGINI));
                    htmlContent = htmlContent.Replace("##VALORTOTALREFORMAS##", string.Format("{0:N2}", VALORTOTALREFORMAS));
                    htmlContent = htmlContent.Replace("##VALORTOTALCODIFICADO##", string.Format("{0:N2}", VALORTOTALCODIFICADO));
                    htmlContent = htmlContent.Replace("##VALORTOTALCOMPROMETIDO##", string.Format("{0:N2}", VALORTOTALCOMPROMETIDO));
                    htmlContent = htmlContent.Replace("##VALORTOTALDEVENGADO##", string.Format("{0:N2}", VALORTOTALDEVENGADO));
                    htmlContent = htmlContent.Replace("##VALORTOTALPORCOMPROMETER##", string.Format("{0:N2}", VALORTOTALPORCOMPROMETER));
                    htmlContent = htmlContent.Replace("##VALORTOTALPORDEVENGAR##", string.Format("{0:N2}", VALORTOTALPORDEVENGAR));
                    htmlContent = htmlContent.Replace("##VALORTOTALPAGADO##", string.Format("{0:N2}", VALORTOTALPAGADO));


                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;

                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
        //public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        //{
        //    //string fecha_hasta = "";
        //    try
        //    {
        //        /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
        //        */
        //        var vReportes = new
        //        {
        //            fecha_hasta = DatosReporte.param1,
        //            ing_gas = DatosReporte.param2,
        //            nTodos = DatosReporte.param3,
        //            nNivel = DatosReporte.param4,
        //            sOperador = DatosReporte.param5
        //        };

        //        //fecha_hasta = "2024-06-20";
        //        string codEmpresa = Constantes.General.Empresa;
        //        NpgsqlCommand cmd = new NpgsqlCommand();

        //        /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/
        //        string sql = @"select * from piepagina p 
        //                        where trim(p.reporte)  like @nombreReporte
        //                        and p.codemp = @codEmpresa; 
        //                        ";
        //        cmd.CommandText = sql;
        //        cmd.Parameters.AddWithValue("@nombreReporte", "RPTCEDULAGASTOS");
        //        cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
        //        var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

        //        /** CARGA EL CUERPO DEL REPORTE **/
        //        if (DatosBase.success)
        //        {
        //            var oReporte = DatosBase.result[0];

        //            /**
        //             * ORIENTACION
        //             * L: landscape/Horizontal
        //             * P: portrait /Vertical 
        //             * */
        //            oReporte.orientacion = "L";

        //            /*** CONTENIDO HTML DESDE BASE DE DATOS
        //                     * */
        //            sql = @"SELECT men_html from mensajes_html p where p.men_codigo  = 5;";
        //            cmd.CommandText = sql;
        //            var DatosHtml = Exec_sql.cargarDatosJson(cmd);
        //            DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
        //            string htmlContent = DatosHtml[0]["men_html"];

        //            ////////////////////////////////////////////////////
        //            ///DATOS DE LA CABECERA ///////////////////
        //            ////////////////////////////////////////////////////

        //            oReporte.numero_documento = $"AL : {Convert.ToString(vReportes.fecha_hasta)}";

        //            ////////////////////////////////////////////////////
        //            ///DATOS DEL DETALLE  
        //            ////////////////////////////////////////////////////
        //            //sql = @"SELECT * FROM sps_cedula_presupuestaria('0004', '" + vReportes.fecha_hasta + "', " + vReportes.ing_gas + ", " + vReportes.nTodos + ", "+ vReportes.nNivel + ", '" + vReportes.sOperador + "', '') ;";
        //            cmd.CommandText = sql;

        //            var Datosprdetmov = Exec_sql.cargarDatosJson(cmd);
        //            Datosprdetmov = JsonConvert.DeserializeObject(Datosprdetmov.result);

        //            float Total_asig_ini = 0;
        //            float Total_reformas = 0;
        //            float Total_codificado = 0;
        //            float Total_comprometido = 0;
        //            float Total_devengado = 0;
        //            float Total_por_comprometer = 0;
        //            float Total_por_devengar = 0;
        //            float Total_pagado = 0;

        //            string html_detalle = "";

        //            /***
        //             * El estilo word-break: break-all;max-width: 35% hace que el texto se corte en un maximo 
        //             * para evitar la distorsion de la presentacion
        //             */

        //            foreach (var item in Datosprdetmov)
        //            {
        //                html_detalle += $@"
        //                            <tr>
        //                                <td style=""font-size: 10px;word-break: break-all;max-width: 10%;"">{item["partida"]}</td>
        //                                <td style=""font-size: 10px;"">{item["nombre"]}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["asig_ini"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["reformas"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["codificado"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["comprometido"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["devengado"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["por_comprometer"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["por_devengar"])}</td>
        //                                <td style=""font-size: 10px;text-align: right;"">{string.Format("{0:N2}", item["pagado"])}</td>
        //                            </tr>";

        //                Total_asig_ini = item["tot_asig_ini"];
        //                Total_reformas = item["tot_reformas"];
        //                Total_codificado = item["tot_codificado"];
        //                Total_comprometido = item["tot_comprometido"];
        //                Total_devengado = item["tot_devengado"];
        //                Total_por_comprometer = item["tot_por_comprometer"];
        //                Total_por_devengar = item["tot_por_devengar"];
        //                Total_pagado = item["tot_pagado"];

        //            }

        //            //REEMPLAZO DEL TOTAL
        //            htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", Convert.ToString(html_detalle));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_ASIG##", string.Format("{0:N2}", Total_asig_ini));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_REFORMAS##", string.Format("{0:N2}", Total_reformas));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_CODIFICADO##", string.Format("{0:N2}", Total_codificado));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_COMPROMETIDO##", string.Format("{0:N2}", Total_comprometido));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_DEVENGADO##", string.Format("{0:N2}", Total_devengado));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_POR_COMPROMETER##", string.Format("{0:N2}", Total_por_comprometer));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_POR_DEVENGAR##", string.Format("{0:N2}", Total_por_devengar));
        //            htmlContent = htmlContent.Replace("##VALOR_TOT_PAGADO##", string.Format("{0:N2}", Total_pagado));

        //            oReporte.cuerpo_reporte = htmlContent;

        //            return PdfBL.GenerarPDFBase64(oReporte);


        //        }
        //        else
        //        {
        //            return DatosBase;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        SeguridadBL.WriteErrorLog(e);
        //        return new
        //        {
        //            success = false,
        //            message = "Error: " + e.Message,
        //            result = ""
        //        };
        //    }


        //}
        //fin

    }
}
