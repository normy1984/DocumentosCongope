﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Catalogo;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Catalogo
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstructuraOrganizacionalController : Controller
    {
        [HttpGet]
        public dynamic Get()
        {
            return EstructuraOrganizacionalBL.Listar();
        }
    }
}
