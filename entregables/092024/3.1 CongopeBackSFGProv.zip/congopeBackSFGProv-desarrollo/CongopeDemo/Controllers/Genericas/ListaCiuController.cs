﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ListaCiuController
    {
        [HttpGet]
        public dynamic Get()
        {
            return ListaCiuBL.Listar();
        }

        [HttpGet("seleccionar_ciu/{cedruc}")]
        public dynamic Seleccionar_ciu(string cedruc)
        {
            return ListaCiuBL.Seleccionar_ciu(cedruc);
        }

        [HttpGet("grupos_ciu/")]
        public dynamic grupos_ciu()
        {
            return ListaCiuBL.grupos_ciu();
        }

        [HttpGet("ciudades/")]
        public dynamic ciudades()
        {
            return ListaCiuBL.ciudades();
        }

        [HttpGet("titulos/")]
        public dynamic titulos()
        {
            return ListaCiuBL.titulos();
        }

        [HttpGet("bancos/")]
        public dynamic bancos()
        {
            return ListaCiuBL.bancos();
        }

        [HttpPost("inserta_actualiza_ciu")]
        public dynamic Inserta_Actualiza_CIU(CiuMO ciuMO)
        {
            return ListaCiuBL.Insertar_Actualiza_CIU(ciuMO);
        }


    }
}
