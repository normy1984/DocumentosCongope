﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class MenuController : Controller
    {
        /// <summary>
        /// Menu lateral de acuerdo al usuario y codigo del padre
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        [HttpGet("{codUsu}/{nivel}/{codigo}")]
        // POST api/<controller>
        public dynamic CargarMenuLateral(int codUsu, int nivel, string codigo)
        {
            return MenuBL.CargarMenuLateral(codUsu, nivel, codigo);
        }

        /// <summary>
        /// Menu principal de acuerdo con los permisos otorgados al padre
        /// </summary>
        /// <param name="codUsu"></param>
        /// <returns></returns>
        [HttpGet("{codUsu}")]
        // POST api/<controller>
        public dynamic CargarMenuPrincipal(int codUsu)
        {
            return MenuBL.CargarMenuPrincipal(codUsu);
        }

        /// <summary>
        /// Retorna el listado de ejercicios fiscales
        /// </summary>
        /// <returns></returns>
        [HttpGet("EjercicioFiscal")]
        // POST api/<controller>
        public dynamic CargarEjercicioFiscal()
        {
            return MenuBL.CargarEjercicioFiscal();
        }

        /// <summary>
        /// Funcion que devuelve las notificaciones del sistema
        /// </summary>
        /// <param name="paramSession"></param>
        /// <returns></returns>
        [HttpPost("Notificaciones")]
        public dynamic CargarNotificaciones(ParamSessionMo paramSession)
        {
            return MenuBL.CargarNotificaciones(paramSession);
        }

        /// <summary>
        /// Funcion que me permite ver si un usuario tiene permisoas para atender notificaciones
        /// </summary>
        /// <param name="CodUsu"></param>
        /// <returns></returns>
        [HttpGet("Notificaciones/{CodUsu}")]
        public dynamic CargarNotificaciones(int CodUsu)
        {
            return MenuBL.TienePermisosNotificaciones(CodUsu);
        }
    }
}
