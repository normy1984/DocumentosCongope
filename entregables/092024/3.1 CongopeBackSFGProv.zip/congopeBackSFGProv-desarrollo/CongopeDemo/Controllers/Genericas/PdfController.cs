﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Reportes;
using Congope.Empresas.Reportes;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Org.BouncyCastle.Utilities;
using System.IO;
using System.Text.Json;

namespace Congope.Empresas.Controllers.Genericas
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class PdfController : Controller
    {

        /// <summary>
        /// Esta funcion envia los parametros por Post para construir el archivo base 64 para el servicio
        /// </summary>
        /// <param name="vReportes"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic HttpPost([FromBody] VariablesPdfMO vReportes)
        {
            try
            {
               
                var anyPdf = new
                {
                    success = false,
                    message = "Error: NO HAY UNA SELECCION VALIDA",
                    result = ""
                }; ;

                switch (vReportes.tipo_reporte)
                {
                    case "RPT205_CERTIFICACION":
                        anyPdf = RPT205_CERTIFICACION.CargarReporte(vReportes);
                        break;
                    case "RPT205_COMPROMISO":
                        anyPdf = RPT205_COMPROMISO.CargarReporte(vReportes);
                        break;
                    case "RPT227_PROFORMA":
                        anyPdf = RPT227_PROFORMA.CargarReporte(vReportes);
                        break;
                    case "RPT_CEDULA_GASTOS":
                        anyPdf = RPT_CEDULA_GASTOS.CargarReporte(vReportes);
                        break;
                    case "RPT220_ESTADOEJEPRE":
                        anyPdf = RPT220_ESTADOEJEPRE.CargarReporte(vReportes);
                        break;
                    case "RPT217_MOVIMIENTO_PARTIDA":
                        anyPdf = RPT217_MOVIMIENTO_PARTIDA.CargarReporte(vReportes);
                        break;
                    case "RPT223_CLASIFICADOR":
                        anyPdf = RPT223_CLASIFICADOR.CargarReporte(vReportes);
                        break;
                    case "RPT241_MOVIMIENTO_COMPROMISO":
                        anyPdf = RPT241_MOVIMIENTO_COMPROMISO.CargarReporte(vReportes);
                        break;
                    case "RPT_CO_CE_NO_UTILIZADO":
                        anyPdf = RPT_CO_CE_NO_UTILIZADO.CargarReporte(vReportes);
                        break;
                    case "RPT234_CEDULAGASTOS_POR_GRUPO":
                        anyPdf = RPT234_CEDULAGASTOS_POR_GRUPO.CargarReporte(vReportes);
                        break;
					case "RPT238_DOC_ARRASTRE_DETALLE":
						anyPdf = RPT238_DOC_ARRASTRE_DETALLE.CargarReporte(vReportes);
					break;	
                    default:
                        anyPdf = RTP_ERROR.CargarReporte();
                        break;
                }

                /* if (anyPdf.success)
                 {

                     /// ESTAS LINEAS CONSTRUYEN EL PDF
                     string base64String = anyPdf.result; // Reemplaza "Base64StringHere" con tu cadena Base64

                     byte[] pdfBytes = Convert.FromBase64String(base64String);

                     MemoryStream memoryStream = new MemoryStream(pdfBytes);

                     return new FileStreamResult(memoryStream, "application/pdf");

                 }
                 else 
                 {

                     return anyPdf;
                 }*/
                return anyPdf;
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
            
        }


    }
}
