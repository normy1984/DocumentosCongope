﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("login")]
    [ApiController]
    public class LoginController : Controller
    {

        /// <summary>
        /// Funcion que trae el token de autenticacion con el usuario y contraseña del sistema
        /// </summary>
        /// <param name="oCredenciales"></param>
        /// <returns></returns>
        [HttpPost("credenciales")]
        public dynamic Index([FromBody] CredencialesLogo oCredenciales)
        {
            return LoginBL.ObtenerToken(oCredenciales);
        }

        /// <summary>
        /// Funcion que realiza la renovacion del token para evitar la caducidad del mismo y errores de registro de parte del usuario
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("renovar")]
        public dynamic Renew([FromBody] TokenRequest request)
        {

            if (request == null || string.IsNullOrEmpty(request.token))
            {
                return BadRequest("Invalid token data");
            }

            // Llama a tu lógica de renovación de token aquí
            return LoginBL.RenovarToken(request.token);

        }

        /// <summary>
        /// Funcion que permite recuperar la contraseña de la aplicacion en el caso de que se lo realice a traves de las tablas del sistema
        /// </summary>
        /// <param name="oCredenciales"></param>
        /// <returns></returns>
        [HttpPost("RecuperarContrasena")]
        public dynamic RecuperarContrasena([FromBody] CredencialesLogo oCredenciales)
        {
            return LoginBL.RecuperarContrasena(oCredenciales);
        }

        /// <summary>
        /// Valida si el tipo de ingreso con Ldap o sin Ldap
        /// </summary>
        /// <returns></returns>
        [HttpGet("ValidarTipoIngreso")]
        public dynamic ValidarTipoIngreso()
        {
            var respuesta = new ApiResultMo<bool>();
            respuesta.success = true;
            respuesta.result = Conexion.ValidarLdap;

            return respuesta;
        }

    }

    
}
