﻿using Congope.Empresas.BussinessLogic.Presupuesto.Procesos;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Presupuesto.Procesos;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Procesos
{
    [Route("api/[controller]")]
    [ApiController]
    public class CargarPresupuestoController : Controller
    {
        [HttpPost]
      
        public dynamic CargarPrepuestoExcel([FromForm] ValidarPresupuestoMo oValidarPresupuestoMo)
        {
            return CargarPresupuestoBL.CargarPresupuestoExcel(oValidarPresupuestoMo);
        }

        [HttpPost("SubirProforma")]
        public dynamic GuardarProformaPresupuestaria(List<EstructuraPresupuestoMo> lEstructuraPresupuestoMo)
        {
            return CargarPresupuestoBL.GuardarProformaPresupuestaria(lEstructuraPresupuestoMo);
        }

        [HttpPost("ValidarCargaProforma")]
        public dynamic ValidarCargaProforma(ParamSessionMo oParamSessionMo)
        {
            return CargarPresupuestoBL.ValidarCargaProforma(oParamSessionMo);
        }
    }
}
