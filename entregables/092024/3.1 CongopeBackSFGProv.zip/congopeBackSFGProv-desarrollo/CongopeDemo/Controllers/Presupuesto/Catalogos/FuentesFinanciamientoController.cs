﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;

namespace Congope.Empresas.Controllers.Presupuesto.Catalogos
{
    [Route("api/[controller]")]
    [ApiController]
    public class FuentesFinanciamientoController : Controller
    {
        /// <summary>
        /// Funcion que trae todo el detalle de informacion para las Fuentes de Financiamiento
        /// </summary>
        /// <returns></returns>
        //[Authorize]
        [HttpGet]
        public dynamic Get()
        {
            var result = FuentesFinanciamientoBL.Listar();

            Console.WriteLine("Resultado de Listar():");

            if (result != null)
            {
                foreach (var item in result.result)
                {
                    Console.WriteLine($"ID: {item.ffn_id}, Nombre: {item.ffn_nombre}, CtaPago: {item.ffn_ctapago}");
                }
            }
            else
            {
                Console.WriteLine("La lista devuelta es nula.");
            }

            return result;
            //return FuentesFinanciamientoBL.Listar();            
        }



        /// <summary>
        /// Obtener Fuente de Financiamiento por Id
        /// </summary>
        /// <param name="id"> identificador de la fuente de financieamiento</param>
        /// <returns>Booleano</returns>
        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public dynamic Get_Codigo(string id)
        {
            return FuentesFinanciamientoBL.ListarFuenteFinanciamientoCodigo(id);
        }



        /// <summary>
        /// Método para actualizar la fuente de financiamiento
        /// </summary>
        /// <param name="id">ID de la fuente de financiamiento</param>
        /// <param name="oFuentesFinanciamientoMO">Información de la fuente de financiamiento</param>
        /// <returns>true o False según se haya realizado o no la actualización</returns>
        // PUT api/<FuenteFinanciamientoController>/5   
        [HttpPut("{id}")]
        public dynamic Put(string id, [FromBody] FuentesFinanciamientoMO oFuentesFinanciamientoMO)
        {

            // No necesitamos modificar el campo ffn_id ya que es el identificador
            oFuentesFinanciamientoMO.ffn_id = id;

            var validacion = Validaciones.ValidarFuentesFinanciamientoPUT(oFuentesFinanciamientoMO);
            if (!validacion.IsValid)
            {
                return BadRequest(new { success = false, messages = validacion.Messages });
            }

            string sTipoAccion = "UPDATE";

            return FuentesFinanciamientoBL.InsertarActualizarFuenteFinanciamiento(sTipoAccion, oFuentesFinanciamientoMO);

        }


        /// <summary>
        /// Método para insertar una nueva fuente de financiamiento
        /// </summary>
        /// <param name="oFuenteFinanciamiento">Información de la nueva fuente de financiamiento</param>
        /// <returns></returns>
        [HttpPost]
        public dynamic Post([FromBody] FuentesFinanciamientoMO oFuentesFinanciamientoMO)
        {

            var validacion = Validaciones.ValidarFuentesFinanciamientoPOST(oFuentesFinanciamientoMO);
            if (!validacion.IsValid)
            {
                return BadRequest(new { success = false, messages = validacion.Messages });
            }


            string sTipoAccion = "INSERT";
            return FuentesFinanciamientoBL.InsertarActualizarFuenteFinanciamiento(sTipoAccion, oFuentesFinanciamientoMO);


        }


        /// <summary>
        /// Método para eliminar una fuente de financiamiento existente por su ID.
        /// </summary>
        /// <param name="id">ID de la fuente de financiamiento que se desea eliminar</param>
        /// <returns></returns>        
        [HttpDelete("{id}")]
        //public dynamic Delete(string id, int anio)
        public dynamic Delete(string id, [FromBody] FuentesFinanciamientoDeleteMO oFuentesFinanciamientoDeleteMO)
        {
            // No necesitamos modificar el campo ffn_id ya que es el identificador
            oFuentesFinanciamientoDeleteMO.ffn_id = id;

            var validacion = Validaciones.ValidarFuentesFinanciamientoDELETE(oFuentesFinanciamientoDeleteMO.ffn_id, oFuentesFinanciamientoDeleteMO.codemp, Convert.ToInt32(oFuentesFinanciamientoDeleteMO.anio));
            if (!validacion.IsValid)
            {
                return BadRequest(new { success = false, messages = validacion.Messages });
            }

            var result = FuentesFinanciamientoBL.EliminarFuenteFinanciamiento(oFuentesFinanciamientoDeleteMO.ffn_id);

            if (result.success)
            {
                return Ok(new { success = true, message = result.message });
            }
            else
            {
                return BadRequest(new { success = false, message = result.message });
            }
        }

    }
}
