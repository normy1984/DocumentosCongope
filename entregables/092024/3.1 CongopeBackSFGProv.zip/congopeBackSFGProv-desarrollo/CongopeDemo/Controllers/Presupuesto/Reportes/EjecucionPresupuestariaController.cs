﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class EjecucionPresupuestariaController
    {
        [HttpGet]
        public dynamic Get(string sFechaHasta)
        {
            return EjecucionPresupuestariaBL.Listar(sFechaHasta);
        }
    }
}
