﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class CertificacionCompromisoArrastreController : Controller
    {
        [HttpPost]
        public dynamic CertificacionesCompromisosArrastre(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNoUtilizadosMo)
        {
            return CertificacionCompromisoArrastreBL.CertificacionesCompromisosArrastre(ingresoCertificacionCompromisoNoUtilizadosMo);
        }

        [HttpPost("Actualizar")]
        public dynamic ActualizarCompromisoCertificacionesArrastre(ActualizarCompromisoArrastreMo actualizarCompromisoArrastreMo)
        {
            return CertificacionCompromisoArrastreBL.ActualizarCompromisoCertificacionesArrastre(actualizarCompromisoArrastreMo);
        }

        [HttpPost("Detalles")]
        public dynamic DetalleCompromisoCertificacionesArrastre(EntradasDetalleCompromisoArrastreMo actualizarCompromisoArrastreMo)
        {
            return CertificacionCompromisoArrastreBL.DetalleCompromisoCertificacionesArrastre(actualizarCompromisoArrastreMo);
        }
    }
}
