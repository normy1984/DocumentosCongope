﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class VerSaldoPartidaController
    {
        [HttpGet]
        public dynamic Get(int nanio, string sPartida)
        {
            return VerSaldoPartidaBL.Listar(nanio, sPartida);
        }
    }
}
