﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class MovimientosCompromisoController : Controller
    {


        /// <summary>
        /// Controlador que llama al objeto de creacion del reporte
        /// </summary>
        /// <param name="movimientosCompromisoMo"></param>
        /// <returns></returns>
        [HttpPost("List")]
        public dynamic CargarListado(MovimientosCompromisoMo movimientosCompromisoMo)
        {
            return MovimientosCompromisoBL.CargarListado(movimientosCompromisoMo);
        }

        /// <summary>
        /// Controlador que llama al objeto de detalle
        /// </summary>
        /// <param name="movimientosCompromisoMo"></param>
        /// <returns></returns>
        [HttpPost("ListDetalle")]
        public dynamic CargarListadoDetalle(DetalleMovimientosCompromisoMo movimientosCompromisoMo)
        {
            return MovimientosCompromisoBL.CargarListadoDetalle(movimientosCompromisoMo);
        }

    }
}
