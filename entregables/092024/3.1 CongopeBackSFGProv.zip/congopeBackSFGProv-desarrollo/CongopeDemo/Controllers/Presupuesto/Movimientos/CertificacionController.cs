﻿using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Tls;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{

    [Route("api/[controller]")]
    [ApiController]

    public class CertificacionController : ControllerBase
    {


        /// <summary>
        /// Actualización de movimientos
        /// </summary>
        /// <param name="mov">Objeto movimiento a actualizar</param>
        /// <returns>Movimiento actualizado</returns>
        [HttpPost]
        public dynamic Post([FromBody] MovimientosPresupuestariosMO mov)
        {
            string sTipoAccion = "INSERTAR";
            return MovimientosPresupuestariosBL.InsertarActualizar_MovimientosPresupuestarios(sTipoAccion, mov);

        }


        /// <summary>
        /// Servicio para liquidar Certificaciones presupuestarias
        /// </summary>
        /// <param name="opCertificacion">Información de certificación y partida</param>
        /// <returns>Infomación de la certificación eliminada</returns>
        [HttpPost("Liquidacion")]
        public dynamic LiquidarCertificacionesPresupuestarias([FromBody] PartidaPresupuestariaDetMO opCertificacion, string accion)
        {
            return CertificacionBL.LiquidarCertificacionesPresupuestarias(opCertificacion, accion);
        }

        [HttpGet]
        public dynamic Get(string codemp, string sigtip , int acutip,  int anio )
        {
            return CertificacionBL.ListarCertificadosConCompromisos(codemp, sigtip, acutip, anio);
        }

        [HttpPost("Aprobacion")]
        public dynamic AprobarCertificacionesPresupuestarias([FromBody] CertificacionAprobacionMO opCertificacion)
        {
            return CertificacionBL.AprobarCertificacionesPresupuestarias(opCertificacion.VarSesion,opCertificacion.sig_tip, opCertificacion.acu_tip);
        }
    }
}
