﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Presupuesto;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProformaPresupuestariaController : ControllerBase  
    {
        [HttpGet]
        public List<ProformaPresupuestariaMO> Get()
        {
            return ProformaPresupuestariaBL.Listar();
        }

        [HttpPut("{emp},{anio},{sig_tip},{acu_tip}")]
        public bool Put([FromBody] Proforma_Presupuestaria_DetalleMO emp)
        {
            return ProformaPresupuestariaBL.Modificar(emp);
        }

    }
}
