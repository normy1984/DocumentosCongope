﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static iText.Signatures.LtvVerification;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientosPresupuestariosController : ControllerBase
    {


        //[HttpGet("SecuencialMovimientos")]
        //public dynamic Get(string empresa, int anio, string tipo)
        //{       
        //    return MovimientosPresupuestariosBL.ObtenerSecuencialMovimientosPresupuestarios(empresa,anio, tipo);
        //}

        /// <summary>
        /// Listar movimientos presupuestarios
        /// </summary>
        /// <param name="tipo">Tipo de Movimiento</param>
        /// <returns>Lista de movimientos</returns>
        [HttpGet]
        public dynamic Get(string tipo, int anio)
        {
            if (tipo.ToUpper() == "N")
                tipo = "";

            return MovimientosPresupuestariosBL.ListarMovimientosPresupuestarios(tipo,anio);
        }

        /// <summary>
        /// Tipo de movimiento por codigo
        /// </summary>
        /// <param name="in_acu_tip">Codigo del Movimiento</param>
        /// <returns>Movimiento por código</returns>
        [HttpGet("{in_acu_tip}")]
        public dynamic Get_Codigo(string in_acu_tip,int anio)
        {
            string[] array = in_acu_tip.Split(' ');

            return MovimientosPresupuestariosBL.ListarMovimientoPresupuestariosCodigoCE(in_acu_tip,anio);
        }


      
        /// <summary>
        /// Funcion post para cargar la informacion de la cabecera del movimiento presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        [HttpPost("ListarMovimientoPresupuestariosCodigo")]
        public dynamic ListarMovimientoPresupuestariosCodigo(MovimientosPresupuestariosCaebeceraMO in_acu_tip)
        {
            
            return MovimientosPresupuestariosBL.ListarMovimientoPresupuestariosCodigo(in_acu_tip);
                   

        }

        /// <summary>
        /// Tipo de movimiento por codigo
        /// </summary>
        /// <param name="in_acu_tip">Codigo del Movimiento</param>
        /// <returns>Movimiento por código</returns>
        [HttpGet("Detalle/{in_acu_tip}")]
        public dynamic Get_Detalle_Codigo(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');
            switch (array[0].ToUpper())
            {
                case Constantes.TipoMovimiento.Certificacion:
                    return MovimientosPresupuestariosBL.ListarDetalleMovimientoPresupuestarioCodigoCE(in_acu_tip);
                    break;
                default:
                    return MovimientosPresupuestariosBL.ListarDetalleMovimientoPresupuestariosCodigo(in_acu_tip);

                    break;
            }

           
        }

        /// <summary>
        /// Tipo de movimiento por codigo
        /// </summary>
        /// <param name="in_acu_tip">Codigo del Movimiento</param>
        /// <returns>Movimiento por código</returns>
        [HttpGet("DetalleCompromiso/{in_acu_tip}")]
        public dynamic Get_Compromiso_Detalle_Codigo(string in_acu_tip)
        {
            return MovimientosPresupuestariosBL.ListarDetalleCompromisoPresupuestariosCodigo(in_acu_tip);

        }

        /// <summary>
        /// Inserción de movimientos
        /// </summary>
        /// <param name="mov">Codigo del movimiento a insertar</param>
        /// <returns>Movimiento insertado</returns>
        [HttpPut("{mov}")]
        public dynamic Put( [FromBody] MovimientosPresupuestariosMO mov)
        {
            string sTipoAccion = "UPDATE";
            return MovimientosPresupuestariosBL.InsertarActualizar_MovimientosPresupuestarios(sTipoAccion, mov);

        }

        /// <summary>
        /// Actualización de movimientos
        /// </summary>
        /// <param name="mov">Objeto movimiento a actualizar</param>
        /// <returns>Movimiento actualizado</returns>
        [HttpPost]
        public dynamic Post( [FromBody] MovimientosPresupuestariosMO mov)
        {
            string sTipoAccion = "INSERTAR";
            return MovimientosPresupuestariosBL.InsertarActualizar_MovimientosPresupuestarios(sTipoAccion, mov);

        }


        [HttpPost("AnulacionCertificacion/")]
        public dynamic PostAnulacion([FromBody] MovimientosPresupuestariosMO mov)
        {
            string sTipoAccion = "ANULAR";
            return MovimientosPresupuestariosBL.Anular_CertificacionPresupuestaria(sTipoAccion, mov);
        }




    }
}
