﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Congope.Empresas.Models.CuentasContables;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EstucturaPlanCuentasController : Controller
    {
        /// <summary>
        /// Mètodo para obtener listado de Plan de Cuentas
        /// </summary>
        /// <returns>Lista de Plan de Cuentas</returns>
        // GET: api/<ValuesController>
        [HttpGet]
        public dynamic Get()
        {
            return EstructuraPlanCuentasBL.ListarEstructuraPlanCuentas();
        }

        /// <summary>
        /// Método para modificar la empresa
        /// </summary>
        /// <param name="planCuenta">Información del plan de cuentas</param>
        /// <returns>true o false segun se haya realizado o no la actualización o inserción</returns>
        // PUT api/<ValuesController>/5
        [HttpPut("{planCuenta}")]
        public dynamic Put(int codigo, [FromBody] EstructuraPlanCuentasMO planCuenta)
        {
            return EstructuraPlanCuentasBL.ModificarEstructuraPlanCuentas(planCuenta);
        }

        /// <summary>
        /// Método para cambiar de estado al plan de cuenta 
        /// </summary>
        /// <param name="planCuenta">Identificación del plan de cuenta</param>
        // DELETE api/<ValuesController>/5
        [HttpDelete("{planCuenta}")]
        public dynamic Delete([FromBody] EstructuraPlanCuentasMO planCuenta)
        {
            return EstructuraPlanCuentasBL.InactivarPlanDeCuentas(planCuenta);
        }
    }
}
