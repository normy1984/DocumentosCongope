﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Mvc;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Congope.Empresas.Controllers.Administracion
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaController : ControllerBase
    {

        /// <summary>
        /// Obtener Empresa por Id
        /// </summary>
        /// <param name="id"> identificacion de la empresa</param>
        /// <returns>Empresa</returns>
        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public dynamic Get(string id)
        {
            return EmpresaDataBL.ObtenerEmpresaCodigo(id);
        }


        [HttpGet("DatosDemograficos/{id}")]
        public dynamic CargarDemograficoCodigo(string id)
        {
            return EmpresaDataBL.CargarDemograficoCodigo(id);
        }


        [HttpGet("TipoEmpleador")]
        public dynamic CargarTipoEmpleador()
        {
            return EmpresaDataBL.CargarTipoEmpleador();
        }


        [HttpGet("EnteSeguridad")]
        public dynamic CargarEnteSeguridad()
        {
            return EmpresaDataBL.CargarEnteSeguridad();
        }

        /// <summary>
        /// Registra una empresa
        /// </summary>
        /// <param name="oEmpresa">Empresa a registrar</param>
        /// <returns>true o False segun se haya realizado o no la inserción</returns>
        // POST api/<ValuesController>
        [HttpPost]
        public dynamic ActualizarInformacionEmpresa([FromForm] EmpresaMO oEmpresa)
        {
            return EmpresaDataBL.ActualizarInformacionEmpresa(oEmpresa);
        }

    }
}
