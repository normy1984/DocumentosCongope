﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class ListaCiuMO
    {
        public string cedruc { get; set; }
        public string descrip { get; set; }
        public string direcci { get; set; }
        public string telefon1 { get; set; }
        public string email1 { get; set; }
        public string grupo { get; set; }
    }
}
