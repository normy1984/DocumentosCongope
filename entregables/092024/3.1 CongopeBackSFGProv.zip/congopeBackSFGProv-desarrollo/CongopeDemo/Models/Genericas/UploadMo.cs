﻿using Congope.Empresas.Data;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace Congope.Empresas.Models.Genericas
{
    public class UploadMo
    {
        public int? anio { get; set; }
        public string? tipo_documento { get; set; }
        public int? codigo_documento { get; set; }
        public string? descripcion { get; set; }
        public int codsistema { get; set; }
        public string? nombrearchivo { get; set; }
    }
}
