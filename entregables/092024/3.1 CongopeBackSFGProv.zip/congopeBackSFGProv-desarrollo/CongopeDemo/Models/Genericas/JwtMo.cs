﻿using Congope.Empresas.Data;
using System.Security.Claims;

namespace Congope.Empresas.Models.Genericas
{
    public class JwtMo
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string Subject { get; set; }
        public int DuracionToken { get; set; }
        public int TiempoMaximoRenovar { get; set; }

        public JwtMo() {
            var vConexion = Conexion.JwtConfiguracion;
            Key = vConexion.JwtKey;
            Issuer = vConexion.JwtIssuer;
            Audience = vConexion.JwtAudience;
            Subject = vConexion.JwtSubject;
            DuracionToken = vConexion.JwtDuracionToken;
            TiempoMaximoRenovar = vConexion.JwtTiempoMaximoRenovar;
        }
        
    }
}
