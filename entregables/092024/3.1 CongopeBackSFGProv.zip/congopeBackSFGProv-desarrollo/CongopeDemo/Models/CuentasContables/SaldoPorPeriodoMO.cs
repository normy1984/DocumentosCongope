﻿namespace Congope.Empresas.Models
{
    public class SaldosPorPeriodoMO
    {
        public string des_per { get; set; }
        public string saldo_inicial { get; set; }
        public string valordb { get; set; }
        public string valorcr { get; set; }
        public string saldo_final { get; set; }

    }
}
