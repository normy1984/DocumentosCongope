﻿namespace Congope.Empresas.Models.CuentasContables
{
 
    public class EstructuraPlanCuentasMO
    {
        public string codigo { get; set; }
        public string niv_est { get; set; }
        public string des_est { get; set; }
        public string lon_est { get; set; }
        public string niv_aso { get; set; }

    }
}
