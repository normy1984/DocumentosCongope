﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class ListaBuscarPartidaMO
    {
        public string partida { get; set; }
        public string nombre { get; set; }
        public decimal por_comprometer_real { get; set; }
    }
}
