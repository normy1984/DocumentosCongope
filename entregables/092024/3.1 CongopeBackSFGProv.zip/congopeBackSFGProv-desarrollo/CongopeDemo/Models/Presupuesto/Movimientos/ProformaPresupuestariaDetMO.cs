﻿namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaDetMO
    {
        public string out_cuenta { get; set; }
        public string out_nom_cue { get; set; }
        public decimal  out_val_deb { get; set; }
        public decimal out_val_cre { get; set; }
        public decimal out_sec_det { get; set; }
        public int out_asociac { get; set; }
    }
}
