﻿namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaCabUnicoMO
    {
        public string out_sig_acu_tip { get; set; }
        public string out_fec_apr { get; set; }
        public string out_des_cab { get; set; }
        public string out_tot_deb { get; set; }
        public string out_nombre_estado { get; set; }
        public string out_estado { get; set; }
    }
}
