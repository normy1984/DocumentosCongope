﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class CertificacionesPresupuestariasMO
    {
        public string cuenta { get; set; }
        public string nom_cue { get; set; }
        public double certificado { get; set; }
        public double val_devengado { get; set; }
        public double saldo { get; set; }
        public double val_dist { get; set; }
        public double out_sec_det { get; set; }
        public int out_acu_tip { get; set; }
        public string out_sig_tip { get; set; }
        public ParamSessionMo VarSesion { get; set; }

    }

    public class CertificacionesCompromisoMO
    {
        public string fec_det { get; set; }
        public int acu_tip_co { get; set; }
        public string partida { get; set; }
        public string nom_cue { get; set; }
        public double valor { get; set; }
       
    }

    public class CertificacionAprobacionMO
    {
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }  
        public ParamSessionMo VarSesion { get; set; }

    }
}
