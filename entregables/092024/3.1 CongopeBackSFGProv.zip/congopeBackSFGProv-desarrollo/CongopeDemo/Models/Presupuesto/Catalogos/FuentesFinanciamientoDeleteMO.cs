﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Npgsql;

namespace Congope.Empresas.Models.Presupuesto.Catalogos
{
    public class FuentesFinanciamientoDeleteMO
    {
        public string ffn_id { get; set; }

        public int anio { get; set; }
        public string codemp { get; set; }

    }
}