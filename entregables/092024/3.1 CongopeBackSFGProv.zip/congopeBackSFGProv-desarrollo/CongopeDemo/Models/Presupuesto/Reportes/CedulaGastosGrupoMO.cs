﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class CedulaGastosGrupoMO
    {
        public decimal grupo { get; set; }
        public string descripcion { get; set; }
        public decimal asig_ini { get; set; }
        public decimal reformas { get; set; }
        public decimal codificado { get; set; }
        public decimal comprometido { get; set; }
        public decimal devengado { get; set; }
        public decimal por_comprometer { get; set; }
        public decimal por_devengar { get; set; }
        public decimal pagado { get; set; }
        public decimal porcen_eje { get; set; }
        public decimal total_asig_ini { get; set; }
        public decimal total_reformas { get; set; }
        public decimal total_codificado { get; set; }
        public decimal total_comprometido { get; set; }
        public decimal total_devengado { get; set; }
        public decimal total_por_comprometer { get; set; }
        public decimal total_por_devengar { get; set; }
        public decimal total_pagado { get; set; }
    }
}
