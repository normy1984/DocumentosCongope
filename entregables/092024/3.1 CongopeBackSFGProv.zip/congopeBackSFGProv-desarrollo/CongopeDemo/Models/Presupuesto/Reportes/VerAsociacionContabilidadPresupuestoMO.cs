﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class VerAsociacionContabilidadPresupuestoMO
    {
        public string cuentac { get; set; }
        public string nombre_cta { get; set; }
        public string cuentap { get; set; }
        public string nombre_prt { get; set; }
    }
}
