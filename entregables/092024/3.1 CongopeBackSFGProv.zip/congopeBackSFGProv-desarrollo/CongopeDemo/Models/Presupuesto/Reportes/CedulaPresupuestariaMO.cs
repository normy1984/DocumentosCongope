﻿namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class CedulaPresupuestariaMO
    {
        public string ult_cue { get; set; }
        public string partida { get; set; }
        public string nombre { get; set; }
        public string niv_cue { get; set; }
        public float asig_ini { get; set; }
        public float reformas { get; set; }
        public float codificado { get; set; }
        public float certificado { get; set; }
        public float certificado_real { get; set; }
        public float comprometido { get; set; }
        public float devengado { get; set; }
        public float por_comprometer { get; set; }
        public float por_comprometer_real { get; set; }
        public float por_devengar { get; set; }
        public float comprometido_mes { get; set; }
        public float devengado_mes { get; set; }
        public float recaudado { get; set; }
        public float pagado { get; set; }
        public float anticipo { get; set; }
        public float porcencom { get; set; }
        public float porcendev { get; set; }
        public string niv_ug { get; set; }
    }
}
