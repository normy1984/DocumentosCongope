﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class MovimientoPorPartidaMO
    {
        public string fec_det { get; set; }
        public string sig_acu_tip { get; set; }
        public string des_cab { get; set; }
        public decimal inicial { get; set; }
        public decimal reforma { get; set; }
        public decimal codificado { get; set; }
        public decimal certificado { get; set; }
        public decimal comprometido { get; set; }
        public decimal devengado { get; set; }
        public decimal por_comprometer { get; set; }
        public decimal por_devengar { get; set; }
        public string num_com { get; set; }
        public string partida { get; set; }
        public string nombre_partida { get; set; } 

    }
}
