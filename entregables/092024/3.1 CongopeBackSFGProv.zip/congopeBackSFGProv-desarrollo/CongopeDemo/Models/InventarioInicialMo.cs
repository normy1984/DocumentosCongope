﻿namespace Congope.Empresas.Models
{
    public class InventarioInicialMo
    {
        public string cuenta { get; set; }
        public string nom_cue { get; set; }
        public int cantidb { get; set; }
        public float costo103 { get; set; }
        public float total { get; set; }
        public int sec_det { get; set; }
        
    }

    public class InventarioInicialMo_Documento
    {
        public string departamento { get; set; }
        public string responsable { get; set; }
        public string n_estado { get; set; }
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }
        public DateOnly fec_asi { get; set; }
        public int bodrec02 { get; set; }

    }
}
