﻿namespace Congope.Empresas.Models
{
    public class EjercicioFiscalMO
    {
        public int id_per { get; set; }
        public string des_per { get; set; }
        public string fec_ini { get; set;}
        public string fec_fin { get; set; }
        public bool estado { get; set; }

    }
}
