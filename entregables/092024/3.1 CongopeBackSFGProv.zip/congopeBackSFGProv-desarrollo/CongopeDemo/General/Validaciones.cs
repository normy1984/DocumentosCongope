﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;

namespace Congope.Empresas.General
{
    public static class Validaciones
    {
        /// <summary>
        /// Método que valida que un campo no esté vacío
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string Message) ValidarCampoVacio(string campo, string nombreCampo)
        {
            if (string.IsNullOrEmpty(campo))
            {
                return (false, $"El campo '{nombreCampo}' no puede estar vacío.");
            }
            return (true, string.Empty);
        }

        /// <summary>
        /// Método que valida la longitud de un campo (se establece longitud mínima y máxima)
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string Message) ValidarLongitudCampo(string campo, string nombreCampo, int minLength, int maxLength)
        {
            if (campo.Length < minLength || campo.Length > maxLength)
            {
                return (false, $"El campo '{nombreCampo}' debe tener entre {minLength} y {maxLength} caracteres.");
            }
            return (true, string.Empty);
        }

        /// <summary>
        /// Método que valida que un campo contenga sólo números
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string Message) ValidarSoloNumerosCampo(string campo, string nombreCampo)
        {
            if (!campo.All(char.IsDigit))
            {
                return (false, $"El campo '{nombreCampo}' solo puede contener números.");
            }
            return (true, string.Empty);
        }

        /// <summary>
        /// Método que agrupa las validaciones para el PUT
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string[] Messages) ValidarFuentesFinanciamientoPUT(FuentesFinanciamientoMO fuente)
        {
            var messages = new List<string>();

            var nombreValidation = ValidarCampoVacio(fuente.ffn_nombre, "ffn_nombre");
            var ctaPagoValidation = ValidarCampoVacio(fuente.ffn_ctapago, "ffn_ctapago");
            var idValidation = ValidarLongitudCampo(fuente.ffn_id, "ffn_id", 1, 3);

            if (!nombreValidation.IsValid)
            {
                messages.Add(nombreValidation.Message);
            }
            if (!ctaPagoValidation.IsValid)
            {
                messages.Add(ctaPagoValidation.Message);
            }
            if (!idValidation.IsValid)
            {
                messages.Add(idValidation.Message);
            }

            return (messages.Count == 0, messages.ToArray());
        }


        /// <summary>
        /// Método que agrupa las validaciones para el POST
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string[] Messages) ValidarFuentesFinanciamientoPOST(FuentesFinanciamientoMO fuente)
        {
            var messages = new List<string>();

            var idCampoVacioValidation = ValidarCampoVacio(fuente.ffn_id, "ffn_id");
            var nombreValidation = ValidarCampoVacio(fuente.ffn_nombre, "ffn_nombre");
            var ctaPagoValidation = ValidarCampoVacio(fuente.ffn_ctapago, "ffn_ctapago");
            var idLongitudValidation = ValidarLongitudCampo(fuente.ffn_id, "ffn_id", 1, 3);
            var idNumerosValidation = ValidarSoloNumerosCampo(fuente.ffn_id, "ffn_id");

            if (!idCampoVacioValidation.IsValid)
            {
                messages.Add(idCampoVacioValidation.Message);
            }
            if (!nombreValidation.IsValid)
            {
                messages.Add(nombreValidation.Message);
            }
            if (!ctaPagoValidation.IsValid)
            {
                messages.Add(ctaPagoValidation.Message);
            }
            if (!idLongitudValidation.IsValid)
            {
                messages.Add(idLongitudValidation.Message);
            }
            if (!idNumerosValidation.IsValid)
            {
                messages.Add(idNumerosValidation.Message);
            }

            // Validar si el ffn_id ya está registrado
            var validacionCreacion = FuentesFinanciamientoBL.ValidarCrearFuenteFinanciamiento(fuente.ffn_id);

            if (validacionCreacion.success)
            {
                messages.Add("El ffn_id ya está registrado en la base de datos.");
            }


            return (messages.Count == 0, messages.ToArray());
        }


        /// <summary>
        /// Método que agrupa las validaciones para el DELETE
        /// </summary>       
        /// <returns></returns>
        public static (bool IsValid, string[] Messages) ValidarFuentesFinanciamientoDELETE(string ffn_id, string codemp, int anio)
        {
            var messages = new List<string>();

            var idCampoVacioValidation = ValidarCampoVacio(ffn_id, "ffn_id");
            var idLongitudValidation = ValidarLongitudCampo(ffn_id, "ffn_id", 1, 3);
            var idNumerosValidation = ValidarSoloNumerosCampo(ffn_id, "ffn_id");
            var codempCampoVacioValidation = ValidarCampoVacio(codemp, "codemp");
            var anioCampoVacioValidation = ValidarCampoVacio(anio.ToString(), "anio");
            var anioLongitudValidation = ValidarLongitudCampo(anio.ToString(), "anio", 4, 4);

            // Podría incluirse una validación para codemp, debería existir este código en la tabla "coempre"


            if (!idCampoVacioValidation.IsValid)
            {
                messages.Add(idCampoVacioValidation.Message);
            }
            if (!idLongitudValidation.IsValid)
            {
                messages.Add(idLongitudValidation.Message);
            }
            if (!idNumerosValidation.IsValid)
            {
                messages.Add(idNumerosValidation.Message);
            }
            if (!anioCampoVacioValidation.IsValid)
            {
                messages.Add(anioCampoVacioValidation.Message);
            }
            if (!anioLongitudValidation.IsValid)
            {
                messages.Add(anioLongitudValidation.Message);
            }
            if (!codempCampoVacioValidation.IsValid)
            {
                messages.Add(codempCampoVacioValidation.Message);
            }

            var validacionEliminacion = FuentesFinanciamientoBL.ValidarEliminacionFuenteFinanciamiento(ffn_id, codemp, anio);

            // Si devuelve true (existen registros enlazados con partidas en prplacta), entonces no se puede eliminar
            if (validacionEliminacion.success)
            {
                messages.Add("No se puede eliminar la fuente de financiamiento porque está enlazada con partidas.");
            }

            return (messages.Count == 0, messages.ToArray());
        }

    }
}