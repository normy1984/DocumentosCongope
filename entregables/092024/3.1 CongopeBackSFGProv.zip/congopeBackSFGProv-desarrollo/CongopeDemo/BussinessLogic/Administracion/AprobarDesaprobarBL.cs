﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Administracion;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Administracion
{
    public class AprobarDesaprobarBL
    {
        /// <summary>
        /// Funcion que devuelve los permisos para aprobar o desaprobar
        /// </summary>
        /// <param name="vAprobarDesaprobarMo"></param>
        /// <returns></returns>
        public static dynamic AprobarDesaprobar(AprobarDesaprobarMo vAprobarDesaprobarMo)
        {
            var cmd = new NpgsqlCommand();
            var sql = @"SELECT 
                            *
                        FROM     
                            public.sp_SelectApruebaDesaprueba
                        (
                            @codUsu,@anio,@codemp,@SigTip
                        )    
                            ;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Integer, vAprobarDesaprobarMo.VarSesion.codUsu);
            cmd.Parameters.AddWithValue("@SigTip", NpgsqlDbType.Varchar, vAprobarDesaprobarMo.SigTip);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Varchar, vAprobarDesaprobarMo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Numeric, vAprobarDesaprobarMo.VarSesion.Anio);
            return Exec_sql.cargarDatosModel<VariablesAprobarDesaprobarMo>(cmd);
        }
    }
}
