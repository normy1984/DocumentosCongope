﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;
using iText.StyledXmlParser.Jsoup.Select;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;
using System.Data;



namespace Congope.Empresas.BussinessLogic.Administracion
{
    /// <summary>
    /// Clase que contiene operaciones Crud para Empresa
    /// </summary>
    public class EmpresaDataBL
    {
        /// <summary>
        /// Método para registrar una empresa
        /// </summary>
        /// <param name="emp">Información de empresa</param>
        /// <returns>bool si se realizó la inserción de la empresa</returns>
        public static bool Registrar(EmpresaMO emp)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spi_empresa", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@nom_emp", emp.nom_emp);
                cmd.Parameters.AddWithValue("@cod_emp", emp.codemp);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {
                    SeguridadBL.WriteErrorLog(e);
                    return false;
                }
            }
        }


        /// <summary>
        /// Método para ver la lista de Empresas
        /// </summary>
        /// <returns>Lista de Empresas</returns>
        public static List<EmpresaMO> Listar()
        {

            List<EmpresaMO> oListaEmpresas = new List<EmpresaMO>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = "select * from vis_empresa";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaEmpresas.Add(new EmpresaMO()
                            {
                                codemp = dr["codemp"].ToString() ?? string.Empty,
                                nom_emp = dr[1].ToString() ?? string.Empty,
                                ruc_emp = dr[2].ToString() ?? string.Empty,
                                dir_emp = dr[3].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return oListaEmpresas;
                }
                catch (Exception e)
                {
                    SeguridadBL.WriteErrorLog(e);
                    return oListaEmpresas;
                }

            }

        }



        /// <summary>
        ///Para obtener una empresa en particular.
        /// </summary>
        /// <param name="codemp"> Codigo de la empresa</param>
        /// <returns>Retorna los datos de la empresa encontrada</returns>
        public static dynamic ObtenerEmpresaCodigo(string codemp)
        {
            var cmd = new NpgsqlCommand();
            string sql = @"select * from public.coempre  
                            where codemp = @codemp;";
            cmd.Parameters.AddWithValue("@codemp", codemp);
            cmd.CommandText = sql;
            var DatosEmpresa = Exec_sql.cargarDatosModel<EmpresaMO>(cmd);
            DatosEmpresa.result[0].ImagenBase64 = VerArchivosRepositorio(DatosEmpresa.result[0].pathlogo);
            return DatosEmpresa;
        }

        /// <summary>
        /// Modica una empresa
        /// </summary>
        /// <param name="emp"> Datos de la empresa</param>
        /// <returns>bool  si se realizo la modificacion</returns>
        public static dynamic Modificar(EmpresaMO DetalleMo)
        {


            NpgsqlCommand cmd = new NpgsqlCommand("spu_empresa");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, DetalleMo.codemp);
            cmd.Parameters.AddWithValue("@in_nom_emp", NpgsqlDbType.Char, DetalleMo.nom_emp);
            cmd.Parameters.AddWithValue("@in_ruc_emp", NpgsqlDbType.Char, DetalleMo.ruc_emp);
            cmd.Parameters.AddWithValue("@in_dir_emp", NpgsqlDbType.Char, DetalleMo.dir_emp);
            cmd.Parameters.AddWithValue("@in_tel1_emp", NpgsqlDbType.Char, DetalleMo.tel1_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_tel2_emp", NpgsqlDbType.Char, DetalleMo.tel2_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_fax1_emp", NpgsqlDbType.Char, DetalleMo.fax1_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_fax2_emp", NpgsqlDbType.Char, DetalleMo.fax2_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_email1", NpgsqlDbType.Char, DetalleMo.email1);
            cmd.Parameters.AddWithValue("@in_email2", NpgsqlDbType.Varchar, DetalleMo.email2 ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_rep_emp", NpgsqlDbType.Char, DetalleMo.rep_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_rep_ruc", NpgsqlDbType.Char, DetalleMo.rep_ruc ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_cont_emp", NpgsqlDbType.Char, DetalleMo.cont_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_cont_ruc", NpgsqlDbType.Char, DetalleMo.cont_ruc ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Convert.ToString(DetalleMo.codUsu));
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, DetalleMo.estado);
            cmd.Parameters.AddWithValue("@in_dirfinan", NpgsqlDbType.Char, DetalleMo.dirfinan ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_diradmin", NpgsqlDbType.Char, DetalleMo.diradmin ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_dirfoto", NpgsqlDbType.Char, DetalleMo.dirfoto ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_serieret", NpgsqlDbType.Char, DetalleMo.serieret ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_autoret", NpgsqlDbType.Char, DetalleMo.autoret ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_ciudad", NpgsqlDbType.Char, DetalleMo.ciudad ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_pathlogo", NpgsqlDbType.Varchar, DetalleMo.pathlogo ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_tipodato", NpgsqlDbType.Numeric, DetalleMo.tipodato);
            cmd.Parameters.AddWithValue("@in_nodeviva", NpgsqlDbType.Numeric, DetalleMo.nodeviva);
            cmd.Parameters.AddWithValue("@in_t_factura", NpgsqlDbType.Numeric, DetalleMo.t_factura);
            cmd.Parameters.AddWithValue("@in_subempre", NpgsqlDbType.Varchar, DetalleMo.subempre ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_color01", NpgsqlDbType.Numeric, DetalleMo.color01);
            cmd.Parameters.AddWithValue("@in_color02", NpgsqlDbType.Numeric, DetalleMo.color02);
            cmd.Parameters.AddWithValue("@in_tipoemp", NpgsqlDbType.Numeric, DetalleMo.tipoemp);
            cmd.Parameters.AddWithValue("@in_path_imag_ser", NpgsqlDbType.Varchar, DetalleMo.path_imag_ser ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_varios_co", NpgsqlDbType.Numeric, DetalleMo.varios_co);
            cmd.Parameters.AddWithValue("@in_path_archielec", NpgsqlDbType.Varchar, DetalleMo.path_archielec ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_nomcomercial", NpgsqlDbType.Varchar, DetalleMo.nomcomercial ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_contrib_espe", NpgsqlDbType.Varchar, DetalleMo.contrib_espe ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_obligado_conta", NpgsqlDbType.Numeric, DetalleMo.obligado_conta);
            cmd.Parameters.AddWithValue("@in_provincia", NpgsqlDbType.Numeric, DetalleMo.provincia);
            cmd.Parameters.AddWithValue("@in_path_archielec_apr", NpgsqlDbType.Varchar, DetalleMo.path_archielec_apr ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_actnrocr", NpgsqlDbType.Numeric, DetalleMo.actnrocr);
            cmd.Parameters.AddWithValue("@in_path_docum", NpgsqlDbType.Varchar, DetalleMo.path_docum ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_version_fecha", NpgsqlDbType.Char, DetalleMo.version_fecha ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_dir_web_presu", NpgsqlDbType.Char, DetalleMo.dir_web_presu ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_dfin_emp", NpgsqlDbType.Char, DetalleMo.dfin_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_dfin_ruc", NpgsqlDbType.Char, DetalleMo.dfin_ruc ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_path_cpbtesegreso", NpgsqlDbType.Char, DetalleMo.path_cpbtesegreso ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_teso_emp", NpgsqlDbType.Char, DetalleMo.teso_emp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_teso_ruc", NpgsqlDbType.Char, DetalleMo.teso_ruc ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_aut_liq_comp", NpgsqlDbType.Char, DetalleMo.aut_liq_comp ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_region", NpgsqlDbType.Numeric, DetalleMo.region);
            cmd.Parameters.AddWithValue("@in_dir_web_viaticos", NpgsqlDbType.Char, DetalleMo.dir_web_viaticos ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_dir_pagina_web", NpgsqlDbType.Char, DetalleMo.dir_pagina_web ?? string.Empty);
            cmd.Parameters.AddWithValue("@in_tipoemplea", NpgsqlDbType.Numeric, DetalleMo.tipoemplea);
            cmd.Parameters.AddWithValue("@in_ente_ss", NpgsqlDbType.Numeric, DetalleMo.ente_ss);
            return Exec_sql.EjecutarQuerySP(cmd);


        }


        public static dynamic ActualizarInformacionEmpresa(EmpresaMO oEmpresaMO)
        {
            try
            {
                if (oEmpresaMO.uploadFile != null && oEmpresaMO.uploadFile.Length != 0)
                {
                    // Ruta donde se guardarán las imágenes
                    var uploadsFolder = Path.Combine(Environment.CurrentDirectory, "assets", "images");

                    // Crear el directorio si no existe
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    // Obtener el nombre del archivo
                    var fileName = Path.GetFileName(oEmpresaMO.uploadFile.FileName);

                    // Crear la ruta completa para guardar el archivo
                    var filePath = Path.Combine(uploadsFolder, fileName);

                    // Guardar el archivo
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        oEmpresaMO.uploadFile.CopyTo(fileStream);
                    }

                    // Asignar la ruta del archivo al campo correspondiente
                    oEmpresaMO.pathlogo = fileName;
                }

                // Llamar a la función para modificar la información de la empresa
                return Modificar(oEmpresaMO);
            }
            catch (Exception ex)
            {
                // Escribir el error en el log
                SeguridadBL.WriteErrorLog(ex);

                // Devolver un resultado indicando el error
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Mètodo para eliminar una empresa
        /// </summary>
        /// <param name="id">Identificación de la empresa</param>
        /// <returns>true o false si se eliminó la empresa</returns>
        public static bool Eliminar(int id)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spd_eliminar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@codemp", id);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {

                    SeguridadBL.WriteErrorLog(e);
                    return false;
                }
            }
        }

        public static dynamic CargarDemograficoCodigo(string sCodigo)
        {
            var cmd = new NpgsqlCommand();
            string sql = @"select split_part(codigo, '.', 2)::int as codigo
                                    , nombre from public.siprocan s 
                                    where s.codigo_p = @codigo_p
                                    and s.activo = 1 order by 1;";
            cmd.Parameters.AddWithValue("@codigo_p", sCodigo);
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic CargarTipoEmpleador()
        {
            var cmd = new NpgsqlCommand();
            string sql = @"Select * from tipo_empleador order by tem_id;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic CargarEnteSeguridad()
        {
            var cmd = new NpgsqlCommand();
            string sql = @"Select* from ente_seguridad_s order by ess_id;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        protected static string VerArchivosRepositorio(string pathArchivo)
        {
            try
            {
                // Combina la ruta del repositorio con el nombre del archivo
                var filePath = Path.Combine(Environment.CurrentDirectory, "assets/images/" + pathArchivo);
                if (!File.Exists(filePath))
                {
                    filePath = Path.Combine(Environment.CurrentDirectory, "assets/images/" + Conexion.ErrorImagen);
                }

                // Verifica si el archivo existe
                if (File.Exists(filePath))
                {
                    // Lee el contenido del archivo como bytes
                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // Convierte los bytes a Base64
                    string base64String = Convert.ToBase64String(fileBytes);

                    return base64String;
                }
                else
                {
                    throw new Exception("Fallo la carga del logo de la empresa.");

                }
            }

            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return ex.Message;

            }


        }

    }

}
