﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.CuentasContables;
using Npgsql;
using System.Data;

namespace Congope.Empresas.BussinessLogic
{
    public class EstructuraPlanCuentasBL
    {
        /// <summary>
        /// Método para lista Estructuras de Plan de Cuentas
        /// </summary>
        /// <returns>Retorna lista de estructuras de Plan de Cuentas</returns>
        public static dynamic ListarEstructuraPlanCuentas()
        {
            string codemp = Constantes.General.Empresa;

            List<EstructuraPlanCuentasMO> oListaEstructuraPlanCuentas = new List<EstructuraPlanCuentasMO>();
            string sql = "select * from sps_estructura_plan_cuentas('" + codemp + "')";

            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            return Exec_sql.cargarDatosModel<EstructuraPlanCuentasMO>(cmd);
        }

        /// <summary>
        /// Mètodo para insertar y modificar una estructura de cuentas
        /// </summary>
        /// <param name="estructuraPlanCuenta">Inf del Plan de cuenta</param>
        /// <returns>Resultado de la insercion o actualización </returns>
        public static dynamic ModificarEstructuraPlanCuentas(EstructuraPlanCuentasMO estructuraPlanCuenta)
        {
            int in_codigo = Int32.Parse(estructuraPlanCuenta.codigo);
            int in_nivel = Int32.Parse(estructuraPlanCuenta.niv_est);
            string in_des_est = estructuraPlanCuenta.des_est;
            int in_lon_est = Int32.Parse(estructuraPlanCuenta.lon_est);
            string in_codemp = Constantes.General.Empresa;
            int in_niv_aso = Int32.Parse(estructuraPlanCuenta.niv_aso);
            List<EstructuraPlanCuentasMO> oListaEstructuraPlanCuentas = new List<EstructuraPlanCuentasMO>();

            string sql = "spiu_estructura_control_plan";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codigo", in_codigo);
            cmd.Parameters.AddWithValue("@in_nivel", in_nivel);
            cmd.Parameters.AddWithValue("@in_des_est", in_des_est);
            cmd.Parameters.AddWithValue("@in_lon_est", in_lon_est);
            cmd.Parameters.AddWithValue("@in_codemp", in_codemp);
            cmd.Parameters.AddWithValue("@in_niv_aso", in_niv_aso);

            return Exec_sql.EjecutarQuerySP(cmd);
        }

        /// <summary>
        /// Mètodo para inactivar plan de cuentas
        /// </summary>
        /// <param name="estructuraPlanCuenta"></param>
        /// <returns>Resultado de la actualización</returns>
        public static dynamic InactivarPlanDeCuentas(EstructuraPlanCuentasMO estructuraPlanCuenta)
        {
            string sql = "spd_plan_cuentas";

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_niv_est", Int32.Parse(estructuraPlanCuenta.niv_est));

            return Exec_sql.EjecutarQuerySP(cmd);
        }
    }
}
