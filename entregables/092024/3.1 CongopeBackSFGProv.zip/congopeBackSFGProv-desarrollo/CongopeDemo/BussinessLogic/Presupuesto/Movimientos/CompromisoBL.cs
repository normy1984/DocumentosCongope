﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using iText.Html2pdf.Attach.Wrapelement;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class CompromisoBL
    {


        public static dynamic ListarCompromisosPresupuestarios(MovimientosPresupuestariosCaebeceraMO tipo)
        {
            string sql = "select * from sps_movimientos_presupuestarios(@in_codemp,@in_anio,@in_codigo)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Varchar, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_codigo", NpgsqlDbType.Varchar, tipo.siglas_num);
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);

        }

        /// <summary>
        /// Funcion para listar los compromisos por codigo o un grupo de codigos concatenado por comas 
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        public static dynamic ListarDetalleCompromisoCertificadoCodigo(AnularCompromisoCabeceraMo acu_tip)
        {
            if (acu_tip.liquidar == 1) // ACA SE AGREGO ESTA INFORMACION PARA LOS DUPLICADOS
            {
                using (var cmdLiquidar = new NpgsqlCommand())
                {
                    string sql_duplicado = $@"
                           select * from sps_certificado_duplicado_acu_tip(@acu_tip,@anio,@codemp);";
                    cmdLiquidar.CommandText = sql_duplicado;
                    cmdLiquidar.Parameters.AddWithValue("@codemp", NpgsqlDbType.Char, acu_tip.VarSesion.CodEmp);
                    cmdLiquidar.Parameters.AddWithValue("@anio", acu_tip.VarSesion.Anio);
                    cmdLiquidar.Parameters.AddWithValue("@acu_tip", NpgsqlDbType.Integer, Convert.ToInt32(acu_tip.siglas_num));

                    var retorno = Exec_sql.cargarDatosJson(cmdLiquidar);

                    retorno = JsonConvert.DeserializeObject(retorno.result.ToString());
                    acu_tip.siglas_num = retorno[0]["cert_acu_tip"].Value.ToString();
                }
            }

            using (var cmd = new NpgsqlCommand())
            {
                var from_tabla = acu_tip.liquidar == 2 ? "public.sps_prdetmovlistarcertificados_compromiso" : "public.sps_prdetmovlistarcertificados";

                string sql = $@"
                           SELECT 
                            out_cuenta as cuenta, 
                            out_certificacion as certificacion, 
                            out_nom_cue as nom_cue, 
                            out_val_cre as val_cre, 
                            out_val_deb as val_deb, 
                            out_val_sal as val_sal, 
                            out_asociac as asociac, 
                            out_estado as estado, 
                            out_periodo as periodo, 
                            out_sec_det as sec_det, 
                            out_valor_maximo as valor_maximo
                            from {from_tabla}
                            (
                             @codemp,
                             @anio,
                             @acu_tip
                            );";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Char, acu_tip.VarSesion.CodEmp);
                cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, acu_tip.VarSesion.Anio);
                cmd.Parameters.AddWithValue("@acu_tip", NpgsqlDbType.Varchar, acu_tip.siglas_num.ToString()); // Asignar valores a los parámetros dinámicos

                return Exec_sql.cargarDatosJson(cmd);
            }

        }
        /// <summary>
        /// Listar los elementos de la cabecera por codigos
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        public static dynamic ListarCebeceraNuevoCompromisoCertificadoCodigo(MovimientosPresupuestariosCaebeceraMO acu_tip)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"
                         SELECT  
                         'CO -1' as siglasnum,
                         current_date as fec_asi,
                         current_date as fec_apr,
                         0 as valor_contrato,
                         '' as cod_proceso,
                         'CE' as sig_tipce,
                         out_acu_tipce as acu_tipce,
                         out_descripcion as des_cab, 
                         out_comprobante as num_com, 
                         out_departamento as departam, 
                         out_responsable as solicita,
                         out_departamento_desc as departam_desc, 
                         out_responsable_desc as solicita_desc 
                         from public.sps_prdetmovnuevocompromisocertificacion(
                         @codemp, 
                         @anio, 
                         @acu_tip);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Char, acu_tip.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@anio", acu_tip.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@acu_tip", NpgsqlDbType.Varchar, acu_tip.siglas_num);

            return Exec_sql.cargarDatosJson(cmd);

        }



        /// <summary>
        /// Insertar y actualizar todos los registros de la cabecera prcabmov
        /// </summary>
        /// <param name="oCompromisoCabecera"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_CabeceraCompromiso(CompromisoCabeceraMo oCompromisoCabecera)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_prcabmov
                            (
                             @in_codemp, 
                             @in_anio, 
                             @in_sig_tip,
                             @in_acu_tip, 
                             @in_num_com, 
                             @in_des_cab, 
                            @in_tot_deb, 
                            @in_tot_cre, 
                            @in_totinid, 
                            @in_totinic, 
                            @in_fec_asi, 
                            @in_fec_apr, 
                            @in_fec_anu, 
                            @in_cre_por, 
                            @in_estado, 
                            @in_periodo, 
                            @in_nropagos, 
                            @in_pagosre, 
                            @in_incremen, 
                            @in_comprom, 
                            @in_sig_tip1, 
                            @in_acu_tip1, 
                            @in_estadono, 
                            @in_liquida, 
                            @in_departam, 
                            @in_solicita, 
                            @in_cedruc, 
                            @in_tipopro, 
                            @in_retfte, 
                            @in_retiva, 
                            @in_cur, 
                            @in_pagado, 
                            @in_recaudad, 
                            @in_sig_tipce, 
                            @in_acu_tipce, 
                            @in_cod_proceso, 
                            @in_arrastre, 
                            @in_tipo_contrato, 
                            @in_admin_contrato, 
                            @in_valor_contrato, 
                            @in_observacion, 
                            @in_desagrupar);
                             ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, oCompromisoCabecera.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, oCompromisoCabecera.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, oCompromisoCabecera.sessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, oCompromisoCabecera.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, oCompromisoCabecera.acu_tip);
            cmd.Parameters.AddWithValue("@in_num_com", NpgsqlDbType.Char, oCompromisoCabecera.num_com);
            cmd.Parameters.AddWithValue("@in_des_cab", NpgsqlDbType.Varchar, oCompromisoCabecera.des_cab);
            cmd.Parameters.AddWithValue("@in_tot_deb", NpgsqlDbType.Double, oCompromisoCabecera.tot_deb);
            cmd.Parameters.AddWithValue("@in_tot_cre", NpgsqlDbType.Double, oCompromisoCabecera.tot_cre);
            cmd.Parameters.AddWithValue("@in_totinid", NpgsqlDbType.Double, oCompromisoCabecera.totinid);
            cmd.Parameters.AddWithValue("@in_totinic", NpgsqlDbType.Double, oCompromisoCabecera.totinic);
            cmd.Parameters.AddWithValue("@in_fec_asi", NpgsqlDbType.Char, oCompromisoCabecera.fec_asi);
            cmd.Parameters.AddWithValue("@in_fec_apr", NpgsqlDbType.Char, oCompromisoCabecera.fec_apr);
            cmd.Parameters.AddWithValue("@in_fec_anu", NpgsqlDbType.Char, oCompromisoCabecera.fec_anu);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, oCompromisoCabecera.estado);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, oCompromisoCabecera.periodo);
            cmd.Parameters.AddWithValue("@in_nropagos", NpgsqlDbType.Smallint, oCompromisoCabecera.nropagos);
            cmd.Parameters.AddWithValue("@in_pagosre", NpgsqlDbType.Smallint, oCompromisoCabecera.pagosre);
            cmd.Parameters.AddWithValue("@in_incremen", NpgsqlDbType.Smallint, oCompromisoCabecera.incremen);
            cmd.Parameters.AddWithValue("@in_comprom", NpgsqlDbType.Double, oCompromisoCabecera.comprom);
            cmd.Parameters.AddWithValue("@in_sig_tip1", NpgsqlDbType.Char, oCompromisoCabecera.sig_tip1);
            cmd.Parameters.AddWithValue("@in_acu_tip1", NpgsqlDbType.Double, oCompromisoCabecera.acu_tip1);
            cmd.Parameters.AddWithValue("@in_estadono", NpgsqlDbType.Smallint, oCompromisoCabecera.estadono);
            cmd.Parameters.AddWithValue("@in_liquida", NpgsqlDbType.Smallint, oCompromisoCabecera.liquida);
            cmd.Parameters.AddWithValue("@in_departam", NpgsqlDbType.Smallint, oCompromisoCabecera.departam);
            cmd.Parameters.AddWithValue("@in_solicita", NpgsqlDbType.Smallint, oCompromisoCabecera.solicita);
            cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, oCompromisoCabecera.cedruc);
            cmd.Parameters.AddWithValue("@in_tipopro", NpgsqlDbType.Smallint, oCompromisoCabecera.tipopro);
            cmd.Parameters.AddWithValue("@in_retfte", NpgsqlDbType.Smallint, oCompromisoCabecera.retfte);
            cmd.Parameters.AddWithValue("@in_retiva", NpgsqlDbType.Smallint, oCompromisoCabecera.retiva);
            cmd.Parameters.AddWithValue("@in_cur", NpgsqlDbType.Char, oCompromisoCabecera.cur);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, oCompromisoCabecera.pagado);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, oCompromisoCabecera.recaudad);
            cmd.Parameters.AddWithValue("@in_sig_tipce", NpgsqlDbType.Char, oCompromisoCabecera.sig_tipce);
            cmd.Parameters.AddWithValue("@in_acu_tipce", NpgsqlDbType.Numeric, oCompromisoCabecera.acu_tipce);
            cmd.Parameters.AddWithValue("@in_cod_proceso", NpgsqlDbType.Char, oCompromisoCabecera.cod_proceso);
            cmd.Parameters.AddWithValue("@in_arrastre", NpgsqlDbType.Numeric, oCompromisoCabecera.arrastre);
            cmd.Parameters.AddWithValue("@in_tipo_contrato", NpgsqlDbType.Numeric, oCompromisoCabecera.tipo_contrato);
            cmd.Parameters.AddWithValue("@in_admin_contrato", NpgsqlDbType.Char, oCompromisoCabecera.admin_contrato);
            cmd.Parameters.AddWithValue("@in_valor_contrato", NpgsqlDbType.Numeric, oCompromisoCabecera.valor_contrato);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, oCompromisoCabecera.observacion);
            cmd.Parameters.AddWithValue("@in_desagrupar", NpgsqlDbType.Numeric, oCompromisoCabecera.desagrupar);



            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Insertar y actualizar los detalles prdetmov
        /// </summary>
        /// <param name="oCompromisoDetalleMo"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_DetalleCompromiso(CompromisoDetalleMo oCompromisoDetalleMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            * from
                            public.spiu_prdetmovcompromiso
                                (@in_codemp,
                                @in_anio,
                                @in_sig_tip,
                                @in_acu_tip,
                                @in_sec_det,
                                @in_cuenta,
                                @in_val_deb,
                                @in_val_cre,
                                @in_fec_det,
                                @in_cod_cli,
                                @in_fec_pos,
                                @in_nroctac,
                                @in_nro_che,
                                @in_tip_com,
                                @in_cre_por,
                                @in_des_det,
                                @in_estado,
                                @in_periodo,
                                @in_factura,
                                @in_asociac,
                                @in_devengad,
                                @in_saldo,
                                @in_pagado,
                                @in_recaudad,
                                @in_val_cert,
                                @in_acu_tip_ce
                                );";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, oCompromisoDetalleMo.sessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, oCompromisoDetalleMo.sessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, oCompromisoDetalleMo.sessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, oCompromisoDetalleMo.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip);
            cmd.Parameters.AddWithValue("@in_sec_det", NpgsqlDbType.Integer, oCompromisoDetalleMo.sec_det);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, oCompromisoDetalleMo.cuenta);
            cmd.Parameters.AddWithValue("@in_val_deb", NpgsqlDbType.Double, oCompromisoDetalleMo.val_deb);
            cmd.Parameters.AddWithValue("@in_val_cre", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cre);
            cmd.Parameters.AddWithValue("@in_fec_det", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_det);
            cmd.Parameters.AddWithValue("@in_cod_cli", NpgsqlDbType.Char, oCompromisoDetalleMo.cod_cli);
            cmd.Parameters.AddWithValue("@in_fec_pos", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_pos);
            cmd.Parameters.AddWithValue("@in_nroctac", NpgsqlDbType.Char, oCompromisoDetalleMo.nroctac);
            cmd.Parameters.AddWithValue("@in_nro_che", NpgsqlDbType.Integer, oCompromisoDetalleMo.nro_che);
            cmd.Parameters.AddWithValue("@in_tip_com", NpgsqlDbType.Smallint, oCompromisoDetalleMo.tip_com);
            cmd.Parameters.AddWithValue("@in_des_det", NpgsqlDbType.Char, oCompromisoDetalleMo.des_det);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, oCompromisoDetalleMo.estado);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, oCompromisoDetalleMo.periodo);
            cmd.Parameters.AddWithValue("@in_factura", NpgsqlDbType.Char, oCompromisoDetalleMo.factura);
            cmd.Parameters.AddWithValue("@in_asociac", NpgsqlDbType.Smallint, oCompromisoDetalleMo.asociac);
            cmd.Parameters.AddWithValue("@in_devengad", NpgsqlDbType.Integer, oCompromisoDetalleMo.devengad);
            cmd.Parameters.AddWithValue("@in_saldo", NpgsqlDbType.Numeric, oCompromisoDetalleMo.saldo);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, oCompromisoDetalleMo.pagado);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, oCompromisoDetalleMo.recaudad);
            cmd.Parameters.AddWithValue("@in_val_cert", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cert);
            cmd.Parameters.AddWithValue("@in_acu_tip_ce", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip_ce);

            return Exec_sql.cargarDatosJson(cmd);
        }



        /// <summary>
        /// Cuando se recibe una lista de detalles con esta funcion se hace recursiva la insercion
        /// </summary>
        /// <param name="compromisoDetalleMoList"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_DetalleCompromisoList(List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            List<dynamic> respuestas = new List<dynamic>();
            bool success = true;

            try
            {
                foreach (var compromisoDetalleMo in compromisoDetalleMoList)
                {
                    try
                    {
                        dynamic respuesta = CompromisoBL.InsertarActualizar_DetalleCompromiso(compromisoDetalleMo);

                        respuestas.Add(respuesta);

                        // Verificar si la operación individual fue exitosa
                        if (!respuesta.success)
                        {
                            success = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        SeguridadBL.WriteErrorLog(ex);
                        respuestas.Add(new
                        {
                            success = false,
                            message = "Error: " + ex.Message,
                            result = ""
                        });
                    }
                }

                return new
                {
                    success = success,
                    message = success ? "Operaciones completadas exitosamente" : "Una o más operaciones fallaron",
                    result = respuestas
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }



        /// <summary>
        /// Funcion para aprobar un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>

        public static dynamic AprobarCompromisoPresupuestario(AprobarCompromisoCabeceraMo in_acu_tip)
        {
            try
            {
                using (var cmd_ValidaFecha = new NpgsqlCommand())
                {
                    string[] array = in_acu_tip.siglas_num.Split(' ');
                    string sql_ValidaFecha = @"SELECT * from public.sps_verifica_periodo_abierto
                            (@in_codemp, @in_anio, @in_fecha);
                          ";
                    cmd_ValidaFecha.CommandText = sql_ValidaFecha;
                    cmd_ValidaFecha.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, in_acu_tip.VarSesion.CodEmp);
                    cmd_ValidaFecha.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, in_acu_tip.VarSesion.Anio);
                    cmd_ValidaFecha.Parameters.AddWithValue("@in_fecha", NpgsqlDbType.Varchar, in_acu_tip.fecha_apr);

                    var respuesta_ValidaFecha = Exec_sql.cargarDatosJson(cmd_ValidaFecha);
                    respuesta_ValidaFecha = JsonConvert.DeserializeObject(respuesta_ValidaFecha.result.ToString());
                    if (respuesta_ValidaFecha[0]["var_id_per"].Value == 0)
                    {
                        throw new Exception(respuesta_ValidaFecha[0]["out_var_msg"].Value + " Fecha de Aprobación:" + in_acu_tip.fecha_apr);
                    }
                }

                using (var cmd = new NpgsqlCommand())
                {
                    string[] array = in_acu_tip.siglas_num.Split(' ');
                    string sql = @"Select 
                           * 
                           FROM 
                           public.sp_aprobarcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip);
                          ";
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, in_acu_tip.VarSesion.CodEmp);
                    cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, in_acu_tip.VarSesion.Anio);
                    cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(array[1]));

                    return Exec_sql.cargarDatosJson(cmd);
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = e.Message,
                    result = ""
                };
            }
        }


        /// <summary>
        /// Funcion para anular un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>

        public static dynamic AnularCompromisoPresupuestario(AnularCompromisoCabeceraMo Datos_ingreso)
        {
            string[] array = Datos_ingreso.siglas_num.Split(' ');

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_anularcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip, @in_cre_por, @in_liquidacion);
                          ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Datos_ingreso.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Datos_ingreso.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Integer, Convert.ToInt32(array[1]));
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Datos_ingreso.VarSesion.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_liquidacion", NpgsqlDbType.Integer, Datos_ingreso.liquidar);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para desaprobar un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        public static dynamic DesAprobarCompromisoPresupuestario(MovimientosPresupuestariosCaebeceraMO Datos_ingreso)
        {

            string[] array = Datos_ingreso.siglas_num.Split(' ');

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_desaprobarcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip);
                          ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Datos_ingreso.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Datos_ingreso.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }


        /// <summary>
        /// Funcion para listar las certificaciones habilitadas para ingresar un nuevo compromiso
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public static dynamic ListCertificacionesPresupuestariasHabilitadas(MovimientosPresupuestariosCaebeceraMO tipo)
        {
            string sql = @"select * from sps_movimiento_presupuestaria_habilitada
                           (
                            @in_codemp,
                            @in_anio,
                            @in_acu_tip
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Varchar, tipo.siglas_num);
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Funcion para obtener los datos de los administradores de contrato
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        public static dynamic ListarAdministradorContrato(MovimientosPresupuestariosCaebeceraMO in_acu_tip)
        {
            string[] array;
            // Intenta dividir el string usando el espacio como delimitador
            array = in_acu_tip.siglas_num.Split(' ');
            // Verifica si el array tiene solo un elemento
            if (array.Length == 1)
            {
                // Inicializa el array con dos elementos
                array = new string[2];
                array[0] = "CO"; // Usar comillas dobles para cadenas
                array[1] = "-1";
            }
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = @"
               SELECT
                *
               FROM public.sps_administrador_contrato
                (
                @in_anio, 
                @in_codemp, 
                @in_sig_tip, 
                @in_acu_tip);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_anio", in_acu_tip.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_codemp", in_acu_tip.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_sig_tip", Convert.ToString(array[0].ToUpper()));
            cmd.Parameters.AddWithValue("@in_acu_tip", Int32.Parse(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para cargar los compromisos presupuestarios por codigo
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        public static dynamic ListarMovimientoPresupuestariosCodigo(MovimientosPresupuestariosCaebeceraMO in_acu_tip)
        {
            string[] array = in_acu_tip.siglas_num.Split(' ');
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = @"
                       SELECT * FROM sps_movimientoPresupuestarioCodigo(@sig_tip, @anio, @acu_tip, @cod_emp);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@sig_tip", Convert.ToString(array[0].ToUpper()));
            cmd.Parameters.AddWithValue("@anio", in_acu_tip.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@acu_tip", Int32.Parse(array[1]));
            cmd.Parameters.AddWithValue("@cod_emp", in_acu_tip.VarSesion.CodEmp);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para listar las certificaciones habilitadas para asociar o desasociar
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public static dynamic AsociarDesasociarCertificados(AsociarCompromisoCabeceraMo tipo)
        {
            string[] array = tipo.siglas_num.Split(' ');

            string sql = @"select * from public.sps_asocia_desasocia_certificado
                           (
                            @in_codemp,
                            @in_anio,
                            @in_acu_tip,
                            @in_asociar,
                            @in_departamento
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Integer, Int32.Parse(array[1]));
            cmd.Parameters.AddWithValue("@in_asociar", NpgsqlDbType.Boolean, tipo.asociar);
            cmd.Parameters.AddWithValue("@in_departamento", NpgsqlDbType.Integer, tipo.departamento);
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
        }


       
        /// <summary>
        /// Funcion que trae las certificaciones que se van a asociar o desasociar
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public static dynamic IU_AsociarDesasociarCertificados(IU_AsociarCompromisoCabeceraMo tipo)
        {
            var respuesta = new ApiResultMo<int>();
            try
            {
                var Total_registros = 0;
               List<double> array;
                // Intenta dividir el string usando el espacio como delimitador
                array = tipo.acu_tip_ce;

                foreach (double str in tipo.acu_tip_ce)
                {
                    var datos = new IU_Codigo_AsociarCompromisoCabeceraMo();
                    datos.VarSesion = tipo.VarSesion;
                    datos.acu_tip_co = tipo.acu_tip_co;
                    datos.acu_tip_ce = str;
                    datos.asociar = tipo.asociar;
                    var resultado = SQL_IU_AsociarDesasociarCertificados(datos);
                    if (resultado.success == false)
                    {
                        throw new Exception(resultado.message);
                    }
                    var retorno = JsonConvert.DeserializeObject(resultado.result.ToString());
                    Total_registros += retorno[0]["total_registros"].Value;
                }

                if (Total_registros == 0) {
                    throw new Exception("No existieron registros afectados !!");
                }

                respuesta.result = Total_registros;
                respuesta.success = true;
                return respuesta;


            }
            catch (Exception ex) { 
            
                respuesta.message = ex.Message;
                return respuesta;
            }


        }

        /// <summary>
        /// Funcion que afecta la asociacion o desasociacion
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public static dynamic SQL_IU_AsociarDesasociarCertificados(IU_Codigo_AsociarCompromisoCabeceraMo tipo)
        {
            string sql = @"select * from public.spiu_asocia_desasocia_certificado
                            (@in_codemp, @in_anio, @in_acu_tip_ce, @in_acu_tip_co, @in_cre_por, @in_tipo);
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, tipo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, tipo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_acu_tip_ce", NpgsqlDbType.Double, tipo.acu_tip_ce);
            cmd.Parameters.AddWithValue("@in_acu_tip_co", NpgsqlDbType.Double, tipo.acu_tip_co);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Varchar, tipo.VarSesion.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_tipo", NpgsqlDbType.Boolean, tipo.asociar);
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

    }



}
