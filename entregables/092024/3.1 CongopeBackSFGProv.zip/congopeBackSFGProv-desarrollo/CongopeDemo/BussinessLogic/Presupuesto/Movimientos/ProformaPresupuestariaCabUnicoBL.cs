﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaCabUnicoBL
    {
        //public static dynamic Listar(string codemp, int anio, string sig_tip, int acu_tip)
        //{
   
        //    string sql = "select * from sps_proforma_presupuestaria_cabecera_unico('" + codemp + "', " + anio + ", '" + sig_tip + "', " + acu_tip + ");";
        //    NpgsqlCommand cmd = new NpgsqlCommand(sql);

        //    cmd.Parameters.AddWithValue("@pag", NpgsqlDbType.Varchar, codemp);
        //    cmd.Parameters.AddWithValue("@pag", NpgsqlDbType.Integer, anio);
        //    cmd.Parameters.AddWithValue("@pag", NpgsqlDbType.Varchar, sig_tip);
        //    cmd.Parameters.AddWithValue("@pag", NpgsqlDbType.Integer, acu_tip);

        //    return Exec_sql.cargarDatosModel<ProformaPresupuestariaCabUnicoMO>(cmd);
        //}


    }
}
