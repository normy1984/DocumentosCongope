﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class MovimientoPorPartidaBL
    {
        public static dynamic Listar(string codemp, int anio, string sFechaDesde, string sFechaHasta, string sPartida)
        {
          
            string sql = "select * from sps_movimiento_por_partida(@emp,@anio_bus,@f_desde,@f_hasta,@spartida)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@emp", NpgsqlDbType.Varchar, codemp);
            cmd.Parameters.AddWithValue("@anio_bus", NpgsqlDbType.Integer, anio);
            cmd.Parameters.AddWithValue("@f_desde", NpgsqlDbType.Varchar, sFechaDesde);
            cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, sFechaHasta);
            cmd.Parameters.AddWithValue("@spartida", NpgsqlDbType.Varchar, sPartida);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
