﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ConsultaPorClasificadorBL
    {
        public static dynamic Listar(string sFechaHasta, int nTipoPresu, string sclasificador = "")
        {

            string sql = "select * from sp_consulta_por_clasificador_presupuestario(@f_hasta,@ntipopresu,@sclafificador)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, sFechaHasta);
            cmd.Parameters.AddWithValue("@ntipopresu", NpgsqlDbType.Integer, nTipoPresu);
            cmd.Parameters.AddWithValue("@sclafificador", NpgsqlDbType.Varchar, sclasificador);
                    
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
