﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Ocsp;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class EjecucionPresupuestariaBL
    {
        public static dynamic Listar(string sFechaHasta)
        {
        
            string sql = "select * from sp_ejecucion_presupuestaria(@f_hasta)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@f_hasta", NpgsqlDbType.Varchar, sFechaHasta);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
