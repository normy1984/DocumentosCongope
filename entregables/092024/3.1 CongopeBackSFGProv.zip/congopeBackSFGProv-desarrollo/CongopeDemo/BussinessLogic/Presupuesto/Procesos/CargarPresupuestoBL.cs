﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Presupuesto.Procesos;
using Npgsql;
using NpgsqlTypes;
using OfficeOpenXml;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Procesos
{
    public class CargarPresupuestoBL
    {
        /// <summary>
        /// Funcion que realiza el procesamiento del archivo excel
        /// </summary>
        /// <param name="ExcelPresupuesto"></param>
        /// <param name="anio"></param>
        /// <returns></returns>
        public static dynamic CargarPresupuestoExcel(ValidarPresupuestoMo oValidarPresupuestoMo)
        {
            try
            {
                if (oValidarPresupuestoMo.File == null || oValidarPresupuestoMo.File.Length == 0)
                {
                    return new
                    {
                        success = false,
                        message = "No se proporcionó un archivo.",
                        result = string.Empty
                    };

                }

                string uploadsFolder = RutaGuardarArchivo();
                string filePath = GuardarArchivo(oValidarPresupuestoMo.File, uploadsFolder, oValidarPresupuestoMo.Anio);

                List<CargarPresupuestoTipoMo> estructuraIngresos = CargarEstructura(2, oValidarPresupuestoMo.Anio, oValidarPresupuestoMo.Codemp).result;
                List<CargarPresupuestoTipoMo> estructuraGastos = CargarEstructura(1, oValidarPresupuestoMo.Anio, oValidarPresupuestoMo.Codemp).result;

                var dataList = ProcesarArchivoExcel(filePath, estructuraIngresos, estructuraGastos, out bool procesadoOk);
                dataList = ValidarEstructuraPadresHijos(dataList, estructuraIngresos, estructuraGastos, ref procesadoOk);

                var objetoExcel = new
                {
                    validado = procesadoOk,
                    result = dataList
                };

                return new
                {
                    success = true,
                    message = "Archivo procesado exitosamente.",
                    result = objetoExcel
                };

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = string.Empty
                };
            }
        }

        /// <summary>
        /// Funcion que devuelve la ruta donde se guarda el archivo
        /// </summary>
        /// <param name="anio"></param>
        /// <returns></returns>
        private static string RutaGuardarArchivo()
        {
            string uploadsFolder = Path.Combine(Conexion.RutaDocumentos, "CargaPresupuesto");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            return uploadsFolder;
        }

        /// <summary>
        /// Funcion para guardar el archivo en el repositorio
        /// </summary>
        /// <param name="file"></param>
        /// <param name="uploadsFolder"></param>
        /// <returns></returns>
        private static string GuardarArchivo(IFormFile file, string uploadsFolder, int anio)
        {
            string fileName = "ProformaPresupuestaria_" + anio.ToString();

            // Asegurarse de que el nombre del archivo tenga la extensión correcta
            if (string.IsNullOrEmpty(Path.GetExtension(fileName)))
            {
                fileName += Path.GetExtension(file.FileName);
            }

            string filePath = Path.Combine(uploadsFolder, fileName);
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyTo(fileStream);
            }
            return filePath;
        }

        /// <summary>
        /// Funcion que realiza el procesamiento del archivo Excel
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="estructuraIngresos"></param>
        /// <param name="estructuraGastos"></param>
        /// <param name="procesadoOk"></param>
        /// <returns></returns>

        private static List<Dictionary<string, object>> ProcesarArchivoExcel(string filePath, List<CargarPresupuestoTipoMo> estructuraIngresos, List<CargarPresupuestoTipoMo> estructuraGastos, out bool procesadoOk)
        {
            var dataList = new List<Dictionary<string, object>>();
            procesadoOk = true;

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var worksheet = package.Workbook.Worksheets[0];
                var headers = ObtenerCabecerasExcel(worksheet);
                var rowCount = worksheet.Dimension.Rows;

                for (int row = 2; row <= rowCount; row++)
                {
                    var rowData = ObtenerDatosFilas(worksheet, headers, row);
                    ValidarDatosPorEstructura(rowData, estructuraIngresos, estructuraGastos, ref procesadoOk);
                    dataList.Add(rowData);
                }
            }

            return dataList;
        }

        /// <summary>
        /// Funcion que permite obtener las cabeceras del archivo excel para su posterior procesamiento
        /// </summary>
        /// <param name="worksheet"></param>
        /// <returns></returns>
        private static List<string> ObtenerCabecerasExcel(ExcelWorksheet worksheet)
        {
            var headers = new List<string>();
            int colCount = worksheet.Dimension.Columns;
            for (int col = 1; col <= colCount; col++)
            {
                headers.Add(worksheet.Cells[1, col].Text.Replace(" ", "_").ToUpper());
            }
            return headers;
        }

        /// <summary>
        /// Funcion que obtiene los datos de cada fila del archivo excel
        /// </summary>
        /// <param name="worksheet"></param>
        /// <param name="headers"></param>
        /// <param name="row"></param>
        /// <returns></returns>
        private static Dictionary<string, object> ObtenerDatosFilas(ExcelWorksheet worksheet, List<string> headers, int row)
        {
            var rowData = new Dictionary<string, object>();
            int colCount = headers.Count;
            for (int col = 1; col <= colCount; col++)
            {
                /*
                Si una celda contiene 1234.567 con formato de moneda ($1,234.57):
                Text devolverá "$1,234.57".
                Value devolverá 1234.567 (como un double).

                Si una celda contiene la fecha 01/01/2024 con formato de fecha (January 1, 2024):
                Text devolverá "January 1, 2024".
                Value devolverá DateTime(2024, 1, 1).

                rowData[headers[col - 1]] =  worksheet.Cells[row, col].Text.Trim();

                Para nuestro caso utilizamos Value ya que al utilizar datos formateados nos genera conflictos
                */

                var cellValue = worksheet.Cells[row, col].Value;
                string cellText = cellValue != null ? cellValue.ToString().Trim() : string.Empty;

                // Si el encabezado es "GASTOS" o "INGRESOS" y el valor es una cadena, reemplaza las comas por puntos
                if (headers[col - 1] == "GASTOS" || headers[col - 1] == "INGRESOS")
                {
                    cellText = string.IsNullOrWhiteSpace(cellText) ? "0" : cellText.Replace(',', '.');
                }

                rowData[headers[col - 1]] = cellText;

            }
            return rowData;
        }

        /// <summary>
        /// Funcion que realiza las validaciones por cada una de las filas
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="estructuraIngresos"></param>
        /// <param name="estructuraGastos"></param>
        /// <param name="procesadoOk"></param>
        private static void ValidarDatosPorEstructura(Dictionary<string, object> rowData, List<CargarPresupuestoTipoMo> estructuraIngresos, List<CargarPresupuestoTipoMo> estructuraGastos, ref bool procesadoOk)
        {
            string tipo = rowData["TIPO"].ToString() ?? string.Empty;
            string partida = rowData["PARTIDA_PRESUPUESTARIA"].ToString() ?? string.Empty;
            string[] arrayPartida = partida?.Split('.') ?? Array.Empty<string>();
            bool validado = true;
            string mensaje = "";
            string ultimo_nivel = "N";

            switch (tipo)
            {
                case "1": // GASTOS
                    ValidarLongitudEstructura(arrayPartida, estructuraGastos, ref validado, ref mensaje, ref procesadoOk, ref ultimo_nivel);
                    ValidarValoresIngresosGastos(rowData, estructuraGastos, arrayPartida, ref validado, ref mensaje, ref procesadoOk, true);
                    break;
                case "2": // INGRESOS
                    ValidarLongitudEstructura(arrayPartida, estructuraIngresos, ref validado, ref mensaje, ref procesadoOk, ref ultimo_nivel);
                    ValidarValoresIngresosGastos(rowData, estructuraIngresos, arrayPartida, ref validado, ref mensaje, ref procesadoOk, false);
                    break;
                default:
                    mensaje += "* TIPO no reconocido.<br>";
                    validado = false;
                    procesadoOk = false;
                    break;
            }
            rowData["CUENTA_PADRE"] = string.Join(".", arrayPartida.Take(arrayPartida.Length - 1));
            rowData["ULTIMO_NIVEL"] = ultimo_nivel;
            rowData["NIVEL"] = arrayPartida.Length;
            rowData["VALIDADO"] = validado;
            rowData["OBSERVACION"] = mensaje;
        }

        /// <summary>
        /// Funcion que valida la longitud de los campos de acuerdo con la estructura
        /// </summary>
        /// <param name="arrayPartida"></param>
        /// <param name="estructura"></param>
        /// <param name="validado"></param>
        /// <param name="mensaje"></param>
        /// <param name="procesadoOk"></param>
        private static void ValidarLongitudEstructura(string[] arrayPartida, List<CargarPresupuestoTipoMo> estructura, ref bool validado, ref string mensaje, ref bool procesadoOk, ref string ultimo_nivel)
        {
            ultimo_nivel = (arrayPartida.Length == estructura.Count) ? "S" : "N";

            if (arrayPartida.Length > estructura.Count)
            {

                mensaje += $"* La estructura de la partida exede el tamaño maximo de {estructura.Count}.<br>";
                validado = false;
                procesadoOk = false;

            }
            else
            {
                for (int i = 0; i < arrayPartida.Length; i++)
                {
                    if (arrayPartida[i].Length != estructura[i].longitud)
                    {
                        mensaje += $"* Nivel: {i + 1} Longitud: {arrayPartida[i].Length} Requerida: {estructura[i].longitud}.<br>";
                        validado = false;
                        procesadoOk = false;
                    }
                }
            }
        }

        /// <summary>
        /// Funcion que valida si los campos deben o no tener valores
        /// </summary>
        /// <param name="rowData"></param>
        /// <param name="estructura"></param>
        /// <param name="arrayPartida"></param>
        /// <param name="validado"></param>
        /// <param name="mensaje"></param>
        /// <param name="procesadoOk"></param>
        /// <param name="isGastos"></param>
        private static void ValidarValoresIngresosGastos(Dictionary<string, object> rowData, List<CargarPresupuestoTipoMo> estructura, string[] arrayPartida, ref bool validado, ref string mensaje, ref bool procesadoOk, bool isGastos)
        {
            
            try {
                float gastos = Convert.ToSingle(rowData["GASTOS"]);
                float ingresos = Convert.ToSingle(rowData["INGRESOS"]);
                bool hasValues = gastos > 0 || ingresos > 0;
                if (estructura.Count != arrayPartida.Length && hasValues)
                {
                    mensaje += "* En este nivel no deben existir valores.<br>";
                    validado = false;
                    procesadoOk = false;
                }

                if (estructura.Count == arrayPartida.Length && (isGastos ? ingresos > 0 : gastos > 0))
                {
                    mensaje += $"* No deben haber valores en {(isGastos ? "INGRESOS" : "GASTOS")}.<br>";
                    validado = false;
                    procesadoOk = false;
                }
            }
            catch
            {
                mensaje += $"* El dato ingresado en Gastos o Ingresos no es un número.<br>";
                validado = false;
                procesadoOk = false;
            }
            

        }

        /// <summary>
        /// Funcion que valida que esten todas las estructuras creadas
        /// </summary>
        /// <param name="dataList"></param>
        /// <param name="estructuraIngresos"></param>
        /// <param name="estructuraGastos"></param>
        /// <param name="procesadoOk"></param>
        /// <returns></returns>
        private static List<Dictionary<string, object>> ValidarEstructuraPadresHijos(List<Dictionary<string, object>> dataList, List<CargarPresupuestoTipoMo> estructuraIngresos, List<CargarPresupuestoTipoMo> estructuraGastos, ref bool procesadoOk)
        {
            var ordenDescendente = dataList.OrderByDescending(d => (string)d["PARTIDA_PRESUPUESTARIA"]).ToList();
            int nivelHijo = 0;
            Dictionary<string, object> itemAnt = new Dictionary<string, object>();
            string[] arrPartidaPadre = Array.Empty<string>();
            var partida_anterior = string.Empty;

            foreach (var item in ordenDescendente)
            {

                if (partida_anterior == item["PARTIDA_PRESUPUESTARIA"].ToString())
                {
                    item["VALIDADO"] = false;
                    item["OBSERVACION"] = "* Registro duplicado.<br>" + item["OBSERVACION"];
                    procesadoOk = false;
                    /// SI DESEO PONERLE TAMBIEN AL OTRO COMO DUPLICADO HAGO ESTO
                    /*var index = dataList.FindIndex(d => d["PARTIDA_PRESUPUESTARIA"].ToString() == item["PARTIDA_PRESUPUESTARIA"].ToString());
                    if (index != -1)
                    {
                        var observacionActual = dataList[index].ContainsKey("OBSERVACION") ? dataList[index]["OBSERVACION"].ToString() : string.Empty;
                        dataList[index]["OBSERVACION"] = "* Registro duplicado.<br>" + observacionActual;
                        dataList[index]["VALIDADO"] = item["VALIDADO"];
                    }*/
                }
                else
                {
                    int contadorEstructura = item["TIPO"].ToString() == "1" ? estructuraGastos.Count : estructuraIngresos.Count;
                    string[] arrayPartida = item["PARTIDA_PRESUPUESTARIA"].ToString()?.Split('.') ?? Array.Empty<string>();

                    if (contadorEstructura == arrayPartida.Length)
                    {
                        nivelHijo = contadorEstructura - 1;
                        arrPartidaPadre = arrayPartida;
                        itemAnt = item;
                    }
                    else if (contadorEstructura > arrayPartida.Length)
                    {
                        while (arrayPartida.Length < nivelHijo)
                        {
                            CrearEstructuraPadre(dataList, ref procesadoOk, arrPartidaPadre, nivelHijo, itemAnt);
                            nivelHijo--;
                        }
                        nivelHijo--;
                    }
                }

                partida_anterior = item["PARTIDA_PRESUPUESTARIA"].ToString();

            }

            while (nivelHijo > 0)
            {
                CrearEstructuraPadre(dataList, ref procesadoOk, arrPartidaPadre, nivelHijo, itemAnt);
                nivelHijo--;
            }

            return dataList.OrderBy(d => (string)d["PARTIDA_PRESUPUESTARIA"]).ToList();
        }

        /// <summary>
        /// Funcion que crea una estructura si no esta completa la misma en el archivo
        /// </summary>
        /// <param name="dataList"></param>
        /// <param name="procesadoOk"></param>
        /// <param name="arrPartidaPadre"></param>
        /// <param name="nivelHijo"></param>
        /// <param name="itemAnt"></param>
        private static void CrearEstructuraPadre(List<Dictionary<string, object>> dataList, ref bool procesadoOk, string[] arrPartidaPadre, int nivelHijo, Dictionary<string, object> itemAnt)
        {
            var fila = new Dictionary<string, object>()
                    {
                        { "PARTIDA_PRESUPUESTARIA", string.Join(".", arrPartidaPadre.Take(nivelHijo)) },
                        { "NOMBRE", itemAnt["NOMBRE"] },
                        { "INGRESOS", "0" },
                        { "GASTOS", "0" },
                        { "TIPO", itemAnt["TIPO"] },
                        { "CUENTA_PADRE", ""},
                        { "ULTIMO_NIVEL", "N" },
                        { "NIVEL", "0" },
                        { "VALIDADO", false },
                        { "OBSERVACION", "* Registro creado por el sistema.<br>" }
                    };
            procesadoOk = false;
            dataList.Add(fila);
        }


        /// <summary>
        /// Creacion de la estructura de acuerdo a lo existente en la base de datos
        /// </summary>
        /// <param name="tipoEstructura"></param>
        /// <param name="anio"></param>
        /// <returns></returns>
        private static dynamic CargarEstructura(int tipoEstructura, int anio, string codemp)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = @"
                                SELECT lon_est AS longitud 
                                FROM prestcta p 
                                WHERE p.anio = @anio 
                                  AND identifi = @tipo
                                  AND codemp = @codemp  
                                ORDER BY niv_est;";
            cmd.Parameters.AddWithValue("@tipo", tipoEstructura);
            cmd.Parameters.AddWithValue("@anio", anio);
            cmd.Parameters.AddWithValue("@codemp", codemp);
            return Exec_sql.cargarDatosModel<CargarPresupuestoTipoMo>(cmd);
        }


        public static dynamic GuardarProformaPresupuestaria(List<EstructuraPresupuestoMo> lEstructuraPresupuestoMo)
        {
            var respuesta = new ApiResultMo<string>();

            /// GUARDAR LOS REGISTROS EN LA BASE DE DATOS GUARDAR PRPLACTA
            foreach (var item in lEstructuraPresupuestoMo)
            {
                var guardaPrPlacta = SqlGuardarPrPLacta(item);
                if (!guardaPrPlacta.success)
                {
                    return guardaPrPlacta;
                }
            }

            var UltimosNiveles = lEstructuraPresupuestoMo.Where(d => d.Ultimo_nivel == "S").ToList();
            double sumaGastos = Math.Round(UltimosNiveles.Sum(d => d.Gastos), 2);
            double sumaIngresos = Math.Round(UltimosNiveles.Sum(d => d.Ingresos), 2);


            ///GUARDAR LOS REGISTROS EN CABECERA MOVIMIENTO
            var guardaCabMov = InsertarActualizar_CabeceraMovimiento(UltimosNiveles[0], sumaIngresos, sumaGastos, 1.0);
            if (!guardaCabMov.success)
            {
                guardaCabMov = InsertarActualizar_CabeceraMovimiento(UltimosNiveles[0], sumaIngresos, sumaGastos, 0.0);
                {
                    if (!guardaCabMov.success)
                    {
                        return guardaCabMov;
                    }
                }
            }

            ///GUARDAR EN EL DETALLE MOVIMIENTO

            var secuencial = 1;

            foreach (var item in UltimosNiveles)
            {
                var guardaDetMov = InsertarActualizar_DetalleMovimiento(item, secuencial);
                if (!guardaDetMov.success)
                {
                    return guardaDetMov;
                }
                secuencial++;
            }

            respuesta.success = true;
            return respuesta;

        }

        /// <summary>
        /// FUNCION SQL PARA GUARDAR LOS REGISTROS EN LA TABLA PRPLACTA
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        private static dynamic SqlGuardarPrPLacta(EstructuraPresupuestoMo DetalleMo)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = @"
                                SELECT total_registros as longitud from public.spiu_prplacta(@in_codemp, @in_anio, @in_cuenta, 
                                @in_identifi, @in_nom_cue, @in_ult_cue, @in_niv_cue, @in_con_mov, 
                                @in_sal_deb, @in_sal_cre, @in_sal_inid, @in_sal_inic, @in_cod_p, 
                                @in_cod_h, @in_cuenta_p, @in_cre_por, @in_aux_cue, @in_ban_cue, 
                                @in_estado, @in_comp_db, @in_comp_cr, @in_scompdb, @in_scompcr, 
                                @in_niv_ug, @in_ffn_id);";
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, DetalleMo.ParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, DetalleMo.ParamSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, DetalleMo.Partida_presupuestaria);
            cmd.Parameters.AddWithValue("@in_identifi", NpgsqlDbType.Smallint, DetalleMo.Tipo);
            cmd.Parameters.AddWithValue("@in_nom_cue", NpgsqlDbType.Varchar, DetalleMo.Nombre);
            cmd.Parameters.AddWithValue("@in_ult_cue", NpgsqlDbType.Char, DetalleMo.Ultimo_nivel);
            cmd.Parameters.AddWithValue("@in_niv_cue", NpgsqlDbType.Integer, DetalleMo.Nivel);
            cmd.Parameters.AddWithValue("@in_con_mov", NpgsqlDbType.Integer, 0);
            cmd.Parameters.AddWithValue("@in_sal_deb", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_sal_cre", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_sal_inid", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_sal_inic", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_cod_p", NpgsqlDbType.Integer, 0);
            cmd.Parameters.AddWithValue("@in_cod_h", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_cuenta_p", NpgsqlDbType.Char, DetalleMo.Cuenta_padre);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, DetalleMo.ParamSessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_aux_cue", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_ban_cue", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, 1);
            cmd.Parameters.AddWithValue("@in_comp_db", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_comp_cr", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_scompdb", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_scompcr", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_niv_ug", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_ffn_id", NpgsqlDbType.Numeric, 0);

            return Exec_sql.cargarDatosModel<CargarPresupuestoTipoMo>(cmd);
        }


        /// <summary>
        /// FUNCION SQL PARA GUARDAR LOS REGISTROS EN LA TABLA CABECERA MOVIMIENTO
        /// </summary>
        /// <param name="oCompromisoCabecera"></param>
        /// <returns></returns>
        private static dynamic InsertarActualizar_CabeceraMovimiento(EstructuraPresupuestoMo oCompromisoCabecera, double val_deb, double val_cre, double acu_tip)
        {

            DateOnly date = DateOnly.FromDateTime(DateTime.Now);
            // Convertir la fecha a cadena en formato "YYYY-MM-DD"
            string fechaActual = date.ToString("yyyy-MM-dd");

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_prcabmov
                            (
                             @in_codemp, 
                             @in_anio, 
                             @in_sig_tip,
                             @in_acu_tip, 
                             @in_num_com, 
                             @in_des_cab, 
                            @in_tot_deb, 
                            @in_tot_cre, 
                            @in_totinid, 
                            @in_totinic, 
                            @in_fec_asi, 
                            @in_fec_apr, 
                            @in_fec_anu, 
                            @in_cre_por, 
                            @in_estado, 
                            @in_periodo, 
                            @in_nropagos, 
                            @in_pagosre, 
                            @in_incremen, 
                            @in_comprom, 
                            @in_sig_tip1, 
                            @in_acu_tip1, 
                            @in_estadono, 
                            @in_liquida, 
                            @in_departam, 
                            @in_solicita, 
                            @in_cedruc, 
                            @in_tipopro, 
                            @in_retfte, 
                            @in_retiva, 
                            @in_cur, 
                            @in_pagado, 
                            @in_recaudad, 
                            @in_sig_tipce, 
                            @in_acu_tipce, 
                            @in_cod_proceso, 
                            @in_arrastre, 
                            @in_tipo_contrato, 
                            @in_admin_contrato, 
                            @in_valor_contrato, 
                            @in_observacion, 
                            @in_desagrupar);
                             ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, oCompromisoCabecera.ParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, oCompromisoCabecera.ParamSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, oCompromisoCabecera.ParamSessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, "PR");
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, acu_tip);
            cmd.Parameters.AddWithValue("@in_num_com", NpgsqlDbType.Char, "");
            cmd.Parameters.AddWithValue("@in_des_cab", NpgsqlDbType.Varchar, "Proforma Año Fiscal " + oCompromisoCabecera.ParamSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_tot_deb", NpgsqlDbType.Double, val_deb);
            cmd.Parameters.AddWithValue("@in_tot_cre", NpgsqlDbType.Double, val_cre);
            cmd.Parameters.AddWithValue("@in_totinid", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_totinic", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_fec_asi", NpgsqlDbType.Char, fechaActual);
            cmd.Parameters.AddWithValue("@in_fec_apr", NpgsqlDbType.Char, fechaActual);
            cmd.Parameters.AddWithValue("@in_fec_anu", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, 2);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, 1);
            cmd.Parameters.AddWithValue("@in_nropagos", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_pagosre", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_incremen", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_comprom", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_sig_tip1", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_acu_tip1", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_estadono", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_liquida", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_departam", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_solicita", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_tipopro", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_retfte", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_retiva", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_cur", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_sig_tipce", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_acu_tipce", NpgsqlDbType.Numeric, 0);
            cmd.Parameters.AddWithValue("@in_cod_proceso", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_arrastre", NpgsqlDbType.Numeric, 0);
            cmd.Parameters.AddWithValue("@in_tipo_contrato", NpgsqlDbType.Numeric, 0);
            cmd.Parameters.AddWithValue("@in_admin_contrato", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_valor_contrato", NpgsqlDbType.Numeric, 0);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, string.Empty);
            cmd.Parameters.AddWithValue("@in_desagrupar", NpgsqlDbType.Numeric, 0);

            return Exec_sql.cargarDatosJson(cmd);
        }


        /// <summary>
        /// FUNCION PARA ACTUALIZAR LOS REGISTROS DE LA TABLA DETALLE MOVIMIENTO
        /// </summary>
        /// <param name="oCompromisoDetalleMo"></param>
        /// <returns></returns>

        private static dynamic InsertarActualizar_DetalleMovimiento(EstructuraPresupuestoMo oCompromisoDetalleMo, int secuencial)
        {

            // Convertir la fecha a cadena en formato "YYYY-MM-DD"
            DateTime now = DateTime.Now;

            // Formatear la hora en el formato HH:mm:ss
            string HoraActual = now.ToString("HH:mm:ss");
            string fechaActual = now.ToString("yyyy-MM-dd");

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"SELECT * from public.spiu_prdetmov(@in_codemp, @in_anio, @in_sig_tip, @in_acu_tip, 
                                                        @in_sec_det, @in_cuenta, @in_val_deb, @in_val_cre, 
                                                        @in_fec_det, @in_cod_cli, @in_fec_pos, @in_nroctac, 
                                                        @in_nro_che, @in_tip_com, @in_cre_por, @in_des_det, 
                                                        @in_estado, @in_periodo, @in_factura, @in_asociac, 
                                                        @in_devengad, @in_saldo, @in_pagado, @in_recaudad, 
                                                        @in_val_cert, @in_acu_tip_ce);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, oCompromisoDetalleMo.ParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, oCompromisoDetalleMo.ParamSessionMo.Anio);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, "PR");
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, 1.0);
            cmd.Parameters.AddWithValue("@in_sec_det", NpgsqlDbType.Integer, secuencial);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, oCompromisoDetalleMo.Partida_presupuestaria);
            cmd.Parameters.AddWithValue("@in_val_deb", NpgsqlDbType.Double, oCompromisoDetalleMo.Ingresos);
            cmd.Parameters.AddWithValue("@in_val_cre", NpgsqlDbType.Double, oCompromisoDetalleMo.Gastos);
            cmd.Parameters.AddWithValue("@in_fec_det", NpgsqlDbType.Char, fechaActual);
            cmd.Parameters.AddWithValue("@in_cod_cli", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_fec_pos", NpgsqlDbType.Char, HoraActual);
            cmd.Parameters.AddWithValue("@in_nroctac", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_nro_che", NpgsqlDbType.Integer, 0);
            cmd.Parameters.AddWithValue("@in_tip_com", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, oCompromisoDetalleMo.ParamSessionMo.codUsu.ToString());
            cmd.Parameters.AddWithValue("@in_des_det", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, 2);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, 0);
            cmd.Parameters.AddWithValue("@in_factura", NpgsqlDbType.Char, string.Empty);
            cmd.Parameters.AddWithValue("@in_asociac", NpgsqlDbType.Smallint, oCompromisoDetalleMo.Tipo);
            cmd.Parameters.AddWithValue("@in_devengad", NpgsqlDbType.Integer, 0);
            cmd.Parameters.AddWithValue("@in_saldo", NpgsqlDbType.Numeric, 0);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_val_cert", NpgsqlDbType.Double, double.NegativeZero);
            cmd.Parameters.AddWithValue("@in_acu_tip_ce", NpgsqlDbType.Double, double.NegativeZero);


            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Funcion que valida si el periodo actual puede realizar la carga por archivo de la proforma presupuestaria
        /// </summary>
        /// <param name="oParamSessionMo"></param>
        /// <returns></returns>
        public static dynamic ValidarCargaProforma(ParamSessionMo oParamSessionMo)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = @"
                                SELECT COUNT(*) as longitud 
                                from public.prdetmov p 
                                where p.codemp = @codemp
                                and p.anio = @anio 
                                AND p.sig_tip != @sig_tip;";
            cmd.Parameters.AddWithValue("@codemp", oParamSessionMo.CodEmp);
            cmd.Parameters.AddWithValue("@anio", oParamSessionMo.Anio);
            cmd.Parameters.AddWithValue("@sig_tip", "PR");
            return Exec_sql.cargarDatosModel<CargarPresupuestoTipoMo>(cmd);
        }

    }
}
