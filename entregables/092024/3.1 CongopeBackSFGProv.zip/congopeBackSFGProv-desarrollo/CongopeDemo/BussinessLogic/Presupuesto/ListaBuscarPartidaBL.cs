﻿using Congope.Empresas.Data;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ListaBuscarPartidaBL
    {
        public static dynamic Listar(int nanio, int nTipoPresu, string sPartida = "")
        {
           
            string sql = "select * from sp_lista_buscar_partida(@nanio, @ntipopresu , @spartidabusca );";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);

            cmd.Parameters.AddWithValue("@nanio", NpgsqlDbType.Integer, nanio);
            cmd.Parameters.AddWithValue("@ntipopresu", NpgsqlDbType.Integer, nTipoPresu);
            cmd.Parameters.AddWithValue("@spartidabusca", NpgsqlDbType.Varchar, sPartida);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
