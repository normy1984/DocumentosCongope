﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ListaCiuBL
    {
        public static dynamic Listar()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_lista_ciu();";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }


        public static dynamic Seleccionar_ciu(string cedruc)
        {
         
            string sql = "select * from sps_ciu(@cedrucbusca);";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@cedrucbusca", cedruc);
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic grupos_ciu()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from grupos_ciu;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic ciudades()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from ciudades;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic titulos()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from titulos;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic bancos()
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from bancos;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic Insertar_Actualiza_CIU(CiuMO oCiu)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select * from spiu_ciu
                            (
                            @in_codtab,
                            @in_cedruc, 
                            @in_descrip,
                            @in_direcci, 
                            @in_telefon1,
                            @in_email1,
                            @in_ciudad,
                            @in_titulo,
                            @in_rucoced,
                            @in_contribespe,
                            @in_banco,
                            @in_nrocta,
                            @in_tipocta,
                            @in_numero_iden,
                            @in_nombre_iden,
                            @in_fechanac,
                            @in_discapacidad,
                            @in_porcen_disca,
                            @in_contesp_nrores,
                            @in_obligado_conta,
                            @in_serie);
                            ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codtab", NpgsqlDbType.Double, oCiu.codtab);
            cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, oCiu.cedruc);
            cmd.Parameters.AddWithValue("@in_descrip", NpgsqlDbType.Char, oCiu.descrip);
            cmd.Parameters.AddWithValue("@in_direcci", NpgsqlDbType.Char, oCiu.direcci);
            cmd.Parameters.AddWithValue("@in_telefon1", NpgsqlDbType.Char, oCiu.telefon1);
            cmd.Parameters.AddWithValue("@in_email1", NpgsqlDbType.Char, oCiu.email1);
            cmd.Parameters.AddWithValue("@in_ciudad", NpgsqlDbType.Double, oCiu.ciudad);
            cmd.Parameters.AddWithValue("@in_titulo", NpgsqlDbType.Double, oCiu.titulo);
            cmd.Parameters.AddWithValue("@in_rucoced", NpgsqlDbType.Double, oCiu.rucoced);
            cmd.Parameters.AddWithValue("@in_contribespe", NpgsqlDbType.Double, oCiu.contribespe);
            cmd.Parameters.AddWithValue("@in_banco", NpgsqlDbType.Char, oCiu.banco);
            cmd.Parameters.AddWithValue("@in_nrocta", NpgsqlDbType.Char, oCiu.nrocta);
            cmd.Parameters.AddWithValue("@in_tipocta", NpgsqlDbType.Double, oCiu.tipocta);
            cmd.Parameters.AddWithValue("@in_numero_iden", NpgsqlDbType.Char, oCiu.numero_iden);
            cmd.Parameters.AddWithValue("@in_nombre_iden", NpgsqlDbType.Char, oCiu.nombre_iden);
            cmd.Parameters.AddWithValue("@in_fechanac", NpgsqlDbType.Char, oCiu.fechanac);
            cmd.Parameters.AddWithValue("@in_discapacidad", NpgsqlDbType.Double, oCiu.discapacidad);
            cmd.Parameters.AddWithValue("@in_porcen_disca", NpgsqlDbType.Double, oCiu.porcen_disca);
            cmd.Parameters.AddWithValue("@in_contesp_nrores", NpgsqlDbType.Char, oCiu.contesp_nrores);
            cmd.Parameters.AddWithValue("@in_obligado_conta", NpgsqlDbType.Double, oCiu.obligado_conta);
            cmd.Parameters.AddWithValue("@in_serie", NpgsqlDbType.Char, oCiu.serie);

            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
