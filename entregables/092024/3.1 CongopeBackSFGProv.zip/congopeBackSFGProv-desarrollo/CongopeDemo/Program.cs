using Congope.Empresas.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using OfficeOpenXml;

//LINEA DE CONFIGURACION DE LA LIBRERIA EPPlus 

ExcelPackage.LicenseContext = LicenseContext.NonCommercial;


var builder = WebApplication.CreateBuilder(args);


// Lineas para la configuracion LDAP

// Configuraci�n de LDAP desde la clase est�tica


// Add services to the container

builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

builder.Services.AddCors(options => {
    options.AddPolicy("NuevaPolitica", app =>
    {
        app.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
    });
});


/// funcionalidad de JwtBearer
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options => {
    options.IncludeErrorDetails = true;
    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateIssuerSigningKey = true,
        ValidateLifetime = true,
        ValidIssuer = Conexion.JwtConfiguracion.JwtIssuer,
        ValidAudience = Conexion.JwtConfiguracion.JwtAudience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Conexion.JwtConfiguracion.JwtKey))
    }
    
    ;

});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseCors("NuevaPolitica");


app.UseHttpsRedirection();

//ya  no con swagger
app.UseStaticFiles();
app.UseRouting();

//// uso de autenticacion
app.UseAuthentication();

app.UseAuthorization();

//ya  no con swagger
app.MapControllers();

app.Run();
