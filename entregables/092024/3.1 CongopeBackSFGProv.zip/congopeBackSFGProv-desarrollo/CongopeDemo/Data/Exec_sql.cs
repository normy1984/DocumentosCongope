﻿using Congope.Empresas.BussinessLogic.Genericas;
using Newtonsoft.Json;
using Npgsql;
using System.Data;
using System.Reflection;

namespace Congope.Empresas.Data
{
    public class Exec_sql
    {
        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato Model de acuerdo a una declaracion de un modelo
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosModel<ModelClass>(NpgsqlCommand Command)
        {
            try
            {
                List<ModelClass> listaGenerica = new List<ModelClass>();

                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();

                    using (NpgsqlDataReader dr = Command.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            listaGenerica = DataReaderMapToList<ModelClass>(dr);
                        }
                        else
                        {
                            return new
                            {
                                success = false,
                                message = "No existen registros",
                                result = ""
                            };
                        }
                    }
                }

                return new
                {
                    success = true,
                    message = "Success",
                    result = listaGenerica
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato JSON
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosJson(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();

                    DataTable listaGenerica = new DataTable();

                    using (NpgsqlDataReader dr = Command.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            listaGenerica.Load(dr);
                        }
                        else
                        {
                            return new
                            {
                                success = false,
                                message = "Error: No existen registros",
                                result = JsonConvert.SerializeObject(new object[0])
                            };
                        }
                    }

                    return new
                    {
                        success = true,
                        message = "Success",
                        result = JsonConvert.SerializeObject(listaGenerica)
                    };
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuery(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.Connection = oConexion;
                    oConexion.Open();
                    int rowsAffected = Command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return new
                        {
                            success = true,
                            message = "Se guardaron correctamente " + rowsAffected + " registros.",
                            result = ""
                        };
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: La actualización no afectó ninguna fila.",
                            result = ""
                        };
                    }
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }


        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuerySP(NpgsqlCommand Command)
        {
            try
            {
                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    Command.CommandType = CommandType.StoredProcedure;
                    Command.Connection = oConexion;
                    oConexion.Open();
                    int rowsAffected = Command.ExecuteNonQuery();

                    if (rowsAffected != 0)
                    {
                        return new
                        {
                            success = true,
                            message = "El comando se ejecutó en el servidor.",
                            result = ""
                        };
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: El comando no se ejecutó en el servidor.",
                            result = ""
                        };
                    }
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que permite la eliminacion de un registro en el servidor
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQueryDelete(NpgsqlCommand Command)
        {
            try
            {
                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.Connection = oConexion;
                oConexion.Open();

                bool deleted = (bool)Command.ExecuteScalar();

                oConexion.Close();

                return new
                {
                    success = deleted,
                    message = deleted ? "Registro eliminado exitosamente" : "No se pudo eliminar el registro"
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message
                };
            }
        }

        /// <summary>
        /// Funcion que convierte un modelo de datos en un modelo declarado previamente
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static List<ModelClass> DataReaderMapToList<ModelClass>(IDataReader dr)
        {
            List<ModelClass> list = new List<ModelClass>();
            ModelClass obj = default(ModelClass);

            // Obtener los nombres de las columnas y convertirlos a minúsculas
            List<string> columnNames = Enumerable.Range(0, dr.FieldCount)
                                                 .Select(i => dr.GetName(i).ToLower())
                                                 .ToList();

            // Obtener los tipos de datos de las propiedades del modelo
            PropertyInfo[] props = typeof(ModelClass).GetProperties();

            while (dr.Read())
            {
                obj = Activator.CreateInstance<ModelClass>();

                foreach (PropertyInfo prop in props)
                {
                    string propName = prop.Name.ToLower();

                    if (columnNames.Contains(propName) && !dr.IsDBNull(columnNames.IndexOf(propName)))
                    {
                        object value = dr.GetValue(columnNames.IndexOf(propName));

                        if (value != DBNull.Value)
                        {
                            // Convertir el valor según el tipo de la propiedad
                            if (prop.PropertyType == typeof(string))
                            {
                                prop.SetValue(obj, Convert.ToString(value).Trim(), null);
                            }
                            else if (prop.PropertyType == typeof(int))
                            {
                                prop.SetValue(obj, Convert.ToInt32(value), null);
                            }
                            else if (prop.PropertyType == typeof(float))
                            {
                                prop.SetValue(obj, Convert.ToSingle(value), null);
                            }
                            // Añadir aquí más conversiones según necesidad (por ejemplo, para tipos DateTime, double, etc.)
                            else
                            {
                                prop.SetValue(obj, value, null);
                            }
                        }
                    }
                    else
                    {
                        // Asignar valor nulo si la columna no está presente en el resultado
                        prop.SetValue(obj, null);
                    }
                }

                list.Add(obj);
            }

            return list;
        }

    }
}
