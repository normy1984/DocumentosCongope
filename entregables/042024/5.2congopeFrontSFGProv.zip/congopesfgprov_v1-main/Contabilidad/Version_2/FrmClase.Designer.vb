﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmClase
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmClase))
        Me.LblTitulo = New System.Windows.Forms.Label()
        Me.TxtPk = New System.Windows.Forms.TextBox()
        Me.PnlControles = New System.Windows.Forms.Panel()
        Me.CmdEliminar = New System.Windows.Forms.Button()
        Me.CmdBuscar = New System.Windows.Forms.Button()
        Me.CmdEditar = New System.Windows.Forms.Button()
        Me.CmdNuevo = New System.Windows.Forms.Button()
        Me.CmdImprimir = New System.Windows.Forms.Button()
        Me.ChkNuevoEditar = New System.Windows.Forms.CheckBox()
        Me.ChkNoHabilitar = New System.Windows.Forms.CheckBox()
        Me.CmdCancelar = New System.Windows.Forms.Button()
        Me.CmdGrabar = New System.Windows.Forms.Button()
        Me.CmdAprobar = New System.Windows.Forms.Button()
        Me.CmdDesaprobar = New System.Windows.Forms.Button()
        Me.TxtEstado = New System.Windows.Forms.TextBox()
        Me.LblEstado = New System.Windows.Forms.Label()
        Me.PnlNavegacion = New System.Windows.Forms.Panel()
        Me.CmdFinal = New System.Windows.Forms.Button()
        Me.CmdDerecha = New System.Windows.Forms.Button()
        Me.CmdIzquierda = New System.Windows.Forms.Button()
        Me.CmdInicio = New System.Windows.Forms.Button()
        Me.CmdSalir = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PnlControles.SuspendLayout()
        Me.PnlNavegacion.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblTitulo
        '
        Me.LblTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTitulo.Location = New System.Drawing.Point(7, 4)
        Me.LblTitulo.Name = "LblTitulo"
        Me.LblTitulo.Size = New System.Drawing.Size(861, 23)
        Me.LblTitulo.TabIndex = 2
        Me.LblTitulo.Text = "TITULO"
        Me.LblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TxtPk
        '
        Me.TxtPk.Location = New System.Drawing.Point(12, 9)
        Me.TxtPk.Name = "TxtPk"
        Me.TxtPk.Size = New System.Drawing.Size(100, 20)
        Me.TxtPk.TabIndex = 3
        Me.TxtPk.Visible = False
        '
        'PnlControles
        '
        Me.PnlControles.Controls.Add(Me.CmdEliminar)
        Me.PnlControles.Controls.Add(Me.CmdBuscar)
        Me.PnlControles.Controls.Add(Me.CmdEditar)
        Me.PnlControles.Controls.Add(Me.CmdNuevo)
        Me.PnlControles.Controls.Add(Me.CmdImprimir)
        Me.PnlControles.Controls.Add(Me.ChkNuevoEditar)
        Me.PnlControles.Controls.Add(Me.ChkNoHabilitar)
        Me.PnlControles.Controls.Add(Me.CmdCancelar)
        Me.PnlControles.Controls.Add(Me.CmdGrabar)
        Me.PnlControles.Controls.Add(Me.CmdAprobar)
        Me.PnlControles.Controls.Add(Me.CmdDesaprobar)
        Me.PnlControles.Controls.Add(Me.TxtEstado)
        Me.PnlControles.Location = New System.Drawing.Point(12, 392)
        Me.PnlControles.Name = "PnlControles"
        Me.PnlControles.Size = New System.Drawing.Size(524, 64)
        Me.PnlControles.TabIndex = 4
        '
        'CmdEliminar
        '
        Me.CmdEliminar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdEliminar.Image = Global.SFGProv.My.Resources.Resources.btn_eliminar1
        Me.CmdEliminar.Location = New System.Drawing.Point(331, 1)
        Me.CmdEliminar.Name = "CmdEliminar"
        Me.CmdEliminar.Size = New System.Drawing.Size(80, 59)
        Me.CmdEliminar.TabIndex = 12
        Me.CmdEliminar.Text = "Eliminar"
        Me.CmdEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdEliminar.UseVisualStyleBackColor = True
        '
        'CmdBuscar
        '
        Me.CmdBuscar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdBuscar.Image = Global.SFGProv.My.Resources.Resources.btn_buscar
        Me.CmdBuscar.Location = New System.Drawing.Point(167, 1)
        Me.CmdBuscar.Name = "CmdBuscar"
        Me.CmdBuscar.Size = New System.Drawing.Size(80, 59)
        Me.CmdBuscar.TabIndex = 11
        Me.CmdBuscar.Text = "Buscar"
        Me.CmdBuscar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdBuscar.UseVisualStyleBackColor = True
        '
        'CmdEditar
        '
        Me.CmdEditar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdEditar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdEditar.Image = Global.SFGProv.My.Resources.Resources.btn_editar
        Me.CmdEditar.Location = New System.Drawing.Point(85, 1)
        Me.CmdEditar.Name = "CmdEditar"
        Me.CmdEditar.Size = New System.Drawing.Size(80, 59)
        Me.CmdEditar.TabIndex = 9
        Me.CmdEditar.Text = "Editar"
        Me.CmdEditar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdEditar.UseVisualStyleBackColor = True
        '
        'CmdNuevo
        '
        Me.CmdNuevo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdNuevo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdNuevo.Image = CType(resources.GetObject("CmdNuevo.Image"), System.Drawing.Image)
        Me.CmdNuevo.Location = New System.Drawing.Point(3, 1)
        Me.CmdNuevo.Name = "CmdNuevo"
        Me.CmdNuevo.Size = New System.Drawing.Size(80, 59)
        Me.CmdNuevo.TabIndex = 7
        Me.CmdNuevo.Text = "Nuevo"
        Me.CmdNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdNuevo.UseVisualStyleBackColor = True
        '
        'CmdImprimir
        '
        Me.CmdImprimir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdImprimir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdImprimir.Image = Global.SFGProv.My.Resources.Resources.btn_imprimir
        Me.CmdImprimir.Location = New System.Drawing.Point(249, 1)
        Me.CmdImprimir.Name = "CmdImprimir"
        Me.CmdImprimir.Size = New System.Drawing.Size(80, 59)
        Me.CmdImprimir.TabIndex = 6
        Me.CmdImprimir.Text = "Imprimir"
        Me.CmdImprimir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdImprimir.UseVisualStyleBackColor = True
        '
        'ChkNuevoEditar
        '
        Me.ChkNuevoEditar.AutoSize = True
        Me.ChkNuevoEditar.Location = New System.Drawing.Point(77, 56)
        Me.ChkNuevoEditar.Name = "ChkNuevoEditar"
        Me.ChkNuevoEditar.Size = New System.Drawing.Size(85, 17)
        Me.ChkNuevoEditar.TabIndex = 13
        Me.ChkNuevoEditar.Text = "NuevoEditar"
        Me.ChkNuevoEditar.UseVisualStyleBackColor = True
        Me.ChkNuevoEditar.Visible = False
        '
        'ChkNoHabilitar
        '
        Me.ChkNoHabilitar.AutoSize = True
        Me.ChkNoHabilitar.Location = New System.Drawing.Point(3, 56)
        Me.ChkNoHabilitar.Name = "ChkNoHabilitar"
        Me.ChkNoHabilitar.Size = New System.Drawing.Size(81, 17)
        Me.ChkNoHabilitar.TabIndex = 14
        Me.ChkNoHabilitar.Text = "No Habilitar"
        Me.ChkNoHabilitar.UseVisualStyleBackColor = True
        Me.ChkNoHabilitar.Visible = False
        '
        'CmdCancelar
        '
        Me.CmdCancelar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdCancelar.Image = Global.SFGProv.My.Resources.Resources.btn_cancelar
        Me.CmdCancelar.Location = New System.Drawing.Point(85, 1)
        Me.CmdCancelar.Name = "CmdCancelar"
        Me.CmdCancelar.Size = New System.Drawing.Size(80, 59)
        Me.CmdCancelar.TabIndex = 10
        Me.CmdCancelar.Text = "Cancelar"
        Me.CmdCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdCancelar.UseVisualStyleBackColor = True
        Me.CmdCancelar.Visible = False
        '
        'CmdGrabar
        '
        Me.CmdGrabar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdGrabar.Image = Global.SFGProv.My.Resources.Resources.btn_grabar
        Me.CmdGrabar.Location = New System.Drawing.Point(3, 1)
        Me.CmdGrabar.Name = "CmdGrabar"
        Me.CmdGrabar.Size = New System.Drawing.Size(80, 59)
        Me.CmdGrabar.TabIndex = 8
        Me.CmdGrabar.Text = "Grabar"
        Me.CmdGrabar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdGrabar.UseVisualStyleBackColor = True
        Me.CmdGrabar.Visible = False
        '
        'CmdAprobar
        '
        Me.CmdAprobar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdAprobar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdAprobar.Image = Global.SFGProv.My.Resources.Resources.btn_aprobar
        Me.CmdAprobar.Location = New System.Drawing.Point(440, 1)
        Me.CmdAprobar.Name = "CmdAprobar"
        Me.CmdAprobar.Size = New System.Drawing.Size(80, 59)
        Me.CmdAprobar.TabIndex = 15
        Me.CmdAprobar.Text = "Aprobar"
        Me.CmdAprobar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdAprobar.UseVisualStyleBackColor = True
        Me.CmdAprobar.Visible = False
        '
        'CmdDesaprobar
        '
        Me.CmdDesaprobar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdDesaprobar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDesaprobar.Image = Global.SFGProv.My.Resources.Resources.btn_desaprobar
        Me.CmdDesaprobar.Location = New System.Drawing.Point(440, 1)
        Me.CmdDesaprobar.Name = "CmdDesaprobar"
        Me.CmdDesaprobar.Size = New System.Drawing.Size(80, 59)
        Me.CmdDesaprobar.TabIndex = 16
        Me.CmdDesaprobar.Text = "Desaprobar"
        Me.CmdDesaprobar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdDesaprobar.UseVisualStyleBackColor = True
        Me.CmdDesaprobar.Visible = False
        '
        'TxtEstado
        '
        Me.TxtEstado.Location = New System.Drawing.Point(472, 40)
        Me.TxtEstado.Name = "TxtEstado"
        Me.TxtEstado.Size = New System.Drawing.Size(49, 20)
        Me.TxtEstado.TabIndex = 17
        Me.TxtEstado.Text = "0"
        Me.TxtEstado.Visible = False
        '
        'LblEstado
        '
        Me.LblEstado.AutoSize = True
        Me.LblEstado.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblEstado.Location = New System.Drawing.Point(956, 4)
        Me.LblEstado.Name = "LblEstado"
        Me.LblEstado.Size = New System.Drawing.Size(23, 17)
        Me.LblEstado.TabIndex = 5
        Me.LblEstado.Text = "..."
        Me.LblEstado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PnlNavegacion
        '
        Me.PnlNavegacion.AutoSize = True
        Me.PnlNavegacion.Controls.Add(Me.CmdFinal)
        Me.PnlNavegacion.Controls.Add(Me.CmdDerecha)
        Me.PnlNavegacion.Controls.Add(Me.CmdIzquierda)
        Me.PnlNavegacion.Controls.Add(Me.CmdInicio)
        Me.PnlNavegacion.Location = New System.Drawing.Point(26, 346)
        Me.PnlNavegacion.Name = "PnlNavegacion"
        Me.PnlNavegacion.Size = New System.Drawing.Size(166, 40)
        Me.PnlNavegacion.TabIndex = 6
        '
        'CmdFinal
        '
        Me.CmdFinal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdFinal.Image = Global.SFGProv.My.Resources.Resources.Btn_04_final
        Me.CmdFinal.Location = New System.Drawing.Point(125, 1)
        Me.CmdFinal.Name = "CmdFinal"
        Me.CmdFinal.Size = New System.Drawing.Size(38, 36)
        Me.CmdFinal.TabIndex = 19
        Me.CmdFinal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdFinal.UseVisualStyleBackColor = True
        '
        'CmdDerecha
        '
        Me.CmdDerecha.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdDerecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDerecha.Image = Global.SFGProv.My.Resources.Resources.Btn_03_Derecha
        Me.CmdDerecha.Location = New System.Drawing.Point(83, 1)
        Me.CmdDerecha.Name = "CmdDerecha"
        Me.CmdDerecha.Size = New System.Drawing.Size(38, 36)
        Me.CmdDerecha.TabIndex = 18
        Me.CmdDerecha.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdDerecha.UseVisualStyleBackColor = True
        '
        'CmdIzquierda
        '
        Me.CmdIzquierda.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdIzquierda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdIzquierda.Image = Global.SFGProv.My.Resources.Resources.Btn_02_izquierda
        Me.CmdIzquierda.Location = New System.Drawing.Point(42, 1)
        Me.CmdIzquierda.Name = "CmdIzquierda"
        Me.CmdIzquierda.Size = New System.Drawing.Size(38, 36)
        Me.CmdIzquierda.TabIndex = 17
        Me.CmdIzquierda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdIzquierda.UseVisualStyleBackColor = True
        '
        'CmdInicio
        '
        Me.CmdInicio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdInicio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdInicio.Image = Global.SFGProv.My.Resources.Resources.Btn_01_inicio
        Me.CmdInicio.Location = New System.Drawing.Point(2, 1)
        Me.CmdInicio.Name = "CmdInicio"
        Me.CmdInicio.Size = New System.Drawing.Size(38, 36)
        Me.CmdInicio.TabIndex = 16
        Me.CmdInicio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdInicio.UseVisualStyleBackColor = True
        '
        'CmdSalir
        '
        Me.CmdSalir.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CmdSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSalir.Image = Global.SFGProv.My.Resources.Resources._exit
        Me.CmdSalir.Location = New System.Drawing.Point(924, 399)
        Me.CmdSalir.Name = "CmdSalir"
        Me.CmdSalir.Size = New System.Drawing.Size(65, 57)
        Me.CmdSalir.TabIndex = 1
        Me.CmdSalir.Text = "Salir"
        Me.CmdSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdSalir.UseVisualStyleBackColor = True
        '
        'FrmClase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.CancelButton = Me.CmdSalir
        Me.ClientSize = New System.Drawing.Size(991, 465)
        Me.Controls.Add(Me.PnlNavegacion)
        Me.Controls.Add(Me.LblEstado)
        Me.Controls.Add(Me.PnlControles)
        Me.Controls.Add(Me.TxtPk)
        Me.Controls.Add(Me.LblTitulo)
        Me.Controls.Add(Me.CmdSalir)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmClase"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmClase"
        Me.PnlControles.ResumeLayout(False)
        Me.PnlControles.PerformLayout()
        Me.PnlNavegacion.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents CmdSalir As Button
    Public WithEvents LblTitulo As Label
    Friend WithEvents TxtPk As TextBox
    Public WithEvents CmdImprimir As Button
    Public WithEvents CmdNuevo As Button
    Public WithEvents CmdGrabar As Button
    Public WithEvents CmdEditar As Button
    Public WithEvents CmdCancelar As Button
    Public WithEvents CmdEliminar As Button
    Public WithEvents CmdBuscar As Button
    Public WithEvents ChkNuevoEditar As CheckBox
    Public WithEvents ChkNoHabilitar As CheckBox
    Public WithEvents PnlControles As Panel
    Public WithEvents CmdDesaprobar As Button
    Public WithEvents CmdAprobar As Button
    Friend WithEvents TxtEstado As TextBox
    Public WithEvents LblEstado As Label
    Public WithEvents CmdInicio As Button
    Public WithEvents CmdFinal As Button
    Public WithEvents CmdDerecha As Button
    Public WithEvents CmdIzquierda As Button
    Public WithEvents PnlNavegacion As Panel
    Friend WithEvents ToolTip1 As ToolTip
End Class
