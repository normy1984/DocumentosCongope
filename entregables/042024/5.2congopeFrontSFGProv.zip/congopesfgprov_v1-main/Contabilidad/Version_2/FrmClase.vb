﻿Public Class FrmClase
    Public bAprueba = False
    Public bDesaprueba = False
    Public Sub HabilitarClass(bValBoolean As Boolean)
        Me.CmdNuevo.Visible = Not bValBoolean
        Me.CmdEditar.Visible = Not bValBoolean
        Me.CmdGrabar.Visible = bValBoolean
        Me.CmdCancelar.Visible = bValBoolean

        Me.CmdEliminar.Enabled = Not bValBoolean
        Me.CmdBuscar.Enabled = Not bValBoolean
        Me.CmdImprimir.Enabled = Not bValBoolean
        Me.CmdSalir.Enabled = Not bValBoolean

        Me.CmdAprobar.Enabled = Not bValBoolean
        Me.CmdDesaprobar.Enabled = Not bValBoolean

        Me.PnlNavegacion.Enabled = Not bValBoolean
    End Sub

    Private Sub CmdSalir_Click(sender As Object, e As EventArgs) Handles CmdSalir.Click
        Me.Close()
    End Sub

    Private Sub Grabar()

    End Sub
    Private Sub Nuevo()

    End Sub
    Private Sub Editar()

    End Sub
    Private Sub Cancelar()

    End Sub

    Private Sub FrmClase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.LblEstado.Location = New Point(Me.Width - (Me.LblEstado.Width + 120), 0)

        Me.LblTitulo.Location = New Point(0, 0)
        Me.LblTitulo.Width = Me.Width
        Mdl_EjeForm.InicializaObjetosForm(Me, Me.PnlControles)
        Me.Text = Me.LblTitulo.Text
        Me.ToolTip1.SetToolTip(Me.CmdInicio, "Registro Inicial")
    End Sub

    Private Sub CmdBuscar_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CmdImprimir_Click(sender As Object, e As EventArgs) Handles CmdImprimir.Click
        If Val(Me.TxtPk.Text) = 0 Then
            Exit Sub
        End If
    End Sub

    Private Sub CmdNuevo_Click(sender As Object, e As EventArgs) Handles CmdNuevo.Click
        Me.ChkNuevoEditar.Checked = False
        Call HabilitarClass(True)
        Call Nuevo()
    End Sub

    Private Sub CmdGrabar_Click(sender As Object, e As EventArgs) Handles CmdGrabar.Click
        If Val(Me.TxtPk.Text) = 0 Or Me.ChkNoHabilitar.Checked = True Then
            Exit Sub
        End If
        Call HabilitarClass(False)
        Call Grabar()
    End Sub

    Private Sub CmdEditar_Click(sender As Object, e As EventArgs) Handles CmdEditar.Click
        Me.ChkNuevoEditar.Checked = True
        If Val(Me.TxtPk.Text) = 0 Then
            Exit Sub
        End If

        Call HabilitarClass(True)
        Call Editar()
    End Sub

    Private Sub CmdCancelar_Click(sender As Object, e As EventArgs) Handles CmdCancelar.Click
        Call HabilitarClass(False)
        Call Cancelar()
    End Sub

    Private Sub CmdEliminar_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ValidaEstadoClass()

        If (vgEsUsuarioConsulta = 3) Then
            Me.CmdAprobar.Visible = False
            Me.CmdDesaprobar.Visible = False
            Exit Sub
        End If

        Select Case Val(Me.TxtEstado.Text)
            Case 0
                Me.CmdAprobar.Visible = False
                Me.CmdDesaprobar.Visible = False
                Me.LblEstado.Text = "..."
            Case 3
                Me.CmdAprobar.Visible = False
                If (bDesaprueba = True) Then
                    Me.CmdDesaprobar.Visible = True
                End If
                Me.LblEstado.Text = "APROBADO"
                Me.LblEstado.ForeColor = Color.Blue
            Case Else
                If (bAprueba = True) Then
                    Me.CmdAprobar.Visible = True
                End If

                Me.CmdDesaprobar.Visible = False
                Me.LblEstado.Text = "CUADRADO"
                Me.LblEstado.ForeColor = Color.Red
        End Select

    End Sub

    Private Sub TxtEstado_TextChanged(sender As Object, e As EventArgs) Handles TxtEstado.TextChanged
        Call ValidaEstadoClass()
    End Sub
End Class