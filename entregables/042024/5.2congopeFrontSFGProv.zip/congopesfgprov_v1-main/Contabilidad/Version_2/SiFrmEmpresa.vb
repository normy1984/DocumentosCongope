﻿Public Class SiFrmEmpresa
    Inherits FrmClase
    Private Sub SiFrmEmpresa_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub
    Private Overloads Sub Habilitar(bValBoolean As Boolean)
        Me.txtemail1.Enabled = bValBoolean
        Me.Txtautoret.Enabled = bValBoolean
        Me.Txtaut_liq_comp.Enabled = bValBoolean
        Me.Txtciudad.Enabled = bValBoolean
        Me.Txtcontrib_espe.Enabled = bValBoolean
        Me.Txtcont_emp.Enabled = bValBoolean
        Me.Txtdfin_emp.Enabled = bValBoolean
        Me.Txtdfin_ruc.Enabled = bValBoolean
        Me.Txtdir_emp.Enabled = bValBoolean
        Me.Txtfax1_emp.Enabled = bValBoolean
        Me.Txtnomcomercial.Enabled = bValBoolean
        Me.Txtnom_emp.Enabled = bValBoolean
        Me.Txtprovincia.Enabled = bValBoolean
        Me.Txtrep_emp.Enabled = bValBoolean
        Me.Txtrep_ruc.Enabled = bValBoolean
        Me.Txtruc_emp.Enabled = bValBoolean
        Me.Txttel1_emp.Enabled = bValBoolean
        Me.Txtserieret.Enabled = bValBoolean
        Me.Txttel2_emp.Enabled = bValBoolean
        Me.Txtteso_ruc.Enabled = bValBoolean
        Me.Txtcont_ruc.Enabled = bValBoolean
        Me.CmdBuscaLogotipo.Enabled = bValBoolean

        Me.CmdNuevo.Visible = False

    End Sub

    Private Sub CmdNuevo_Click(sender As Object, e As EventArgs) Handles CmdNuevo.Click
        Me.ChkNuevoEditar.Checked = False
        Call Habilitar(True)
    End Sub

    Private Sub CmdEditar_Click(sender As Object, e As EventArgs) Handles CmdEditar.Click
        If (Me.TxtCodEmp.Text.ToString.Trim.Length = 0) Then
            Exit Sub
        End If

        Me.ChkNuevoEditar.Checked = True
        Call Habilitar(True)

    End Sub

    Private Sub CmdBuscar_Click(sender As Object, e As EventArgs) Handles CmdBuscar.Click
        Call ConsultarDatos("0004")
    End Sub

    Private Sub CmdSalir_Click(sender As Object, e As EventArgs) Handles CmdSalir.Click

    End Sub

    Private Sub CmdImprimir_Click(sender As Object, e As EventArgs) Handles CmdImprimir.Click
    End Sub

    Private Sub CmdGrabar_Click_1(sender As Object, e As EventArgs) Handles CmdGrabar.Click
        Call Habilitar(False)

        Sql = "select * from coempre where codemp = '" & Me.TxtCodEmp.Text.Trim & "'"
        RsSql = Bdd.RetornaTabla(Sql)
        If RsSql.Rows.Count = 0 Then
            RsSql.Rows.Add()
            RsSql.Rows(0).Item("codemp") = Me.TxtCodEmp.Text.ToString
            Bdd.Insertar(RsSql, "coempre")
        End If

        RsSql.Rows(0).Item("nom_emp") = Me.Txtnom_emp.Text.ToString
        RsSql.Rows(0).Item("ruc_emp") = Me.Txtruc_emp.Text.ToString
        RsSql.Rows(0).Item("dir_emp") = Me.Txtdir_emp.Text.ToString
        RsSql.Rows(0).Item("tel1_emp") = Me.Txttel1_emp.Text.ToString
        RsSql.Rows(0).Item("tel2_emp") = Me.Txttel2_emp.Text.ToString
        RsSql.Rows(0).Item("fax1_emp") = Me.Txtfax1_emp.Text.ToString
        RsSql.Rows(0).Item("email1") = Me.txtemail1.Text.ToString
        RsSql.Rows(0).Item("rep_emp") = Me.Txtrep_emp.Text.ToString
        RsSql.Rows(0).Item("rep_ruc") = Me.Txtrep_ruc.Text.ToString
        RsSql.Rows(0).Item("cont_emp") = Me.Txtcont_emp.Text.ToString
        RsSql.Rows(0).Item("cont_ruc") = Me.Txtcont_ruc.Text.ToString
        RsSql.Rows(0).Item("serieret") = Me.Txtserieret.Text.ToString
        RsSql.Rows(0).Item("autoret") = Me.Txtautoret.Text.ToString
        RsSql.Rows(0).Item("ciudad") = Me.Txtciudad.Text.ToString
        RsSql.Rows(0).Item("nomcomercial") = Me.Txtnomcomercial.Text.ToString
        RsSql.Rows(0).Item("contrib_espe") = Me.Txtcontrib_espe.Text.ToString
        RsSql.Rows(0).Item("provincia") = Me.Txtprovincia.Text.ToString
        RsSql.Rows(0).Item("dfin_emp") = Me.Txtdfin_emp.Text.ToString
        RsSql.Rows(0).Item("dfin_ruc") = Me.Txtdfin_ruc.Text.ToString
        RsSql.Rows(0).Item("teso_emp") = Me.Txtteso_emp.Text.ToString
        RsSql.Rows(0).Item("teso_ruc") = Me.Txtteso_ruc.Text.ToString
        RsSql.Rows(0).Item("aut_liq_comp") = Me.Txtaut_liq_comp.Text.ToString
        RsSql.Rows(0).Item("pathlogo") = Me.TxtPathLogo.Text.ToString

        Bdd.Actualizar(RsSql, "coempre", " where codemp = '" & vgEmpresa & "' ")


    End Sub

    Private Sub CmdCancelar_Click_1(sender As Object, e As EventArgs) Handles CmdCancelar.Click
        Call Habilitar(False)
    End Sub
    Private Sub ConsultarDatos(nIdPri As String)
        Try
            Sql = "select * from coempre where codemp = '" & nIdPri & "'"
            RsSql = Bdd.RetornaTabla(Sql)
            If RsSql.Rows.Count > 0 Then
                Me.TxtPk.Text = RsSql.Rows(0).Item("codemp").ToString().Trim
                Me.TxtCodEmp.Text = RsSql.Rows(0).Item("codemp").ToString().Trim
                Me.txtemail1.Text = RsSql.Rows(0).Item("email1").ToString().Trim
                Me.Txtautoret.Text = RsSql.Rows(0).Item("autoret").ToString().Trim
                Me.Txtaut_liq_comp.Text = RsSql.Rows(0).Item("aut_liq_comp").ToString().Trim
                Me.Txtciudad.Text = RsSql.Rows(0).Item("ciudad").ToString().Trim
                Me.Txtcontrib_espe.Text = RsSql.Rows(0).Item("contrib_espe").ToString().Trim
                Me.Txtcont_emp.Text = RsSql.Rows(0).Item("cont_emp").ToString().Trim
                Me.Txtdfin_emp.Text = RsSql.Rows(0).Item("dfin_emp").ToString().Trim
                Me.Txtdfin_ruc.Text = RsSql.Rows(0).Item("dfin_ruc").ToString().Trim
                Me.Txtdir_emp.Text = RsSql.Rows(0).Item("dir_emp").ToString().Trim
                Me.Txtfax1_emp.Text = RsSql.Rows(0).Item("fax1_emp").ToString().Trim
                Me.Txtnomcomercial.Text = RsSql.Rows(0).Item("nomcomercial").ToString().Trim
                Me.Txtnom_emp.Text = RsSql.Rows(0).Item("nom_emp").ToString().Trim
                Me.Txtprovincia.Text = RsSql.Rows(0).Item("provincia").ToString().Trim
                Me.Txtrep_emp.Text = RsSql.Rows(0).Item("rep_emp").ToString().Trim
                Me.Txtrep_ruc.Text = RsSql.Rows(0).Item("rep_ruc").ToString().Trim
                Me.Txtruc_emp.Text = RsSql.Rows(0).Item("ruc_emp").ToString().Trim
                Me.Txttel1_emp.Text = RsSql.Rows(0).Item("tel1_emp").ToString().Trim
                Me.Txtserieret.Text = RsSql.Rows(0).Item("serieret").ToString().Trim
                Me.Txttel2_emp.Text = RsSql.Rows(0).Item("tel2_emp").ToString().Trim
                Me.Txtteso_ruc.Text = RsSql.Rows(0).Item("teso_ruc").ToString().Trim
                Me.Txtcont_ruc.Text = RsSql.Rows(0).Item("cont_ruc").ToString().Trim
                Me.TxtPathLogo.Text = RsSql.Rows(0).Item("pathlogo").ToString().Trim

                Dim img As New Bitmap(vgDirImagenes + Me.TxtPathLogo.Text.Trim)
                Me.PbxLogotipo.Image = img


            End If

        Catch ex As Exception
            MessageBox.Show(Err.Description)
        End Try
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles CmdBuscaLogotipo.Click
        Dim FileName As String
        Dim openFileDialog1 As New OpenFileDialog
        openFileDialog1.InitialDirectory = vgDirImagenes
        openFileDialog1.Filter = "Imagenes (*.jpg,*.png)|*.jpg;*.png"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            FileName = openFileDialog1.FileName
            Dim nFin_path As Integer = InStrRev(FileName, "\")

            FileName = Mid(FileName, nFin_path + 1, Len(FileName) - nFin_path)

            Me.TxtPathLogo.Text = FileName
            Dim img As New Bitmap(vgDirImagenes + FileName)
            Me.PbxLogotipo.Image = img
        End If
    End Sub
End Class
