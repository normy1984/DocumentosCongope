﻿Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports Microsoft.SqlServer
Imports Org.BouncyCastle.Asn1.X509

Public Class IA_Frm_Ingreso_Bodega

    Dim wArchCabe As String
    Dim wArchDeta As String
    Dim sPlacta As String
    Dim nRegistroMin As Integer, nRegistroMax As Integer
    Dim sSigTipAct As String
    Dim wPorcentajeIvaItem As Double
    Dim sVistaSActual As String
    Private Sub IA_Frm_Ingreso_Bodega_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sSigTipAct = "IB"
        Bdd.MinMaxTabla("incabmov", "acu_tip", sSigTipAct)
        Me.bAprueba = RetornaPerimiteAprobDesaprob(sSigTipAct, 1)
        Me.bDesaprueba = RetornaPerimiteAprobDesaprob(sSigTipAct, 2)
        Call InicializaFormulario()
    End Sub

    Private Sub InicializaFormulario()
        Dim nCodigoParametroIB As Integer

        Call Utilitarios.SacaMinMaxTabla(IIf(vgCodSistema = 3, "incabmov", "accabmov"), "IB", nRegistroMin, nRegistroMax)
        Dim wPorcentajeIvaLocal = vgPorcentajeIva

        Call NodevIva()

        'Me.TxtCiudad.Text = Trim$(UCase(Funciones.RetornaCiudadEmpresa))
        '    If Me.TxtCiudad.Text = UCase("Orellana") Then
        '        Me.TxtSecuencia.Visible = True
        '        Me.Label1(2).Visible = True
        '    End If


        Me.CmdAprobar.Visible = RetornaPerimiteAprobDesaprob("IB", 1)
        Me.CmdDesaprobar.Visible = RetornaPerimiteAprobDesaprob("IB", 2)
        Me.CmdAnular.Visible = RetornaPerimiteAprobDesaprob("IB", 2)

        Me.Txtsig_tip.Text = "IB"
        Dim fFechaAct = Funciones.RetornaFechaReportes(2)
        Me.fecha_ib.Value = fFechaAct
        Me.fecha_factura.Value = fFechaAct

        Funciones.CargarCombos(Me.CmbTipoDocum, 138, 1)

        Me.Txtestable.Text = "001"
        Me.Txtpunto_emi.Text = "001"
        nCodigoParametroIB = 9

        wArchCabe = "incabmov"
        wArchDeta = "indetmov"
        sPlacta = "inplacta"
        sVistaSActual = "saldo_act_in"

        Me.CntMaquinaria.Visible = False
        If (vgCodSistema = 3) Then
            Dim nAsociaMaquinaria = Bdd.RetornaParametroSistema(44)
            If nAsociaMaquinaria = 1 Then
                Me.CntMaquinaria.Visible = True
            End If
        End If

        '    If (wCodSistema = 5) Then
        '        wArchCabe = "accabmov"
        '        wArchDeta = "acdetmov"
        '        sPlacta = "acplacta"
        '        sVistaSActual = "saldo_act_ac"
        '        Me.LblTitulo.Caption = "INGRESO A BODEGA - ACTIVOS FIJOS"
        '        Me.ChkSujetosControl.Visible = True
        '        Me.CmdGenerarDBF.Visible = True
        '        nCodigoParametroIB = 11

        '        nParamTiempo = Mod_Utilitarios.RetornaParametroSistema(18)
        '        Me.TxtPideTiempoGarantia.Text = nParamTiempo
        '    End If

        Dim nParamDocEscan = Bdd.RetornaParametroSistema(nCodigoParametroIB)
        If nParamDocEscan = 1 Then
            Me.CmdDocEscaneados.Visible = True
        End If

        If (Bdd.RetornaParametroSistema(29)) = 1 Then
            Me.ChkAsociarNotaEnt.Checked = True
        End If

        '    PermiteVolverDigitado
        Me.Grid2.RowTemplate.Height = 15
    End Sub

    Private Sub Habilitar(bValorB As Boolean)
        Me.CmdBuscaDepartamento.Enabled = bValorB
        Me.CmdBuscaResponsable.Enabled = bValorB
        Me.CmdF4.Enabled = bValorB
        Me.fecha_ib.Enabled = bValorB
        Me.CmdBuscaProveedor.Enabled = bValorB
        Me.Txtestable.Enabled = bValorB
        Me.Txtpunto_emi.Enabled = bValorB
        Me.Txtfactura.Enabled = bValorB
        Me.TxtPtoLlega.Enabled = bValorB
        Me.fecha_factura.Enabled = bValorB
        Me.Panel1.Enabled = bValorB
        Me.Txtobserva.ReadOnly = Not bValorB
        Me.CmbTipoDocum.Enabled = bValorB
        Me.CntMaquinaria.Enabled = bValorB
        Me.CmdResumenCtaCnt.Enabled = Not bValorB
        Me.CmdDocEscaneados.Enabled = Not bValorB
        Me.ChkOpcionImprimir.Enabled = Not bValorB
    End Sub

    Private Sub CmdBuscar_Click(sender As Object, e As EventArgs) Handles CmdBuscar.Click
        IA_Frm_Busqueda_IB.ChkNoImprime.Checked = True
        IA_Frm_Busqueda_IB.ShowDialog()
        Dim nAcutip = Val(IA_Frm_Busqueda_IB.Tag)
        IA_Frm_Busqueda_IB.Close()

        If nAcutip = 0 Then
            Mensajes("Opcion Cancelada")
            Exit Sub
        End If

        Me.Txtsig_tip.Text = "IB"
        Me.Txtacu_tip.Text = nAcutip

        Call Consultar_Datos()
        Call HabilitaEstado()
    End Sub

    Private Sub NodevIva()
        Me.ChkNoDevIva.Checked = False
        cad = "select nodeviva as retorna from coempre where codemp = '" & vgEmpresa & "'"
        Dim nNoDevIva = Bdd.RetornaUnValor(cad)
        Me.ChkNoDevIva.Checked = IIf(nNoDevIva = 0, False, True)

    End Sub

    Private Sub Consultar_Datos()
        Dim RsCab As DataTable
        Me.TxtEstado.Text = 0
        Dim nCodUsuario = vgCodUsu

        'LimpiaObjetos

        RsCab = Nothing

        Dim sSigTip = Me.Txtsig_tip.Text
        Dim nAcutip = Me.Txtacu_tip.Text
        Me.TxtPk.Text = nAcutip

        Dim warchcab = "incabmov"
        If (vgCodSistema = 5) Then
            warchcab = "accabmov"
        End If

        Me.LblCpbteAsocia.Text = ""

        cad = "select b.descrip as proveedor, c.descrip as c_estado, d.descrip as forma_pago, e.descrip as tipo_doc, f.descrip as maquinaria, a.* " &
        "from " & warchcab & " a " &
        "left join ciu b on a.codemp = b.codemp and a.codcli02 = b.cedruc " &
        "left join tablas c on a.codemp = c.codemp and c.codtab = 2 and c.codigo > 0 and a.estado = c.codigo " &
        "left join tablas d on a.codemp = d.codemp and d.codtab = 36 and d.codigo > 0 and a.formpa02 = d.codigo " &
        "left join tablas e on a.codemp = e.codemp and e.codtab = 138 and e.codigo > 0 and a.tipodoc = e.codigo " &
        "left join tablas f on a.codemp = f.codemp and f.codtab = 26 and f.codigo > 0 and a.vehiculo = f.codigo " &
        "Where " & Funciones.GetEmp("a") &
        "and a.sig_tip = '" & sSigTip & "' " &
        "and acu_tip = " & nAcutip

        RsCab = Bdd.RetornaTabla(cad)

        If (RsCab.Rows.Count > 0) Then
            Dim westado = RsCab.Rows(0)("estado")
            Me.TxtEstado.Text = westado
            fecha_factura.Value = Funciones.FormatoFecha(RsCab.Rows(0)("fec_apr"))
            Me.Txtcedruc.Text = Trim$(RsCab.Rows(0)("codcli02"))
            Me.Txtcedruc_nombre.Text = Bdd.RetornaNobreCiu(Me.Txtcedruc.Text)

            Me.txtresponsa.Text = RsCab.Rows(0)("codrec02")
            Me.Txtresponsable.Text = RetornaDescripTabla(RsCab.Rows(0)("codrec02"), 54)

            'iva.Text = ret_blk(RsCab("impiva02"))
            Me.Txtdepartam.Text = RsCab.Rows(0)("bodrec02")
            Me.TxtDepartamento.Text = RetornaDescripTabla(RsCab.Rows(0)("bodrec02"), 19)
            Me.Check2.Checked = IIf(RsCab.Rows(0)("tiponc") = 1, True, False)

            Me.fecha_factura.Value = RsCab.Rows(0)("inictra")

            Me.ivapres.Text = Nvl(RsCab.Rows(0)("ivapres"), 0)
            Me.RET3XMI.Text = Nvl(RsCab.Rows(0)("ret3xmil"), 0)
            Me.wnrodias.Text = Val(Nvl(RsCab.Rows(0)("dias02"), 0))
            Me.Txtobserva.Text = Trim((RsCab.Rows(0)("observa")))
            Me.Txtestable.Text = Trim((RsCab.Rows(0)("serie1")))
            Me.Txtpunto_emi.Text = Trim((RsCab.Rows(0)("serie2")))
            Me.Txtfactura.Text = (RsCab.Rows(0)("factura"))
            Me.Txtsecuencia.Text = RsCab.Rows(0)("nropagos")

            Me.ChkSujetosControl.Checked = RsCab.Rows(0)("otros")
            nCodUsuario = Val(IIf(IsDBNull(RsCab.Rows(0)("cre_por")), 0, RsCab.Rows(0)("cre_por")))

            If Val(RsCab.Rows(0)("acu_tip1")) > 0 Then
                Me.LblCpbteAsocia.Text = Trim$(RsCab.Rows(0)("sig_tip1")) & "-" & Trim$(RsCab.Rows(0)("acu_tip1"))
                Me.LblCpbteAsocia.Visible = True
            End If

            Me.CmbTipoDocum.Text = Trim$(Nvl(RsCab.Rows(0)("tipo_doc"), "Factura"))

            Me.LblConsedoc.Text = ""
            If Me.LblConsedoc.Visible = True Then
                Me.LblConsedoc.Text = Bdd.RetornaNumeroConsedoc(Trim$(Me.Txtsig_tip.Text), Val(Me.Txtacu_tip.Text))
            End If
            Me.TxtPtoLlega.Text = Trim$(Nvl(RsCab.Rows(0)("ptollega"), ""))

            Me.TxtIdMaquinaria.Text = Nvl(RsCab.Rows(0)("vehiculo"), 0)
            Me.LblMaquinaria.Text = Bdd.RetornaDescripTabla(Val(Me.TxtIdMaquinaria.Text), 26)
        End If
        Me.ChkNoPropietario.Checked = False
        If nCodUsuario <> vgCodUsu Then
            Me.ChkNoPropietario.Checked = True
        End If

        Call RepresentaNotaEntregaAsociado(Me.Txtacu_tip.Text)

        LlenaDetalle()
    End Sub

    Private Sub RepresentaNotaEntregaAsociado(nAcuTipIb As Double)
        Dim rsT3 As DataTable
        If Me.ChkAsociarNotaEnt.Checked = False Or nAcuTipIb = 0 Then
            Exit Sub
        End If

        Dim nNtaId = 0
        Dim sNotaEntrega = ""
        Me.LblNotaEntrega.Visible = False
        Dim sSigTipIb = "IB"
        Dim sNroNota = "nte_establecimiento||'-'||nte_punto_emi||'-'||nte_nro_nota"

        cad = "select nte_id, cast(" & sNroNota & " as character(20)) as numero " &
        "from innte_cab " &
        "where nte_codemp = '" & vgEmpresa & "' " &
        "and nte_sig_tip_ib = '" & sSigTipIb & "' " &
        "and nte_acu_tip_ib = " & nAcuTipIb & " "

        rsT3 = Bdd.RetornaTabla(cad)
        If rsT3.Rows.Count > 0 Then
            nNtaId = rsT3.Rows(0)("nte_id")
            sNotaEntrega = Trim$(rsT3.Rows(0)("numero"))
        End If

        Me.TxtNte_Id.Text = nNtaId
        If nNtaId = 0 Then
            sNotaEntrega = ""
        End If
        Me.LblNotaEntrega.Text = "NOTA DE ENTREGA:" & sNotaEntrega
        Me.LblNotaEntrega.Visible = True
    End Sub

    Private Sub LlenaDetalle()
        Dim nSustotal12 As Double, nSustotal0 As Double, nSubTotal As Double, nTotalIva As Double, nTotalGeneral As Double
        Dim nSubTotalSinDes As Double, nTotalDesc As Double, nValorIvaXX As Double, nValorIva0 As Double, nValorDes As Double
        Dim nTotalDescIva As Double, nTotalDescSinIva As Double, nTotalConIva As Double, nTotalSinIva As Double, nTotal As Double, nDescuento As Double, nValorIva As Double, nSubtotal12 As Double
        Dim nIRBPNR As Double, nSubtotal0 As Double
        Me.Grid1.DataSource = Nothing
        Dim sSigTip = Me.Txtsig_tip.Text
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        nTotalDesc = 0
        nTotalDescIva = 0
        nTotalDescSinIva = 0
        nIRBPNR = 0
        Me.LblNroItems.Text = "Nro.Items: 0"
        Dim sNomCue = Funciones.Itm_Nombre("b")
        Dim sLeftJoinTablas = ""
        Dim sCampoUMedida = " cast('' as character(50)) "
        Dim sCampoCanXLote = " b.can_x_lote, "
        If vgCodSistema = 3 Then
            sCampoUMedida = " c.descrip "
            sLeftJoinTablas = "left join tablas c on a.codemp = c.codemp and c.codtab = 31 and c.codigo > 0 and b.embalaje = c.codigo "
            sNomCue = "b.nom_cue"
            sCampoCanXLote = ""
        End If

        cad = "select  a.cuenta, " & sNomCue & " as nom_cue, c.descrip as u_medida, 
        a.cantidb, a.descto03, a.costototreal, a.costototdesc, a.preciotot, a.costo103,
        (a.costo103 * a.cantidb) as total,  a.impiva03, a.precioven, 
        a.sec_det, a.tiponc
        from indetmov a 
        left join inplacta b on a.codemp = b.codemp and a.anio = b.anio and a.cuenta = b.cuenta 
        left join tablas c on a.codemp = c.codemp and c.codtab = 31 and c.codigo > 0 and b.embalaje = c.codigo 
        Where " & Funciones.GetEmp("a") & "  
        and a.sig_tip = '" & sSigTip & "' 
        and a.acu_tip = " & nAcutip & " 
        order by a.acu_tip, a.sec_det;"

        RsDet = Bdd.RetornaTabla(cad)

        If (RsDet.Rows.Count > 0) Then
            Me.Grid1.DataSource = RsDet

            Me.LblNroItems.Text = "Nro.Items: " & RsDet.Rows.Count
        End If

        For Each fila As DataGridViewRow In Me.Grid1.Rows
            nIRBPNR = nIRBPNR + (fila.Cells("precioven").Value * fila.Cells("cantidb").Value)
            If (Val(RsDet.Rows(0)("impiva03")) <> 0) Then
                nTotalDescIva = nTotalDescIva + (Val(fila.Cells("costototreal").Value) - Val(fila.Cells("costototdesc").Value))
            Else
                nTotalDescSinIva = nTotalDescSinIva + (Val(fila.Cells("costototreal").Value) - Val(fila.Cells("costototdesc").Value))
            End If
        Next

        ''DESGLOSE PORCENTAJE IVA
        Call RepresentaPorcentajesIVA()
        Dim nFilaTotal = Val(Me.Grid2.Tag)
        Dim wDecimalesL = 4

        nSubtotal12 = 0
        nSubtotal0 = 0
        nDescuento = 0
        nSubTotal = 0
        nValorIva = 0
        nTotal = 0

        If (nFilaTotal > 0) Then
            If (Me.Grid2.Rows(0).Cells("impiva03").Value.ToString.Trim = "0%") Then
                nSubtotal0 = Val(Me.Grid2.Rows(0).Cells("substotal").Value)
            End If

            nSubtotal12 = Round(Val(Me.Grid2.Rows(nFilaTotal).Cells("substotal").Value) - nSubtotal0, wDecimalesL)

            nDescuento = Val(Me.Grid2.Rows(nFilaTotal).Cells("descuento").Value) ' Val(Replace(Me.Grid2.TextMatrix(nFilaTotal, 3), ",", ""))
            nSubTotal = Val(Me.Grid2.Rows(nFilaTotal).Cells("substotal").Value)
            nValorIva = Val(Me.Grid2.Rows(nFilaTotal).Cells("valor_iva").Value)
            nTotal = Val(Me.Grid2.Rows(nFilaTotal).Cells("total").Value)
        End If


        Me.LblSubTotal12.Text = Funciones.FormatoNumeroSepara(nSubtotal12, wDecimalesL).ToString()
        Me.LblSubTotal0.Text = Funciones.FormatoNumeroSepara(nSubtotal0, wDecimalesL).ToString()
        Me.LblSubTotal_2.Text = Funciones.FormatoNumeroSepara(nTotal, wDecimalesL).ToString()
        Me.LblDescuentos.Text = Funciones.FormatoNumeroSepara(nDescuento, wDecimalesL)
        Me.LblSubTotal.Text = Funciones.FormatoNumeroSepara(nSubTotal, wDecimalesL)
        Me.LblValorIva.Text = Funciones.FormatoNumeroSepara(nValorIva, wDecimalesL)
        Me.LblIRBPNR.Text = Funciones.FormatoNumeroSepara(nIRBPNR, wDecimalesL)
        Me.LblTotal.Text = Funciones.FormatoNumeroSepara(nTotal, wDecimalesL).ToString()


        Call InitGrid(Me.Grid1)
    End Sub

    Private Sub InitGrid(ObjGrid As DataGridView)
        vgHeader = {
            {120, "CÓDIGO", "S"},
            {230, "NOMBRE", "S"},
            {60, "U. MEDIDA", "S"},
            {60, "CANT.", "N2"},
            {50, "% DESC.", "N2"},
            {75, "COSTO", "N2"},
            {75, "DESC.", "N2"},
            {60, "IVA", "N2"},
            {75, "V. UNIT.", "N6"},
            {100, "TOTAL", "N6"},
            {40, "% IVA", "N2"},
            {50, "IRBPNR", "N2"},
            {0, "sec_det", "N2"},
            {0, "tiponc", "N2"}
        }
        Funciones.InitGrid(ObjGrid, vgHeader, 6.7)
    End Sub

    Private Sub RepresentaPorcentajesIVA()
        Dim nCostototreal As Double, nDescuento As Double, nSubstotal As Double, nValor_iva As Double, nTotal As Double
        Dim nCostototreal_02 As Double, nDescuento_02 As Double, nSubstotal_02 As Double, nValor_iva_02 As Double, nTotal_02 As Double
        Dim wDecimalesL As Double
        Dim rsT3 As DataTable
        wDecimalesL = 4
        Dim sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        Me.Grid2.DataSource = Nothing
        Me.Grid2.Visible = False
        nCostototreal = 0
        nDescuento = 0
        nSubstotal = 0
        nValor_iva = 0
        nTotal = 0

        nCostototreal_02 = 0
        nDescuento_02 = 0
        nSubstotal_02 = 0
        nValor_iva_02 = 0
        nTotal_02 = 0

        cad = "select cast(impiva03 as character(25))||'%' as impiva03, " &
        "sum(costototreal) as costototreal, " &
        "sum(cast(costototreal - costototdesc as numeric(14,4))) as descuento, " &
        "sum(costototdesc) as substotal, " &
        "sum(cast(costototdesc * (impiva03 /100) as numeric(14,4))) as valor_iva, " &
        "sum(cast(costototdesc + (costototdesc * (impiva03 /100)) as numeric(14,4))) as total, " &
        "impiva03 as iva  " &
        "From indetmov " &
        "Where " & Funciones.GetEmp("") & " " &
        "and sig_tip = '" & sSigTip & "' " &
        "and acu_tip = " & nAcutip & " " &
        "group by 1, 7 " &
        "order by 7;"
        rsT3 = Bdd.RetornaTabla(cad)

        If (rsT3.Rows.Count > 0) Then
            Me.Grid2.DataSource = rsT3
        End If

        Dim nFila = 0
        For Each fila As DataGridViewRow In Me.Grid2.Rows
            nCostototreal = nCostototreal + Val(fila.Cells("costototreal").Value)
            nDescuento = nDescuento + Val(fila.Cells("descuento").Value)
            nSubstotal = nSubstotal + Val(fila.Cells("substotal").Value)
            nValor_iva = nValor_iva + Val(fila.Cells("valor_iva").Value)
            nTotal = nTotal + Val(fila.Cells("total").Value)
            nFila += 1
        Next

        Me.Grid2.Tag = 0
        If (rsT3.Rows.Count > 0) Then
            nFila += 1

            rsT3.Rows.Add()
            rsT3.Rows.Add()
            rsT3.Rows(nFila)("impiva03") = "TOTAL"
            rsT3.Rows(nFila)("costototreal") = nCostototreal
            rsT3.Rows(nFila)("descuento") = nDescuento
            rsT3.Rows(nFila)("substotal") = nSubstotal
            rsT3.Rows(nFila)("valor_iva") = nValor_iva
            rsT3.Rows(nFila)("total") = nTotal

            Me.Grid2.Tag = nFila

            Call InitGrid2(Me.Grid2)
        End If
        Me.Grid2.RowTemplate.Height = 15
        Me.Grid2.Visible = True
    End Sub

    Private Sub CmdInicio_Click(sender As Object, e As EventArgs) Handles CmdInicio.Click
        Me.Txtacu_tip.Text = vgRegistroMin
        Call Consultar_Datos()
        Call HabilitaEstado()
    End Sub

    Private Sub CmdFinal_Click(sender As Object, e As EventArgs) Handles CmdFinal.Click
        Me.Txtacu_tip.Text = vgRegistroMax
        Call Consultar_Datos()
        Call HabilitaEstado()
    End Sub

    Private Sub CmdIzquierda_Click(sender As Object, e As EventArgs) Handles CmdIzquierda.Click
        Dim nAnter = Val(Me.Txtacu_tip.Text)
        nAnter = nAnter - 1
        If (nAnter < vgRegistroMin) Then
            nAnter = vgRegistroMin
        End If
        Me.Txtacu_tip.Text = nAnter
        Call Consultar_Datos()
        Call HabilitaEstado()
    End Sub

    Private Sub CmdDerecha_Click(sender As Object, e As EventArgs) Handles CmdDerecha.Click
        Dim nSig = Val(Me.Txtacu_tip.Text)
        nSig = nSig + 1
        If (nSig > vgRegistroMax) Then
            nSig = vgRegistroMax
        End If
        Me.Txtacu_tip.Text = nSig
        Call Consultar_Datos()
        Call HabilitaEstado()
    End Sub

    Private Sub CmdEditar_Click(sender As Object, e As EventArgs) Handles CmdEditar.Click
        If (Val(Me.TxtPk.Text) = 0) Then
            Exit Sub
        End If
        Call Habilitar(True)
    End Sub

    Private Sub CmdNuevo_Click(sender As Object, e As EventArgs) Handles CmdNuevo.Click
        Call Habilitar(True)

        If (Mensajes("Desea generar un Nuevo Ingreso a Bodega (IB)?", 1) = 7) Then
            Call Habilitar(False)
            Call HabilitarClass(False)
            Exit Sub
        End If

        Call LimpiaObjetos()

        Me.ChkNuevoEditar.Checked = False
        Me.Txtsig_tip.Text = "IB"
        Me.Txtacu_tip.Text = Bdd.RetornaSecuencia(Me.Txtsig_tip.Text)

        If Val(Txtacu_tip.Text) = 0 Then
            Exit Sub
        End If

        Call PoneTipoDocumFactura()

        Me.Txtsecuencia.Text = 0



        Dim sRucEmpresa = Funciones.RetornaRucEmpresa
        If (sRucEmpresa = "1560002480001") Then
            cad = "select max(nropagos) as retorna " &
            "from incabmov " &
            "where " & Funciones.GetEmp("") & " " &
            "and sig_tip = 'IB' " &
            "and cre_por = '" & Trim$(vgCodUsu) & "'"

            Me.Txtsecuencia.Text = Val(Bdd.RetornaUnValor(cad)) + 1
        End If

        Call Habilitar(True)
        Call IngresaModificaCabecera(1)

        Consultar_Datos()
        LlenaDetalle()

        Me.CmdAprobar.Enabled = False
        Me.CmdAnular.Enabled = False
        Me.CmdDesaprobar.Enabled = False
        Me.CmdBuscaDepartamento.Select()
    End Sub

    Private Sub CmdGrabar_Click(sender As Object, e As EventArgs) Handles CmdGrabar.Click

        If (Me.CmdQuitar.Visible = True) Then
            LimpiaTextosItems()
        End If

        If GrabarCabecera() = 0 Then
            Exit Sub
        End If

        Call Utilitarios.SacaMinMaxTabla(IIf(vgCodSistema = 3, "incabmov", "accabmov"), "IB", nRegistroMin, nRegistroMax)


        Call Habilitar(False)
        Call HabilitaEstado

    End Sub

    Private Sub CmdCancelar_Click(sender As Object, e As EventArgs) Handles CmdCancelar.Click
        Call Habilitar(False)
        Call Consultar_Datos()
    End Sub

    Private Sub Grid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Grid1.CellContentClick

    End Sub

    Private Sub Grid1_DoubleClick(sender As Object, e As EventArgs) Handles Grid1.DoubleClick

        If Me.CmdSalir.Enabled = True Then
            Exit Sub
        End If
        Me.Grid1.Enabled = False
        Dim RsIte As DataTable

        Dim nFila = Me.Grid1.CurrentRow.Index

        Me.Txtcuenta.Text = Me.Grid1.Rows(nFila).DataBoundItem("cuenta").ToString.Trim
        Call BuscaDatosItem(Me.Txtcuenta.Text)

        Me.Txtcantidad.Text = Me.Grid1.Rows(nFila).DataBoundItem("cantidb")
        Me.descto03.Text = Me.Grid1.Rows(nFila).DataBoundItem("descto03")
        Me.TxtCostoTotReal.Text = Me.Grid1.Rows(nFila).DataBoundItem("costototreal")
        Me.preciotot.Text = Me.Grid1.Rows(nFila).DataBoundItem("costototdesc")

        Me.LblCostoTotal.Text = Me.Grid1.Rows(nFila).DataBoundItem("preciotot")
        Me.LblCostoItem.Text = Me.Grid1.Rows(nFila).DataBoundItem("costo103")
        Me.ChkIva.Checked = IIf(Val(Me.Grid1.Rows(nFila).DataBoundItem("impiva03")) <> 0, True, False)
        Me.TxtSecDet.Text = Me.Grid1.Rows(nFila).DataBoundItem("sec_det")
        Me.TxtIrbpnr.Text = Me.Grid1.Rows(nFila).DataBoundItem("precioven")

        'Me.OptDescuento(0).Value = True
        'If Val(Me.Grid1.TextMatrix(Me.Grid1.Row, 12 + 1)) = 1 Then
        '    Me.OptDescuento(1).Value = True
        'End If


        cad = "select ivanosi, salcoscr as retencion100 " &
        "from " & sPlacta & " a " &
        "where " & Funciones.GetEmp("a") & " " &
        "and a.cuenta = '" & Trim$(Me.Txtcuenta.Text) & "' "
        RsIte = Bdd.RetornaTabla(cad)

        If RsIte.Rows.Count > 0 Then
            Me.ChkIva.Checked = IIf(Val(RsIte.Rows(0)("ivanosi")) = 2, True, False)
            Me.TxtRetencion100IVA.Text = Nvl(RsIte.Rows(0)("retencion100"), 0)
        End If

        Me.CmdQuitar.Visible = True
        Me.Grid1.Enabled = False
        Me.CmdF4.Enabled = False

        Me.TxtCostoTotReal.Select()
    End Sub

    Private Sub InitGrid2(ObjGrid As DataGridView)
        vgHeader = {
            {50, "IVA", "S"},
            {75, "MONTO", "N4"},
            {60, "DESC.", "N4"},
            {75, "SUBTOT.", "N4"},
            {75, "VAL.IVA", "N4"},
            {0, "TOTAL", "N4"},
            {0, "iva", "N4"}
        }
        Funciones.InitGrid(ObjGrid, vgHeader, 6.7)

    End Sub

    Private Sub BtnAgregar_Click(sender As Object, e As EventArgs) Handles BtnAgregar.Click
        If Len(Me.Txtcuenta.Text.Trim) = 0 Then
            Mensajes("Seleccione un Item por favor")
            Me.Txtcuenta.Select()
            Exit Sub
        End If

        If Val(Me.Txtcantidad.Text) = 0 Then
            Mensajes("Ingrese la cantidad por favor")
            Me.Txtcantidad.Select()
            Exit Sub
        End If

        If Val(Me.LblCostoItem.Text) = 0 Then
            Mensajes("Ingrese el costo por favor")
            Me.TxtCostoTotReal.Select()
            Exit Sub
        End If

        If VerificaItemEnMismoIB(Trim$(Me.Txtcuenta.Text), Val(Me.Txtacu_tip.Text)) = 1 Then
            LimpiaTextosItems()
            Exit Sub
        End If

        Call IngresaModificaDetalle()

        'verifica caducidad
        If Me.chkCaducidad.Checked = True Then
            'inFrmIngresoCaduc.txtCantTotal.Text = Me.cantidad.Text
            'inFrmIngresoCaduc.TxtIB.Text = Me.pedido(0).Text
            'inFrmIngresoCaduc.txtItem.Text = Me.cuenta.Text
            'inFrmIngresoCaduc.lblItem.Caption = Trim$(Me.cuenta.Text) & " - " & Trim$(Me.descuenta.Text)
            'inFrmIngresoCaduc.Show vbModal
        End If
        'continua
        Me.ChkSujetosControl.Enabled = False


        LlenaDetalle()
        Me.TxtSecDet.Text = 0
        LimpiaTextosItems()
        Me.CmdF4.Select()

        Me.CmdCancelar.Enabled = False
    End Sub

    Private Sub BuscaDatosItem(sCodigoItem As String)
        Dim RsIte As DataTable

        Dim nCodDep = Val(Me.Txtdepartam.Text)

        If vgCodSistema = 3 Then
            cad = "select a.*, b.costo as costo_dep " &
            "from " & sPlacta & " a " &
            "left join initedep b on a.codemp = b.codemp and a.anio = b.anio and a.cuenta = b.cuenta and b.cod_dep = " & nCodDep & " " &
            "where " & Funciones.GetEmp("a") & " " &
            "and a.cuenta = '" & sCodigoItem & "' "
        Else
            cad = "select a.*, a.costo as costo_dep " &
            "from " & sPlacta & " a " &
            "where " & Funciones.GetEmp("a") & " " &
            "and a.cuenta = '" & sCodigoItem & "' "
        End If

        Me.TxtIrbpnr.Text = 0
        Me.LblCmasIBP.Text = "Costo Uni."
        RsIte = Bdd.RetornaTabla(cad)
        If RsIte.Rows.Count > 0 Then
            Me.txtnom_cue.Text = RsIte.Rows(0)("nom_cue").ToString.Trim
            Me.ChkIva.Checked = IIf(Val(RsIte.Rows(0)("ivanosi")) = 2, True, False)
            wPorcentajeIvaItem = Val(RsIte.Rows(0)("precio05"))
            If vgCodSistema = 3 Then
                Me.chkCaducidad.Checked = IIf(Val(RsIte.Rows(0)("tiene_caduc")) = 1, True, False)
                Me.TxtIrbpnr.Text = IIf(RsIte.Rows(0)("irbpnr") = 0, 0, vgValorIRBPNR)
            Else
                Me.chkCaducidad.Checked = False
            End If
            Me.txtcostoact.Text = Funciones.FormatoNumeroSepara(Nvl(RsIte.Rows(0)("costo_dep"), 0), 4)
            Me.TxtRetencion100IVA.Text = Nvl(RsIte.Rows(0)("salcoscr"), 0) 'SI SE RETIENE O NO EL 100% IVA
        End If
        Me.Txtcantidad.Text = 0

        If vgCodSistema = 5 Then
            Me.Txtcantidad.Text = 1
            Me.Txtcantidad.Enabled = False
        End If
    End Sub

    Private Sub LimpiaTextosItems()
        Me.Txtcuenta.Text = ""
        Me.txtnom_cue.Text = ""
        Me.Txtcantidad.Text = 0
        Me.descto03.Text = 0
        Me.preciotot.Text = 0
        Me.LblCostoItem.Text = "0.00"
        Me.LblCostoTotal.Text = "0.00"
        Me.ChkIva.Checked = False
        Me.chkCaducidad.Checked = False
        Me.txtcostoact.Text = "0.00"
        Me.TxtCostoTotReal.Text = "0.00"
        Me.CmdQuitar.Visible = False
        Me.Grid1.Enabled = True
        Me.CmdF4.Enabled = True
        Me.TxtSecDet.Text = 0
        Me.TxtRetencion100IVA.Text = 0
    End Sub

    Private Function VerificaItemEnMismoIB(sCodigoItem As String, nAcuTipBusca As Double)
        Dim rsT3 As DataTable
        If vgCodSistema <> 5 Then
            VerificaItemEnMismoIB = VerificaItemEnMismoIBInventarios(sCodigoItem, nAcuTipBusca)
            Exit Function
        End If

        If Val(Me.TxtSecDet.Text) > 0 Then
            VerificaItemEnMismoIB = 0
            Exit Function
        End If

        Dim nNoExisteEnIB = 0
        cad = "select anio, acu_tip " &
        "From acdetmov " &
        "Where sig_tip = 'IB' " &
        "and cuenta = '" & sCodigoItem & "' ;    "
        rsT3 = Bdd.RetornaTabla(cad)

        If rsT3.Rows.Count > 0 Then
            Dim sCadAnio = ""
            If (Val(rsT3.Rows(0)("anio")) <> vgAnio) Then
                sCadAnio = " del año " & Trim$(rsT3.Rows(0)("anio")) & " "
            End If

            Dim sCadAcu = "El Item ya está registrado en este IB "
            If (Val(rsT3("acu_tip")) <> nAcuTipBusca) Then
                sCadAcu = "El Item ya está registrado en el IB-" & Trim$(rsT3.Rows(0)("acu_tip")) & " "
            End If
            Dim sMensaje = sCadAcu & " " & sCadAnio

            Mensajes(sMensaje)
            nNoExisteEnIB = 1
        End If
        VerificaItemEnMismoIB = nNoExisteEnIB
    End Function

    Private Function VerificaItemEnMismoIBInventarios(sCodigoItem As String, nAcuTipBusca As Double)
        If Val(Me.TxtSecDet.Text) > 0 Then
            VerificaItemEnMismoIBInventarios = 0
            Exit Function
        End If

        Dim rsT3 As DataTable
        Dim nNoExisteEnIB = 0
        cad = "select a.cuenta, b.nom_cue, count(*) as nro_existe " &
        "From indetmov a " &
        "left join inplacta b on a.codemp = b.codemp and a.anio = b.anio and a.cuenta = b.cuenta " &
        "Where " & Funciones.GetEmp("a") & " " &
        "and a.sig_tip = 'IB' " &
        "and a.acu_tip = " & nAcuTipBusca & " " &
        "and a.cuenta = '" & sCodigoItem & "'  " &
        "group by 1, 2"

        rsT3 = Bdd.RetornaTabla(cad)

        If rsT3.Rows.Count > 0 Then
            Dim nItemRepre = Trim$(rsT3.Rows(0)("cuenta")) & " " & Trim$(rsT3.Rows(0)("nom_cue"))
            Dim sMensaje = "El Item " & nItemRepre & " ya está registrado " & rsT3.Rows(0)("nro_existe") & " veces en este IB, desea ingresarlo de todos modos? "
            Dim nRespuesta = Mensajes(sMensaje, 1)
            If nRespuesta = 6 Then
                nNoExisteEnIB = 0
            Else
                nNoExisteEnIB = 1
            End If
        End If
        VerificaItemEnMismoIBInventarios = nNoExisteEnIB
    End Function

    Private Sub CmdQuitar_Click(sender As Object, e As EventArgs) Handles CmdQuitar.Click
        Dim sSigTip = Me.Txtsig_tip.Text.Trim
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        Dim nSecDet = Val(Me.TxtSecDet.Text)

        cad = "delete from " & wArchDeta & " " &
        "where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip & " and sec_det = " & nSecDet

        Bdd.EjecutarCadena(cad)
        'verifica caducidad
        If Val(Me.chkCaducidad.Checked) = 1 Then
            Call eliminaCaducidad(nAcutip, Me.Txtcuenta.Text)
        End If
        'continua
        LlenaDetalle()

        Me.CmdQuitar.Visible = False
        LimpiaTextosItems()
    End Sub

    Private Sub IngresaModificaDetalle()
        Dim RsAdd As DataTable, cad As String, nAnioGarantia As Integer, nMesGarantia As Integer
        Dim RsSecu As DataTable
        Dim nSecDet = Val(Me.TxtSecDet.Text)
        Dim sSigTip = Me.Txtsig_tip.Text
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        Dim nInsertaModifica = 0

        'If Me.OptDescuento(0).Value = True Then
        Dim nQueDesc = 0
        'Else
        '    nQueDesc = 1
        'End If

        Dim cad_where = " where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip & "  and sec_det = " & nSecDet
        cad = " select * from " & wArchDeta & cad_where

        RsAdd = Bdd.RetornaTabla(cad)

        If RsAdd.Rows.Count = 0 Then
            cad = "select case when max(sec_det) is null then 0 else max(sec_det) end as retorna " &
            "from " & wArchDeta & " " &
            "where " & Funciones.GetEmp("") & " " &
            "and sig_tip = '" & sSigTip & "' " &
            "and acu_tip = " & nAcutip & " "

            nSecDet = Bdd.RetornaUnValor(cad) + 1

            RsAdd.Rows.Add()
            RsAdd.Rows(0)("codemp") = Trim$(vgEmpresa)
            RsAdd.Rows(0)("anio") = vgAnio
            RsAdd.Rows(0)("sig_tip") = Trim(sSigTip)
            RsAdd.Rows(0)("acu_tip") = Val(nAcutip)
            RsAdd.Rows(0)("sec_det") = nSecDet
            RsAdd.Rows(0)("vcodemp") = Trim(vgEmpresa)
            RsAdd.Rows(0)("vanio") = vgAnio
            RsAdd.Rows(0)("vsig_tip") = Trim(sSigTip)
            RsAdd.Rows(0)("vacu_tip") = Val(nAcutip)

            RsAdd.Rows(0)("cre_por") = vgCodUsu
            RsAdd.Rows(0)("fec_cre") = Funciones.FormatoFecha(vgFechaServer)
        Else
            RsAdd.Rows(0)("mod_por") = vgCodUsu
            RsAdd.Rows(0)("fec_mod") = Funciones.FormatoFecha(vgFechaServer)
            nInsertaModifica = 1
        End If

        Dim nCostoItem = Val(Replace(Me.LblCostoItem.Text, ",", ""))

        RsAdd.Rows(0)("cuenta") = Me.Txtcuenta.Text
        RsAdd.Rows(0)("bodega03") = Val(Me.Txtdepartam.Text)
        RsAdd.Rows(0)("codcli03") = Me.Txtcedruc.Text
        RsAdd.Rows(0)("costo103") = nCostoItem
        RsAdd.Rows(0)("preci103") = nCostoItem
        RsAdd.Rows(0)("cantidb") = Val(Me.Txtcantidad.Text)
        RsAdd.Rows(0)("canticr") = 0
        RsAdd.Rows(0)("impiva03") = IIf(Me.ChkIva.Checked = True, wPorcentajeIvaItem, 0)
        RsAdd.Rows(0)("descto03") = Val(Me.descto03.Text)
        RsAdd.Rows(0)("valiva03") = 0
        RsAdd.Rows(0)("valdes03") = 0
        RsAdd.Rows(0)("valrec03") = 0
        RsAdd.Rows(0)("fecha") = Funciones.FormatoFecha(Me.fecha_ib.Value)
        RsAdd.Rows(0)("estado") = 2
        RsAdd.Rows(0)("periodo") = Me.fecha_ib.Value.Month
        RsAdd.Rows(0)("vendedor") = Val(Me.txtresponsa.Text)
        RsAdd.Rows(0)("cantemb") = 1
        RsAdd.Rows(0)("tiponc") = nQueDesc
        RsAdd.Rows(0)("costoing") = 0
        RsAdd.Rows(0)("precioli") = 0
        RsAdd.Rows(0)("precioven") = 0
        RsAdd.Rows(0)("porutil") = 0
        RsAdd.Rows(0)("utilidad") = 0
        RsAdd.Rows(0)("cantifac") = 0
        RsAdd.Rows(0)("preciotot") = Val(Replace(Me.LblCostoTotal.Text, ",", ""))
        RsAdd.Rows(0)("precioant") = 0
        RsAdd.Rows(0)("cuentap") = ""
        RsAdd.Rows(0)("guia") = 0
        RsAdd.Rows(0)("fechguia") = 0
        RsAdd.Rows(0)("transpor") = 0
        RsAdd.Rows(0)("costototreal") = Val(Me.TxtCostoTotReal.Text)
        RsAdd.Rows(0)("costototdesc") = Val(Me.preciotot.Text)
        RsAdd.Rows(0)("precioven") = Val(Me.TxtIrbpnr.Text)

        If vgCodSistema = 5 Then
            'nAnioGarantia = Nvl(RsAdd.Rows(0)("anio_garan"), 0)
            'nMesGarantia = Nvl(RsAdd.Rows(0)("mes_garan"), 0)
            'Call RetornaTiempoGarantia(nAnioGarantia, nMesGarantia)
            'RsAdd.Rows(0)("anio_garan") = nAnioGarantia
            'RsAdd.Rows(0)("mes_garan") = nMesGarantia
        End If

        If nInsertaModifica = 0 Then
            cad = Bdd.Insertar(RsAdd, wArchDeta)
        Else
            cad = Bdd.Actualizar(RsAdd, wArchDeta, cad_where)
        End If
    End Sub

    Private Sub TxtCostoTotReal_Leave(sender As Object, e As EventArgs) Handles TxtCostoTotReal.Leave
        If (Val(TxtCostoTotReal.Text) = 0) Then
            Exit Sub
        End If
        Dim nCostoTotR = Val(TxtCostoTotReal.Text)
        If (Val(descto03.Text) > 0) Then
            '//'If Me.OptDescuento(0).Value = True Then
            nCostoTotR = Funciones.Round(Val(TxtCostoTotReal.Text) - (Val(TxtCostoTotReal.Text) * (descto03.Text / 100)), vgDecimales)
            'Else
            'nCostoTotR = Round(Val(TxtCostoTotReal.Text) - Val(Me.descto03.Text), 2)
            'End If
        End If
        preciotot.Text = nCostoTotR
        CalculaCostosItem()
    End Sub

    Private Sub eliminaCaducidad(ib As Double, item As String)
        cad = "delete " &
        "From incaduc_detall " &
        "where " & Funciones.GetEmp("") & " " &
        "and sig_tip = 'IB' " &
        "and acu_tip = " & ib & " " &
        "and coditem = '" & item & "' "
        Bdd.EjecutarCadena(cad)
    End Sub

    Private Sub CmdBuscaDepartamento_Click(sender As Object, e As EventArgs) Handles CmdBuscaDepartamento.Click
        SiFrmBuscarCatalogo.TxtCodTab.Text = 19
        SiFrmBuscarCatalogo.ShowDialog()
        Dim sCodRetorna = Val(SiFrmBuscarCatalogo.Tag)
        SiFrmBuscarCatalogo.Close()
        If (sCodRetorna = 0) Then
            Exit Sub
        End If
        Me.Txtdepartam.Text = sCodRetorna
        Me.TxtDepartamento.Text = Bdd.RetornaNombreTablas(19, sCodRetorna)
    End Sub

    Private Sub CmdBuscaResponsable_Click(sender As Object, e As EventArgs) Handles CmdBuscaResponsable.Click
        SiFrmBuscarCatalogo.TxtCodTab.Text = 54
        SiFrmBuscarCatalogo.ShowDialog()
        Dim sCodRetorna = Val(SiFrmBuscarCatalogo.Tag)
        SiFrmBuscarCatalogo.Close()
        If (sCodRetorna = 0) Then
            Exit Sub
        End If
        Me.txtresponsa.Text = sCodRetorna
        Me.Txtresponsable.Text = Bdd.RetornaNombreTablas(54, sCodRetorna)
    End Sub

    Private Sub CalculaCostosItem()
        Dim nCostoT As Double, nCostoItem As Double, nDecimalesLocal As Double
        nDecimalesLocal = vgDecimales
        Dim nCantidad = Val(Me.Txtcantidad.Text)
        Dim nCostototreal = Val(Me.TxtCostoTotReal.Text)
        Dim nDescue = Val(Me.descto03.Text)
        nCostoT = Val(Me.preciotot.Text)



        If Val(Me.TxtRetencion100IVA.Text) = 0 Then
            If Me.ChkNoDevIva.Checked = True And Me.ChkIva.Checked = True Then
                nCostoT = Round(nCostoT * ((wPorcentajeIvaItem / 100) + 1), vgDecimales)
            End If
        Else
            nCostoT = Round(Val(Me.preciotot.Text), vgDecimales)
        End If

        Me.LblCostoTotal.Text = Funciones.FormatoNumeroSepara(nCostoT, nDecimalesLocal)
        If (nCantidad <> 0) Then
            nCostoItem = nCostoT / nCantidad
        Else
            nCostoItem = 0
        End If

        If Val(Me.TxtIrbpnr.Text) > 0 Then
            nCostoItem = nCostoItem + vgValorIRBPNR
        End If


        Me.LblCostoItem.Text = Funciones.FormatoNumeroSepara(nCostoItem, nDecimalesLocal)
    End Sub

    Private Sub LimpiaObjetos()
        Me.fecha_ib.Value = Funciones.FormatoFecha(Now)
        Me.Txtcedruc.Text = ""
        Me.Txtcedruc_nombre.Text = ""

        Me.txtresponsa.Text = ""
        Me.Txtresponsable.Text = ""

        'iva.Text = ""
        Me.Txtdepartam.Text = ""
        Me.TxtDepartamento.Text = ""
        'Check2.Value = 0

        Me.fecha_ib.Value = Funciones.FormatoFecha(Now)
        Me.Txtfactura.Text = ""
        'Me.ivapres.Text = ""
        'Me.RET3XMI.Text = ""
        'Me.wnrodias.Text = 0
        Me.Txtobserva.Text = ""
        Me.Txtestable.Text = ""
        Me.Txtpunto_emi.Text = ""
        Me.TxtNte_Id.Text = 0
        Me.TxtRetencion100IVA.Text = 0
    End Sub

    Private Sub PoneTipoDocumFactura()
        cad = "select descrip as retorna from tablas where codemp = '" & vgEmpresa & "' and codtab = 138 and codigo = 1"
        Me.CmbTipoDocum.Text = Bdd.RetornaUnValor(cad).ToString.Trim
    End Sub

    Private Function IngresaModificaCabecera(Optional nVerificaFac As Integer = 0)
        Dim RsAdd As New DataTable
        Dim sNomTipoDoc = Trim$(Me.CmbTipoDocum.Text)
        If (Me.ChkSujetosControl.Checked = False) Then
            If (nVerificaFac = 0) Then
                If Len(Trim$(Me.Txtfactura.Text)) = 0 Then
                    Mensajes("Ingrese Número de " & sNomTipoDoc & " por favor")
                    IngresaModificaCabecera = 0
                    Exit Function
                End If
            End If
        End If

        Dim nIdMaquinaria = 0
        If vgCodSistema = 3 And Me.CntMaquinaria.Visible = True Then
            nIdMaquinaria = Val(Me.TxtIdMaquinaria.Text)
        End If


        Dim sSigTip = Me.Txtsig_tip.Text.Trim
        Dim nAcuTip = Val(Me.Txtacu_tip.Text)
        Dim nInsertaModifica = 0
        Dim nSecuenciaAlterna = Val(Trim$(Me.Txtsecuencia.Text))
        Dim cad_where = " where " & Funciones.GetEmp("") & " and  acu_tip = " & nAcuTip & " and sig_tip = '" & sSigTip & "' "
        cad = " select * from " & wArchCabe & cad_where

        RsAdd = Bdd.RetornaTabla(cad)

        If RsAdd.Rows.Count = 0 Then
            RsAdd.Rows.Add()
            RsAdd.Rows(0)("codemp") = Trim$(vgEmpresa)
            RsAdd.Rows(0)("anio") = vgAnio
            RsAdd.Rows(0)("ucodemp") = Trim(vgEmpresa)
            RsAdd.Rows(0)("uanio") = vgAnio
            RsAdd.Rows(0)("sig_tip") = sSigTip
            RsAdd.Rows(0)("acu_tip") = nAcuTip
            RsAdd.Rows(0)("cre_por") = vgCodUsu
            RsAdd.Rows(0)("fec_cre") = Funciones.FormatoFecha(vgFechaServer)
            RsAdd.Rows(0)("hora") = DateTime.Now.ToString("hh:mm:ss")
        Else
            RsAdd.Rows(0)("mod_por") = vgCodUsu
            RsAdd.Rows(0)("fec_mod") = Funciones.FormatoFecha(vgFechaServer)
            nInsertaModifica = 1
        End If

        RsAdd.Rows(0)("tot_deb") = 0
        RsAdd.Rows(0)("codcli02") = Trim$(Txtcedruc.Text)
        RsAdd.Rows(0)("impiva02") = vgPorcentajeIva
        RsAdd.Rows(0)("descto02") = Val(descto03.Text)
        RsAdd.Rows(0)("bodent02") = 0
        RsAdd.Rows(0)("bodrec02") = Val(Me.Txtdepartam.Text)
        RsAdd.Rows(0)("codent02") = 0
        RsAdd.Rows(0)("codrec02") = Val(Me.txtresponsa.Text)
        RsAdd.Rows(0)("formpa02") = 0
        RsAdd.Rows(0)("vendedor") = 0
        RsAdd.Rows(0)("fec_asi") = Funciones.FormatoFecha(Me.fecha_ib.Value)
        RsAdd.Rows(0)("fec_apr") = Funciones.FormatoFecha(Me.fecha_ib.Value)
        RsAdd.Rows(0)("periodo") = Me.fecha_ib.Value.Month
        RsAdd.Rows(0)("estado") = 2
        RsAdd.Rows(0)("dias02") = Val(wnrodias.Text)
        RsAdd.Rows(0)("estadono") = 1
        RsAdd.Rows(0)("tiponc") = IIf(Me.Check2.Checked = True, 1, 0)
        RsAdd.Rows(0)("transpor") = "" 'UCase(wtransp)
        RsAdd.Rows(0)("ptollega") = Trim$(Me.TxtPtoLlega.Text)
        RsAdd.Rows(0)("ptoparte") = Mid(Trim$(Me.TxtDepartamento.Text), 1, 30)
        RsAdd.Rows(0)("inictra") = Funciones.FormatoFecha(Me.fecha_factura.Value)
        RsAdd.Rows(0)("termtra") = Funciones.FormatoFecha(Me.fecha_factura.Value)
        RsAdd.Rows(0)("factura") = Trim$(Txtfactura.Text)
        RsAdd.Rows(0)("ivapres") = Val(Me.ivapres.Text)
        RsAdd.Rows(0)("ret3xmil") = Val(RET3XMI.Text)
        RsAdd.Rows(0)("nropagos") = nSecuenciaAlterna
        RsAdd.Rows(0)("pagosre") = 0
        RsAdd.Rows(0)("observa") = UCase(Txtobserva.Text)
        RsAdd.Rows(0)("serie1") = Me.Txtestable.Text
        RsAdd.Rows(0)("serie2") = Me.Txtpunto_emi.Text
        RsAdd.Rows(0)("vehiculo") = nIdMaquinaria
        RsAdd.Rows(0)("proyecto") = 0
        RsAdd.Rows(0)("subtotal12") = Val(Replace(Me.LblSubTotal12.Text, ",", ""))
        RsAdd.Rows(0)("subtotal0") = Val(Replace(Me.LblSubTotal0.Text, ",", ""))
        RsAdd.Rows(0)("descuento") = Val(Replace(Me.LblDescuentos.Text, ",", ""))
        RsAdd.Rows(0)("subtotal") = Val(Replace(Me.LblSubTotal.Text, ",", ""))
        RsAdd.Rows(0)("valoriva") = Val(Replace(Me.LblValorIva.Text, ",", ""))
        RsAdd.Rows(0)("gastos") = Val(Replace(Me.LblIRBPNR.Text, ",", "")) 'IRBPNR
        RsAdd.Rows(0)("total") = Val(Replace(Me.LblTotal.Text, ",", ""))
        RsAdd.Rows(0)("otros") = IIf(Me.ChkSujetosControl.Checked = True, 1, 0)
        RsAdd.Rows(0)("tipodoc") = Me.CmbTipoDocum.SelectedValue

        If nInsertaModifica = 0 Then
            cad = Bdd.Insertar(RsAdd, wArchCabe)
        Else
            cad = Bdd.Actualizar(RsAdd, wArchCabe, cad_where)
        End If

        Call Bdd.RegistraAuditoria(wArchCabe, sSigTip, nAcuTip)
        IngresaModificaCabecera = 1

        Call AsociaIB_NotaEntrega(nAcuTip)
    End Function

    Private Sub CmdF4_Click(sender As Object, e As EventArgs) Handles CmdF4.Click
        Dim nVerItemBaja As Integer
        If Val(Me.Txtdepartam.Text) = 0 Then
            Mensajes("Selecciones una Bodega en la cual se realizará el Ingreso")
            Exit Sub
        End If
        nVerItemBaja = 0
        If vgCodSistema = 5 Then
            nVerItemBaja = 98
        End If

        Dim frm As New In_Frm_Buscar_Item

        frm.TxtCodBodega.Text = Me.Txtdepartam.Text
        frm.ShowDialog()
        Dim sCuenta = frm.Tag

        If (sCuenta.ToString.ToString.Length = 0) Then
            Exit Sub
        End If

        Me.Txtcuenta.Text = sCuenta
        Call BuscaDatosItem(Trim$(sCuenta))

        If Me.Txtcantidad.Enabled = True Then
            Me.Txtcantidad.Select()
        Else
            Me.TxtCostoTotReal.Select()
        End If
    End Sub

    Private Sub AsociaIB_NotaEntrega(nAcuTipIb As Double)
        If Me.ChkAsociarNotaEnt.Checked = False Or Val(Me.TxtNte_Id.Text) <> 0 Then
            Exit Sub
        End If
        Dim nIdNotaEntre = 0
        'InFrmNotaEntregaBuscar.ChkBuscaParaRec.Value = 1
        'InFrmNotaEntregaBuscar.Show vbModal
        'Dim nIdNotaEntre = Val(InFrmNotaEntregaBuscar.Tag)
        'Unload InFrmNotaEntregaBuscar

        If (nIdNotaEntre = 0) Then
            Mensajes("No Selecciono ninguna NOTA DE ENTREGA")
        Else
            If (Mensajes("Se asociara el IB-" & nAcuTipIb & " con la NOTA DE ENTREGA seleccionada, Una vez Asociada no se podra cambiar, desea continuar?", 1)) Then
                Exit Sub
            End If

            Dim sNte_Cab = "innte_cab"
            If vgCodSistema = 5 Then
                sNte_Cab = "acnte_cab"
            End If

            cad = "update innte_cab set nte_sig_tip_ib = 'IB', nte_acu_tip_ib = " & nAcuTipIb & " 
            where nte_codemp = '" & vgEmpresa & "' and nte_id = " & nIdNotaEntre & " "
            Bdd.EjecutarCadena(cad)
        End If
        Call RepresentaNotaEntregaAsociado(nAcuTipIb)
    End Sub

    Private Sub CmdDesaprobar_Click(sender As Object, e As EventArgs) Handles CmdDesaprobar.Click

        Dim sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)

        If VerificaItemsTransferencias(sSigTip, nAcutip) = 1 Then
            Exit Sub
        End If

        If (Mensajes("Desea volver a estado CUADRADO el IB " & nAcutip & "?", 1) = 7) Then
            Exit Sub
        End If

        Dim nCodBod As Double, sCodigoItem As String
        Dim RsExi As New DataTable, RsDet As New DataTable, fFecha1 As String

        Dim fFecha = Me.fecha_ib.Value
        fFecha1 = fFecha
        Dim wDia = fFecha.Day
        nCodBod = Val(Me.Txtdepartam.Text)
        Dim cad_item = "select cuenta from " & wArchDeta & " where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip

        Dim wperiodo = Bdd.VerificaPeriodoAbierto(fFecha1)

        If wperiodo = 0 Then
            Mensajes("No existe período contable, no se puede continuar")
            Exit Sub
        End If

        If (DevuelveStock() = 0) Then
            Exit Sub
        End If


        cad = "update " & wArchCabe & " set estado = 2 where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        Bdd.EjecutarCadena(cad)

        Call Bdd.RegistraAuditoria(wArchCabe, sSigTip, nAcutip, 2)

        cad = "update " & wArchDeta & " set estado = 2 where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        Bdd.EjecutarCadena(cad)

        Call ActItemResponsableDepartamentoDesaprobar(sSigTip, nAcutip)

        Consultar_Datos()
        HabilitaEstado()
    End Sub

    Function GrabarCabecera()
        Dim fFechaIB As String
        fFechaIB = Funciones.FormatoFecha(Me.fecha_ib.Value)
        Dim nNroPeriodo = Bdd.VerificaPeriodoAbierto(fFechaIB)
        Dim wDia = Me.fecha_ib.Value.Day

        If nNroPeriodo = 0 Then
            Mensajes("No existe período contable")
            Me.fecha_ib.Select()
            GrabarCabecera = 0
            Exit Function
        End If

        GrabarCabecera = IngresaModificaCabecera()
    End Function

    Private Sub CmdBuscaProveedor_Click(sender As Object, e As EventArgs) Handles CmdBuscaProveedor.Click
        SiFrmCiuBuscar.ShowDialog()
        Dim sCedRuc As String = SiFrmCiuBuscar.Tag
        SiFrmCiuBuscar.Close()

        If sCedRuc.ToString.Length = 0 Then
            Exit Sub
        End If

        Me.TxtPk.Text = sCedRuc
        Me.Txtcedruc.Text = sCedRuc
        Me.Txtcedruc_nombre.Text = Bdd.RetornaNombreCiu(Me.Txtcedruc.Text)
        Me.CmdF4.Select()
    End Sub

    Private Sub CmdAprobar_Click(sender As Object, e As EventArgs) Handles CmdAprobar.Click
        If (Mensajes("Desea aprobar el IB " & Me.Txtacu_tip.Text & "?", 1) = 7) Then
            Exit Sub
        End If

        'Me.OptImprimir(0).Value = True
        Call AprobrarIB
        Consultar_Datos()
        HabilitaEstado()
        Call Imprimir()
    End Sub

    Private Sub HabilitaEstado()
        Me.CmdEditar.Enabled = True
        Me.CmdAprobar.Enabled = True
        Me.CmdDesaprobar.Enabled = False
        Me.CmdAnular.Enabled = False

        If Val(Me.TxtEstado.Text) = 3 Or Val(Me.TxtEstado.Text) = 6 Then
            Me.CmdEditar.Enabled = False
            Me.CmdAprobar.Enabled = False
            If Len(Trim$(Me.LblCpbteAsocia.Text)) = 0 Then
                Me.CmdDesaprobar.Enabled = True
                Me.CmdAnular.Enabled = True
            End If

            If Val(Me.TxtEstado.Text) = 6 Then
                Me.CmdDesaprobar.Enabled = False
                Me.CmdAnular.Enabled = False
            End If
        End If

        Dim sRucEmpresa = Funciones.RetornaRucEmpresa


        If sRucEmpresa = "0760000180001" Or sRucEmpresa = "1560002480001" Then
            If Me.ChkNoPropietario.Checked = True Then
                Me.CmdEditar.Enabled = False
            End If
        End If

    End Sub

    Private Sub AprobrarIB()
        Dim nCodBod As Double
        Dim wcosto As Double
        Dim wprecio As Double, nCostoNuevo As Double
        Dim fFecha As Date, sCodigoItem As String, sSigTip As String

        fFecha = Funciones.FormatoFecha(Me.fecha_ib.Value)
        Dim sFecha = Funciones.FormatoFecha(fFecha)
        Dim wDia = fFecha.Day
        sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        nCodBod = Val(Me.Txtdepartam.Text)
        Dim wperiodo = Bdd.VerificaPeriodoAbierto(fFecha)

        If wperiodo = 0 Then
            Mensajes("No existe período contable, no se puede aprobar el IB")
            Exit Sub
        End If

        Dim sAndGarantias = ""
        If vgCodSistema = 5 Then
            sAndGarantias = " , max(anio_garan) as anio_garan, max(mes_garan) as mes_garan "
        End If

        cad = "select cuenta, cast(sum(cantidb) as double precision) as cantidb, " &
        "cast(sum(costo103 * cantidb) / sum(cantidb) as double precision) as costo103 " &
        sAndGarantias &
        "from " & wArchDeta & " a " &
        "Where " & Funciones.GetEmp("a") &
        "and a.sig_tip = '" & sSigTip & "' " &
        "and a.acu_tip = " & nAcutip & " " &
        "group by 1 " &
        "order by 1"

        RsDet = Bdd.RetornaTabla(cad)

        If (RsDet.Rows.Count) Then
            For II = 0 To RsDet.Rows.Count - 1
                sCodigoItem = Trim$(RsDet.Rows(II)("cuenta"))
                nCostoNuevo = Funciones.RetornaCostoPromedio(sCodigoItem, RsDet.Rows(II)("cantidb"), RsDet.Rows(II)("costo103"), nCodBod)

                'graba_saldo_in sSigTip, Val(RsDet.Rows(II)("cantidb")), 0, wperiodo, sCodigoItem, nCodBod, RsDet.Rows(II)("costo103"), RsDet.Rows(II)("costo103"), wDia

                Dim sActFecha = ""
                If vgCodSistema = 5 Then
                    sActFecha = ", fechacom = '" & sFecha & "', anio_garan = " & Nvl(RsDet.Rows(II)("anio_garan"), 0) & " , mes_garan = " & Nvl(RsDet.Rows(II)("mes_garan"), 0) & " "
                End If

                cad = "update " & sPlacta & " set con_mov = 1, costo = " & nCostoNuevo & ", precio02 = costo " & sActFecha &
                    "where " & Funciones.GetEmp("") & " and cuenta = '" & sCodigoItem & "'"
                Bdd.EjecutarCadena(cad)

                If vgCodSistema = 3 Then
                    Call Funciones.InsertaCostoDepartamento(sCodigoItem, nCodBod, nCostoNuevo)

                    cad = "update " & wArchDeta & " " &
                        "set precioant = " & nCostoNuevo & " " &
                        "Where " & Funciones.GetEmp("") &
                        "and sig_tip = '" & sSigTip & "' " &
                        "and acu_tip = " & nAcutip & " " &
                        "and cuenta = '" & sCodigoItem & "' "

                    Bdd.EjecutarCadena(cad)

                    'ACTUALIZA EL COSTO DE LA TT AL COSTO PROMEDIO CALCULADO
                    cad = "update indetmov set costo103 = " & nCostoNuevo & ", preci103 = " & nCostoNuevo & " " &
                        "Where " & Funciones.GetEmp("") & " " &
                        "and sig_tip = 'TT' " &
                        "and estado < 3 " &
                        "and fecha >= '" & sFecha & "' " &
                        "and cuenta = '" & sCodigoItem & "'"
                    Bdd.EjecutarCadena(cad)
                End If
            Next
        End If

        '------------------------------
        Call ActItemResponsableDepartamento(Trim$(sSigTip), nAcutip)

        cad = "update " & wArchCabe & " set estado = 3 where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        Bdd.EjecutarCadena(cad)

        Call Bdd.RegistraAuditoria(wArchCabe, sSigTip, nAcutip, 3)

        cad = "update " & wArchDeta & " set periodo = " & wArchCabe & ".periodo, estado = " & wArchCabe & ".estado, fecha = " & wArchCabe & ".fec_apr " &
        "From " & wArchCabe & " " &
        "Where " & wArchCabe & ".codemp = " & wArchDeta & ".codemp " &
        "and " & wArchCabe & ".anio = " & wArchDeta & ".anio " &
        "and " & wArchCabe & ".sig_tip = " & wArchDeta & ".sig_tip " &
        "and " & wArchCabe & ".acu_tip = " & wArchDeta & ".acu_tip " &
        "and " & wArchCabe & ".codemp = '" & vgEmpresa & "' " &
        "and " & wArchCabe & ".anio = " & vgAnio & " " &
        "and " & wArchCabe & ".sig_tip = '" & sSigTip & "' " &
        "and " & wArchCabe & ".acu_tip = " & nAcutip & ";"
        Bdd.EjecutarCadena(cad)

        cad = "update " & wArchDeta & " set bodega03 = " & wArchCabe & ".bodrec02 " &
        "From " & wArchCabe & " " &
        "Where " & wArchCabe & ".codemp = " & wArchDeta & ".codemp " &
        "and " & wArchCabe & ".anio = " & wArchDeta & ".anio " &
        "and " & wArchCabe & ".sig_tip = " & wArchDeta & ".sig_tip " &
        "and " & wArchCabe & ".acu_tip = " & wArchDeta & ".acu_tip " &
        "and " & wArchCabe & ".codemp = '" & vgEmpresa & "' " &
        "and " & wArchCabe & ".anio = " & vgAnio & " " &
        "and " & wArchCabe & ".sig_tip = '" & sSigTip & "' " &
        "and " & wArchCabe & ".acu_tip = " & nAcutip & " " &
        "and " & wArchDeta & ".cantidb <> 0 ;"
        Bdd.EjecutarCadena(cad)


    End Sub

    Private Sub CmdImprimir_Click(sender As Object, e As EventArgs) Handles CmdImprimir.Click
        Call Imprimir()
    End Sub

    Private Sub ActItemResponsableDepartamento(sSigTip As String, nAcutip As Double)
        Dim RsTmp As New DataTable

        If vgCodSistema <> 5 Then
            Exit Sub
        End If
        Dim sResponsable = 0
        Dim sDepartamento = 0

        Dim sNomTabla = "acplacta"
        Dim sTablaDetalle = "acdetmov"

        cad = "select bodrec02, codrec02 from accabmov where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        RsTmp = Bdd.RetornaTabla(cad)
        If RsTmp.Rows.Count > 0 Then
            sResponsable = Nvl(RsTmp.Rows(0)("codrec02"), 0)
            sDepartamento = Nvl(RsTmp.Rows(0)("bodrec02"), 0)
        End If

        cad = "update " & sNomTabla & " set inicosdb = responsa , inicoscr = departam " &
        "where " & Funciones.GetEmp("") & " " &
        "and cuenta in (select cuenta from " & sTablaDetalle & " Where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip & ") "
        Bdd.EjecutarCadena(cad)

        cad = "update " & sNomTabla & " set responsa = " & sResponsable & ", departam = " & sDepartamento & ", sig_tip = '', acu_tip = 0 " &
        "where " & Funciones.GetEmp("") & " " &
        "and cuenta in (select cuenta from " & sTablaDetalle & " Where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip & ") "
        Bdd.EjecutarCadena(cad)


    End Sub

    Private Sub Imprimir()
        Dim sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)
        If Me.ChkOpcionImprimir.Checked = False Then
            Select Case vgCodSistema
                Case 3
                    vgParametrosRep = "302#" & sSigTip & "#" & nAcutip
                Case 5
                    vgParametrosRep = "505#" & sSigTip & "#" & nAcutip
            End Select
        End If

        If Me.ChkOpcionImprimir.Checked = True Then
            '    Select Case wCodSistema
            '        Case 3
            '            If Me.TxtCiudad.Text = UCase("Orellana") Or Me.TxtCiudad.Text = UCase("Tulcán") Then
            '                sParametros = "309#" & Trim$(Siglas(1).Text) & "#" & Trim$(pedido(0).Text)
            '            Else
            '                sParametros = "005#" & Trim$(Siglas(1).Text) & "#" & Trim$(pedido(0).Text)
            '            End If
            '        Case 5
            '            If Me.TxtCiudad.Text = UCase("Orellana") Or Me.TxtCiudad.Text = UCase("Tulcán") Then
            '                sParametros = "515#" & Trim$(Siglas(1).Text) & "#" & Trim$(pedido(0).Text)
            '            Else
            '                sParametros = "506#" & Trim$(Siglas(1).Text) & "#" & Trim$(pedido(0).Text)
            '            End If
            '    End Select
        End If

        Funciones.Imprimir(vgParametrosRep)
    End Sub

    Private Function VerificaItemsTransferencias(sSigTipIb As String, nAcuTipIb As Double)
        Dim RsVtt As New DataTable, rsT3 As New DataTable
        Dim nTieneAsociacion = 0

        cad = "select fec_apr " &
        "From " & wArchCabe & " " &
        "Where " & Funciones.GetEmp("") & " " &
        "and estado = 3 " &
        "and sig_tip = '" & sSigTipIb & "' " &
        "and acu_tip = " & nAcuTipIb & " "
        rsT3 = Bdd.RetornaTabla(cad)

        If rsT3.Rows.Count > 0 Then
            Dim sDocTT = ""
            Dim fFechaApr = rsT3.Rows(0)("fec_apr")
            cad = "SELECT sig_tip, acu_tip " &
            "From " & wArchDeta & " " &
            "Where " & Funciones.GetEmp("") & " " &
            "AND CANTICR > 0 " &
            "AND ESTADO = 3 " &
            "AND CUENTA  in(select cuenta from " & wArchDeta & " where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTipIb & "' and acu_tip = " & nAcuTipIb & ") " &
            "AND SIG_TIP = 'TT' " &
            "AND FECHA >= '" & fFechaApr & "' " &
            "group by 1, 2 " &
            "order by 1, 2"
            RsVtt = Bdd.RetornaTabla(cad)
            If (RsVtt.Rows.Count > 0) Then
                For II = 0 To RsVtt.Rows.Count - 1
                    sDocTT = sDocTT & RsVtt.Rows(II)("sig_tip") & " " & RsVtt.Rows(II)("acu_tip") & Chr(13)
                Next
            End If

            If Len(Trim$(sDocTT)) > 0 Then
                Mensajes("Las siguiente Transferencias tienen afectación con este IB." & Chr(13) & sDocTT & "tiene que desaprobar para continuar")
                nTieneAsociacion = 1
            End If
        End If

        VerificaItemsTransferencias = nTieneAsociacion
    End Function

    Private Function DevuelveStock()
        Dim nCodBod As Double, sSigTip As String, sCodigoItem As String
        Dim RsExi As New DataTable, RsDet As New DataTable, fFecha1 As String

        Dim fFecha = Me.fecha_ib.Value
        fFecha1 = fFecha
        Dim wDia = fFecha.day
        nCodBod = Val(Me.Txtdepartam.Text)
        sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)

        cad = "select count(*) as retorna " &
        "from " & wArchDeta & " a " &
        "left join " & wArchCabe & " b on a.codemp = b.codemp and a.anio = b.anio and a.sig_tip = b.sig_tip and a.acu_tip = b.acu_tip " &
        "left join " & sVistaSActual & " c on a.codemp = c.codemp and a.anio = c.anio and a.cuenta = c.cuenta " &
        "Where " & Funciones.GetEmp("a") &
        "and a.sig_tip = '" & sSigTip & "' " &
        "and a.acu_tip = " & nAcutip & " " &
        "and c.bodega = " & nCodBod & " " &
        "and ROUND(CAST(c.saldo AS NUMERIC(14,4)),2) < ROUND(CAST(a.cantidb AS NUMERIC(14,4)),2)"

        Dim nCon = Bdd.RetornaUnValor(cad)

        If nCon > 0 Then
            Mensajes("No se puede continuar, porque no existe suficiente saldo")
            DevuelveStock = 0
            Exit Function
        End If


        cad = "select * " &
        "from " & wArchDeta & " a " &
        "Where " & Funciones.GetEmp("a") &
        "and a.sig_tip = '" & sSigTip & "' " &
        "and a.acu_tip = " & nAcutip & " " &
        "order by a.acu_tip, a.sec_det"

        RsDet = Bdd.RetornaTabla(cad)
        If (RsDet.Rows.Count > 0) Then
            For II = 0 To RsDet.Rows.Count - 1
                sCodigoItem = Trim$(RsDet.Rows(II)("cuenta"))
                'graba_saldo_in sSigTip, Val(RsDet("cantidb")) * -1, 0, wperiodo, sCodigoItem, nCodBod, RsDet("costo103"), RsDet("costo103"), wDia

                cad = "update " & sPlacta & " set costo = precio02 where " & Funciones.GetEmp("") & " and cuenta = '" & sCodigoItem & "'"
                Bdd.EjecutarCadena(cad)

                cad = "update initedep set costo = costo_ant where " & Funciones.GetEmp("") & " and cuenta = '" & sCodigoItem & "' and cod_dep = " & nCodBod
                Bdd.EjecutarCadena(cad)
            Next
        End If
        DevuelveStock = 1
    End Function

    Private Sub CmdAnular_Click(sender As Object, e As EventArgs) Handles CmdAnular.Click
        Dim fFecha1 As String
        Dim sSigTip = Trim$(Me.Txtsig_tip.Text)
        Dim nAcutip = Val(Me.Txtacu_tip.Text)

        Dim sMensaje = "Desea Anular el IB " & nAcutip & ", si acepta no habra reversión, Continuar? "

        If (Mensajes(sMensaje, 1) = 7) Then
            Exit Sub
        End If

        fFecha1 = Funciones.FormatoFecha(Me.fecha_ib.Value)
        Dim wperiodo = Bdd.VerificaPeriodoAbierto(fFecha1)

        If wperiodo = 0 Then
            Mensajes("No existe período contable, no se puede continuar")
            Exit Sub
        End If

        If (DevuelveStock() = 0) Then
            Exit Sub
        End If

        cad = "update " & wArchCabe & " set estado = 6 " &
        "where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        Bdd.EjecutarCadena(cad)

        cad = "update " & wArchDeta & " set estado = 6 " &
        "where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip
        Bdd.EjecutarCadena(cad)

        Call Bdd.RegistraAuditoria(wArchCabe, sSigTip, nAcutip, 6)

        Consultar_Datos()
        HabilitaEstado()
    End Sub

    Private Sub CmdBuscaMaquina_Click(sender As Object, e As EventArgs) Handles CmdBuscaMaquina.Click
        SiFrmBuscarCatalogo.TxtCodTab.Text = 26
        SiFrmBuscarCatalogo.ShowDialog()
        Dim sCodRetorna = Val(SiFrmBuscarCatalogo.Tag)
        SiFrmBuscarCatalogo.Close()
        If (sCodRetorna = 0) Then
            Exit Sub
        End If
        Me.TxtIdMaquinaria.Text = sCodRetorna
        Me.LblMaquinaria.Text = Bdd.RetornaNombreTablas(26, sCodRetorna)
    End Sub

    Private Sub CmdQuitarMaquinaria_Click(sender As Object, e As EventArgs) Handles CmdQuitarMaquinaria.Click
        Me.TxtIdMaquinaria.Text = ""
        Me.LblMaquinaria.Text = ""
    End Sub

    Private Sub Txtcantidad_TextChanged(sender As Object, e As EventArgs) Handles Txtcantidad.TextChanged

    End Sub

    Private Sub Txtcantidad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtcantidad.KeyPress

        Me.descto03.Select()

    End Sub

    Private Sub descto03_KeyPress(sender As Object, e As KeyPressEventArgs) Handles descto03.KeyPress
        Me.TxtCostoTotReal.Select()
    End Sub

    Private Sub ActItemResponsableDepartamentoDesaprobar(sSigTip As String, nAcutip As Double)
        Dim RsTmp As New DataTable

        If vgCodSistema <> 5 Then
            Exit Sub
        End If
        Dim sResponsable = 0
        Dim sDepartamento = 0

        Dim sNomTabla = "acplacta"
        Dim sTablaDetalle = "acdetmov"

        cad = "update " & sNomTabla & " set responsa = inicosdb , departam = inicoscr " &
       "where " & Funciones.GetEmp("") & " " &
       "and cuenta in (select cuenta from " & sTablaDetalle & " Where " & Funciones.GetEmp("") & " and sig_tip = '" & sSigTip & "' and acu_tip = " & nAcutip & ") "
        Bdd.EjecutarCadena(cad)
    End Sub
End Class
