﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SiFrmEmpresa
    Inherits SFGProv.FrmClase

    'Form invalida a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtCodEmp = New System.Windows.Forms.TextBox()
        Me.Txtruc_emp = New System.Windows.Forms.TextBox()
        Me.Txtnom_emp = New System.Windows.Forms.TextBox()
        Me.Txtnomcomercial = New System.Windows.Forms.TextBox()
        Me.Txtdir_emp = New System.Windows.Forms.TextBox()
        Me.Txtciudad = New System.Windows.Forms.TextBox()
        Me.Txttel1_emp = New System.Windows.Forms.TextBox()
        Me.Txttel2_emp = New System.Windows.Forms.TextBox()
        Me.Txtfax1_emp = New System.Windows.Forms.TextBox()
        Me.txtemail1 = New System.Windows.Forms.TextBox()
        Me.Txtcontrib_espe = New System.Windows.Forms.TextBox()
        Me.Txtdfin_emp = New System.Windows.Forms.TextBox()
        Me.Txtcont_emp = New System.Windows.Forms.TextBox()
        Me.Txtcont_ruc = New System.Windows.Forms.TextBox()
        Me.Txtdfin_ruc = New System.Windows.Forms.TextBox()
        Me.Txtrep_ruc = New System.Windows.Forms.TextBox()
        Me.Txtaut_liq_comp = New System.Windows.Forms.TextBox()
        Me.Txtautoret = New System.Windows.Forms.TextBox()
        Me.Txtserieret = New System.Windows.Forms.TextBox()
        Me.Txtprovincia = New System.Windows.Forms.TextBox()
        Me.Txtrep_emp = New System.Windows.Forms.TextBox()
        Me.Txtteso_ruc = New System.Windows.Forms.TextBox()
        Me.Txtteso_emp = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.CmdBuscaLogotipo = New System.Windows.Forms.Button()
        Me.TxtPathLogo = New System.Windows.Forms.TextBox()
        Me.PbxLogotipo = New System.Windows.Forms.PictureBox()
        Me.PnlControles.SuspendLayout()
        Me.PnlNavegacion.SuspendLayout()
        CType(Me.PbxLogotipo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CmdSalir
        '
        Me.CmdSalir.Location = New System.Drawing.Point(950, 477)
        '
        'LblTitulo
        '
        Me.LblTitulo.Location = New System.Drawing.Point(81, 9)
        Me.LblTitulo.Size = New System.Drawing.Size(1007, 23)
        Me.LblTitulo.Text = "DATOS GENERALES DE LA EMPRESA"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.Location = New System.Drawing.Point(454, 15)
        Me.CmdImprimir.Visible = False
        '
        'CmdNuevo
        '
        Me.CmdNuevo.Location = New System.Drawing.Point(3, 2)
        Me.CmdNuevo.Visible = False
        '
        'CmdGrabar
        '
        Me.CmdGrabar.Location = New System.Drawing.Point(3, 2)
        '
        'CmdEditar
        '
        Me.CmdEditar.Location = New System.Drawing.Point(85, 2)
        '
        'CmdCancelar
        '
        Me.CmdCancelar.Location = New System.Drawing.Point(85, 2)
        '
        'CmdEliminar
        '
        Me.CmdEliminar.Location = New System.Drawing.Point(358, 11)
        '
        'CmdBuscar
        '
        Me.CmdBuscar.Location = New System.Drawing.Point(167, 2)
        '
        'PnlControles
        '
        Me.PnlControles.Location = New System.Drawing.Point(12, 465)
        Me.PnlControles.Size = New System.Drawing.Size(253, 64)
        '
        'LblEstado
        '
        Me.LblEstado.Location = New System.Drawing.Point(864, 0)
        '
        'PnlNavegacion
        '
        Me.PnlNavegacion.Location = New System.Drawing.Point(15, 408)
        Me.PnlNavegacion.Visible = False
        '
        'TxtCodEmp
        '
        Me.TxtCodEmp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtCodEmp.Enabled = False
        Me.TxtCodEmp.Location = New System.Drawing.Point(197, 34)
        Me.TxtCodEmp.Name = "TxtCodEmp"
        Me.TxtCodEmp.Size = New System.Drawing.Size(105, 20)
        Me.TxtCodEmp.TabIndex = 3
        '
        'Txtruc_emp
        '
        Me.Txtruc_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtruc_emp.Enabled = False
        Me.Txtruc_emp.Location = New System.Drawing.Point(197, 55)
        Me.Txtruc_emp.Name = "Txtruc_emp"
        Me.Txtruc_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtruc_emp.TabIndex = 4
        '
        'Txtnom_emp
        '
        Me.Txtnom_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtnom_emp.Enabled = False
        Me.Txtnom_emp.Location = New System.Drawing.Point(197, 77)
        Me.Txtnom_emp.Name = "Txtnom_emp"
        Me.Txtnom_emp.Size = New System.Drawing.Size(816, 20)
        Me.Txtnom_emp.TabIndex = 5
        '
        'Txtnomcomercial
        '
        Me.Txtnomcomercial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtnomcomercial.Enabled = False
        Me.Txtnomcomercial.Location = New System.Drawing.Point(197, 99)
        Me.Txtnomcomercial.Name = "Txtnomcomercial"
        Me.Txtnomcomercial.Size = New System.Drawing.Size(210, 20)
        Me.Txtnomcomercial.TabIndex = 6
        '
        'Txtdir_emp
        '
        Me.Txtdir_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtdir_emp.Enabled = False
        Me.Txtdir_emp.Location = New System.Drawing.Point(197, 122)
        Me.Txtdir_emp.Name = "Txtdir_emp"
        Me.Txtdir_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtdir_emp.TabIndex = 7
        '
        'Txtciudad
        '
        Me.Txtciudad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtciudad.Enabled = False
        Me.Txtciudad.Location = New System.Drawing.Point(197, 148)
        Me.Txtciudad.Name = "Txtciudad"
        Me.Txtciudad.Size = New System.Drawing.Size(210, 20)
        Me.Txtciudad.TabIndex = 8
        '
        'Txttel1_emp
        '
        Me.Txttel1_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txttel1_emp.Enabled = False
        Me.Txttel1_emp.Location = New System.Drawing.Point(490, 146)
        Me.Txttel1_emp.Name = "Txttel1_emp"
        Me.Txttel1_emp.Size = New System.Drawing.Size(74, 20)
        Me.Txttel1_emp.TabIndex = 9
        '
        'Txttel2_emp
        '
        Me.Txttel2_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txttel2_emp.Enabled = False
        Me.Txttel2_emp.Location = New System.Drawing.Point(644, 146)
        Me.Txttel2_emp.Name = "Txttel2_emp"
        Me.Txttel2_emp.Size = New System.Drawing.Size(112, 20)
        Me.Txttel2_emp.TabIndex = 10
        '
        'Txtfax1_emp
        '
        Me.Txtfax1_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtfax1_emp.Enabled = False
        Me.Txtfax1_emp.Location = New System.Drawing.Point(791, 146)
        Me.Txtfax1_emp.Name = "Txtfax1_emp"
        Me.Txtfax1_emp.Size = New System.Drawing.Size(112, 20)
        Me.Txtfax1_emp.TabIndex = 11
        '
        'txtemail1
        '
        Me.txtemail1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtemail1.Enabled = False
        Me.txtemail1.Location = New System.Drawing.Point(197, 172)
        Me.txtemail1.Name = "txtemail1"
        Me.txtemail1.Size = New System.Drawing.Size(564, 20)
        Me.txtemail1.TabIndex = 12
        '
        'Txtcontrib_espe
        '
        Me.Txtcontrib_espe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtcontrib_espe.Enabled = False
        Me.Txtcontrib_espe.Location = New System.Drawing.Point(197, 195)
        Me.Txtcontrib_espe.Name = "Txtcontrib_espe"
        Me.Txtcontrib_espe.Size = New System.Drawing.Size(210, 20)
        Me.Txtcontrib_espe.TabIndex = 13
        '
        'Txtdfin_emp
        '
        Me.Txtdfin_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtdfin_emp.Enabled = False
        Me.Txtdfin_emp.Location = New System.Drawing.Point(197, 243)
        Me.Txtdfin_emp.Name = "Txtdfin_emp"
        Me.Txtdfin_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtdfin_emp.TabIndex = 14
        '
        'Txtcont_emp
        '
        Me.Txtcont_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtcont_emp.Enabled = False
        Me.Txtcont_emp.Location = New System.Drawing.Point(197, 266)
        Me.Txtcont_emp.Name = "Txtcont_emp"
        Me.Txtcont_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtcont_emp.TabIndex = 15
        '
        'Txtcont_ruc
        '
        Me.Txtcont_ruc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtcont_ruc.Enabled = False
        Me.Txtcont_ruc.Location = New System.Drawing.Point(510, 266)
        Me.Txtcont_ruc.Name = "Txtcont_ruc"
        Me.Txtcont_ruc.Size = New System.Drawing.Size(210, 20)
        Me.Txtcont_ruc.TabIndex = 18
        '
        'Txtdfin_ruc
        '
        Me.Txtdfin_ruc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtdfin_ruc.Enabled = False
        Me.Txtdfin_ruc.Location = New System.Drawing.Point(510, 243)
        Me.Txtdfin_ruc.Name = "Txtdfin_ruc"
        Me.Txtdfin_ruc.Size = New System.Drawing.Size(210, 20)
        Me.Txtdfin_ruc.TabIndex = 17
        '
        'Txtrep_ruc
        '
        Me.Txtrep_ruc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtrep_ruc.Enabled = False
        Me.Txtrep_ruc.Location = New System.Drawing.Point(510, 220)
        Me.Txtrep_ruc.Name = "Txtrep_ruc"
        Me.Txtrep_ruc.Size = New System.Drawing.Size(210, 20)
        Me.Txtrep_ruc.TabIndex = 16
        '
        'Txtaut_liq_comp
        '
        Me.Txtaut_liq_comp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtaut_liq_comp.Enabled = False
        Me.Txtaut_liq_comp.Location = New System.Drawing.Point(629, 328)
        Me.Txtaut_liq_comp.Name = "Txtaut_liq_comp"
        Me.Txtaut_liq_comp.Size = New System.Drawing.Size(210, 20)
        Me.Txtaut_liq_comp.TabIndex = 21
        '
        'Txtautoret
        '
        Me.Txtautoret.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtautoret.Enabled = False
        Me.Txtautoret.Location = New System.Drawing.Point(413, 328)
        Me.Txtautoret.Name = "Txtautoret"
        Me.Txtautoret.Size = New System.Drawing.Size(210, 20)
        Me.Txtautoret.TabIndex = 20
        '
        'Txtserieret
        '
        Me.Txtserieret.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtserieret.Enabled = False
        Me.Txtserieret.Location = New System.Drawing.Point(197, 328)
        Me.Txtserieret.Name = "Txtserieret"
        Me.Txtserieret.Size = New System.Drawing.Size(210, 20)
        Me.Txtserieret.TabIndex = 19
        '
        'Txtprovincia
        '
        Me.Txtprovincia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtprovincia.Enabled = False
        Me.Txtprovincia.Location = New System.Drawing.Point(950, 142)
        Me.Txtprovincia.Name = "Txtprovincia"
        Me.Txtprovincia.Size = New System.Drawing.Size(63, 20)
        Me.Txtprovincia.TabIndex = 22
        '
        'Txtrep_emp
        '
        Me.Txtrep_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtrep_emp.Enabled = False
        Me.Txtrep_emp.Location = New System.Drawing.Point(197, 221)
        Me.Txtrep_emp.Name = "Txtrep_emp"
        Me.Txtrep_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtrep_emp.TabIndex = 23
        '
        'Txtteso_ruc
        '
        Me.Txtteso_ruc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtteso_ruc.Enabled = False
        Me.Txtteso_ruc.Location = New System.Drawing.Point(510, 289)
        Me.Txtteso_ruc.Name = "Txtteso_ruc"
        Me.Txtteso_ruc.Size = New System.Drawing.Size(210, 20)
        Me.Txtteso_ruc.TabIndex = 25
        '
        'Txtteso_emp
        '
        Me.Txtteso_emp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtteso_emp.Enabled = False
        Me.Txtteso_emp.Location = New System.Drawing.Point(197, 289)
        Me.Txtteso_emp.Name = "Txtteso_emp"
        Me.Txtteso_emp.Size = New System.Drawing.Size(210, 20)
        Me.Txtteso_emp.TabIndex = 24
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(147, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Código:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(160, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "RUC:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(111, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Razón Social:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(84, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 13)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Nombre Comercial:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(132, 124)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Dirección:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(147, 153)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 13)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Ciudad:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(413, 149)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 13)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Teléfono 1:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(570, 149)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 13)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Teléfono 2:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(756, 149)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "Fax:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(151, 174)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 35
        Me.Label10.Text = "E-Mail:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(924, 122)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 13)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "Cod. Provincia"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(4, 202)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(193, 13)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "Contrib. Espec. Nro. Resolución:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(103, 223)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 13)
        Me.Label13.TabIndex = 38
        Me.Label13.Text = "Representante:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(90, 247)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(107, 13)
        Me.Label14.TabIndex = 39
        Me.Label14.Text = "Dir. Financiero/a:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(135, 268)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(62, 13)
        Me.Label15.TabIndex = 40
        Me.Label15.Text = "Contador:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(123, 289)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(74, 13)
        Me.Label16.TabIndex = 41
        Me.Label16.Text = "Tesorero/a:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(414, 223)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(91, 13)
        Me.Label17.TabIndex = 42
        Me.Label17.Text = "Cédula o RUC:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(414, 247)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(91, 13)
        Me.Label18.TabIndex = 43
        Me.Label18.Text = "Cédula o RUC:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(468, 269)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 13)
        Me.Label19.TabIndex = 44
        Me.Label19.Text = "RUC:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(414, 293)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(91, 13)
        Me.Label20.TabIndex = 45
        Me.Label20.Text = "Cédula o RUC:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(50, 330)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(147, 13)
        Me.Label21.TabIndex = 46
        Me.Label21.Text = "Datos Cpbte. Retención:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(211, 312)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(36, 13)
        Me.Label22.TabIndex = 47
        Me.Label22.Text = "Serie"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(413, 312)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(77, 13)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Autorización"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(626, 312)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(196, 13)
        Me.Label24.TabIndex = 49
        Me.Label24.Text = "Autorización  Liquidación Compra"
        '
        'CmdBuscaLogotipo
        '
        Me.CmdBuscaLogotipo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscaLogotipo.Enabled = False
        Me.CmdBuscaLogotipo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdBuscaLogotipo.Location = New System.Drawing.Point(353, 493)
        Me.CmdBuscaLogotipo.Name = "CmdBuscaLogotipo"
        Me.CmdBuscaLogotipo.Size = New System.Drawing.Size(317, 25)
        Me.CmdBuscaLogotipo.TabIndex = 50
        Me.CmdBuscaLogotipo.Text = "Buscar Logotipo"
        Me.CmdBuscaLogotipo.UseVisualStyleBackColor = True
        '
        'TxtPathLogo
        '
        Me.TxtPathLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPathLogo.Enabled = False
        Me.TxtPathLogo.Location = New System.Drawing.Point(672, 493)
        Me.TxtPathLogo.Name = "TxtPathLogo"
        Me.TxtPathLogo.Size = New System.Drawing.Size(48, 20)
        Me.TxtPathLogo.TabIndex = 51
        Me.TxtPathLogo.Visible = False
        '
        'PbxLogotipo
        '
        Me.PbxLogotipo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PbxLogotipo.Location = New System.Drawing.Point(353, 354)
        Me.PbxLogotipo.Name = "PbxLogotipo"
        Me.PbxLogotipo.Size = New System.Drawing.Size(317, 133)
        Me.PbxLogotipo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PbxLogotipo.TabIndex = 52
        Me.PbxLogotipo.TabStop = False
        '
        'SiFrmEmpresa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1023, 541)
        Me.Controls.Add(Me.PbxLogotipo)
        Me.Controls.Add(Me.TxtPathLogo)
        Me.Controls.Add(Me.CmdBuscaLogotipo)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txtteso_ruc)
        Me.Controls.Add(Me.Txtteso_emp)
        Me.Controls.Add(Me.Txtrep_emp)
        Me.Controls.Add(Me.Txtprovincia)
        Me.Controls.Add(Me.Txtaut_liq_comp)
        Me.Controls.Add(Me.Txtautoret)
        Me.Controls.Add(Me.Txtserieret)
        Me.Controls.Add(Me.Txtcont_ruc)
        Me.Controls.Add(Me.Txtdfin_ruc)
        Me.Controls.Add(Me.Txtrep_ruc)
        Me.Controls.Add(Me.Txtcont_emp)
        Me.Controls.Add(Me.Txtdfin_emp)
        Me.Controls.Add(Me.Txtcontrib_espe)
        Me.Controls.Add(Me.txtemail1)
        Me.Controls.Add(Me.Txtfax1_emp)
        Me.Controls.Add(Me.Txttel2_emp)
        Me.Controls.Add(Me.Txttel1_emp)
        Me.Controls.Add(Me.Txtciudad)
        Me.Controls.Add(Me.Txtdir_emp)
        Me.Controls.Add(Me.Txtnomcomercial)
        Me.Controls.Add(Me.Txtnom_emp)
        Me.Controls.Add(Me.Txtruc_emp)
        Me.Controls.Add(Me.TxtCodEmp)
        Me.Name = "SiFrmEmpresa"
        Me.Text = "Datos de la Empresa"
        Me.Controls.SetChildIndex(Me.PnlNavegacion, 0)
        Me.Controls.SetChildIndex(Me.LblEstado, 0)
        Me.Controls.SetChildIndex(Me.PnlControles, 0)
        Me.Controls.SetChildIndex(Me.CmdSalir, 0)
        Me.Controls.SetChildIndex(Me.LblTitulo, 0)
        Me.Controls.SetChildIndex(Me.TxtCodEmp, 0)
        Me.Controls.SetChildIndex(Me.Txtruc_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtnom_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtnomcomercial, 0)
        Me.Controls.SetChildIndex(Me.Txtdir_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtciudad, 0)
        Me.Controls.SetChildIndex(Me.Txttel1_emp, 0)
        Me.Controls.SetChildIndex(Me.Txttel2_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtfax1_emp, 0)
        Me.Controls.SetChildIndex(Me.txtemail1, 0)
        Me.Controls.SetChildIndex(Me.Txtcontrib_espe, 0)
        Me.Controls.SetChildIndex(Me.Txtdfin_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtcont_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtrep_ruc, 0)
        Me.Controls.SetChildIndex(Me.Txtdfin_ruc, 0)
        Me.Controls.SetChildIndex(Me.Txtcont_ruc, 0)
        Me.Controls.SetChildIndex(Me.Txtserieret, 0)
        Me.Controls.SetChildIndex(Me.Txtautoret, 0)
        Me.Controls.SetChildIndex(Me.Txtaut_liq_comp, 0)
        Me.Controls.SetChildIndex(Me.Txtprovincia, 0)
        Me.Controls.SetChildIndex(Me.Txtrep_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtteso_emp, 0)
        Me.Controls.SetChildIndex(Me.Txtteso_ruc, 0)
        Me.Controls.SetChildIndex(Me.Label1, 0)
        Me.Controls.SetChildIndex(Me.Label2, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.Label4, 0)
        Me.Controls.SetChildIndex(Me.Label5, 0)
        Me.Controls.SetChildIndex(Me.Label6, 0)
        Me.Controls.SetChildIndex(Me.Label7, 0)
        Me.Controls.SetChildIndex(Me.Label8, 0)
        Me.Controls.SetChildIndex(Me.Label9, 0)
        Me.Controls.SetChildIndex(Me.Label10, 0)
        Me.Controls.SetChildIndex(Me.Label11, 0)
        Me.Controls.SetChildIndex(Me.Label12, 0)
        Me.Controls.SetChildIndex(Me.Label13, 0)
        Me.Controls.SetChildIndex(Me.Label14, 0)
        Me.Controls.SetChildIndex(Me.Label15, 0)
        Me.Controls.SetChildIndex(Me.Label16, 0)
        Me.Controls.SetChildIndex(Me.Label17, 0)
        Me.Controls.SetChildIndex(Me.Label18, 0)
        Me.Controls.SetChildIndex(Me.Label19, 0)
        Me.Controls.SetChildIndex(Me.Label20, 0)
        Me.Controls.SetChildIndex(Me.Label21, 0)
        Me.Controls.SetChildIndex(Me.Label22, 0)
        Me.Controls.SetChildIndex(Me.Label23, 0)
        Me.Controls.SetChildIndex(Me.Label24, 0)
        Me.Controls.SetChildIndex(Me.CmdBuscaLogotipo, 0)
        Me.Controls.SetChildIndex(Me.TxtPathLogo, 0)
        Me.Controls.SetChildIndex(Me.PbxLogotipo, 0)
        Me.PnlControles.ResumeLayout(False)
        Me.PnlControles.PerformLayout()
        Me.PnlNavegacion.ResumeLayout(False)
        CType(Me.PbxLogotipo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtCodEmp As TextBox
    Friend WithEvents Txtruc_emp As TextBox
    Friend WithEvents Txtnom_emp As TextBox
    Friend WithEvents Txtnomcomercial As TextBox
    Friend WithEvents Txtdir_emp As TextBox
    Friend WithEvents Txtciudad As TextBox
    Friend WithEvents Txttel1_emp As TextBox
    Friend WithEvents Txttel2_emp As TextBox
    Friend WithEvents Txtfax1_emp As TextBox
    Friend WithEvents txtemail1 As TextBox
    Friend WithEvents Txtcontrib_espe As TextBox
    Friend WithEvents Txtdfin_emp As TextBox
    Friend WithEvents Txtcont_emp As TextBox
    Friend WithEvents Txtcont_ruc As TextBox
    Friend WithEvents Txtdfin_ruc As TextBox
    Friend WithEvents Txtrep_ruc As TextBox
    Friend WithEvents Txtaut_liq_comp As TextBox
    Friend WithEvents Txtautoret As TextBox
    Friend WithEvents Txtserieret As TextBox
    Friend WithEvents Txtprovincia As TextBox
    Friend WithEvents Txtrep_emp As TextBox
    Friend WithEvents Txtteso_ruc As TextBox
    Friend WithEvents Txtteso_emp As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents CmdBuscaLogotipo As Button
    Friend WithEvents TxtPathLogo As TextBox
    Friend WithEvents PbxLogotipo As PictureBox
End Class
