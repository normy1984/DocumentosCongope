﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IA_Frm_Ingreso_Bodega
    Inherits SFGProv.FrmClase

    'Form invalida a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ChkNoDevIva = New System.Windows.Forms.CheckBox()
        Me.CmdAnular = New System.Windows.Forms.Button()
        Me.LblPorcenIva = New System.Windows.Forms.Label()
        Me.Txtsig_tip = New System.Windows.Forms.TextBox()
        Me.TxtDepartamento = New System.Windows.Forms.TextBox()
        Me.Txtresponsable = New System.Windows.Forms.TextBox()
        Me.Txtcedruc = New System.Windows.Forms.TextBox()
        Me.fecha_ib = New System.Windows.Forms.DateTimePicker()
        Me.Txtcedruc_nombre = New System.Windows.Forms.TextBox()
        Me.Txtestable = New System.Windows.Forms.TextBox()
        Me.Txtpunto_emi = New System.Windows.Forms.TextBox()
        Me.Txtfactura = New System.Windows.Forms.TextBox()
        Me.fecha_factura = New System.Windows.Forms.DateTimePicker()
        Me.TxtPtoLlega = New System.Windows.Forms.TextBox()
        Me.Txtobserva = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CmdQuitar = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.BtnAgregar = New System.Windows.Forms.Button()
        Me.TxtSecDet = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.LblCmasIBP = New System.Windows.Forms.Label()
        Me.CmdF4 = New System.Windows.Forms.Button()
        Me.ChkIva = New System.Windows.Forms.CheckBox()
        Me.chkCaducidad = New System.Windows.Forms.CheckBox()
        Me.LblCostoItem = New System.Windows.Forms.TextBox()
        Me.LblCostoTotal = New System.Windows.Forms.TextBox()
        Me.preciotot = New System.Windows.Forms.TextBox()
        Me.TxtCostoTotReal = New System.Windows.Forms.TextBox()
        Me.descto03 = New System.Windows.Forms.TextBox()
        Me.Txtcantidad = New System.Windows.Forms.TextBox()
        Me.txtcostoact = New System.Windows.Forms.TextBox()
        Me.txtnom_cue = New System.Windows.Forms.TextBox()
        Me.Txtcuenta = New System.Windows.Forms.TextBox()
        Me.Grid1 = New System.Windows.Forms.DataGridView()
        Me.Grid2 = New System.Windows.Forms.DataGridView()
        Me.Txtacu_tip = New System.Windows.Forms.TextBox()
        Me.txtresponsa = New System.Windows.Forms.TextBox()
        Me.Txtdepartam = New System.Windows.Forms.TextBox()
        Me.Txtsecuencia = New System.Windows.Forms.TextBox()
        Me.ChkSujetosControl = New System.Windows.Forms.CheckBox()
        Me.LblCpbteAsocia = New System.Windows.Forms.Label()
        Me.CmbTipoDocum = New System.Windows.Forms.ComboBox()
        Me.LblConsedoc = New System.Windows.Forms.Label()
        Me.CntMaquinaria = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.LblMaquinaria = New System.Windows.Forms.Label()
        Me.CmdQuitarMaquinaria = New System.Windows.Forms.Button()
        Me.CmdBuscaMaquina = New System.Windows.Forms.Button()
        Me.TxtIdMaquinaria = New System.Windows.Forms.TextBox()
        Me.ChkNoPropietario = New System.Windows.Forms.CheckBox()
        Me.ChkAsociarNotaEnt = New System.Windows.Forms.CheckBox()
        Me.LblNotaEntrega = New System.Windows.Forms.Label()
        Me.TxtNte_Id = New System.Windows.Forms.TextBox()
        Me.LblSubTotal_2 = New System.Windows.Forms.TextBox()
        Me.LblDescuentos = New System.Windows.Forms.TextBox()
        Me.LblSubTotal = New System.Windows.Forms.TextBox()
        Me.LblValorIva = New System.Windows.Forms.TextBox()
        Me.LblIRBPNR = New System.Windows.Forms.TextBox()
        Me.LblTotal = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.CmdBuscaDepartamento = New System.Windows.Forms.Button()
        Me.CmdBuscaResponsable = New System.Windows.Forms.Button()
        Me.CmdBuscaProveedor = New System.Windows.Forms.Button()
        Me.CmdDocEscaneados = New System.Windows.Forms.Button()
        Me.TxtIrbpnr = New System.Windows.Forms.TextBox()
        Me.TxtRetencion100IVA = New System.Windows.Forms.TextBox()
        Me.wnrodias = New System.Windows.Forms.TextBox()
        Me.Check2 = New System.Windows.Forms.CheckBox()
        Me.ivapres = New System.Windows.Forms.TextBox()
        Me.RET3XMI = New System.Windows.Forms.TextBox()
        Me.LblSubTotal12 = New System.Windows.Forms.TextBox()
        Me.LblSubTotal0 = New System.Windows.Forms.TextBox()
        Me.ChkOpcionImprimir = New System.Windows.Forms.CheckBox()
        Me.CmdResumenCtaCnt = New System.Windows.Forms.Button()
        Me.CmdGenerarDBF = New System.Windows.Forms.Button()
        Me.LblNroItems = New System.Windows.Forms.Label()
        Me.PnlControles.SuspendLayout()
        Me.PnlNavegacion.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Grid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Grid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CntMaquinaria.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdSalir
        '
        Me.CmdSalir.Location = New System.Drawing.Point(986, 522)
        '
        'LblTitulo
        '
        Me.LblTitulo.Location = New System.Drawing.Point(0, 0)
        Me.LblTitulo.Size = New System.Drawing.Size(1060, 23)
        Me.LblTitulo.Text = "INGRESO A BODEGA - EXISTENCIAS"
        '
        'CmdImprimir
        '
        '
        'CmdNuevo
        '
        '
        'CmdGrabar
        '
        '
        'CmdEditar
        '
        '
        'CmdCancelar
        '
        '
        'CmdEliminar
        '
        Me.CmdEliminar.Location = New System.Drawing.Point(737, 0)
        Me.CmdEliminar.Visible = False
        '
        'CmdBuscar
        '
        '
        'PnlControles
        '
        Me.PnlControles.Controls.Add(Me.CmdAnular)
        Me.PnlControles.Location = New System.Drawing.Point(12, 519)
        Me.PnlControles.Size = New System.Drawing.Size(501, 61)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdGrabar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdCancelar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdNuevo, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdEditar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdDesaprobar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdAprobar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.ChkNoHabilitar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.ChkNuevoEditar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdImprimir, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdBuscar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdEliminar, 0)
        Me.PnlControles.Controls.SetChildIndex(Me.CmdAnular, 0)
        '
        'CmdDesaprobar
        '
        Me.CmdDesaprobar.Location = New System.Drawing.Point(330, 1)
        '
        'CmdAprobar
        '
        Me.CmdAprobar.Location = New System.Drawing.Point(330, 1)
        '
        'LblEstado
        '
        Me.LblEstado.Location = New System.Drawing.Point(903, 0)
        '
        'CmdInicio
        '
        '
        'CmdFinal
        '
        '
        'CmdDerecha
        '
        '
        'CmdIzquierda
        '
        '
        'PnlNavegacion
        '
        Me.PnlNavegacion.Location = New System.Drawing.Point(282, 380)
        '
        'ChkNoDevIva
        '
        Me.ChkNoDevIva.AutoSize = True
        Me.ChkNoDevIva.Location = New System.Drawing.Point(187, 494)
        Me.ChkNoDevIva.Name = "ChkNoDevIva"
        Me.ChkNoDevIva.Size = New System.Drawing.Size(81, 17)
        Me.ChkNoDevIva.TabIndex = 7
        Me.ChkNoDevIva.Text = "CheckBox1"
        Me.ChkNoDevIva.UseVisualStyleBackColor = True
        Me.ChkNoDevIva.Visible = False
        '
        'CmdAnular
        '
        Me.CmdAnular.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdAnular.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdAnular.Image = Global.SFGProv.My.Resources.Resources.btn_anular
        Me.CmdAnular.Location = New System.Drawing.Point(415, 4)
        Me.CmdAnular.Name = "CmdAnular"
        Me.CmdAnular.Size = New System.Drawing.Size(79, 53)
        Me.CmdAnular.TabIndex = 18
        Me.CmdAnular.Text = "Anular"
        Me.CmdAnular.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdAnular.UseVisualStyleBackColor = True
        '
        'LblPorcenIva
        '
        Me.LblPorcenIva.AutoSize = True
        Me.LblPorcenIva.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPorcenIva.Location = New System.Drawing.Point(857, 454)
        Me.LblPorcenIva.Name = "LblPorcenIva"
        Me.LblPorcenIva.Size = New System.Drawing.Size(65, 13)
        Me.LblPorcenIva.TabIndex = 8
        Me.LblPorcenIva.Text = "IVA <> 0%"
        '
        'Txtsig_tip
        '
        Me.Txtsig_tip.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtsig_tip.Location = New System.Drawing.Point(117, 33)
        Me.Txtsig_tip.Name = "Txtsig_tip"
        Me.Txtsig_tip.ReadOnly = True
        Me.Txtsig_tip.Size = New System.Drawing.Size(24, 20)
        Me.Txtsig_tip.TabIndex = 9
        Me.Txtsig_tip.Text = "IB"
        '
        'TxtDepartamento
        '
        Me.TxtDepartamento.BackColor = System.Drawing.SystemColors.ControlDark
        Me.TxtDepartamento.Location = New System.Drawing.Point(115, 55)
        Me.TxtDepartamento.Name = "TxtDepartamento"
        Me.TxtDepartamento.ReadOnly = True
        Me.TxtDepartamento.Size = New System.Drawing.Size(286, 20)
        Me.TxtDepartamento.TabIndex = 10
        '
        'Txtresponsable
        '
        Me.Txtresponsable.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtresponsable.Location = New System.Drawing.Point(115, 77)
        Me.Txtresponsable.Name = "Txtresponsable"
        Me.Txtresponsable.ReadOnly = True
        Me.Txtresponsable.Size = New System.Drawing.Size(286, 20)
        Me.Txtresponsable.TabIndex = 11
        '
        'Txtcedruc
        '
        Me.Txtcedruc.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtcedruc.Location = New System.Drawing.Point(574, 35)
        Me.Txtcedruc.Name = "Txtcedruc"
        Me.Txtcedruc.ReadOnly = True
        Me.Txtcedruc.Size = New System.Drawing.Size(96, 20)
        Me.Txtcedruc.TabIndex = 12
        '
        'fecha_ib
        '
        Me.fecha_ib.Cursor = System.Windows.Forms.Cursors.Hand
        Me.fecha_ib.Enabled = False
        Me.fecha_ib.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.fecha_ib.Location = New System.Drawing.Point(115, 99)
        Me.fecha_ib.Name = "fecha_ib"
        Me.fecha_ib.Size = New System.Drawing.Size(102, 20)
        Me.fecha_ib.TabIndex = 13
        '
        'Txtcedruc_nombre
        '
        Me.Txtcedruc_nombre.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtcedruc_nombre.Location = New System.Drawing.Point(675, 35)
        Me.Txtcedruc_nombre.Name = "Txtcedruc_nombre"
        Me.Txtcedruc_nombre.ReadOnly = True
        Me.Txtcedruc_nombre.Size = New System.Drawing.Size(329, 20)
        Me.Txtcedruc_nombre.TabIndex = 14
        '
        'Txtestable
        '
        Me.Txtestable.Enabled = False
        Me.Txtestable.Location = New System.Drawing.Point(574, 56)
        Me.Txtestable.Name = "Txtestable"
        Me.Txtestable.Size = New System.Drawing.Size(39, 20)
        Me.Txtestable.TabIndex = 15
        '
        'Txtpunto_emi
        '
        Me.Txtpunto_emi.Enabled = False
        Me.Txtpunto_emi.Location = New System.Drawing.Point(632, 56)
        Me.Txtpunto_emi.Name = "Txtpunto_emi"
        Me.Txtpunto_emi.Size = New System.Drawing.Size(38, 20)
        Me.Txtpunto_emi.TabIndex = 16
        '
        'Txtfactura
        '
        Me.Txtfactura.Enabled = False
        Me.Txtfactura.Location = New System.Drawing.Point(691, 56)
        Me.Txtfactura.Name = "Txtfactura"
        Me.Txtfactura.Size = New System.Drawing.Size(101, 20)
        Me.Txtfactura.TabIndex = 17
        '
        'fecha_factura
        '
        Me.fecha_factura.Cursor = System.Windows.Forms.Cursors.Hand
        Me.fecha_factura.Enabled = False
        Me.fecha_factura.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.fecha_factura.Location = New System.Drawing.Point(907, 56)
        Me.fecha_factura.Name = "fecha_factura"
        Me.fecha_factura.Size = New System.Drawing.Size(97, 20)
        Me.fecha_factura.TabIndex = 18
        '
        'TxtPtoLlega
        '
        Me.TxtPtoLlega.Enabled = False
        Me.TxtPtoLlega.Location = New System.Drawing.Point(574, 77)
        Me.TxtPtoLlega.Name = "TxtPtoLlega"
        Me.TxtPtoLlega.Size = New System.Drawing.Size(218, 20)
        Me.TxtPtoLlega.TabIndex = 19
        '
        'Txtobserva
        '
        Me.Txtobserva.Location = New System.Drawing.Point(574, 99)
        Me.Txtobserva.Multiline = True
        Me.Txtobserva.Name = "Txtobserva"
        Me.Txtobserva.ReadOnly = True
        Me.Txtobserva.Size = New System.Drawing.Size(430, 47)
        Me.Txtobserva.TabIndex = 20
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.CmdQuitar)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.BtnAgregar)
        Me.Panel1.Controls.Add(Me.TxtSecDet)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.LblCmasIBP)
        Me.Panel1.Controls.Add(Me.CmdF4)
        Me.Panel1.Controls.Add(Me.ChkIva)
        Me.Panel1.Controls.Add(Me.chkCaducidad)
        Me.Panel1.Controls.Add(Me.LblCostoItem)
        Me.Panel1.Controls.Add(Me.LblCostoTotal)
        Me.Panel1.Controls.Add(Me.preciotot)
        Me.Panel1.Controls.Add(Me.TxtCostoTotReal)
        Me.Panel1.Controls.Add(Me.descto03)
        Me.Panel1.Controls.Add(Me.Txtcantidad)
        Me.Panel1.Controls.Add(Me.txtcostoact)
        Me.Panel1.Controls.Add(Me.txtnom_cue)
        Me.Panel1.Controls.Add(Me.Txtcuenta)
        Me.Panel1.Enabled = False
        Me.Panel1.Location = New System.Drawing.Point(5, 148)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1054, 41)
        Me.Panel1.TabIndex = 21
        '
        'CmdQuitar
        '
        Me.CmdQuitar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdQuitar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdQuitar.Location = New System.Drawing.Point(1001, 0)
        Me.CmdQuitar.Name = "CmdQuitar"
        Me.CmdQuitar.Size = New System.Drawing.Size(50, 38)
        Me.CmdQuitar.TabIndex = 65
        Me.CmdQuitar.Text = "Quitar"
        Me.CmdQuitar.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(167, 2)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(74, 13)
        Me.Label22.TabIndex = 62
        Me.Label22.Text = "Descripción"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(7, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 13)
        Me.Label15.TabIndex = 61
        Me.Label15.Text = "Código"
        '
        'BtnAgregar
        '
        Me.BtnAgregar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAgregar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAgregar.Location = New System.Drawing.Point(939, 0)
        Me.BtnAgregar.Name = "BtnAgregar"
        Me.BtnAgregar.Size = New System.Drawing.Size(61, 38)
        Me.BtnAgregar.TabIndex = 4
        Me.BtnAgregar.Text = "Agregar"
        Me.BtnAgregar.UseVisualStyleBackColor = True
        '
        'TxtSecDet
        '
        Me.TxtSecDet.Location = New System.Drawing.Point(1021, 3)
        Me.TxtSecDet.Name = "TxtSecDet"
        Me.TxtSecDet.Size = New System.Drawing.Size(24, 20)
        Me.TxtSecDet.TabIndex = 60
        Me.TxtSecDet.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(379, 3)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(63, 13)
        Me.Label21.TabIndex = 59
        Me.Label21.Text = "Cost. Act."
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(450, 3)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(57, 13)
        Me.Label20.TabIndex = 58
        Me.Label20.Text = "Cantidad"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(525, 3)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(44, 13)
        Me.Label19.TabIndex = 57
        Me.Label19.Text = "Dscto."
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(582, 3)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(73, 13)
        Me.Label18.TabIndex = 56
        Me.Label18.Text = "Costo Real."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(655, 3)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(76, 13)
        Me.Label17.TabIndex = 55
        Me.Label17.Text = "Costo Desc."
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(732, 3)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(74, 13)
        Me.Label16.TabIndex = 54
        Me.Label16.Text = "Costo + IVA"
        '
        'LblCmasIBP
        '
        Me.LblCmasIBP.AutoSize = True
        Me.LblCmasIBP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCmasIBP.Location = New System.Drawing.Point(806, 3)
        Me.LblCmasIBP.Name = "LblCmasIBP"
        Me.LblCmasIBP.Size = New System.Drawing.Size(66, 13)
        Me.LblCmasIBP.TabIndex = 53
        Me.LblCmasIBP.Text = "Costo Uni."
        '
        'CmdF4
        '
        Me.CmdF4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdF4.Location = New System.Drawing.Point(128, 16)
        Me.CmdF4.Name = "CmdF4"
        Me.CmdF4.Size = New System.Drawing.Size(29, 23)
        Me.CmdF4.TabIndex = 25
        Me.CmdF4.Text = "+"
        Me.CmdF4.UseVisualStyleBackColor = True
        '
        'ChkIva
        '
        Me.ChkIva.AutoSize = True
        Me.ChkIva.Enabled = False
        Me.ChkIva.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkIva.Location = New System.Drawing.Point(875, 1)
        Me.ChkIva.Name = "ChkIva"
        Me.ChkIva.Size = New System.Drawing.Size(58, 17)
        Me.ChkIva.TabIndex = 23
        Me.ChkIva.Text = "I.V.A."
        Me.ChkIva.UseVisualStyleBackColor = True
        '
        'chkCaducidad
        '
        Me.chkCaducidad.AutoSize = True
        Me.chkCaducidad.Enabled = False
        Me.chkCaducidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCaducidad.Location = New System.Drawing.Point(875, 21)
        Me.chkCaducidad.Name = "chkCaducidad"
        Me.chkCaducidad.Size = New System.Drawing.Size(72, 17)
        Me.chkCaducidad.TabIndex = 22
        Me.chkCaducidad.Text = "CADUC."
        Me.chkCaducidad.UseVisualStyleBackColor = True
        '
        'LblCostoItem
        '
        Me.LblCostoItem.BackColor = System.Drawing.SystemColors.ControlDark
        Me.LblCostoItem.Location = New System.Drawing.Point(802, 18)
        Me.LblCostoItem.Name = "LblCostoItem"
        Me.LblCostoItem.ReadOnly = True
        Me.LblCostoItem.Size = New System.Drawing.Size(68, 20)
        Me.LblCostoItem.TabIndex = 21
        Me.LblCostoItem.Text = "0.00"
        Me.LblCostoItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblCostoTotal
        '
        Me.LblCostoTotal.BackColor = System.Drawing.SystemColors.ControlDark
        Me.LblCostoTotal.Location = New System.Drawing.Point(729, 18)
        Me.LblCostoTotal.Name = "LblCostoTotal"
        Me.LblCostoTotal.ReadOnly = True
        Me.LblCostoTotal.Size = New System.Drawing.Size(68, 20)
        Me.LblCostoTotal.TabIndex = 20
        Me.LblCostoTotal.Text = "0.00"
        Me.LblCostoTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'preciotot
        '
        Me.preciotot.Location = New System.Drawing.Point(657, 18)
        Me.preciotot.Name = "preciotot"
        Me.preciotot.Size = New System.Drawing.Size(68, 20)
        Me.preciotot.TabIndex = 3
        Me.preciotot.Text = "0.00"
        Me.preciotot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TxtCostoTotReal
        '
        Me.TxtCostoTotReal.Location = New System.Drawing.Point(584, 18)
        Me.TxtCostoTotReal.Name = "TxtCostoTotReal"
        Me.TxtCostoTotReal.Size = New System.Drawing.Size(68, 20)
        Me.TxtCostoTotReal.TabIndex = 2
        Me.TxtCostoTotReal.Text = "0.00"
        Me.TxtCostoTotReal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'descto03
        '
        Me.descto03.Location = New System.Drawing.Point(512, 18)
        Me.descto03.Name = "descto03"
        Me.descto03.Size = New System.Drawing.Size(68, 20)
        Me.descto03.TabIndex = 1
        Me.descto03.Text = "0.00"
        Me.descto03.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Txtcantidad
        '
        Me.Txtcantidad.Location = New System.Drawing.Point(440, 18)
        Me.Txtcantidad.Name = "Txtcantidad"
        Me.Txtcantidad.Size = New System.Drawing.Size(68, 20)
        Me.Txtcantidad.TabIndex = 0
        Me.Txtcantidad.Text = "0.00"
        Me.Txtcantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtcostoact
        '
        Me.txtcostoact.BackColor = System.Drawing.SystemColors.ControlDark
        Me.txtcostoact.Location = New System.Drawing.Point(369, 18)
        Me.txtcostoact.Name = "txtcostoact"
        Me.txtcostoact.ReadOnly = True
        Me.txtcostoact.Size = New System.Drawing.Size(68, 20)
        Me.txtcostoact.TabIndex = 15
        Me.txtcostoact.TabStop = False
        Me.txtcostoact.Text = "0.00"
        Me.txtcostoact.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtnom_cue
        '
        Me.txtnom_cue.BackColor = System.Drawing.SystemColors.ControlDark
        Me.txtnom_cue.Location = New System.Drawing.Point(159, 18)
        Me.txtnom_cue.Name = "txtnom_cue"
        Me.txtnom_cue.ReadOnly = True
        Me.txtnom_cue.Size = New System.Drawing.Size(208, 20)
        Me.txtnom_cue.TabIndex = 14
        Me.txtnom_cue.TabStop = False
        '
        'Txtcuenta
        '
        Me.Txtcuenta.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtcuenta.Location = New System.Drawing.Point(5, 18)
        Me.Txtcuenta.Name = "Txtcuenta"
        Me.Txtcuenta.ReadOnly = True
        Me.Txtcuenta.Size = New System.Drawing.Size(121, 20)
        Me.Txtcuenta.TabIndex = 13
        Me.Txtcuenta.TabStop = False
        '
        'Grid1
        '
        Me.Grid1.AllowUserToAddRows = False
        Me.Grid1.AllowUserToDeleteRows = False
        Me.Grid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid1.Location = New System.Drawing.Point(5, 190)
        Me.Grid1.Name = "Grid1"
        Me.Grid1.ReadOnly = True
        Me.Grid1.Size = New System.Drawing.Size(1046, 188)
        Me.Grid1.TabIndex = 22
        '
        'Grid2
        '
        Me.Grid2.AllowUserToAddRows = False
        Me.Grid2.AllowUserToDeleteRows = False
        Me.Grid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid2.Location = New System.Drawing.Point(453, 380)
        Me.Grid2.Name = "Grid2"
        Me.Grid2.ReadOnly = True
        Me.Grid2.Size = New System.Drawing.Size(376, 102)
        Me.Grid2.TabIndex = 23
        '
        'Txtacu_tip
        '
        Me.Txtacu_tip.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Txtacu_tip.Location = New System.Drawing.Point(145, 33)
        Me.Txtacu_tip.Name = "Txtacu_tip"
        Me.Txtacu_tip.ReadOnly = True
        Me.Txtacu_tip.Size = New System.Drawing.Size(53, 20)
        Me.Txtacu_tip.TabIndex = 24
        '
        'txtresponsa
        '
        Me.txtresponsa.Cursor = System.Windows.Forms.Cursors.Hand
        Me.txtresponsa.Location = New System.Drawing.Point(395, 77)
        Me.txtresponsa.Name = "txtresponsa"
        Me.txtresponsa.Size = New System.Drawing.Size(24, 20)
        Me.txtresponsa.TabIndex = 26
        Me.txtresponsa.Visible = False
        '
        'Txtdepartam
        '
        Me.Txtdepartam.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtdepartam.Location = New System.Drawing.Point(395, 55)
        Me.Txtdepartam.Name = "Txtdepartam"
        Me.Txtdepartam.Size = New System.Drawing.Size(24, 20)
        Me.Txtdepartam.TabIndex = 25
        Me.Txtdepartam.Visible = False
        '
        'Txtsecuencia
        '
        Me.Txtsecuencia.Location = New System.Drawing.Point(270, 33)
        Me.Txtsecuencia.Name = "Txtsecuencia"
        Me.Txtsecuencia.Size = New System.Drawing.Size(53, 20)
        Me.Txtsecuencia.TabIndex = 27
        Me.Txtsecuencia.Visible = False
        '
        'ChkSujetosControl
        '
        Me.ChkSujetosControl.AutoSize = True
        Me.ChkSujetosControl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkSujetosControl.Location = New System.Drawing.Point(122, 381)
        Me.ChkSujetosControl.Name = "ChkSujetosControl"
        Me.ChkSujetosControl.Size = New System.Drawing.Size(157, 17)
        Me.ChkSujetosControl.TabIndex = 28
        Me.ChkSujetosControl.Text = "SUJETOS A CONTROL"
        Me.ChkSujetosControl.UseVisualStyleBackColor = True
        Me.ChkSujetosControl.Visible = False
        '
        'LblCpbteAsocia
        '
        Me.LblCpbteAsocia.AutoSize = True
        Me.LblCpbteAsocia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCpbteAsocia.Location = New System.Drawing.Point(1007, 59)
        Me.LblCpbteAsocia.Name = "LblCpbteAsocia"
        Me.LblCpbteAsocia.Size = New System.Drawing.Size(34, 13)
        Me.LblCpbteAsocia.TabIndex = 29
        Me.LblCpbteAsocia.Text = "AS-1"
        Me.LblCpbteAsocia.Visible = False
        '
        'CmbTipoDocum
        '
        Me.CmbTipoDocum.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmbTipoDocum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbTipoDocum.Enabled = False
        Me.CmbTipoDocum.FormattingEnabled = True
        Me.CmbTipoDocum.Location = New System.Drawing.Point(446, 56)
        Me.CmbTipoDocum.Name = "CmbTipoDocum"
        Me.CmbTipoDocum.Size = New System.Drawing.Size(125, 21)
        Me.CmbTipoDocum.TabIndex = 30
        '
        'LblConsedoc
        '
        Me.LblConsedoc.AutoSize = True
        Me.LblConsedoc.Location = New System.Drawing.Point(9, 4)
        Me.LblConsedoc.Name = "LblConsedoc"
        Me.LblConsedoc.Size = New System.Drawing.Size(87, 13)
        Me.LblConsedoc.TabIndex = 31
        Me.LblConsedoc.Text = "CONSEDOC No:"
        Me.LblConsedoc.Visible = False
        '
        'CntMaquinaria
        '
        Me.CntMaquinaria.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CntMaquinaria.Controls.Add(Me.Label23)
        Me.CntMaquinaria.Controls.Add(Me.LblMaquinaria)
        Me.CntMaquinaria.Controls.Add(Me.CmdQuitarMaquinaria)
        Me.CntMaquinaria.Controls.Add(Me.CmdBuscaMaquina)
        Me.CntMaquinaria.Controls.Add(Me.TxtIdMaquinaria)
        Me.CntMaquinaria.Enabled = False
        Me.CntMaquinaria.Location = New System.Drawing.Point(5, 122)
        Me.CntMaquinaria.Name = "CntMaquinaria"
        Me.CntMaquinaria.Size = New System.Drawing.Size(438, 23)
        Me.CntMaquinaria.TabIndex = 32
        Me.CntMaquinaria.Visible = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(3, 3)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(89, 13)
        Me.Label23.TabIndex = 21
        Me.Label23.Text = "MAQUINARIA:"
        '
        'LblMaquinaria
        '
        Me.LblMaquinaria.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMaquinaria.Location = New System.Drawing.Point(92, 3)
        Me.LblMaquinaria.Name = "LblMaquinaria"
        Me.LblMaquinaria.Size = New System.Drawing.Size(281, 15)
        Me.LblMaquinaria.TabIndex = 20
        Me.LblMaquinaria.Text = "..."
        '
        'CmdQuitarMaquinaria
        '
        Me.CmdQuitarMaquinaria.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdQuitarMaquinaria.Location = New System.Drawing.Point(406, -1)
        Me.CmdQuitarMaquinaria.Name = "CmdQuitarMaquinaria"
        Me.CmdQuitarMaquinaria.Size = New System.Drawing.Size(29, 23)
        Me.CmdQuitarMaquinaria.TabIndex = 19
        Me.CmdQuitarMaquinaria.Text = "-"
        Me.CmdQuitarMaquinaria.UseVisualStyleBackColor = True
        '
        'CmdBuscaMaquina
        '
        Me.CmdBuscaMaquina.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscaMaquina.Location = New System.Drawing.Point(378, -1)
        Me.CmdBuscaMaquina.Name = "CmdBuscaMaquina"
        Me.CmdBuscaMaquina.Size = New System.Drawing.Size(29, 23)
        Me.CmdBuscaMaquina.TabIndex = 18
        Me.CmdBuscaMaquina.Text = "+"
        Me.CmdBuscaMaquina.UseVisualStyleBackColor = True
        '
        'TxtIdMaquinaria
        '
        Me.TxtIdMaquinaria.Location = New System.Drawing.Point(359, 0)
        Me.TxtIdMaquinaria.Name = "TxtIdMaquinaria"
        Me.TxtIdMaquinaria.Size = New System.Drawing.Size(10, 20)
        Me.TxtIdMaquinaria.TabIndex = 16
        Me.TxtIdMaquinaria.Visible = False
        '
        'ChkNoPropietario
        '
        Me.ChkNoPropietario.AutoSize = True
        Me.ChkNoPropietario.Location = New System.Drawing.Point(187, 471)
        Me.ChkNoPropietario.Name = "ChkNoPropietario"
        Me.ChkNoPropietario.Size = New System.Drawing.Size(81, 17)
        Me.ChkNoPropietario.TabIndex = 33
        Me.ChkNoPropietario.Text = "CheckBox1"
        Me.ChkNoPropietario.UseVisualStyleBackColor = True
        Me.ChkNoPropietario.Visible = False
        '
        'ChkAsociarNotaEnt
        '
        Me.ChkAsociarNotaEnt.AutoSize = True
        Me.ChkAsociarNotaEnt.Location = New System.Drawing.Point(187, 428)
        Me.ChkAsociarNotaEnt.Name = "ChkAsociarNotaEnt"
        Me.ChkAsociarNotaEnt.Size = New System.Drawing.Size(81, 17)
        Me.ChkAsociarNotaEnt.TabIndex = 34
        Me.ChkAsociarNotaEnt.Text = "CheckBox1"
        Me.ChkAsociarNotaEnt.UseVisualStyleBackColor = True
        Me.ChkAsociarNotaEnt.Visible = False
        '
        'LblNotaEntrega
        '
        Me.LblNotaEntrega.AutoSize = True
        Me.LblNotaEntrega.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNotaEntrega.Location = New System.Drawing.Point(762, 19)
        Me.LblNotaEntrega.Name = "LblNotaEntrega"
        Me.LblNotaEntrega.Size = New System.Drawing.Size(242, 13)
        Me.LblNotaEntrega.TabIndex = 35
        Me.LblNotaEntrega.Text = "NOTA DE ENTREGA:001-001-000000009"
        Me.LblNotaEntrega.Visible = False
        '
        'TxtNte_Id
        '
        Me.TxtNte_Id.Location = New System.Drawing.Point(899, 77)
        Me.TxtNte_Id.Name = "TxtNte_Id"
        Me.TxtNte_Id.Size = New System.Drawing.Size(105, 20)
        Me.TxtNte_Id.TabIndex = 36
        Me.TxtNte_Id.Visible = False
        '
        'LblSubTotal_2
        '
        Me.LblSubTotal_2.BackColor = System.Drawing.Color.Silver
        Me.LblSubTotal_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSubTotal_2.Location = New System.Drawing.Point(925, 384)
        Me.LblSubTotal_2.Name = "LblSubTotal_2"
        Me.LblSubTotal_2.Size = New System.Drawing.Size(120, 20)
        Me.LblSubTotal_2.TabIndex = 37
        Me.LblSubTotal_2.Text = "0.00"
        Me.LblSubTotal_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblDescuentos
        '
        Me.LblDescuentos.BackColor = System.Drawing.Color.Silver
        Me.LblDescuentos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDescuentos.Location = New System.Drawing.Point(925, 406)
        Me.LblDescuentos.Name = "LblDescuentos"
        Me.LblDescuentos.Size = New System.Drawing.Size(120, 20)
        Me.LblDescuentos.TabIndex = 38
        Me.LblDescuentos.Text = "0.00"
        Me.LblDescuentos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblSubTotal
        '
        Me.LblSubTotal.BackColor = System.Drawing.Color.Silver
        Me.LblSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSubTotal.Location = New System.Drawing.Point(925, 429)
        Me.LblSubTotal.Name = "LblSubTotal"
        Me.LblSubTotal.Size = New System.Drawing.Size(120, 20)
        Me.LblSubTotal.TabIndex = 39
        Me.LblSubTotal.Text = "0.00"
        Me.LblSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblValorIva
        '
        Me.LblValorIva.BackColor = System.Drawing.Color.Gainsboro
        Me.LblValorIva.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblValorIva.Location = New System.Drawing.Point(925, 451)
        Me.LblValorIva.Name = "LblValorIva"
        Me.LblValorIva.Size = New System.Drawing.Size(120, 20)
        Me.LblValorIva.TabIndex = 40
        Me.LblValorIva.Text = "0.00"
        Me.LblValorIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblIRBPNR
        '
        Me.LblIRBPNR.BackColor = System.Drawing.Color.Silver
        Me.LblIRBPNR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIRBPNR.Location = New System.Drawing.Point(925, 474)
        Me.LblIRBPNR.Name = "LblIRBPNR"
        Me.LblIRBPNR.Size = New System.Drawing.Size(120, 20)
        Me.LblIRBPNR.TabIndex = 41
        Me.LblIRBPNR.Text = "0.00"
        Me.LblIRBPNR.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LblTotal
        '
        Me.LblTotal.BackColor = System.Drawing.Color.Silver
        Me.LblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotal.Location = New System.Drawing.Point(871, 497)
        Me.LblTotal.Name = "LblTotal"
        Me.LblTotal.Size = New System.Drawing.Size(174, 26)
        Me.LblTotal.TabIndex = 42
        Me.LblTotal.Text = "0.00"
        Me.LblTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(786, 490)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 40)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "TOTAL A PAGAR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(871, 387)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "TOTAL:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(835, 411)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "DESCUENTO:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(846, 432)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "SUBTOTAL:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(864, 477)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 47
        Me.Label5.Text = "IRBPNR:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(76, 35)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "NRO:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(1, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 13)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "DEPARTAMENTO:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(13, 84)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 13)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "RESPONSABLE:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(47, 104)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(67, 13)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "FECHA IB:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(443, 38)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 13)
        Me.Label10.TabIndex = 52
        Me.Label10.Text = "RUC / PROVEEDOR:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(818, 60)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 13)
        Me.Label11.TabIndex = 53
        Me.Label11.Text = "FECHA FACT."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(459, 81)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(112, 13)
        Me.Label12.TabIndex = 54
        Me.Label12.Text = "NRO. ADICIONAL:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(472, 103)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(99, 13)
        Me.Label13.TabIndex = 55
        Me.Label13.Text = "OBSERVACIÓN:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(205, 35)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 13)
        Me.Label14.TabIndex = 56
        Me.Label14.Text = "SECUEN:"
        Me.Label14.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Location = New System.Drawing.Point(616, 65)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(11, 2)
        Me.Panel3.TabIndex = 57
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Location = New System.Drawing.Point(-1, -1)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(11, 2)
        Me.Panel4.TabIndex = 58
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Location = New System.Drawing.Point(675, 65)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(11, 2)
        Me.Panel5.TabIndex = 58
        '
        'CmdBuscaDepartamento
        '
        Me.CmdBuscaDepartamento.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscaDepartamento.Enabled = False
        Me.CmdBuscaDepartamento.Location = New System.Drawing.Point(401, 54)
        Me.CmdBuscaDepartamento.Name = "CmdBuscaDepartamento"
        Me.CmdBuscaDepartamento.Size = New System.Drawing.Size(29, 23)
        Me.CmdBuscaDepartamento.TabIndex = 59
        Me.CmdBuscaDepartamento.Text = "+"
        Me.CmdBuscaDepartamento.UseVisualStyleBackColor = True
        '
        'CmdBuscaResponsable
        '
        Me.CmdBuscaResponsable.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscaResponsable.Enabled = False
        Me.CmdBuscaResponsable.Location = New System.Drawing.Point(401, 77)
        Me.CmdBuscaResponsable.Name = "CmdBuscaResponsable"
        Me.CmdBuscaResponsable.Size = New System.Drawing.Size(29, 23)
        Me.CmdBuscaResponsable.TabIndex = 60
        Me.CmdBuscaResponsable.Text = "+"
        Me.CmdBuscaResponsable.UseVisualStyleBackColor = True
        '
        'CmdBuscaProveedor
        '
        Me.CmdBuscaProveedor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdBuscaProveedor.Enabled = False
        Me.CmdBuscaProveedor.Location = New System.Drawing.Point(1010, 33)
        Me.CmdBuscaProveedor.Name = "CmdBuscaProveedor"
        Me.CmdBuscaProveedor.Size = New System.Drawing.Size(29, 23)
        Me.CmdBuscaProveedor.TabIndex = 61
        Me.CmdBuscaProveedor.Text = "+"
        Me.CmdBuscaProveedor.UseVisualStyleBackColor = True
        '
        'CmdDocEscaneados
        '
        Me.CmdDocEscaneados.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdDocEscaneados.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdDocEscaneados.Location = New System.Drawing.Point(335, 464)
        Me.CmdDocEscaneados.Name = "CmdDocEscaneados"
        Me.CmdDocEscaneados.Size = New System.Drawing.Size(113, 53)
        Me.CmdDocEscaneados.TabIndex = 62
        Me.CmdDocEscaneados.Text = "Doc. Escaneados"
        Me.CmdDocEscaneados.UseVisualStyleBackColor = True
        '
        'TxtIrbpnr
        '
        Me.TxtIrbpnr.Location = New System.Drawing.Point(786, 551)
        Me.TxtIrbpnr.Name = "TxtIrbpnr"
        Me.TxtIrbpnr.Size = New System.Drawing.Size(68, 20)
        Me.TxtIrbpnr.TabIndex = 63
        Me.TxtIrbpnr.Text = "0.00"
        Me.TxtIrbpnr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TxtIrbpnr.Visible = False
        '
        'TxtRetencion100IVA
        '
        Me.TxtRetencion100IVA.Location = New System.Drawing.Point(269, 101)
        Me.TxtRetencion100IVA.Name = "TxtRetencion100IVA"
        Me.TxtRetencion100IVA.Size = New System.Drawing.Size(72, 20)
        Me.TxtRetencion100IVA.TabIndex = 64
        Me.TxtRetencion100IVA.Visible = False
        '
        'wnrodias
        '
        Me.wnrodias.Location = New System.Drawing.Point(368, 103)
        Me.wnrodias.Name = "wnrodias"
        Me.wnrodias.Size = New System.Drawing.Size(65, 20)
        Me.wnrodias.TabIndex = 65
        Me.wnrodias.Text = "0"
        Me.wnrodias.Visible = False
        '
        'Check2
        '
        Me.Check2.AutoSize = True
        Me.Check2.Location = New System.Drawing.Point(187, 446)
        Me.Check2.Name = "Check2"
        Me.Check2.Size = New System.Drawing.Size(81, 17)
        Me.Check2.TabIndex = 66
        Me.Check2.Text = "CheckBox1"
        Me.Check2.UseVisualStyleBackColor = True
        Me.Check2.Visible = False
        '
        'ivapres
        '
        Me.ivapres.Location = New System.Drawing.Point(782, 534)
        Me.ivapres.Name = "ivapres"
        Me.ivapres.Size = New System.Drawing.Size(67, 20)
        Me.ivapres.TabIndex = 67
        Me.ivapres.Visible = False
        '
        'RET3XMI
        '
        Me.RET3XMI.Location = New System.Drawing.Point(782, 534)
        Me.RET3XMI.Name = "RET3XMI"
        Me.RET3XMI.Size = New System.Drawing.Size(43, 20)
        Me.RET3XMI.TabIndex = 68
        Me.RET3XMI.Visible = False
        '
        'LblSubTotal12
        '
        Me.LblSubTotal12.BackColor = System.Drawing.Color.Silver
        Me.LblSubTotal12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSubTotal12.Location = New System.Drawing.Point(860, 534)
        Me.LblSubTotal12.Name = "LblSubTotal12"
        Me.LblSubTotal12.Size = New System.Drawing.Size(120, 20)
        Me.LblSubTotal12.TabIndex = 69
        Me.LblSubTotal12.Text = "0.00"
        Me.LblSubTotal12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.LblSubTotal12.Visible = False
        '
        'LblSubTotal0
        '
        Me.LblSubTotal0.BackColor = System.Drawing.Color.Silver
        Me.LblSubTotal0.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSubTotal0.Location = New System.Drawing.Point(860, 555)
        Me.LblSubTotal0.Name = "LblSubTotal0"
        Me.LblSubTotal0.Size = New System.Drawing.Size(120, 20)
        Me.LblSubTotal0.TabIndex = 70
        Me.LblSubTotal0.Text = "0.00"
        Me.LblSubTotal0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.LblSubTotal0.Visible = False
        '
        'ChkOpcionImprimir
        '
        Me.ChkOpcionImprimir.CheckAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ChkOpcionImprimir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkOpcionImprimir.Location = New System.Drawing.Point(270, 486)
        Me.ChkOpcionImprimir.Name = "ChkOpcionImprimir"
        Me.ChkOpcionImprimir.Size = New System.Drawing.Size(62, 32)
        Me.ChkOpcionImprimir.TabIndex = 71
        Me.ChkOpcionImprimir.Text = "Acta E-R"
        Me.ChkOpcionImprimir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkOpcionImprimir.UseVisualStyleBackColor = True
        '
        'CmdResumenCtaCnt
        '
        Me.CmdResumenCtaCnt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdResumenCtaCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdResumenCtaCnt.Location = New System.Drawing.Point(4, 410)
        Me.CmdResumenCtaCnt.Name = "CmdResumenCtaCnt"
        Me.CmdResumenCtaCnt.Size = New System.Drawing.Size(177, 53)
        Me.CmdResumenCtaCnt.TabIndex = 72
        Me.CmdResumenCtaCnt.Text = "Ver Resumen Cta. Contable"
        Me.CmdResumenCtaCnt.UseVisualStyleBackColor = True
        '
        'CmdGenerarDBF
        '
        Me.CmdGenerarDBF.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdGenerarDBF.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdGenerarDBF.Location = New System.Drawing.Point(2, 464)
        Me.CmdGenerarDBF.Name = "CmdGenerarDBF"
        Me.CmdGenerarDBF.Size = New System.Drawing.Size(177, 53)
        Me.CmdGenerarDBF.TabIndex = 73
        Me.CmdGenerarDBF.Text = "Enviar Código Barras"
        Me.CmdGenerarDBF.UseVisualStyleBackColor = True
        Me.CmdGenerarDBF.Visible = False
        '
        'LblNroItems
        '
        Me.LblNroItems.AutoSize = True
        Me.LblNroItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNroItems.Location = New System.Drawing.Point(8, 381)
        Me.LblNroItems.Name = "LblNroItems"
        Me.LblNroItems.Size = New System.Drawing.Size(79, 13)
        Me.LblNroItems.TabIndex = 74
        Me.LblNroItems.Text = "Nro. items: 0"
        '
        'IA_Frm_Ingreso_Bodega
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1061, 583)
        Me.Controls.Add(Me.LblNroItems)
        Me.Controls.Add(Me.CmdGenerarDBF)
        Me.Controls.Add(Me.CmdResumenCtaCnt)
        Me.Controls.Add(Me.ChkOpcionImprimir)
        Me.Controls.Add(Me.LblSubTotal0)
        Me.Controls.Add(Me.LblSubTotal12)
        Me.Controls.Add(Me.RET3XMI)
        Me.Controls.Add(Me.ivapres)
        Me.Controls.Add(Me.Check2)
        Me.Controls.Add(Me.wnrodias)
        Me.Controls.Add(Me.TxtRetencion100IVA)
        Me.Controls.Add(Me.TxtIrbpnr)
        Me.Controls.Add(Me.CmdDocEscaneados)
        Me.Controls.Add(Me.CmdBuscaProveedor)
        Me.Controls.Add(Me.CmdBuscaResponsable)
        Me.Controls.Add(Me.CmdBuscaDepartamento)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.LblConsedoc)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LblTotal)
        Me.Controls.Add(Me.LblIRBPNR)
        Me.Controls.Add(Me.LblValorIva)
        Me.Controls.Add(Me.LblSubTotal)
        Me.Controls.Add(Me.LblDescuentos)
        Me.Controls.Add(Me.LblSubTotal_2)
        Me.Controls.Add(Me.TxtNte_Id)
        Me.Controls.Add(Me.LblNotaEntrega)
        Me.Controls.Add(Me.ChkAsociarNotaEnt)
        Me.Controls.Add(Me.ChkNoPropietario)
        Me.Controls.Add(Me.CntMaquinaria)
        Me.Controls.Add(Me.CmbTipoDocum)
        Me.Controls.Add(Me.LblCpbteAsocia)
        Me.Controls.Add(Me.ChkSujetosControl)
        Me.Controls.Add(Me.Txtsecuencia)
        Me.Controls.Add(Me.Txtacu_tip)
        Me.Controls.Add(Me.Grid2)
        Me.Controls.Add(Me.Grid1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Txtobserva)
        Me.Controls.Add(Me.TxtPtoLlega)
        Me.Controls.Add(Me.fecha_factura)
        Me.Controls.Add(Me.Txtfactura)
        Me.Controls.Add(Me.Txtpunto_emi)
        Me.Controls.Add(Me.Txtestable)
        Me.Controls.Add(Me.Txtcedruc_nombre)
        Me.Controls.Add(Me.fecha_ib)
        Me.Controls.Add(Me.Txtcedruc)
        Me.Controls.Add(Me.Txtresponsable)
        Me.Controls.Add(Me.TxtDepartamento)
        Me.Controls.Add(Me.Txtsig_tip)
        Me.Controls.Add(Me.LblPorcenIva)
        Me.Controls.Add(Me.ChkNoDevIva)
        Me.Controls.Add(Me.txtresponsa)
        Me.Controls.Add(Me.Txtdepartam)
        Me.Name = "IA_Frm_Ingreso_Bodega"
        Me.Text = "TITULO"
        Me.Controls.SetChildIndex(Me.Txtdepartam, 0)
        Me.Controls.SetChildIndex(Me.txtresponsa, 0)
        Me.Controls.SetChildIndex(Me.ChkNoDevIva, 0)
        Me.Controls.SetChildIndex(Me.LblPorcenIva, 0)
        Me.Controls.SetChildIndex(Me.Txtsig_tip, 0)
        Me.Controls.SetChildIndex(Me.TxtDepartamento, 0)
        Me.Controls.SetChildIndex(Me.Txtresponsable, 0)
        Me.Controls.SetChildIndex(Me.Txtcedruc, 0)
        Me.Controls.SetChildIndex(Me.fecha_ib, 0)
        Me.Controls.SetChildIndex(Me.Txtcedruc_nombre, 0)
        Me.Controls.SetChildIndex(Me.Txtestable, 0)
        Me.Controls.SetChildIndex(Me.Txtpunto_emi, 0)
        Me.Controls.SetChildIndex(Me.Txtfactura, 0)
        Me.Controls.SetChildIndex(Me.fecha_factura, 0)
        Me.Controls.SetChildIndex(Me.TxtPtoLlega, 0)
        Me.Controls.SetChildIndex(Me.Txtobserva, 0)
        Me.Controls.SetChildIndex(Me.Panel1, 0)
        Me.Controls.SetChildIndex(Me.Grid1, 0)
        Me.Controls.SetChildIndex(Me.Grid2, 0)
        Me.Controls.SetChildIndex(Me.CmdSalir, 0)
        Me.Controls.SetChildIndex(Me.LblTitulo, 0)
        Me.Controls.SetChildIndex(Me.PnlControles, 0)
        Me.Controls.SetChildIndex(Me.LblEstado, 0)
        Me.Controls.SetChildIndex(Me.PnlNavegacion, 0)
        Me.Controls.SetChildIndex(Me.Txtacu_tip, 0)
        Me.Controls.SetChildIndex(Me.Txtsecuencia, 0)
        Me.Controls.SetChildIndex(Me.ChkSujetosControl, 0)
        Me.Controls.SetChildIndex(Me.LblCpbteAsocia, 0)
        Me.Controls.SetChildIndex(Me.CmbTipoDocum, 0)
        Me.Controls.SetChildIndex(Me.CntMaquinaria, 0)
        Me.Controls.SetChildIndex(Me.ChkNoPropietario, 0)
        Me.Controls.SetChildIndex(Me.ChkAsociarNotaEnt, 0)
        Me.Controls.SetChildIndex(Me.LblNotaEntrega, 0)
        Me.Controls.SetChildIndex(Me.TxtNte_Id, 0)
        Me.Controls.SetChildIndex(Me.LblSubTotal_2, 0)
        Me.Controls.SetChildIndex(Me.LblDescuentos, 0)
        Me.Controls.SetChildIndex(Me.LblSubTotal, 0)
        Me.Controls.SetChildIndex(Me.LblValorIva, 0)
        Me.Controls.SetChildIndex(Me.LblIRBPNR, 0)
        Me.Controls.SetChildIndex(Me.LblTotal, 0)
        Me.Controls.SetChildIndex(Me.Label1, 0)
        Me.Controls.SetChildIndex(Me.Label2, 0)
        Me.Controls.SetChildIndex(Me.Label3, 0)
        Me.Controls.SetChildIndex(Me.Label4, 0)
        Me.Controls.SetChildIndex(Me.Label5, 0)
        Me.Controls.SetChildIndex(Me.LblConsedoc, 0)
        Me.Controls.SetChildIndex(Me.Label6, 0)
        Me.Controls.SetChildIndex(Me.Label7, 0)
        Me.Controls.SetChildIndex(Me.Label8, 0)
        Me.Controls.SetChildIndex(Me.Label9, 0)
        Me.Controls.SetChildIndex(Me.Label10, 0)
        Me.Controls.SetChildIndex(Me.Label11, 0)
        Me.Controls.SetChildIndex(Me.Label12, 0)
        Me.Controls.SetChildIndex(Me.Label13, 0)
        Me.Controls.SetChildIndex(Me.Label14, 0)
        Me.Controls.SetChildIndex(Me.Panel3, 0)
        Me.Controls.SetChildIndex(Me.Panel5, 0)
        Me.Controls.SetChildIndex(Me.CmdBuscaDepartamento, 0)
        Me.Controls.SetChildIndex(Me.CmdBuscaResponsable, 0)
        Me.Controls.SetChildIndex(Me.CmdBuscaProveedor, 0)
        Me.Controls.SetChildIndex(Me.CmdDocEscaneados, 0)
        Me.Controls.SetChildIndex(Me.TxtIrbpnr, 0)
        Me.Controls.SetChildIndex(Me.TxtRetencion100IVA, 0)
        Me.Controls.SetChildIndex(Me.wnrodias, 0)
        Me.Controls.SetChildIndex(Me.Check2, 0)
        Me.Controls.SetChildIndex(Me.ivapres, 0)
        Me.Controls.SetChildIndex(Me.RET3XMI, 0)
        Me.Controls.SetChildIndex(Me.LblSubTotal12, 0)
        Me.Controls.SetChildIndex(Me.LblSubTotal0, 0)
        Me.Controls.SetChildIndex(Me.ChkOpcionImprimir, 0)
        Me.Controls.SetChildIndex(Me.CmdResumenCtaCnt, 0)
        Me.Controls.SetChildIndex(Me.CmdGenerarDBF, 0)
        Me.Controls.SetChildIndex(Me.LblNroItems, 0)
        Me.PnlControles.ResumeLayout(False)
        Me.PnlControles.PerformLayout()
        Me.PnlNavegacion.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Grid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Grid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CntMaquinaria.ResumeLayout(False)
        Me.CntMaquinaria.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ChkNoDevIva As CheckBox
    Friend WithEvents CmdAnular As Button
    Friend WithEvents LblPorcenIva As Label
    Friend WithEvents Txtsig_tip As TextBox
    Friend WithEvents TxtDepartamento As TextBox
    Friend WithEvents Txtresponsable As TextBox
    Friend WithEvents Txtcedruc As TextBox
    Friend WithEvents fecha_ib As DateTimePicker
    Friend WithEvents Txtcedruc_nombre As TextBox
    Friend WithEvents Txtestable As TextBox
    Friend WithEvents Txtpunto_emi As TextBox
    Friend WithEvents Txtfactura As TextBox
    Friend WithEvents fecha_factura As DateTimePicker
    Friend WithEvents TxtPtoLlega As TextBox
    Friend WithEvents Txtobserva As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Grid1 As DataGridView
    Friend WithEvents Grid2 As DataGridView
    Friend WithEvents descto03 As TextBox
    Friend WithEvents Txtcantidad As TextBox
    Friend WithEvents txtcostoact As TextBox
    Friend WithEvents txtnom_cue As TextBox
    Friend WithEvents Txtcuenta As TextBox
    Friend WithEvents BtnAgregar As Button
    Friend WithEvents ChkIva As CheckBox
    Friend WithEvents chkCaducidad As CheckBox
    Friend WithEvents LblCostoItem As TextBox
    Friend WithEvents LblCostoTotal As TextBox
    Friend WithEvents preciotot As TextBox
    Friend WithEvents TxtCostoTotReal As TextBox
    Friend WithEvents Txtacu_tip As TextBox
    Friend WithEvents txtresponsa As TextBox
    Friend WithEvents Txtdepartam As TextBox
    Friend WithEvents Txtsecuencia As TextBox
    Friend WithEvents ChkSujetosControl As CheckBox
    Friend WithEvents LblCpbteAsocia As Label
    Friend WithEvents CmbTipoDocum As ComboBox
    Friend WithEvents LblConsedoc As Label
    Friend WithEvents CntMaquinaria As Panel
    Friend WithEvents LblMaquinaria As Label
    Friend WithEvents CmdQuitarMaquinaria As Button
    Friend WithEvents CmdBuscaMaquina As Button
    Friend WithEvents TxtIdMaquinaria As TextBox
    Friend WithEvents ChkNoPropietario As CheckBox
    Friend WithEvents ChkAsociarNotaEnt As CheckBox
    Friend WithEvents LblNotaEntrega As Label
    Friend WithEvents TxtNte_Id As TextBox
    Friend WithEvents LblSubTotal_2 As TextBox
    Friend WithEvents LblDescuentos As TextBox
    Friend WithEvents LblSubTotal As TextBox
    Friend WithEvents LblValorIva As TextBox
    Friend WithEvents LblIRBPNR As TextBox
    Friend WithEvents LblTotal As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents CmdF4 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents CmdBuscaDepartamento As Button
    Friend WithEvents CmdBuscaResponsable As Button
    Friend WithEvents CmdBuscaProveedor As Button
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents LblCmasIBP As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents CmdDocEscaneados As Button
    Friend WithEvents TxtIrbpnr As TextBox
    Friend WithEvents TxtRetencion100IVA As TextBox
    Friend WithEvents TxtSecDet As TextBox
    Friend WithEvents CmdQuitar As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents wnrodias As TextBox
    Friend WithEvents Check2 As CheckBox
    Friend WithEvents ivapres As TextBox
    Friend WithEvents RET3XMI As TextBox
    Friend WithEvents LblSubTotal12 As TextBox
    Friend WithEvents LblSubTotal0 As TextBox
    Friend WithEvents ChkOpcionImprimir As CheckBox
    Friend WithEvents CmdResumenCtaCnt As Button
    Friend WithEvents CmdGenerarDBF As Button
    Friend WithEvents LblNroItems As Label
    Friend WithEvents Label23 As Label
End Class
