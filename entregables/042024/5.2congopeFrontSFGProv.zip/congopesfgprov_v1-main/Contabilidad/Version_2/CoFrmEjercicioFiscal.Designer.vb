﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CoFrmEjercicioFiscal
    Inherits SFGProv.FrmClaseDialogo

    'Form invalida a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.LblAnioActual = New System.Windows.Forms.Label()
        Me.Grid1 = New System.Windows.Forms.DataGridView()
        Me.ChkAbrirCerrar = New System.Windows.Forms.CheckBox()
        Me.CntFechas = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DtmFin = New System.Windows.Forms.DateTimePicker()
        Me.DtmIni = New System.Windows.Forms.DateTimePicker()
        Me.CntBuscaPor.SuspendLayout()
        CType(Me.Grid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CntFechas.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdSalir
        '
        Me.CmdSalir.Location = New System.Drawing.Point(521, 458)
        '
        'LblTitulo
        '
        Me.LblTitulo.Location = New System.Drawing.Point(21, 9)
        Me.LblTitulo.Size = New System.Drawing.Size(566, 23)
        Me.LblTitulo.Text = "EJERCICIO FISCAL"
        '
        'CntBuscaPor
        '
        Me.CntBuscaPor.Location = New System.Drawing.Point(13, 521)
        Me.CntBuscaPor.Visible = False
        '
        'LblAnioActual
        '
        Me.LblAnioActual.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblAnioActual.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAnioActual.Location = New System.Drawing.Point(198, 45)
        Me.LblAnioActual.Name = "LblAnioActual"
        Me.LblAnioActual.Size = New System.Drawing.Size(212, 23)
        Me.LblAnioActual.TabIndex = 4
        Me.LblAnioActual.Text = "AÑO: 0000"
        Me.LblAnioActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Grid1
        '
        Me.Grid1.AllowUserToAddRows = False
        Me.Grid1.AllowUserToDeleteRows = False
        Me.Grid1.AllowUserToOrderColumns = True
        Me.Grid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Grid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Grid1.Location = New System.Drawing.Point(13, 71)
        Me.Grid1.Name = "Grid1"
        Me.Grid1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Grid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Grid1.ShowEditingIcon = False
        Me.Grid1.Size = New System.Drawing.Size(580, 352)
        Me.Grid1.TabIndex = 5
        '
        'ChkAbrirCerrar
        '
        Me.ChkAbrirCerrar.Appearance = System.Windows.Forms.Appearance.Button
        Me.ChkAbrirCerrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkAbrirCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.ChkAbrirCerrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkAbrirCerrar.Image = Global.SFGProv.My.Resources.Resources.mnu_abrir
        Me.ChkAbrirCerrar.Location = New System.Drawing.Point(431, 458)
        Me.ChkAbrirCerrar.Name = "ChkAbrirCerrar"
        Me.ChkAbrirCerrar.Size = New System.Drawing.Size(84, 57)
        Me.ChkAbrirCerrar.TabIndex = 6
        Me.ChkAbrirCerrar.Text = "Abrir/Cerrar"
        Me.ChkAbrirCerrar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ChkAbrirCerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ChkAbrirCerrar.UseVisualStyleBackColor = True
        '
        'CntFechas
        '
        Me.CntFechas.BackColor = System.Drawing.Color.Transparent
        Me.CntFechas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CntFechas.Controls.Add(Me.Label3)
        Me.CntFechas.Controls.Add(Me.Label2)
        Me.CntFechas.Controls.Add(Me.DtmFin)
        Me.CntFechas.Controls.Add(Me.DtmIni)
        Me.CntFechas.Location = New System.Drawing.Point(13, 458)
        Me.CntFechas.Name = "CntFechas"
        Me.CntFechas.Size = New System.Drawing.Size(351, 34)
        Me.CntFechas.TabIndex = 11
        Me.CntFechas.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(5, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Fecha Ini:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(177, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Fecha Fin:"
        '
        'DtmFin
        '
        Me.DtmFin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DtmFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFin.Location = New System.Drawing.Point(250, 7)
        Me.DtmFin.Name = "DtmFin"
        Me.DtmFin.Size = New System.Drawing.Size(94, 20)
        Me.DtmFin.TabIndex = 12
        '
        'DtmIni
        '
        Me.DtmIni.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DtmIni.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmIni.Location = New System.Drawing.Point(78, 7)
        Me.DtmIni.Name = "DtmIni"
        Me.DtmIni.Size = New System.Drawing.Size(94, 20)
        Me.DtmIni.TabIndex = 11
        '
        'CoFrmEjercicioFiscal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(608, 523)
        Me.Controls.Add(Me.CntFechas)
        Me.Controls.Add(Me.ChkAbrirCerrar)
        Me.Controls.Add(Me.Grid1)
        Me.Controls.Add(Me.LblAnioActual)
        Me.Name = "CoFrmEjercicioFiscal"
        Me.Text = "Ejercicio Fiscal"
        Me.Controls.SetChildIndex(Me.CmdAceptar, 0)
        Me.Controls.SetChildIndex(Me.CntBuscaPor, 0)
        Me.Controls.SetChildIndex(Me.CmdSalir, 0)
        Me.Controls.SetChildIndex(Me.LblTitulo, 0)
        Me.Controls.SetChildIndex(Me.LblAnioActual, 0)
        Me.Controls.SetChildIndex(Me.Grid1, 0)
        Me.Controls.SetChildIndex(Me.ChkAbrirCerrar, 0)
        Me.Controls.SetChildIndex(Me.CntFechas, 0)
        Me.CntBuscaPor.ResumeLayout(False)
        Me.CntBuscaPor.PerformLayout()
        CType(Me.Grid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CntFechas.ResumeLayout(False)
        Me.CntFechas.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents LblAnioActual As Label
    'Friend WithEvents Grid1 As DataGridView
    Friend WithEvents ChkAbrirCerrar As CheckBox
    Friend WithEvents CntFechas As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DtmFin As DateTimePicker
    Friend WithEvents DtmIni As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents Grid1 As DataGridView
End Class
