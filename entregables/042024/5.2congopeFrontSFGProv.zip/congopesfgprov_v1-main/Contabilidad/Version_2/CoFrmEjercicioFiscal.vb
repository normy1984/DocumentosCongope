﻿Public Class CoFrmEjercicioFiscal
    Private Sub CoFrmEjercicioFiscal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.LblAnioActual.Text = "AÑO: " & vgAnio
        Call LlenaGrid()
    End Sub

    Private Sub LlenaGrid()
        Me.Grid1.DataSource = Nothing
        cad = "select id_per, des_per, fec_ini, fec_fin, cast(case when estado = 2 then 1 else 0 end as boolean) as estado
        from copercon
        where anio = " & vgAnio & "
        order by id_per"

        RsSql = Bdd.RetornaTabla(cad)
        If RsSql.Rows.Count > 0 Then
            Me.Grid1.DataSource = RsSql
        End If
        Call InitGrid(Me.Grid1)


        For Each fila As DataGridViewRow In Me.Grid1.Rows
            If fila.Cells("estado").Value = 0 Then
                fila.DefaultCellStyle.ForeColor = Color.Red
            Else
                fila.DefaultCellStyle.ForeColor = Color.Blue
            End If
        Next

    End Sub
    Private Sub InitGrid(ObjGrid As DataGridView)
        vgHeader = {
            {100, "MES", "S"},
            {100, "NOMBRE", "S"},
            {100, "FECHA INI", "S"},
            {100, "FECHA FIN", "S"},
            {0, "ESTADO", "S"}
        }
        Funciones.InitGrid(ObjGrid, vgHeader)
    End Sub

    Private Sub Grid1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Grid1.CellFormatting
        If Me.Grid1.Columns(e.ColumnIndex).Name.ToUpper = "ESTADO" Then
            If Convert.ToInt32(e.Value) = 1 Then
                e.CellStyle.ForeColor = Color.Blue
                e.CellStyle.BackColor = Color.Blue
            End If

        End If
    End Sub
    Private Sub Grid1_SelectionChanged(sender As Object, e As EventArgs) Handles Grid1.SelectionChanged
    End Sub

    Private Sub Grid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Grid1.CellContentClick
        Dim NFila As Integer = Grid1.SelectedCells(0).RowIndex
        If Me.Grid1.Columns(e.ColumnIndex).Name.ToUpper = "ESTADO" Then
            If Grid1.SelectedCells.Count <> 0 Then
                Dim nEstadoAct As Integer

                Dim nCodMes As Integer = Grid1.Rows(NFila).DataBoundItem("id_per")
                Dim nAbiertoCerrado As Boolean = Grid1.Rows(NFila).Cells("estado").Value
                If nAbiertoCerrado = False Then
                    nEstadoAct = 2
                Else
                    nEstadoAct = 1
                End If

                Dim sFecIni = Funciones.FormatoFecha(Me.DtmIni.Value)
                Dim sFecFin = Funciones.FormatoFecha(Me.DtmFin.Value)

                cad = "update copercon set estado = " & nEstadoAct & ", 
                fec_ini = '" & sFecIni & "',
                fec_fin = '" & sFecFin & "',
                fec_mod = '" & vgFecha & "',  
                mod_por = " & vgCodUsu & " 
                where codemp = '" & vgEmpresa & "' 
                and anio = " & vgAnio & " 
                and id_per = " & nCodMes & " "
                Bdd.EjecutarCadena(cad)

                Me.Grid1.Refresh()
            End If
        End If
    End Sub

    Private Sub ChkAbrirCerrar_CheckedChanged(sender As Object, e As EventArgs) Handles ChkAbrirCerrar.CheckedChanged
        Dim bBoolean As Boolean = Me.ChkAbrirCerrar.Checked

        Me.Grid1.Columns(4).Visible = bBoolean
        Me.Grid1.Columns(4).ReadOnly = Not bBoolean

        If bBoolean = False Then
            Call LlenaGrid()
        End If

        Me.CmdSalir.Enabled = Not bBoolean
        Me.CntFechas.Visible = bBoolean

    End Sub

    Private Sub Grid1_RowStateChanged(sender As Object, e As DataGridViewRowStateChangedEventArgs) Handles Grid1.RowStateChanged
        Try
            If Grid1.SelectedCells.Count <> 0 Then
                Dim NFila As Integer = Grid1.SelectedCells(0).RowIndex
                Me.DtmIni.Value = Grid1.Rows(NFila).DataBoundItem("fec_ini")
                Me.DtmFin.Value = Grid1.Rows(NFila).DataBoundItem("fec_fin")
            End If
        Catch ex As Exception

        End Try

    End Sub

    'Private Sub Grid1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Grid1.CellContentClick
    '    'If Me.Grid1.Columns(e.ColumnIndex).Name.ToUpper = "ESTADO" Then
    '    '    'Me.Grid1.Rows.Item(Me.Grid1.SelectedRows)
    '    'End If
    'End Sub


End Class
