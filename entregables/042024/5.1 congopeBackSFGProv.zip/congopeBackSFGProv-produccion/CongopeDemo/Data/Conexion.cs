﻿using Npgsql;
namespace Congope.Empresas.Data
{
    public class Conexion
    {
        NpgsqlConnection conexion = new NpgsqlConnection();
        static string servidor = "172.24.5.34";
        static string sPassword = "financiero";
        static string sUid = "postgres";
        static string sDatabase = "contabilidad";
        static string sPort = "5432";
        public static string cadena = "server=" + servidor + ";port=" + sPort + ";user id=" +
            sUid + ";password=" + sPassword + ";database=" + sDatabase + ";";


        public NpgsqlConnection establecerConexion(){
            try
            {
                conexion.ConnectionString = cadena;
                conexion.Open();
                Console.WriteLine("Se conecto");
            }
            catch (NpgsqlException e)
            {
                Console.WriteLine("Error "+e.ToString());
                throw;
            }
            return conexion;
        }
    }
}
