﻿namespace Congope.Empresas.General
{
    /// <summary>
    /// Contiene las constantes generales del sistema
    /// </summary>
    internal static class Constantes
    {
        internal struct General
        {
            /// <summary>
            /// Error timeout
            /// </summary>
            internal const string Empresa = "0004";
        }
    }
}
