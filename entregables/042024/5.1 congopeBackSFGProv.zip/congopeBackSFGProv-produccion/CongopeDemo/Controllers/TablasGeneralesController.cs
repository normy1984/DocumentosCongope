﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TablasGeneralesController : Controller
    {
        [HttpGet]
        public List<TablasGeneralesMo> Get()
        {
            return TablasGeneralesBL.Listar();
        }

        [HttpGet]
        [Route("Detalle/{codtab}")]

        public List<TablasGenerales_DetalleMo> GetDetalle(int codtab)
        {
            return TablasGeneralesBL.ListarDetalle(codtab);
        }

    }


}
