﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventarioInicialController : Controller
    {
        // Llamada a los datos generales de Inventario Inicial
        [HttpGet]
        public List<InventarioInicialMo> Get()
        {
            return InventarioInicialBl.ListarInventarioInicial();
        }

        // Llamada a los datos generales de Inventario Inicial_Documento
        [HttpGet]
        [Route("Documento")]
        public List<InventarioInicialMo_Documento> Get_Documento()
        {
            return InventarioInicialBl.ListarInventarioInicial_Documento();
        }


        //// GET: InventarioInicialController/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        //// GET: InventarioInicialController/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: InventarioInicialController/Create
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create(IFormCollection collection)
        //{
        //    try
        //    {
        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: InventarioInicialController/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    return View();
        //}

        //// POST: InventarioInicialController/Edit/5
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit(int id, IFormCollection collection)
        //{
        //    try
        //    {
        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //// GET: InventarioInicialController/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: InventarioInicialController/Delete/5
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Delete(int id, IFormCollection collection)
        //{
        //    try
        //    {
        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
