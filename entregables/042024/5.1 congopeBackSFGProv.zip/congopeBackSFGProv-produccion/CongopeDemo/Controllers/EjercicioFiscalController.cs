﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EjercicioFiscalController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}
        /// <summary>
        /// Listado de Ejercicios Fiscales.
        /// </summary>
        /// <returns></returns>
        // GET: api/<ValuesController>
        [HttpGet]
        public List<EjercicioFiscalMO> Get()
        {
            return EjercicioFiscalBl.Listar();
        }

    }
}
