﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers
{
    /// <summary>
    /// Clase con métodos para Api Rest de Empresa
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class EstructuraCodigoController : ControllerBase
    {

         /// <summary>
         /// Permite listar las estructuras de código
         /// </summary>
         /// <returns>Lista de Estructuras de código</returns>
        [HttpGet]
        public List<EstructuraCodigoMO> Get()
        {
            return EstructuraCodigoBL.Listar();
        }
        
        /// <summary>
        /// Método para modificar la estructura de código
        /// </summary>
        /// <param name="est">Información de la empresa</param>
        /// <returns>true o False segun se haya realizado o no la actualización</returns>
        // PUT api/<ValuesController>/5
        [HttpPut("{est}")]
        public bool Put([FromBody] EstructuraCodigoMO est)
        {
            return EstructuraCodigoBL.Modificar(est);
        }


    }
}
