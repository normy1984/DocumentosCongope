﻿namespace Congope.Empresas.Models
{
    public class TablasGeneralesMo
    {
        public int codtab { get; set; }
        public string descrip { get; set; }
    }

    public class TablasGenerales_DetalleMo
    {
        public int codigo { get; set; }
        public string descrip { get; set; }
        public string dato1 { get; set; }
        public string dato2 { get; set; }
        public string dato3 { get; set; }
        public string dato4 { get; set; }
        public string cuentadb { get; set; }
        public string cuentadevol { get; set; }
        public string cuentaddb { get; set; }
        public string cuentadcr { get; set; }
    }
}
