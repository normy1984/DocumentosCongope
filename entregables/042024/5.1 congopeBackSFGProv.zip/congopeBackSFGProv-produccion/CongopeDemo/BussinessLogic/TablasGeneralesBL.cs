﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Npgsql;
using System.Numerics;

namespace Congope.Empresas.BussinessLogic
{
    public class TablasGeneralesBL
    {
        /// <summary>
        /// Método para lista Tablas Generales
        /// </summary>
        /// <returns>Retorna lista de Tablas Generales</returns>
        public static List<TablasGeneralesMo> Listar()
        {
            string esAdministrador = Constantes.General.esAdministrador;
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGeneralesMo> oListaTablasGenerales = new List<TablasGeneralesMo>();

            string sql = "select po_codtab, po_descrip from select_tablas('" + codEmpresa + "','" + esAdministrador + "')";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGenerales.Add(new TablasGeneralesMo()
                            {
                                codtab = Convert.ToInt32( dr[0].ToString() ?? string.Empty),
                                descrip = dr[1].ToString() ?? string.Empty,

                            });
                        }
                    }
                    return oListaTablasGenerales;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return oListaTablasGenerales;
                }

            }
        }

        /// <summary>
        /// Método para lista Tablas Generales Detalle
        /// </summary>
        /// <returns>Retorna lista de Tablas Generales Detalle</returns>
        public static List<TablasGenerales_DetalleMo> ListarDetalle(BigInteger Pi_codtab)
        {
            
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGenerales_DetalleMo> oListaTablasGeneralesDetalle = new List<TablasGenerales_DetalleMo>();

            string sql = @"select 
                        po_codigo,
                        po_descrip,
                        po_direcci,
                        po_telefon2,
                        po_fax1,
                        po_cuentadb,
                        po_cuentacr,
                        po_cuentagst,
                        po_cuentadevol,
                        po_cuentaddb,
                        po_cuentadcr
                        from select_tablas_detalle
                        ('" + codEmpresa + "'," + Pi_codtab + ")";

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGeneralesDetalle.Add(new TablasGenerales_DetalleMo()
                            {
                                codigo = Convert.ToInt32(dr[0].ToString() ?? string.Empty),
                                descrip = dr[1].ToString() ?? string.Empty,
                                dato1 = dr[1].ToString() ?? string.Empty,
                                dato2 = dr[1].ToString() ?? string.Empty,
                                dato3 = dr[1].ToString() ?? string.Empty,
                                dato4 = dr[1].ToString() ?? string.Empty,
                                cuentadb = dr[1].ToString() ?? string.Empty,
                                cuentadevol = dr[1].ToString() ?? string.Empty,
                                cuentaddb = dr[1].ToString() ?? string.Empty,
                                cuentadcr = dr[1].ToString() ?? string.Empty,
    });
                        }
                    }
                    return oListaTablasGeneralesDetalle;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return oListaTablasGeneralesDetalle;
                }

            }
        }
    }
}
