﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Npgsql;
using System.Data;

namespace Congope.Empresas.BussinessLogic
{
    public class EstructuraCodigoBL
    {
        /// <summary>
        /// Método para lista Estructuras de Código
        /// </summary>
        /// <returns>Retorna lista de estructuras de código</returns>
        public static List<EstructuraCodigoMO> Listar()
        {
            string codemp = Constantes.General.Empresa;

            List<EstructuraCodigoMO> oListaCodigo = new List<EstructuraCodigoMO>();
            string sql = "select * from sps_estructura_control('" + codemp + "')";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            
            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);
                    
                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaCodigo.Add(new EstructuraCodigoMO()
                            {
                                nivel = dr[0].ToString()?? string.Empty,
                                descripcion = dr[1].ToString() ?? string.Empty,
                                longitud = dr[2].ToString() ?? string.Empty,
                                item_aso = dr[3].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return oListaCodigo;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return oListaCodigo;
                }

            }
        }

        //public static EstructuraCodigoMO Obtener(string codemp)
        //{

        //    EstructuraCodigoMO oEstructuraCodigo = new EstructuraCodigoMO();

        //    using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
        //    {

        //        string sql = "select * from prueba1('" + codemp + "')";
        //        try
        //        {

        //            oConexion.Open();

        //            using (NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion))
        //            {
        //                NpgsqlDataReader dr = cmd.ExecuteReader();

        //                while (dr.Read())
        //                {
        //                    oEstructuraCodigo = new EstructuraCodigoMO()
        //                    {
        //                        nivel = dr[0].ToString(),
        //                        descripcion = dr[1].ToString(),
        //                        longitud = dr[2].ToString(),
        //                        itemAsociado = dr[3].ToString(),

        //                    };
        //                }

        //            }

        //            return oEstructuraCodigo;
        //        }
        //        catch (Exception e)
        //        {

        //            throw e;
        //            return oEstructuraCodigo;
        //        }

        //    }

        //}
        /// <summary>
        /// Modifica una estructura de Código
        /// </summary>
        /// <param name="est"> Item de la estructura</param>
        /// <returns>bool  si se realizo la modificacion</returns>
        public static bool Modificar(EstructuraCodigoMO est)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {

                NpgsqlCommand cmd = new NpgsqlCommand("spu_estructura_control", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@nivel", Int32.Parse(est.nivel));
                cmd.Parameters.AddWithValue("@itemaso", Int32.Parse(est.item_aso));
                cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                                        Environment.NewLine, e.StackTrace);
                    return false;
                }
            }
        }

    }
}
