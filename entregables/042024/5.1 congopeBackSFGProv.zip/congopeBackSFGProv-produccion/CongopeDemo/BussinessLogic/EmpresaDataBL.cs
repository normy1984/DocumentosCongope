﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Npgsql;
using System.Data;



namespace Congope.Empresas.BussinessLogic
{
    /// <summary>
    /// Clase que contiene operaciones Crud para Empresa
    /// </summary>
    public class EmpresaDataBL
    {
        /// <summary>
        /// Método para registrar una empresa
        /// </summary>
        /// <param name="emp">Información de empresa</param>
        /// <returns>bool si se realizó la inserción de la empresa</returns>
        public static bool Registrar(EmpresaMO emp)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spi_empresa", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@nom_emp", emp.nom_emp);
                cmd.Parameters.AddWithValue("@cod_emp", emp.codemp);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                         Environment.NewLine, e.StackTrace);
                    return false;                    
                }
            }
        }

 
        /// <summary>
        /// Método para ver la lista de Empresas
        /// </summary>
        /// <returns>Lista de Empresas</returns>
        public static List<EmpresaMO> Listar()
        {

            List<EmpresaMO> oListaEmpresas = new List<EmpresaMO>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = "select * from vis_empresa";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaEmpresas.Add(new EmpresaMO()
                            {
                                codemp = dr[0].ToString() ?? string.Empty,
                                nom_emp = dr[1].ToString() ?? string.Empty,
                                ruc_emp = dr[2].ToString() ?? string.Empty,
                                dir_emp = dr[3].ToString() ?? string.Empty,                             
                            });
                        }                   
                    }
                    return oListaEmpresas;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.StackTrace);
                    return oListaEmpresas;
                }

            }

        }



        /// <summary>
        ///Para obtener una empresa en particular.
        /// </summary>
        /// <param name="codemp"> Codigo de la empresa</param>
        /// <returns>Retorna los datos de la empresa encontrada</returns>
        public static EmpresaMO Obtener(string codemp)
        {
           
            EmpresaMO oEmpresa = new EmpresaMO();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
            
                string sql = "select * from vis_empresa  where codemp = '" + codemp + "'";
                try
                {

                    oConexion.Open();
                   
                    using (NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion))
                    {                       
                        NpgsqlDataReader dr = cmd.ExecuteReader();
                      
                        while (dr.Read())
                        {
                            oEmpresa = new EmpresaMO()
                            {
                                codemp = dr[0].ToString() ?? string.Empty,
                                nom_emp = dr[1].ToString() ?? string.Empty,
                                ruc_emp = dr[2].ToString() ?? string.Empty,
                                nomcomercial = dr[3].ToString() ?? string.Empty,
                                dir_emp = dr[4].ToString()?? string.Empty,
                                ciudad = dr[5].ToString() ?? string.Empty,
                                tel1_emp = dr[6].ToString() ?? string.Empty,
                                tel2_emp = dr[7].ToString() ?? string.Empty,
                                fax1_emp = dr[8].ToString() ?? string.Empty,
                                email1 = dr[9].ToString() ?? string.Empty,
                                rep_emp = dr[10].ToString() ?? string.Empty,
                                rep_ruc = dr[11].ToString() ?? string.Empty,
                                cont_emp = dr[12].ToString() ?? string.Empty,
                                cont_ruc = dr[13].ToString() ?? string.Empty,
                                serieret = dr[14].ToString() ?? string.Empty,
                                autoret = dr[15].ToString() ?? string.Empty,                                                           
                                contrib_espe = dr[16].ToString() ?? string.Empty,
                                provincia = dr[17].ToString() ?? string.Empty,
                                dfin_emp = dr[18].ToString() ?? string.Empty,
                                dfin_ruc = dr[19].ToString() ?? string.Empty,
                                teso_emp = dr[20].ToString() ?? string.Empty,
                                teso_ruc = dr[21].ToString() ?? string.Empty,
                                aut_liq_comp = dr[22].ToString() ?? string.Empty,
                                pathlogo = dr[23].ToString() ?? string.Empty,
                                region = dr[24].ToString() ?? string.Empty
                            };                          
                        }

                    }

                    return oEmpresa;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.StackTrace);
                    return oEmpresa;
                }

            }

        }

        /// <summary>
        /// Modica una empresa
        /// </summary>
        /// <param name="emp"> Datos de la empresa</param>
        /// <returns>bool  si se realizo la modificacion</returns>
        public static bool Modificar(EmpresaMO emp)
        {
        
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spu_empresa", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@varcodemp", emp.codemp);
                cmd.Parameters.AddWithValue("@varnomemp", emp.nom_emp);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {

                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.StackTrace);
                    return false;
                }
            }
        }

        /// <summary>
        /// Mètodo para eliminar una empresa
        /// </summary>
        /// <param name="id">Identificación de la empresa</param>
        /// <returns>true o false si se eliminó la empresa</returns>
        public static bool Eliminar(int id)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spd_eliminar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@codemp", id);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {

                    Console.WriteLine("Explicitly specified:{0}{1}",
                       Environment.NewLine, e.StackTrace);
                    return false;
                }
            }       
        }
    }
    
}
