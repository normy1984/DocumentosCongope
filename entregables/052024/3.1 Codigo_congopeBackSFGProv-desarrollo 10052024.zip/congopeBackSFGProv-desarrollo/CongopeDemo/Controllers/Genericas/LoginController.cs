﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("login")]
    [ApiController]
    public class LoginController : Controller
    {
        
/// <summary>
/// Funcion que trae el token de autenticacion con el usuario y contraseña del sistema
/// </summary>
/// <param name="oCredenciales"></param>
/// <returns></returns>
        [HttpPost("credenciales")]
        public dynamic Index([FromBody] CredencialesLogo oCredenciales)
        {
            return new LoginBL().ObtenerToken(oCredenciales);
        }

       /// <summary>
       /// Funcion utilizada para el reset de la contraseña
       /// </summary>
       /// <param name="Codigo_usuario"></param>
       /// <returns></returns>
        [HttpPut("RecuperaContrasena/{Codigo_usuario}")]
        public dynamic RecuperaContrasena(int Codigo_usuario)
        {
            return new LoginBL().RecuperaContrasena(Codigo_usuario);
        }

    }
}
