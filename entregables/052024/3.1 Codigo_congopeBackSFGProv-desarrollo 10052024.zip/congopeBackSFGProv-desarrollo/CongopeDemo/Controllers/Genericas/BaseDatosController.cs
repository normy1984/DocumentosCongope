﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseDatosController : Controller
    {
        /// <summary>
        /// Evento post para cargar la informacion del catalogo de padres
        /// </summary>
        /// <param name="oTablasGenerales"></param>
        /// <returns></returns>
        [HttpPost("VerificaCatalogoPadre")]
        public dynamic GetCatalogoPadre(TablasGeneralesMo oTablasGenerales)
        {
            if (oTablasGenerales.codtab <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no procesado",
                    result = "El codigo debe ser mayor a 0"
                };
            }

            return BaseDatosBL.VerificaCatalogoPadre(oTablasGenerales);
        }

        /// <summary>
        /// Evento post para cargar la informacion de los hijos
        /// </summary>
        /// <param name="oVerificaCatalogoHijo"></param>
        /// <returns></returns>
        [HttpPost("VerificaCatalogoHijo")]
        public dynamic GetCatalogoHijo(VerificaCatalogoHijo oVerificaCatalogoHijo)
        {
            if (oVerificaCatalogoHijo.CodigoCatalogoPadre <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no procesado",
                    result = "El CodigoCatalogoPadre debe ser mayor a 0"
                };
            }
            if (oVerificaCatalogoHijo.CodigoCatalogoHijo <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no procesado",
                    result = "El CodigoCatalogoHijo debe ser mayor a 0"
                };
            }
            return BaseDatosBL.VerificaCatalogoHijo(oVerificaCatalogoHijo);
        }
    }
}
