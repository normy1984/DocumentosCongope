﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Genericas
{
    [Route("api/[controller]")]
    [ApiController]
    public class CorreoController : Controller
    {


        [HttpPost]
        // POST api/<controller>
        public dynamic Post([FromBody] CorreoMo oCorreo)
        {
           return new CorreoBL().Enviar(oCorreo);
        }

        
    }
}
