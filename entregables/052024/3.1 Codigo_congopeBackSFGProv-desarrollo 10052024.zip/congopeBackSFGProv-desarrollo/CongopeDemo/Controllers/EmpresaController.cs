﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Mvc;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Congope.Empresas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaController : ControllerBase
    {
        /// <summary>
        /// Listar Empresas.
        /// </summary>
        /// <returns></returns>
        // GET: api/<ValuesController>
        [HttpGet]
        public List<EmpresaMO> Get()
        {
            return EmpresaDataBL.Listar();
        }

        /// <summary>
        /// Obtener Empresa por Id
        /// </summary>
        /// <param name="id"> identificacion de la empresa</param>
        /// <returns>Empresa</returns>
        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public EmpresaMO Get(string id)
        {
            return EmpresaDataBL.Obtener(id); 
        }

        /// <summary>
        /// Registra una empresa
        /// </summary>
        /// <param name="oEmpresa">Empresa a registrar</param>
        /// <returns>true o False segun se haya realizado o no la inserción</returns>
        // POST api/<ValuesController>
        [HttpPost]
        public bool Post([FromBody] EmpresaMO oEmpresa)
        {
            return EmpresaDataBL.Registrar(oEmpresa);
        }

        /// <summary>
        /// Método para modificar la empresa
        /// </summary>
        /// <param name="emp">Información de la empresa</param>
        /// <returns>true o False segun se haya realizado o no la actualización</returns>
        // PUT api/<ValuesController>/5
        [HttpPut("{emp}")]
        public bool Put( [FromBody] EmpresaMO emp)
        {
            return EmpresaDataBL.Modificar(emp);
        }

        /// <summary>
        /// Método para Eliminar la empresa
        /// </summary>
        /// <param name="id">Identificación de la empresa</param>
        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
