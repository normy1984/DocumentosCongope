﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;


namespace Congope.Empresas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CuentasContablesController : ControllerBase
    {
   
        /// <summary>
        /// Listado de Cuentas Contables
        /// </summary>
        /// <param name="pag">Número de Paginas </param>
        /// <param name="reg">Registros por página</param>
        /// <returns>Registro de Cuentas Contables</returns>
        [HttpGet]
        public dynamic Get(int pag,int reg)
        {

            return CuentasContablesBL.ListarCuentasContables(pag, reg);
        }

        /// <summary>
        /// Obtener Detalle de Plan de Cuentas
        /// </summary>
        /// <param name="id"> Identificacion del plan de cuentas</param>
        /// <returns>Plan de Cuentas</returns>
        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public dynamic Get(string id)
        {
            return CuentasContablesBL.ObtenerDetalleCuentaContable(id);
        }

        
        /// <summary>
        /// Saldos por período de una cuenta
        /// </summary>
        /// <param name="cuenta">Id de la cuenta</param>
        /// <returns>Información de saldos</returns>
        [HttpGet]
        [Route("SaldoPorPeriodo/{cuenta}")]
        public dynamic Get_SaldosPorPeriodo(string cuenta)
        {
            return SaldosPorPeriodoBL.ObtenerSaldoPorPeriodoCuentaContable(cuenta);
        }
        
       /// <summary>
       /// Inserta o actualiza la información de una cuenta contable
       /// </summary>
       /// <param name="codigo">Codigo de acción</param>
       /// <param name="cuenta">Número de la cuenta</param>
       /// <returns>Resultado de la acción</returns>
        [HttpPut("{cuenta}")]
        public dynamic Put(int codigo,[FromBody] PlanCuentasMO cuenta)
        {
            return CuentasContablesBL.ModificarCuentaContable(cuenta);
        }

       /// <summary>
       /// Inactivación de la cuenta
       /// </summary>
       /// <param name="cuenta">Número de cuenta</param>
       /// <returns>Resultado de la acción</returns>
        [HttpDelete("{cuenta}")]
        public dynamic Delete( [FromBody] PlanCuentasMO cuenta)
        {
            return CuentasContablesBL.EliminarDetalle(cuenta);
        }

        [HttpGet]
        [Route("NivelesCreacion/{cuenta}")]
        public dynamic Get_CreacionCuenta(string cuenta)
        {
            return CuentasContablesBL.DesplegarInfoCreacionCuentasContables(cuenta);
        }

    }
}
