﻿using Congope.Empresas.BussinessLogic.Parametrizacion;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace Congope.Empresas.Controllers.Parametrizacion
{
    [Route("api/[controller]")]
    [ApiController]
    public class TablasGeneralesController : Controller
    {
        /// <summary>
        /// Controlador que retorna una lista con los datos de tablas  de CatalogoPadre
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public dynamic Get()
        {
            return TablasGeneralesBL.ListarTablas();
        }
        /// <summary>
        /// Controlador que retorna una lista con los datos de tablas de CatalogoPadre x Codigo
        /// </summary>
        /// <param name="codtab"></param>
        /// <returns></returns>
        [HttpGet("{codtab}")]
        public dynamic GetTablas_Codigo(int codtab)
        {
            return TablasGeneralesBL.ListarTablas_Codigo(codtab);
        }

        [HttpGet("categoria/{categoria}")]
        public dynamic obtenerTabla(string categoria)
        {          
            var codigoCategoria=CategoriasTabla.obtenerCodigo(categoria);          
            return TablasGeneralesBL.ListarDetalle(codigoCategoria);;           
        }
        /// <summary>
        /// Controlador que retorna una lista con los datos de tablas de CatalogoHijo x codtab
        /// </summary>
        /// <param name="codtab"></param>
        /// <returns></returns>
        [HttpGet("Detalle/{codtab}")]
        public dynamic GetDetalle(int codtab)
        {
            return TablasGeneralesBL.ListarDetalle(codtab);
        }
        /// <summary>
        /// Controlador que retorna una lista con los datos de tablas de CatalogoHijo x codtab
        /// </summary>
        /// <param name="codtab"></param>
        /// <returns></returns>
        [HttpGet("DetalleSinDiccionario/{codtab}")]
        public dynamic DetalleSinDiccionario(int codtab)
        {
            return TablasGeneralesBL.ListarDetalleSinDiccionario(codtab);
        }
        /// <summary>
        /// Controlador que retorna el detalle con los datos de tablas de CatalogoHijo x codigo y codtab
        /// </summary>
        /// <param name="codtab"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        [HttpGet("Detalle/{codtab}/{codigo}")]
        public dynamic GetDetalle_Codigo(int codtab, int codigo)
        {
            return TablasGeneralesBL.ListarDetalle_Codigo(codtab, codigo);
        }


        /// <summary>
        /// Controlador que permite ingresar el guardado de nuevos registros de tabla para el CatalogoPadre
        /// </summary>
        /// <param name="oTablasGenerales_DetalleMo"></param>
        /// <returns></returns>
        [HttpPost("Detalle")]
        public dynamic Post([FromBody] TablasGenerales_DetalleMo oTablasGenerales_DetalleMo)
        {
            if (oTablasGenerales_DetalleMo.codigo != 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no guardado",
                    result = "El codigo debe ser igual a 0"
                };
            }

            if (oTablasGenerales_DetalleMo.codtab <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado",
                    result = "El codtab debe ser mayor a 0"
                };
            }
            return TablasGeneralesBL.InsertUpdate_Detalle(oTablasGenerales_DetalleMo);
        }
        /// <summary>
        /// Controlador que permite ingresar la actualizacion de los registros de tabla para el CatalogoPadre
        /// </summary>
        /// <param name="codigo"></param>
        /// <param name="TablaDetalleMo"></param>
        /// <returns></returns>
        [HttpPut("Detalle/{codigo}")]
        public dynamic PutTablaDetalle(int codigo, [FromBody] TablasGenerales_DetalleMo TablaDetalleMo)
        {
            if (codigo == 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no guardado",
                    result = "El codigo debe ser mayor a 0"
                };
            }

            if (codigo != TablaDetalleMo.codigo)
            {
                return new
                {
                    success = false,
                    message = "Registro no guardado",
                    result = "El codigo debe ser igual al enviado en el json"
                };
            }

            if (TablaDetalleMo.codtab <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado",
                    result = "El codtab debe ser mayor a 0"
                };
            }

            return TablasGeneralesBL.InsertUpdate_Detalle(TablaDetalleMo);
        }

        /// <summary>
        /// Controlador que permite la eliminacion de los registros del Catalogo Hijo
        /// </summary>
        /// <param name="codigo"></param>
        /// <param name="TablaDetalleMo"></param>
        /// <returns></returns>
        [HttpDelete("Detalle/{codigo}")]
        public dynamic DeleteTablaDetalle(int codigo, [FromBody] TablasGeneralesDetalleDelete TablaDetalleMo)
        {

            if (codigo == 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado",
                    result = "El codigo debe ser mayor a 0"
                };
            }

            if (codigo != TablaDetalleMo.codigo)
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado",
                    result = "El codigo debe ser igual al enviado en el json"
                };
            }

            if (TablaDetalleMo.codtab <= 0)
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado",
                    result = "El codtab debe ser mayor a 0"
                };
            }

            return TablasGeneralesBL.Delete_Detalle(TablaDetalleMo);
        }
    }


}
