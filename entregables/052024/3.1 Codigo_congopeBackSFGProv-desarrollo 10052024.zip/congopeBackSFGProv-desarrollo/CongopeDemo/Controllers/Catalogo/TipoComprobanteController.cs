﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Catalogo;
using Congope.Empresas.BussinessLogic.Parametrizacion;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;

namespace Congope.Empresas.Controllers.Catalogo
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class TipoComprobanteController : Controller
    {
        /// <summary>
        /// Funcion que trae todo el detalle de informacion para el TipoComprobante
        /// </summary>
        /// <returns></returns>
        //[Authorize]
        [HttpGet]
        public dynamic Get()
        {
            //var identity = HttpContext.User.Identity as ClaimsIdentity;
            //var rToken = JwtMo.ValidarToken(identity);
            //if (!rToken.success) return rToken;

            return TipoComprobanteBL.Listar();
        }
        /// <summary>
        /// Funcion que trae la informacion de TipoComprobante de acuerdo con la sigla
        /// </summary>
        /// <param name="sigla"></param>
        /// <returns></returns>
        [HttpGet("{sigla}")]
        public dynamic Get_Codigo(string sigla)
        {
            return TipoComprobanteBL.ListarComprobanteCodigo(sigla);
       

        }
        /// <summary>
        /// Funcion para realizar la insercion de tipo comprobante
        /// </summary>
        /// <param name="oTipoComprobanteMO"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic Post([FromBody] TipoComprobanteMO oTipoComprobanteMO)
        {
            string sTipoAccion = "INSERT";
            return TipoComprobanteBL.InsertarActualizar_TiposComprobante(sTipoAccion, oTipoComprobanteMO);
        }
        /// <summary>
        /// Funcion que realiza el update de tipo comprobante de acuerdo con la sigla
        /// </summary>
        /// <param name="sigla"></param>
        /// <param name="oTipoComprobanteMO"></param>
        /// <returns></returns>
        [HttpPut("{sigla}")]
        public dynamic Put(string sigla, [FromBody] TipoComprobanteMO oTipoComprobanteMO)
        {
            string sTipoAccion = "UPDATE";

            if (sigla != oTipoComprobanteMO.sigla)
            {
                return new
                {
                    success = false,
                    message = "Registro no guardado",
                    result = "Las siglas no coinciden con la estructura json"
                };
            }
            return TipoComprobanteBL.InsertarActualizar_TiposComprobante(sTipoAccion, oTipoComprobanteMO);
        }

/// <summary>
/// Funcion que permite la eliminacion de un registro de Tipo Comprobante
/// </summary>
/// <param name="sigla"></param>
/// <returns></returns>
        [HttpDelete("{sigla}")]
        public dynamic Eliminar_TiposComprobante(string sigla)
        {

            if (sigla == "")
            {
                return new
                {
                    success = false,
                    message = "Registro no eliminado, Ingrese una sigla valida",
                    result = ""
                };
            }

            return TipoComprobanteBL.Eliminar_TiposComprobante(sigla);
        }
    }
}
