﻿using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Congope.Empresas.Models
{
    public class PlanCuentasMO
    {
        public string codigo { get; set; }
        public string cuenta_p { get; set; }
        public string cuenta { get; set; }
        public string nom_cue { get; set; }
        public string ult_cue { get; set; }
        public string niv_cue { get; set; }
        public string aux_cue { get; set; }
        public string ban_cue { get; set; }
        public string nivbal { get; set; }
        public string tipocuec { get; set; }
        public string por_iva { get; set; }
        public string por_ret { get; set; }
        public string renta { get; set; }
        public string ctapeaje { get; set; }
        public string ctatrans { get; set; }
        public string ctapago { get; set; }
        public string cta_evol { get; set; }
        public string ctapasateso { get; set; }
        public string cta_repcom { get; set; }
        public string cxc_iva_ret100_lrti { get; set; }
        public string cta_iess { get; set; }
        public string sal_inic { get; set; }
        public string sal_cre { get; set; }
        public string sal_inid { get; set; }
        public string sal_deb { get; set; }

    }
}
