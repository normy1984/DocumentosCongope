﻿namespace Congope.Empresas.Models
{
    /// <summary>
    /// Modelo de Empresa
    /// </summary>
    public class EmpresaMO
    {
        public string codemp { get ; set ; }
        public string nom_emp { get ;  set; }
        public string ruc_emp { get; set; }
        public string nomcomercial { get; set; }
        public string dir_emp { get; set; }
        public string tel1_emp { get; set; }
        public string tel2_emp { get; set; }
        public string fax1_emp { get; set; }
        public string email1 { get; set; }
        public string rep_emp { get; set; }
        public string rep_ruc { get; set; }
        public string cont_emp { get; set; }
        public string cont_ruc { get; set; }       
        public string serieret { get; set; }
        public string autoret { get; set; }
        public string ciudad { get; set; }
        public string pathlogo { get; set; }      
        public string contrib_espe { get; set; }     
        public string provincia { get; set; }       
        public string dfin_emp { get; set; }
        public string dfin_ruc { get; set; }     
        public string teso_emp { get; set; }
        public string teso_ruc { get; set; }
        public string aut_liq_comp { get; set; }
        public string region { get; set; }
    }
}
