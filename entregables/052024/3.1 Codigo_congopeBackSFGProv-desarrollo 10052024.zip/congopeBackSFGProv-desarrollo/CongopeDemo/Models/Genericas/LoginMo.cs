﻿namespace Congope.Empresas.Models.Genericas
{
    public class LoginMo
    {
        public int CodigoUsu { get; set; }
        public string login { get; set; }
        public string contrasena { get; set; }
        public string llave { get; set; }
        public string NombresCompletos { get; set; }
        public string correo { get; set; }

    }

    public class CredencialesLogo {
        public string login { get; set; }
        public string contrasena { get; set; }
    }
}
