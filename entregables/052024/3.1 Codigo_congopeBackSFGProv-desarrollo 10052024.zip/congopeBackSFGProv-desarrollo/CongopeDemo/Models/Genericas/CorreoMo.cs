﻿using Congope.Empresas.Data;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using System.Reflection.Metadata.Ecma335;

namespace Congope.Empresas.Models.Genericas
{
    public class CorreoMo
    {
        public string[] Para { get; set; }
        public string Asunto { get; set; }
        public bool isHtml { get; set; }
        public string Body { get; set; }
    }
    public class CorreoConexion
    {

        public string MailstrHost { get; set; }
        public int Mailport { get; set; }
        public string MailstrUserName { get; set; }
        public string MailstrFromPass { get; set; }
        public string MailstrFrom { get; set; }
        public string MailstrNameFrom { get; set; }
        public bool MailEnableSsl { get; set; }


        public CorreoConexion()
        {
            Conexion vConexion = new();

            MailstrHost = vConexion.MailstrHost;
            Mailport = vConexion.Mailport;
            MailstrUserName = vConexion.MailstrUserName;
            MailstrFromPass = vConexion.MailstrFromPass;
            MailstrFrom = vConexion.MailFrom;
            MailstrNameFrom = vConexion.MailNameFrom;
            MailEnableSsl = vConexion.MailEnableSsl;
        }

    }
}
