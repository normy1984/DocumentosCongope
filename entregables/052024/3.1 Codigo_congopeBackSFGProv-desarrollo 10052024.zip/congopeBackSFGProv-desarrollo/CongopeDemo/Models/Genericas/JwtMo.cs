﻿using Congope.Empresas.Data;
using System.Security.Claims;

namespace Congope.Empresas.Models.Genericas
{
    public class JwtMo
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string Subject { get; set; }

        public JwtMo() {
            Conexion vConexion = new();
            Key = vConexion.JwtKey;
            Issuer = vConexion.JwtIssuer;
            Audience = vConexion.JwtAudience;
            Subject = vConexion.JwtSubject;
        }
        public static dynamic ValidarToken(ClaimsIdentity identity)
        {
            try {
                if (identity.Claims.Count() == 0)
                {
                    return new
                    {
                        success = false,
                        message = "Verificar si se envio un token valido",
                        result = ""
                    };
                }
                return new
                {
                    success = false,
                    message = "Verificar si se envio un token valido",
                    result = ""
                };
                //var id = identity.Claims.FirstOrDefault(x => x.Type == "id").Value;
            }
            catch (Exception Ex) 
            {
                return new
                {
                    success = false,
                    message = "Error: "+ Ex.Message,
                    result = ""

                };
            }

        }
    }
}
