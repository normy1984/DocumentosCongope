﻿namespace Congope.Empresas.Models.Genericas
{
    public class VerificaCatalogoHijo
    {
        public int CodigoCatalogoPadre { get; set; }
        public int CodigoCatalogoHijo { get; set; }
        public string NombreCatalogoHijo { get; set; }
        public string Dato01 { get; set; }
        public string Dato02 { get; set; }
        public string Dato03 { get; set; }

    }
}
