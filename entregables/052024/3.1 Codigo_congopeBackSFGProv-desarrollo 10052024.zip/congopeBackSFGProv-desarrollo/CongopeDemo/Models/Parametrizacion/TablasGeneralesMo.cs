﻿namespace Congope.Empresas.Models.Parametrizacion
{
    public class TablasGeneralesMo
    {
        public int codtab { get; set; }
        public string descrip { get; set; }
    }

    public class TablasGenerales_DetalleMo
    {
        public int codigo { get; set; }
        public string descrip { get; set; }
        public string direcci { get; set; }
        public string telefon1 { get; set; }
        public string telefon2 { get; set; }
        public string fax1 { get; set; }
        public string cuentadb { get; set; }
        public string cuentadevol { get; set; }
        public string cuentaddb { get; set; }
        public string cuentadcr { get; set; }
        public string cedruc { get; set; }
        public string placa3 { get; set; }
        public int codtab { get; set; }
        public string cuentacr { get; set; }
        public string cuentagst { get; set; }
        public int secuenc { get; set; }
    }

    public class TablasGeneralesDetalleDelete
    {
        public int codtab { get; set; }
        public int codigo { get; set; }

    }
}
