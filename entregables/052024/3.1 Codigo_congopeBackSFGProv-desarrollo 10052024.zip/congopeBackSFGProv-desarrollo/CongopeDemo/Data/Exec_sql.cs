﻿using Congope.Empresas.BussinessLogic.Genericas;
using Newtonsoft.Json;
using Npgsql;
using System.Data;
using System.Reflection;

namespace Congope.Empresas.Data
{
    public class Exec_sql
    {
        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato Model de acuerdo a una declaracion de un modelo
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosModel<ModelClass>(NpgsqlCommand Command)
        {
            try
            {
                List<ModelClass> listaGenerica = new List<ModelClass>();

                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.Connection = oConexion;
                oConexion.Open();

                using (NpgsqlDataReader dr = Command.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        listaGenerica = DataReaderMapToList<ModelClass>(dr);
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: No existen registros",
                            result = ""
                        };
                    }
                }

                oConexion.Close();

                return new
                {
                    success = true,
                    message = "Success",
                    result = listaGenerica
                };

            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }

            

        }
        /// <summary>
        /// Funcion que retorna el resultado de una consulta en formato JSON
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic cargarDatosJson(NpgsqlCommand Command)
        {
            try
            {
                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.Connection = oConexion;
                oConexion.Open();

                DataTable listaGenerica = new DataTable();

                using (NpgsqlDataReader dr = Command.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        listaGenerica.Load(dr);
                    }
                    else
                    {
                        return new
                        {
                            success = false,
                            message = "Error: No existen registros",
                            result = ""
                        };
                    }
                }

                oConexion.Close();

                return new
                {
                    success = true,
                    message = "Success",
                    result = JsonConvert.SerializeObject(listaGenerica)
                };
            }
            catch (Exception e) 
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
         }
        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuery(NpgsqlCommand Command)
        {
            try
            {
                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.Connection = oConexion;
                oConexion.Open();
                int rowsAffected = Command.ExecuteNonQuery();
                oConexion.Close();

                if (rowsAffected > 0)
                {
                    return new
                    {
                        success = true,
                        message = "Se guardaron correctamente " + rowsAffected + " registros.",
                        result = ""
                    };
                }
                else
                {
                    return new
                    {
                        success = false,
                        message = "Error: La actualización no afectó ninguna fila.",
                        result = ""
                    };
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: "+ e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que permite ejecutar una consulta y devuelve true si hubo filas afectadas o false si no hay filas afectadas
        /// </summary>
        /// <param name="Command"></param>
        /// <returns></returns>
        public static dynamic EjecutarQuerySP(NpgsqlCommand Command)
        {
            try
            {
                NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena);
                Command.CommandType = CommandType.StoredProcedure;
                Command.Connection = oConexion;
                oConexion.Open();
                int rowsAffected = Command.ExecuteNonQuery();
                oConexion.Close();

                if (rowsAffected != 0)
                {
                    return new
                    {
                        success = true,
                        message = "El comando se ejecuto en el servidor.",
                        result = ""
                    };
                }
                else
                {
                    return new
                    {
                        success = false,
                        message = "Error: El comando no se ejecuto en el servidor.",
                        result = ""
                    };
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }
        /// <summary>
        /// Funcion que convierte un modelo de datos en un modelo declarado previamente
        /// </summary>
        /// <typeparam name="ModelClass"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static List<ModelClass> DataReaderMapToList<ModelClass>(IDataReader dr)
        {
            List<ModelClass> list = new List<ModelClass>();
            ModelClass obj = default(ModelClass);

            //Lista creada para obtener lo nombres de las columnas de DataReader
            List<string> columnNames = new List<string>();
            for (int i = 0; i < dr.FieldCount; i++)
            {
                // Obtener el nombre de la columna en la posición actual
                columnNames.Add(dr.GetName(i).ToLower());
            }

            while (dr.Read())
            {
                obj = Activator.CreateInstance<ModelClass>();

                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                {
                    if (columnNames.Contains(prop.Name.ToLower()))
                    {
                        if (!object.Equals(dr[prop.Name], DBNull.Value))
                        {
                            switch (prop.PropertyType.Name)
                            {
                                case "String":
                                    prop.SetValue(obj, Convert.ToString(dr[prop.Name].ToString() ?? string.Empty).Trim(), null);
                                    break;
                                case "Single":
                                    prop.SetValue(obj, Convert.ToSingle(dr[prop.Name].ToString() ?? string.Empty), null);
                                    break;
                                default:
                                    prop.SetValue(obj, dr[prop.Name], null);
                                    break;
                            }
                           
                        }
                    }
                    else 
                    {
                        prop.SetValue(obj, null);
                    }
                    
                }
                list.Add(obj);
            }
            return list;
        }
    }
}
