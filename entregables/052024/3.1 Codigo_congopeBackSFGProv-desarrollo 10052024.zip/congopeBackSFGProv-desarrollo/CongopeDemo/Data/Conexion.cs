﻿using Npgsql;
namespace Congope.Empresas.Data
{
    public class Conexion
    {
        //RUTA ARCHIVO ERRORES
        public static string ErrorlogFilePath = "error.log";

        //VARIABLES PARA LAS CONEXIONES PARA CORREO ELECTRONICO
        public string MailstrHost = "in-v3.mailjet.com";
        public int Mailport = 587;
        public string MailstrUserName = "d367bd2db8eb19e95e1992fe56fb77ee";
        public string MailstrFromPass = "9a7cd823338abe9699d5352f312eacda";
        public string MailFrom = "soporteuio@congope.gob.ec";
        public string MailNameFrom = "Servicios Congope";
        public bool MailEnableSsl = true;


        /** VARIABLES CONEXIONES HABILITANTES PARA EL TOKEN JWT **/
        // CADENA DE 32 CARACTERES QUE SIRVE PARA LA GENERACION DEL TOKEN DE AUTENTICACION DE LOS APIS
        public string JwtKey = "x6D711WpG6GekBcC5DBb5dUV6UavPPNR";
        public string JwtIssuer = "http://localhost:5142/";
        public string JwtAudience = "http://localhost:5142/";
        public string JwtSubject = "ApiCongope";


        /** VARIABLES DE CONEXIONES PARA LA BASE DE DATOS **/
        NpgsqlConnection conexion = new NpgsqlConnection();
        static string servidor = "172.24.5.34";
        static string sPassword = "financiero";
        static string sUid = "postgres";
        static string sDatabase = "contabilidad";
        static string sPort = "5432";
        public static string cadena = "server=" + servidor + ";port=" + sPort + ";user id=" +
            sUid + ";password=" + sPassword + ";database=" + sDatabase + ";";



        public NpgsqlConnection establecerConexion(){
            try
            {
                conexion.ConnectionString = cadena;
                conexion.Open();
                Console.WriteLine("Se conecto");
            }
            catch (NpgsqlException e)
            {
                Console.WriteLine("Error "+e.ToString());
                throw;
            }
            return conexion;
        }


    }
}
