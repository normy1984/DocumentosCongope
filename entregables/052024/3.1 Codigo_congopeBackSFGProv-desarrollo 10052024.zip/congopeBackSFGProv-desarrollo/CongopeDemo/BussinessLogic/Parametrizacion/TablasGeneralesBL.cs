﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.VisualBasic;
using Npgsql;
using System.Data;
using System.Numerics;
using System.Collections;
using static Npgsql.Replication.PgOutput.Messages.RelationMessage;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Diagnostics.CodeAnalysis;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Parametrizacion
{
    public class TablasGeneralesBL
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic ListarTablas()
        {
            string esAdministrador = Constantes.General.esAdministrador;
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGeneralesMo> oListaTablasGenerales = new List<TablasGeneralesMo>();

            string sql = "select out_codtab, out_descrip from select_tablas('" + codEmpresa + "','" + esAdministrador + "')";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGenerales.Add(new TablasGeneralesMo()
                            {
                                codtab = dr.GetInt32(dr.GetOrdinal("out_codtab")),
                                descrip = dr["out_descrip"].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oListaTablasGenerales
                    };
                   
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre por Padre
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarTablas_Codigo(int in_codtab)
        {
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGeneralesMo> oListaTablasGenerales = new List<TablasGeneralesMo>();

            string sql = @"select 
                        out_codtab, 
                        out_descrip 
                        from select_tablas_codigo
                        ('" + codEmpresa + "'," + in_codtab + ")";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGenerales.Add(new TablasGeneralesMo()
                            {
                                codtab = dr.GetInt32(dr.GetOrdinal("out_codtab")),
                                descrip = dr["out_descrip"].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oListaTablasGenerales
                    };
                 
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }
        /// <summary>
        /// Listar Detalle Sin Diccionario
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarDetalleSinDiccionario(int in_codtab)
        {
            if ((int)in_codtab < 0)
            {
                return new
                {
                    success = true,
                    message = "No existe la tabla buscada",
                    result = "error"
                };
            }
            var cmd = new NpgsqlCommand();
            string sql = "";
            string codEmpresa = Constantes.General.Empresa;

        sql = @"select 
                        out_codigo as codigo,
                        out_descrip as descrip,
                        out_direcci as direcci,
                        out_telefon1 as telefon1,
                        out_telefon2 as telefon2,
                        out_fax1 as fax1,
                        out_cuentadb as cuentadb,
                        out_cuentacr as cuentacr,
                        out_cuentagst as cuentagst,
                        out_cuentadevol as cuentadevol,
                        out_cuentaddb as cuentaddb,
                        out_cuentadcr as cuentadcr,
                        out_cedruc as cedruc,
                        out_placa3 as placa3,
                        @in_codtab as codtab
                        from select_tablas_detalle
                        (@codEmpresa,@in_codtab)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
            cmd.Parameters.AddWithValue("@in_codtab",NpgsqlDbType.Integer, in_codtab);

            return  Exec_sql.cargarDatosModel<TablasGenerales_DetalleMo>(cmd);
          
        }

        /// <summary>
        /// Funcion para obtener la informacion CatalogoHijo por Padre
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarDetalle(BigInteger in_codtab)
        {
            if((int)in_codtab<0){
                    return new
                    {
                        success = true,
                        message = "No existe la tabla buscada",
                        result = "error"
                    };
            }
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGenerales_DetalleMo> oListaTablasGeneralesDetalle = new List<TablasGenerales_DetalleMo>();

            string sql = @"select 
                        out_codigo,
                        out_descrip,
                        out_direcci,
                        out_telefon1,
                        out_telefon2,
                        out_fax1,
                        out_cuentadb,
                        out_cuentacr,
                        out_cuentagst,
                        out_cuentadevol,
                        out_cuentaddb,
                        out_cuentadcr,
                        out_cedruc,
                        out_placa3
                        from select_tablas_detalle
                        ('" + codEmpresa + "'," + in_codtab + ")";

            var sqlDiccionarioTabla="select diccionario from diccionario_tabla where codtab="+in_codtab;

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                var comandoDiccionarioTabla= new NpgsqlCommand(sqlDiccionarioTabla, oConexion);
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                   

                    oConexion.Open();

                    var registroDiccionario =(string) comandoDiccionarioTabla.ExecuteScalar(); 
                    var tablaDiccionario=ConversorTabla.convertir(registroDiccionario.Trim());
                    var columnasDiccionario=tablaDiccionario.Keys;
                    var prefijo="out_";
                    var diccionario = new List<object>();


                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                                             
                            var registro= new Hashtable();
                            foreach(var columna in columnasDiccionario){
                                var campo=tablaDiccionario[columna];                            
                    
                                var valor=dr[prefijo+columna];
                                valor=valor.ToString().Trim();
                                registro.Add(campo,valor);
                            }
                             
                            diccionario.Add(registro); 
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = diccionario
                    };
                  
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }

        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre por Padre y por codigo
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <param name="in_codigo"></param>
        /// <returns></returns>
        public static dynamic ListarDetalle_Codigo(BigInteger in_codtab, BigInteger in_codigo)
        {

            string codEmpresa = Constantes.General.Empresa;

            List<TablasGenerales_DetalleMo> oListaTablasGeneralesDetalle = new List<TablasGenerales_DetalleMo>();

            string sql = @"select 
                        out_codigo,
                        out_descrip,
                        out_direcci,
                        out_telefon1,
                        out_telefon2,
                        out_fax1,
                        out_cuentadb,
                        out_cuentacr,
                        out_cuentagst,
                        out_cuentadevol,
                        out_cuentaddb,
                        out_cuentadcr,
                        out_cedruc,
                        out_placa3
                        from select_tablas_detalle_codigo
                        ('" + codEmpresa + "'," + in_codtab + "," + in_codigo + ")";

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGeneralesDetalle.Add(new TablasGenerales_DetalleMo()
                            {
                                codigo = Convert.ToInt32(dr["out_codigo"].ToString()),
                                descrip = dr["out_descrip"].ToString() ?? string.Empty,
                                direcci = dr["out_direcci"].ToString() ?? string.Empty,
                                telefon1 = dr["out_telefon1"].ToString() ?? string.Empty,
                                telefon2 = dr["out_telefon2"].ToString() ?? string.Empty,
                                fax1 = dr["out_fax1"].ToString() ?? string.Empty,
                                cuentadb = dr["out_cuentadb"].ToString() ?? string.Empty,
                                cuentadevol = dr["out_cuentadevol"].ToString() ?? string.Empty,
                                cuentaddb = dr["out_cuentaddb"].ToString() ?? string.Empty,
                                cuentadcr = dr["out_cuentadcr"].ToString() ?? string.Empty,
                                cedruc = dr["out_cedruc"].ToString() ?? string.Empty,
                                placa3 = dr["out_placa3"].ToString() ?? string.Empty,
                                cuentacr = dr["out_cuentacr"].ToString() ?? string.Empty,
                                cuentagst = dr["out_cuentagst"].ToString() ?? string.Empty,
                                codtab = Convert.ToInt32(in_codtab.ToString()),
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oListaTablasGeneralesDetalle
                    };
                   
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);

                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }

        /// <summary>
        /// Funcion para insertar y actualizar la informacion del CatalogoHijo por Padre y codigo
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        public static dynamic InsertUpdate_Detalle(TablasGenerales_DetalleMo DetalleMo)
        {
            string codEmpresa = Constantes.General.Empresa;

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spiu_tabla_detalle", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@in_codemp", codEmpresa);
                cmd.Parameters.AddWithValue("@in_codtab", DetalleMo.codtab);
                cmd.Parameters.AddWithValue("@in_codigo", DetalleMo.codigo);
                cmd.Parameters.AddWithValue("@in_descrip", DetalleMo.descrip);
                cmd.Parameters.AddWithValue("@in_direcci", DetalleMo.direcci);
                cmd.Parameters.AddWithValue("@in_telefon1", DetalleMo.telefon1);
                cmd.Parameters.AddWithValue("@in_telefon2", DetalleMo.telefon2);
                cmd.Parameters.AddWithValue("@in_fax1", DetalleMo.fax1);
                cmd.Parameters.AddWithValue("@in_cuentadb", DetalleMo.cuentadb);
                cmd.Parameters.AddWithValue("@in_cuentacr", DetalleMo.cuentacr);
                cmd.Parameters.AddWithValue("@in_cuentagst", DetalleMo.cuentagst);
                cmd.Parameters.AddWithValue("@in_cuentadevol", DetalleMo.cuentadevol);
                cmd.Parameters.AddWithValue("@in_cuentaddb", DetalleMo.cuentaddb);
                cmd.Parameters.AddWithValue("@in_cuentadcr", DetalleMo.cuentadcr);
                cmd.Parameters.AddWithValue("@in_cedruc", DetalleMo.cedruc);
                cmd.Parameters.AddWithValue("@in_placa3", DetalleMo.placa3);
                cmd.Parameters.AddWithValue("@in_secuenc", DetalleMo.secuenc);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return new
                    {
                        success = true,
                        message = "Registro guardado",
                        result = DetalleMo
                    };
                }
                catch (Exception e)
                {

                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.InnerException);
                    return new
                    {
                        success = false,
                        message = "Registro no guardado",
                        result = e.StackTrace
                    };
                }
            }
        }

        /// <summary>
        /// Funcion para inactivar el registro de CatalogoHijo
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        public static dynamic Delete_Detalle(TablasGeneralesDetalleDelete DetalleMo)
        {
            string codEmpresa = Constantes.General.Empresa;
            var cmd = new NpgsqlCommand();
            string sql = "";

            sql = "spd_tabla_detalle";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", codEmpresa);
            cmd.Parameters.AddWithValue("@in_codtab", DetalleMo.codtab);
            cmd.Parameters.AddWithValue("@in_codigo", DetalleMo.codigo);

            return Exec_sql.EjecutarQuerySP(cmd);

        }
    }
}
