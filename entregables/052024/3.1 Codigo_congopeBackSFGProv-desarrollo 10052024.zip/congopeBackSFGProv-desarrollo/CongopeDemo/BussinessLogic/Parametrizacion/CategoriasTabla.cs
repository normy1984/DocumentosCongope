
using System.Collections;
using System.Collections.Generic;

namespace Congope.Empresas.BussinessLogic.Parametrizacion
{
    
    public class CategoriasTabla
    {
        
        public static int obtenerCodigo(string categoria){
            var hashtable = new Hashtable();
            hashtable.Add("contratos-laborales", 88);
            hashtable.Add("area", 6);
            var contieneClave=hashtable.ContainsKey(categoria);

         

            return contieneClave?(Int32)hashtable[categoria]:-1;
        }

    }
}