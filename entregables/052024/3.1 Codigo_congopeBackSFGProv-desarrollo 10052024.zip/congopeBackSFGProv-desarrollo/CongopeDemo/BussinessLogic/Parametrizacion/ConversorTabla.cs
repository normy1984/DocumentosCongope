using System.Collections;
using System.Text.RegularExpressions;

namespace Congope.Empresas.BussinessLogic.Parametrizacion
{

    public class ConversorTabla
    {
        private string diccionario;
        private Hashtable terminos;
        private ConversorTabla(string diccionario)
        {
            this.diccionario = diccionario;
            this.terminos=new Hashtable();
           // this.terminos.Add("codtab","Tabla");
            this.terminos.Add("codigo","Codigo");
        }

        private void crearDiccionario(){
            var lineas=this.diccionario.Trim().Split(',');
            
            foreach(string linea in lineas){
              var esLineaVacia=linea.Trim()=="";
              
              if(esLineaVacia){
                continue;
              }

              var terminos=linea.Split('=',2);
              var esCantidadValida=terminos.Length==2;
              
              if(!esCantidadValida){
                continue;
              }
              var columna=terminos[0].Trim();
              var equivalencia=terminos[1].Trim();
              equivalencia = Regex.Replace(equivalencia, @"\b([a-z])", m => m.Value.ToUpper());
              equivalencia = equivalencia.Replace(" ", "");
              this.terminos.Add(columna,equivalencia);  
            }
        }

        public static Hashtable convertir(string diccionario){
            var conversor = new ConversorTabla(diccionario);
            conversor.crearDiccionario();
            return conversor.terminos;
        }
    }
}