﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic
{
    /// <summary>
    /// Clase para TipoComprobante
    /// </summary>
    public class TipoComprobanteBL
    {
        /// <summary>
        /// Funcion que retorna la lista TipoComprobante
        /// </summary>
        /// <returns></returns>
        public static dynamic Listar()
        {
            string codemp = Constantes.General.Empresa;
            string modulo = Constantes.General.contabilidad;
            String oAnio = Constantes.General.anio;
          
           /* string sql = @"select 
                          sig_tip as sigla, 
                         acu_tip as secuencia, 
                         case op_pagado 
                         WHEN 0 then 'No Devenga, Paga o Recauda'
                         WHEN 1 then 'Devengado'
                         WHEN 2 then 'Pagado'
                         WHEN 3 then 'Devengado y (Pagado ó Recaudado)'
						 END as opcionPagado,
                         tipcomrol as comprobanteRol, 
                         des_tip as descripcion, 
                         case reiniciasec 
                         WHEN 0 then 'No'
                         WHEN 1 then 'Si'
						 END as reiniciaSecuencia,
                         tpo_cpbte_grn as comprobanteGarantia   
                         from sps_tipos_comprobantes
                            ('" + codemp + "'," + oAnio + "," + modulo + ");";*/

            string sql = @"select 
                          sig_tip as sigla, 
                         acu_tip as secuencia, 
                         op_pagado as opcionPagado,
                         tipcomrol as comprobanteRol, 
                         TRIM(des_tip) as descripcion, 
                         reiniciasec as reiniciaSecuencia,
                         tpo_cpbte_grn as comprobanteGarantia   
                         from sps_tipos_comprobantes
                            ('" + codemp + "'," + oAnio + "," + modulo + ");";


            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            return Exec_sql.cargarDatosModel<TipoComprobanteMO>(cmd);
            //return Exec_sql.cargarDatosJson(cmd);

        }
        /// <summary>
        /// Funcion que trae la informacion de TipoComprobante por codigo
        /// </summary>
        /// <param name="sigla"></param>
        /// <returns></returns>
        public static dynamic ListarComprobanteCodigo(string sigla)
        {
            string codemp = Constantes.General.Empresa;
            string modulo = Constantes.General.contabilidad;
            String oAnio = Constantes.General.anio;

            string sql = @"select 
                         sig_tip as sigla,
                         acu_tip as secuencia, 
                         des_tip as descripcion, 
                         op_pagado as opcionPagado, 
                         tipcomrol as comprobanteRol, 
                         reiniciasec as reiniciaSecuencia,
                         tpo_cpbte_grn as comprobanteGarantia 
                         from sps_tipos_comprobantes_codigo
                         (
                          @codemp,
                          @oAnio,
                          @modulo,
                          @sigla
                         )";
            NpgsqlCommand cmd = new NpgsqlCommand(sql);
            cmd.Parameters.AddWithValue("@codemp", codemp);
            cmd.Parameters.AddWithValue("@oAnio", Convert.ToInt32(oAnio));
            cmd.Parameters.AddWithValue("@modulo", Convert.ToInt32(modulo));
            cmd.Parameters.AddWithValue("@sigla", sigla);
        
            return Exec_sql.cargarDatosModel<TipoComprobanteMO>(cmd);

        }
        /// <summary>
        /// Funcion utilizada para insertar o actualizar la informacion de TipoComprobante
        /// </summary>
        /// <param name="sTipoAccion"></param>
        /// <param name="otipoComprobanteMO"></param>
        /// <returns></returns>
        public static dynamic InsertarActualizar_TiposComprobante(string sTipoAccion, TipoComprobanteMO otipoComprobanteMO)
        {
            string codemp = Constantes.General.Empresa;
            string usuario = Constantes.General.codigoUsuario;
            string modulo = Constantes.General.contabilidad;
            String oAnio = Constantes.General.anio;
            NpgsqlCommand cmd = new NpgsqlCommand();
           
            string sql = @"Select 
                            out_sig_tip as sigla,
                            out_acu_tip as secuencia,
                            out_des_tip as descripcion,
                            out_acu_tip,
                            out_des_tip,
                            out_op_pagado as opcionPagado,
                            out_tipcomrol as comprobanteRol,
                            out_reiniciasec as reiniciaSecuencia,
                            out_tpo_cpbte_grn as comprobanteGarantia
                            from spiu_tipos_comprobantes
                            (
                             @in_tipo_accion,
                             @in_codemp,
                             @in_anio,
                             @in_sistema,
                             @in_sig_tip,
                             @in_acu_tip,
                             @in_des_tip,
                             @in_op_pagado,
                             @in_tipcomrol,
                             @in_reiniciasec,
                             @in_tpo_cpbte_grn,
                             @in_usu
                             )";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@in_tipo_accion", sTipoAccion);
                cmd.Parameters.AddWithValue("@in_codemp", codemp);
                cmd.Parameters.AddWithValue("@in_anio", Convert.ToInt32(oAnio));
                cmd.Parameters.AddWithValue("@in_sistema", Convert.ToInt32(modulo));
                cmd.Parameters.AddWithValue("@in_sig_tip",  otipoComprobanteMO.sigla);
                cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Numeric, otipoComprobanteMO.secuencia);
                cmd.Parameters.AddWithValue("@in_des_tip",  otipoComprobanteMO.descripcion);
                cmd.Parameters.AddWithValue("@in_op_pagado", NpgsqlDbType.Numeric, otipoComprobanteMO.opcionPagado);
                cmd.Parameters.AddWithValue("@in_tipcomrol", otipoComprobanteMO.comprobanteRol);
                cmd.Parameters.AddWithValue("@in_reiniciasec", NpgsqlDbType.Numeric, otipoComprobanteMO.reiniciaSecuencia);
                cmd.Parameters.AddWithValue("@in_tpo_cpbte_grn", NpgsqlDbType.Numeric,otipoComprobanteMO.comprobanteGarantia);
                cmd.Parameters.AddWithValue("@in_usu", NpgsqlDbType.Varchar, Convert.ToString(usuario));


            return Exec_sql.cargarDatosModel<TipoComprobanteMO>(cmd);    
            }

        /// <summary>
        /// Funcion para eliminar los registros de un Tipo de Comprobante
        /// </summary>
        /// <param name="Sigla"></param>
        /// <returns></returns>
        public static dynamic Eliminar_TiposComprobante(string Sigla)
        {
            string codemp = Constantes.General.Empresa;
            string modulo = Constantes.General.contabilidad;
            String oAnio = Constantes.General.anio;
            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"DELETE 
                            public.cotipcom
                            WHERE 
                            codemp = @in_codemp 
				            and sistema = @in_sistema
				            and anio = @in_anio
				            and sig_tip = @in_sig_tip;
                            ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", codemp);
            cmd.Parameters.AddWithValue("@in_anio", Convert.ToInt32(oAnio));
            cmd.Parameters.AddWithValue("@in_sistema", Convert.ToInt32(modulo));
            cmd.Parameters.AddWithValue("@in_sig_tip", Sigla);
            return Exec_sql.EjecutarQuery(cmd);
        }
      
    }
}
