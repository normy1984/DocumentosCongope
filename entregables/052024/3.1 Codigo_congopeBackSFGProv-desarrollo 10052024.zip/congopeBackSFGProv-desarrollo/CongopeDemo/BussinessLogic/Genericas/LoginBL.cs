﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Npgsql;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class LoginBL
    {
        /// <summary>
        /// Funcion que trae la informacion de un usuario con el atributo de usuario y contraseña
        /// </summary>
        /// <param name="oCredencialesLogo"></param>
        /// <returns></returns>
        public dynamic GetUsuario(CredencialesLogo oCredencialesLogo)
        {
            try
            {
                List<LoginMo> oLoginMo = new List<LoginMo>();
                dynamic result = "";
                string message = "Error: ";
                bool success = false;

                string sql = @"select *
                           from usuarios
                           where UPPER(LTRIM(RTRIM((nomb_usu)))) = @usuario";

                using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
                {
                    NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);
                    cmd.Parameters.AddWithValue("@usuario", oCredencialesLogo.login.ToUpper());

                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oLoginMo.Add(new LoginMo()
                            {
                                CodigoUsu = Convert.ToInt32(dr["cod_usu"].ToString()),
                                login = dr["nomb_usu"].ToString() ?? string.Empty,
                                contrasena = dr["password"].ToString() ?? string.Empty,
                                llave = dr["llave"].ToString() ?? string.Empty,
                                NombresCompletos = dr["descrip"].ToString() ?? string.Empty,

                            });
                        }
                    }

                    switch (oLoginMo.Count)
                    {
                        case 0:
                            message += "No existe el usuario";
                        break;
                        case 1:
                            message += "Contraseña Incorrecta";
                            var ContrasenaBase = SeguridadBL.DecryptStringFromBytes_Aes(oLoginMo[0].contrasena.Trim(), oLoginMo[0].llave.Trim());
                            if (ContrasenaBase == oCredencialesLogo.contrasena)
                            {
                                message = "Lectura exitosa";
                                success = true;
                                result = oLoginMo;
                            }

                            break;
                        default:
                            message += "No existe el usuario";
                            break;
                    }


                    return new
                    {
                        success = success,
                        message = message,
                        result = result
                    };

                }



            }

            catch (Exception e)
            {
                Console.WriteLine("Explicitly specified:{0}{1}",
                Environment.NewLine, e.StackTrace);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }
        /// <summary>
        /// Funcion que genera el token de autorizacion de los servicios
        /// </summary>
        /// <param name="oCredenciales"></param>
        /// <returns></returns>
        public dynamic ObtenerToken(CredencialesLogo oCredenciales)
        {
            try
            {

                dynamic respuesta = GetUsuario(oCredenciales);

                if (respuesta.success == true)
                {
                    List<LoginMo> oLoginMo = new List<LoginMo>();
                    oLoginMo = respuesta.result;

                    var jwt = new JwtMo();

                    var claims = new[]
                    {
                                new Claim(JwtRegisteredClaimNames.Sub, jwt.Subject),
                                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                                new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()),
                                new Claim("id", oLoginMo[0].CodigoUsu.ToString()),
                                new Claim("usuario", oLoginMo[0].login.ToString()),
                            };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
                    var singIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(
                        jwt.Issuer,
                        jwt.Audience,
                        claims,
                        expires: DateTime.Now.AddMinutes(3),
                        signingCredentials: singIn
                        );
                    return new
                    {
                        success = true,
                        message = "Token Generado Exitosamente",
                        result = new JwtSecurityTokenHandler().WriteToken(token)
                    };
                }
                else
                {
                    return respuesta;
                }
            }
            catch (Exception e)
            {
                return new
                {
                    success = false,
                    message = "Error de generación de token",
                    result = e.Message
                };

            }
        }

        public dynamic RecuperaContrasena(int iCodigoUsuario)
        {
            dynamic respuesta, result = "";
            var cmd = new NpgsqlCommand();
            List<LoginMo> oLoginMo = new List<LoginMo>();
            string message = "Error: ";
            string sql = "";
            bool success = false;

            try
            {

                /// SE VALIDA EL USUARIO AL QUE SE DESEA RESETEAR LA CONTRASEÑA

                sql = @"SELECT
                           cod_usu as CodigoUsu,
                           nomb_usu as login,
                           descrip as NombresCompletos,
                           password as contrasena,
                           llave,
                           correo_origen as correo
                           from usuarios
                           where cod_usu = @usuario";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@usuario", iCodigoUsuario);
                respuesta = Exec_sql.cargarDatosModel<LoginMo>(cmd);

                if (respuesta.success == true)
                {
                    oLoginMo = respuesta.result;

                    switch (oLoginMo.Count)
                    {
                        case 0:
                            message += "No existe el usuario";
                            break;
                        case 1:
                            message += "El correo electronico <" + oLoginMo[0].correo.Trim() + "> es invalido!!";

                            var CorreoValido = SeguridadBL.IsValidEmail(oLoginMo[0].correo.Trim());

                            if (CorreoValido == true)
                            {
                                // SI TIENE UN CORREO VALIDO PARA ACTUALIZAR REALIZO EL PROCESO DE ACTUALIZACION
                                string _html = string.Empty;
                                sql = @"select *
                                           from mensajes_html
                                           where men_codigo = @men_codigo;";
                                cmd.CommandText = sql;
                                cmd.Parameters.AddWithValue("@men_codigo", 1);
                                
                                respuesta = Exec_sql.cargarDatosJson(cmd);
                                respuesta = JsonConvert.DeserializeObject(respuesta.result);
                                _html = respuesta[0]["men_html"];

                                var nuevaContrasena = new SeguridadBL().GeneraCodigo(8);
                                var ClaveEncriptada = SeguridadBL.EncryptStringToBytes_Aes(nuevaContrasena);

                                sql = @"UPDATE
                                           usuarios
                                           set 
                                           password = @password,
                                           llave = @llave,
                                           clave = ''
                                           where cod_usu = @cod_usu;";
                                cmd.CommandText = sql;
                                cmd.Parameters.AddWithValue("@cod_usu", oLoginMo[0].CodigoUsu);
                                cmd.Parameters.AddWithValue("@password", ClaveEncriptada.contrasenaEncriptada);
                                cmd.Parameters.AddWithValue("@llave", ClaveEncriptada.llave);
                                respuesta = Exec_sql.EjecutarQuery(cmd);

                                // SI LOS REGISTROS SE EJECUTARON CORRECTAMENTE SE ENVIA EL CORREO ELECTRONICO
                                if (respuesta.success == true)
                                {
                                    _html = _html.Replace("##USUARIO_NOMBRE##", oLoginMo[0].NombresCompletos.ToUpper());
                                    _html = _html.Replace("##USUARIO##", oLoginMo[0].login);
                                    _html = _html.Replace("##CONTRASENA##", nuevaContrasena);


                                    // ENVIAR CORREO PARA RECUPERACION DE CONTRASEÑA 
                                    var oCorreo = new CorreoMo();
                                    oCorreo.Para = new String[] { oLoginMo[0].correo };
                                    oCorreo.Asunto = "RESETEO DE CONTRASEÑA SFGProv";
                                    oCorreo.isHtml = true;
                                    oCorreo.Body = _html;

                                    var oEnviarCorreo = new CorreoBL().Enviar(oCorreo);

                                    success = oEnviarCorreo.success;
                                    message = oEnviarCorreo.message;
                                    result = oEnviarCorreo.result;
                                }
                                else
                                {
                                    success = respuesta.success;
                                    message = respuesta.message;
                                    result = respuesta.result;
                                }
                            }

                            break;
                        default:
                            message += "No existe el usuario";
                            break;
                    }
                }

      
                    return new
                    {
                        success = success,
                        message = message,
                        result = result
                    };
            }

            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }

        }

    }
}
