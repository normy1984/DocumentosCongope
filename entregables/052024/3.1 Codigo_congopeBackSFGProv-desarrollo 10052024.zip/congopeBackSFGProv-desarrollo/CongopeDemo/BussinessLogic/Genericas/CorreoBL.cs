﻿using Congope.Empresas.Models.Genericas;
using System.Net.Mail;
using System.Net;
using System;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class CorreoBL
    {
        /// <summary>
        /// Funcion que envia el correo electronico dentro de los servicios
        /// </summary>
        /// <param name="oCorreo"></param>
        /// <returns></returns>
        public dynamic Enviar(CorreoMo oCorreo)
        {
            try
            {
                //Obtenemos el servidor smtp del archivo de configuración.
                var oConfigCorreo = new CorreoConexion();

                //Proporcionamos la información de autenticación al servidor de Correo
                SmtpClient smtp = new SmtpClient(oConfigCorreo.MailstrHost, oConfigCorreo.Mailport);
                MailMessage msg = new MailMessage();

                //Creamos el contenido del correo. 
                msg.From = new MailAddress(oConfigCorreo.MailstrFrom, oConfigCorreo.MailstrNameFrom);
                foreach (string para in oCorreo.Para) msg.To.Add(new MailAddress(para));
                msg.Subject = oCorreo.Asunto;
                msg.IsBodyHtml = oCorreo.isHtml;
                msg.Body = oCorreo.Body;


                //Enviamos el correo
                smtp.Credentials = new NetworkCredential(oConfigCorreo.MailstrUserName, oConfigCorreo.MailstrFromPass);
                smtp.EnableSsl = oConfigCorreo.MailEnableSsl;
                smtp.Send(msg);

                return new
                {
                    success = true,
                    message = "Correo enviado exitosamente",
                    result = ""
                };
            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Correo no enviado. Error: "+ ex.Message,
                    result = ""
                };
               
            }

        }
    }
}
