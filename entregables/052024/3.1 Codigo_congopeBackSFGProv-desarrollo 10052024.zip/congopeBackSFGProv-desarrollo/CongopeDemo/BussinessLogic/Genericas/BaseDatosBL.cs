﻿using Congope.Empresas.BussinessLogic.Parametrizacion;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Npgsql;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Genericas
{
   

    public class BaseDatosBL
    {
  /// <summary>
  /// Funcion que se utiliza para el mantenimiento del Catalogo de Tablas a Nivel de Padre
  /// </summary>
  /// <param name="tablasGeneralesMo"></param>
  /// <returns></returns>
        public static dynamic VerificaCatalogoPadre(TablasGeneralesMo tablasGeneralesMo)
        {
                    TablasGenerales_DetalleMo oDetalleMo = new TablasGenerales_DetalleMo();
                    oDetalleMo.cedruc = "0";
                    oDetalleMo.codigo = 0;
                    oDetalleMo.codtab = tablasGeneralesMo.codtab;
                    oDetalleMo.cuentacr = string.Empty;
                    oDetalleMo.cuentadb = string.Empty;
                    oDetalleMo.cuentadcr = string.Empty;
                    oDetalleMo.cuentaddb = string.Empty;
                    oDetalleMo.cuentadevol = string.Empty;
                    oDetalleMo.cuentagst = string.Empty;
                    oDetalleMo.descrip = tablasGeneralesMo.descrip;
                    oDetalleMo.direcci = string.Empty;
                    oDetalleMo.fax1 = string.Empty;
                    oDetalleMo.placa3 = string.Empty;
                    oDetalleMo.secuenc = 0;
                    oDetalleMo.telefon1 = string.Empty;
                    oDetalleMo.telefon2 = string.Empty;

                    return TablasGeneralesBL.InsertUpdate_Detalle(oDetalleMo);
        }
        /// <summary>
        /// Funcion que se utiliza para el mantenimiento de los catalogos a nivel de Detalle(Hijo)
        /// </summary>
        /// <param name="oVerificaCatalogoHijo"></param>
        /// <returns></returns>
        public static dynamic VerificaCatalogoHijo(VerificaCatalogoHijo oVerificaCatalogoHijo)
        {
        
                    TablasGenerales_DetalleMo oDetalleMo = new TablasGenerales_DetalleMo();
                    oDetalleMo.cedruc = "0";
                    oDetalleMo.codigo = oVerificaCatalogoHijo.CodigoCatalogoHijo;
                    oDetalleMo.codtab = oVerificaCatalogoHijo.CodigoCatalogoPadre;
                    oDetalleMo.cuentacr = string.Empty;
                    oDetalleMo.cuentadb = string.Empty;
                    oDetalleMo.cuentadcr = string.Empty;
                    oDetalleMo.cuentaddb = string.Empty;
                    oDetalleMo.cuentadevol = string.Empty;
                    oDetalleMo.cuentagst = string.Empty;
                    oDetalleMo.descrip = oVerificaCatalogoHijo.NombreCatalogoHijo;
                    oDetalleMo.direcci = oVerificaCatalogoHijo.Dato02;
                    oDetalleMo.fax1 = string.Empty;
                    oDetalleMo.placa3 = string.Empty;
                    oDetalleMo.secuenc = 0;
                    oDetalleMo.telefon1 = oVerificaCatalogoHijo.Dato01;
                    oDetalleMo.telefon2 = oVerificaCatalogoHijo.Dato03;
                    return  TablasGeneralesBL.InsertUpdate_Detalle(oDetalleMo);
        }

       
    }
}
