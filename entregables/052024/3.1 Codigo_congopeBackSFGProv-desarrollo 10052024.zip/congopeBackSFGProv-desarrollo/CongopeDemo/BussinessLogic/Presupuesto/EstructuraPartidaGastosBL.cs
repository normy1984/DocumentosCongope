﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto;
using Npgsql;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Presupuesto
{
    public class EstructuraPartidaGastosBL
    {

        public static List<EstructuraPartidaGastosMO> Listar()
        {
            string codemp = Constantes.General.Empresa;
            string modulo = Constantes.General.contabilidad;
            List<EstructuraPartidaGastosMO> oListaComprobante = new List<EstructuraPartidaGastosMO>();
            string sql = "select * from sps_estructura_partida('" + codemp + "','" + modulo + "')";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaComprobante.Add(new EstructuraPartidaGastosMO()
                            {
                                niv_est  = dr[0].ToString() ?? string.Empty,
                                des_est = dr[1].ToString() ?? string.Empty,
                                lon_est = dr[2].ToString() ?? string.Empty,
                                item_aso = dr[3].ToString() ?? string.Empty,
                                foce = dr[4].ToString() ?? string.Empty,
                                orienta_gas = dr[5].ToString() ?? string.Empty,
                                niv_ug = dr[6].ToString() ?? string.Empty,
                                niv_comp = dr[7].ToString() ?? string.Empty,
                                niv_proy = dr[8].ToString() ?? string.Empty,
                                digitos = dr[9].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return oListaComprobante;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return oListaComprobante;
                }
            }
        }

        public static bool Modificar(EstructuraPartidaGastosMO est)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {

                NpgsqlCommand cmd = new NpgsqlCommand("spu_estructura_partida", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
               // cmd.Parameters.AddWithValue("@in_aniofiscal", int.Parse(est.anio));
              //  cmd.Parameters.AddWithValue("@in_identifi", int.Parse(est.identifi));
                cmd.Parameters.AddWithValue("@in_itemaso", int.Parse(est.item_aso));
                cmd.Parameters.AddWithValue("@in_orienta_gas", int.Parse(est.orienta_gas));
                cmd.Parameters.AddWithValue("@in_foce", int.Parse(est.foce));
                cmd.Parameters.AddWithValue("@in_niv_ug", int.Parse(est.niv_ug));
                cmd.Parameters.AddWithValue("@in_niv_proy", int.Parse(est.niv_proy));
                cmd.Parameters.AddWithValue("@in_codemp", Constantes.General.Empresa);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                                        Environment.NewLine, e.StackTrace);
                    return false;
                }
            }
        }
    }
}
