﻿namespace Congope.Empresas.General
{
    /// <summary>
    /// Contiene las constantes generales del sistema
    /// </summary>
    internal static class Constantes
    {
        internal struct General
        {
            /// <summary>
            /// Error timeout
            /// </summary>
            internal const string Empresa = "0004";
            /// <summary>
            /// Modulos
            /// </summary>
            internal const string contabilidad = "1";

            /// <summary>
            /// Modulos
            /// </summary>
            internal const string presupuesto = "2";

            /// <summary>
            /// Modulos
            /// </summary>
            internal const string inventario = "3";

            /// <summary>
            /// Modulos
            /// </summary>
            internal const string nomina = "4";
            /// <summary>
            /// Modulos
            /// </summary>
            internal const string activosFijos = "5";

            /// <summary>
            /// Variables cargadas por defecto para poner auditorias y controles en objetos
            /// </summary>
            internal const string anio = "2024";
            internal const string esAdministrador = "1";
            internal const string codigoUsuario = "2";

        }
        internal struct EstadosCuenta
        {
            /// <summary>
            /// Error timeout
            /// </summary>
            internal const string activo = "1";

            /// <summary>
            /// Error timeout
            /// </summary>
            internal const string inactivo = "2";
        }

        internal struct  TipoCuenta
        {
            internal const string apertura = "AP";
        }
        
    }
}
