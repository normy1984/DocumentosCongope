import { RouteInfo } from "./sidebar.metadata";
export const ROUTES: RouteInfo[] =  [
  {
  nivel: 1,
  codigo: "01",
  path: "",
  title: "CONTABILIDAD",
  iconType: "",
  icon: "",
  class: "",
  groupTitle: true,
  badge: "",
  badgeClass: "",
  submenu: []
},
{
  nivel: 2,
  codigo: "01.001",
  path: "",
  title: "Parametrización",
  iconType: "feather",
  icon: "chevrons-down",
  class: "menu-toggle",
  groupTitle: false,
  badge: "6",
  badgeClass: "badge bg-green sidebar-badge float-end",
  submenu: [
      {
          nivel: 3,
          codigo: "01.001.001",
          path: "Parametrizacion/DatosdelaEmpresa",
          title: "Datos de la Empresa",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.001.002",
          path: "Parametrizacion/EjercicioFiscal",
          title: "Ejercicio Fiscal",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.001.003",
          path: "Parametrizacion/EstructuraPlandeCuentas",
          title: "Estructura Plan de Cuentas",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.001.004",
          path: "Parametrizacion/TiposdeComprobantes",
          title: "Tipos de Comprobantes",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.001.005",
          path: "Parametrizacion/TablasGenerales",
          title: "Tablas Generales",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.001.006",
          path: "Parametrizacion/DefinirCtas.pasanaTesoreria",
          title: "Definir Ctas. pasan a Tesorería",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      }
  ]
},
{
  nivel: 2,
  codigo: "01.002",
  path: "",
  title: "Catálogos",
  iconType: "feather",
  icon: "chevrons-down",
  class: "menu-toggle",
  groupTitle: false,
  badge: "3",
  badgeClass: "badge bg-green sidebar-badge float-end",
  submenu: [
      {
          nivel: 3,
          codigo: "01.002.001",
          path: "Catalogos/PlandeCuentas",
          title: "Plan de Cuentas",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.002.002",
          path: "Catalogos/CodigodeIdentificacionUnica",
          title: "Código de Identificación Única",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      },
      {
          nivel: 3,
          codigo: "01.002.003",
          path: "Catalogos/CuentasBancarias",
          title: "Cuentas Bancarias",
          iconType: "",
          icon: "",
          class: "ml-menu",
          groupTitle: false,
          badge: "0",
          badgeClass: "",
          submenu: []
      }
  ]
}
];
