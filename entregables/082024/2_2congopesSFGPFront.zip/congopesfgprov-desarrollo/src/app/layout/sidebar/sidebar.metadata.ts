// Sidebar route metadata
export interface RouteInfo {
  nivel:number;
  codigo:string;
  path: string;
  title: string;
  iconType: string;
  icon: string;
  class: string;
  groupTitle: boolean;
  badge: string;
  badgeClass: string;
  submenu: RouteInfo[];
}
