import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ListModule } from 'app/paginas/generico/list.module';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MovimientosPresupuestariosMo } from 'app/models/params/movpresupuestarios-mo';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { CompromisoCabeceraMo, CompromisoDetalleMo } from 'app/models/movimientos/compromiso-mo';
import { DatePipe } from '@angular/common';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { CargarArchivosComponent } from 'app/paginas/generico/cargar-archivos/cargar-archivos.component';
import { CargaArchivoMo } from 'app/models/carga-archivo-mo';
import { ConsultaAprobarDesaprobarService } from 'app/servicios/generico/consulta-aprobar-desaprobar.service';
import { VariablesAprobarDesaprobarMo } from 'app/models/administracion/aprobar-desaprobar-mo';
import { ContentObserver } from '@angular/cdk/observers';

@Component({
  selector: 'app-compromiso-edit',
  templateUrl: './compromiso-edit.component.html',
  standalone: true,
  imports: [EditModule, ListModule,
    MatAutocompleteModule, MatSlideToggleModule, MatDatepickerModule, FormsModule
  ],
  // ESTA PARTE DE LOS PROVIDERS CAMBIA LOS OBJETOS DE ANGULAR MATERIAL A ESPAÑOL
  providers: [DatePipe,
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
    },

  ],
})

export class CompromisoEditComponent implements OnInit {


  @Input('param') param!: string;

  // Inyectando servicios
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);

  /**VARIABLE QUE CAPTURA SI EL USUARIO ES SOLO LECTURA */
  public usuarioConsulta:boolean = sessionStorage.getItem('usuarioConsulta') === 'true' ? true : false;
  

  // Enlaces con las vistas
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild('picker_fec_asi') picker_fec_asi!: MatDatepicker<Date>;
  @ViewChild('picker_fec_aprob') picker_fec_aprob!: MatDatepicker<Date>;
  @ViewChild('solicita_desc') solicita_desc!: ElementRef<HTMLInputElement>;
  @ViewChild('departam_desc') departam_desc!: ElementRef<HTMLInputElement>;

  // Variables para manejo del formulario y datos
  public FormularioDatos!: UntypedFormGroup;
  public dataSource: MatTableDataSource<any> = new MatTableDataSource();
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: any = 0;
  public minDate = new Date();
  public resultado: any[] = [];
  public editedElement: any | null = null;
  public isEditing: boolean = false;
  public OcultarError: boolean = true;
  public MensajeError: string = '';

  // Variables de visualización
  public NoCompromiso: string = '';
  public estado_desc: string = '';
  public colorEstado: string = 'label-default';
  public creadoPor: string = '';
  public modificadoPor: string = '';
  public anio: number = 0;
  public estado: number = 0;
  public VerAnula_desc: string = '';
  public VerAnuladoPor_desc: string = '';

  // Flags de visibilidad para botones
  public OcultarBtnAprobar: boolean = false;
  public OcultarBtnDesaprobar: boolean = false;
  public OcultarBtnImprimir: boolean = false;
  public OcultarBtnAnular: boolean = false;
  public OcultarBtnLiquidar: boolean = false;
  public OcultarBtnDuplicar: boolean = false;
  public OcultarBtnDistribuir: boolean = false;
  public OcultarBtnVerSaldo: boolean = false;
  public OcultarBtnCargarArchivos: boolean = false;
  public OcultarBtnGuardarCancelar: boolean = false;
  public OcultarAnula: boolean = true;
  public OcultarAnuladoPor: boolean = true;

  // Definición de columnas para la tabla
  public displayedColumns: string[] = [
    "actions",
    "certificacion",
    "cuenta",
    "nom_cue",
    "val_cre",
    "val_deb",
    "val_sal"
  ];

  // Variables para departamentos y responsables
  public departam: number = 0;
  public solicita: number = 0;
  public OpcionesDepartamentos!: any[];
  public OpcionesResponsables!: any[];
  public EstructuraDepartamentos!: any[];
  public EstructuraResponsables!: any[];

  // Modelos para los datos del formulario
  blankObjectCabecera = {} as CompromisoCabeceraMo;
  ModeloDatosCabecera: CompromisoCabeceraMo = new CompromisoCabeceraMo(this.blankObjectCabecera);
  blankObjectDetalle = {} as CompromisoDetalleMo;
  ModeloDatosDetalle: CompromisoDetalleMo = new CompromisoDetalleMo(this.blankObjectDetalle);
  blankObject = {} as MovimientosPresupuestariosMo;
  ModeloDatos: MovimientosPresupuestariosMo = new MovimientosPresupuestariosMo(this.blankObject);

   // Rutas de la API y navegación
   public pagina: string = "Movimientos/CompromisosPresupuestarios";
   public paginaA: string = "Movimientos/CompromisosPresupuestarios";
   public rutaapi: string = "MovimientosPresupuestarios";

   public VarApruebaDesaprueba:VariablesAprobarDesaprobarMo = new VariablesAprobarDesaprobarMo();

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private datePipe: DatePipe,
    private ServApruebaDesaprueba: ConsultaAprobarDesaprobarService
  ) {

    // Suscripción a eventos del router para manejar la navegación de la página
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const rutaActual = event.url;
        this.paginaA = rutaActual && rutaActual.includes('/Movimientos/CompromisosPresupuestariosA/') ? "Movimientos/CompromisosPresupuestarios" : "Movimientos/CompromisosPresupuestariosA";
      }
    });

  }

 
  ngOnInit(): void {

    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = arrayResultado[1];
    this.CargarForm();
    this.CargarGrid();
    this.CargarDatosDepartamento();
    this.CargarDatosResponsables();
    this.cargarVariablesApruebaDesaprueba();

  }
  

  cargarVariablesApruebaDesaprueba()
  {
    this.ServApruebaDesaprueba.GetVariablesAprobarDesaprobar('CO').subscribe({
      next: (result) => {
        this.VarApruebaDesaprueba = result;
      },
      error: (err) => {
        console.error('Error al obtener variables:', err);
      }
    });
  }
  
  /**
  * Funcion que dirige a la pantalla para el nuevo registro
  */
  VolverPagina() {
    this.router.navigate([this.pagina]);
  }


  /**
   * Funcion que crea el formulario
   * @returns 
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      fec_asi: [this.ModeloDatos.fec_asi, [Validators.required]],
      num_com: [this.ModeloDatos.num_com, [Validators.required]],
      fec_apr: [this.ModeloDatos.fec_apr],
      departam_desc: ["",[Validators.required]],
      solicita_desc: ["", [Validators.required]],
      des_cab: [this.ModeloDatos.des_cab, [Validators.required]],
      cod_proceso: [""],
      valor_contrato: [0],
    });
  }


  /**
   * Funcion que carga la informacion de la forma
   */
  CargarForm(): void {
    // Determina la ruta de la API según el tipo de evento
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
        break;
      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Compromiso/CertCebecera");
        break;
    }
  
    // Solicita los datos del compromiso utilizando el identificador proporcionado
    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
      next: (data) => {
        if (data.success) {
          let resultado: any[] = JSON.parse(data.result);
          let datosForm: any = resultado[0];
  
          // Actualiza los campos del formulario con los datos obtenidos
          this.FormularioDatos.patchValue({
            num_com: datosForm.num_com,
            des_cab: datosForm.des_cab,
            fec_asi: datosForm.fec_asi,
            fec_apr: datosForm.fec_apr,
            solicita_desc: datosForm.solicita_desc,
            departam_desc: datosForm.departam_desc,
            cod_proceso: datosForm.cod_proceso,
            valor_contrato: datosForm.valor_contrato
          });
  
          // Actualiza las propiedades del componente con los datos obtenidos
          this.departam = datosForm.departam;
          this.solicita = datosForm.solicita;
          this.minDate = datosForm.fec_asi;
          this.NoCompromiso = datosForm.siglasnum ?? '';
          this.estado_desc = datosForm.estado_desc ?? '';
          this.anio = datosForm.anio ?? '';
          this.creadoPor = datosForm.creado_por ?? '';
          this.modificadoPor = datosForm.modificado_por ?? '';
          this.estado = datosForm.estado ?? '';
  
          this.ModeloDatosCabecera.acu_tipce = datosForm.acu_tipce ?? '';
          this.ModeloDatosCabecera.sig_tipce = datosForm.sig_tipce ?? '';
  
          this.VerAnula_desc = datosForm.anula_siglas_num;
          this.VerAnuladoPor_desc = datosForm.anulado_siglasnum;
  
          // Manejo del estado según las condiciones de anulación
          if (parseInt(this.VerAnula_desc) > 0) {
            if (this.estado === 3) {
              this.estado = 993; // Estado que indica que anula a un compromiso y que esta aprobado
            } else {
              this.estado = 991; // Estado que indica que anula a un compromiso y esta pendiente de aprobar
            }
            this.OcultarAnula = false;
          }
          if (parseInt(this.VerAnuladoPor_desc) > 0) {
            this.estado = 992; // Estado que indica que fue anulado por otro compromiso
            this.OcultarAnuladoPor = false;
          }
  
          // Configura el estado del formulario y la acción a realizar según el evento
          switch (this.evento) {
            case "EDITAR":
              this.accion = "MANTENIMIENTO";
              this.colorEstado = 'label-danger';
              break;
            case "DUPLICAR":
              this.accion = "CREAR NUEVO - DUPLICADO";
              this.NoCompromiso = "CO -1";
              this.estado_desc = 'EN EDICION - BORRADOR';
              this.estado = 0;
              break;
            case "NUEVO":
              this.estado_desc = 'EN EDICION - BORRADOR';
              this.estado = 0;
              break;
          }
  
          // Actualiza los botones según el estado del compromiso
          this.AccionesBotones(this.estado);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  
    // Crea y asigna el formulario
    this.FormularioDatos = this.CrearFormulario();
  }
  
  /**
   * Funcion que genera la lista de datos para los grids de las pantallas
   */
  CargarGrid(): void {
    switch (this.evento) {
      case "EDITAR":
      case "DUPLICAR":
        this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/DetalleCompromiso");
        break;

      case "NUEVO":
        this.ServicioClienteHttp.SeteoRuta("Compromiso/CertDetalle");
        break;
    }


    this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
      next: (data) => {

        if (data.success) {
          this.resultado = JSON.parse(data.result);
        }
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;

      },
      error: (err) => {
        console.log(err.message)
      }
    })

  }

  /** 
 * Calcula el total comprometido de todas las transacciones.
 * @returns {number} El total comprometido.
 */
TotalComprometido(): number {
  return this.resultado
    .map(transaccion => transaccion.val_cre)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total devengado de todas las transacciones.
 * @returns {number} El total devengado.
 */
TotalDevengado(): number {
  return this.resultado
    .map(transaccion => transaccion.val_deb)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}

/** 
 * Calcula el total del saldo de todas las transacciones.
 * @returns {number} El total del saldo.
 */
TotalSaldo(): number {
  return this.resultado
    .map(transaccion => transaccion.val_sal)
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
}


  /**
 * Carga información de departamentos desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosDepartamento(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/19");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraDepartamentos = data.result;
        this.OpcionesDepartamentos = this.EstructuraDepartamentos.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Carga información de responsables desde el servidor y actualiza las opciones disponibles.
 */
CargarDatosResponsables(): void {
  this.ServicioClienteHttp.SeteoRuta("TablasGenerales/DetalleSinDiccionario/54");
  this.ServicioClienteHttp.Obtener_Lista().subscribe({
    next: (data) => {
      if (data.success) {
        this.EstructuraResponsables = data.result;
        this.OpcionesResponsables = this.EstructuraResponsables.slice();
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Filtra las opciones de autocompletar basándose en la entrada del usuario.
 * @param opcion La opción a filtrar (solicita_desc o departam_desc).
 */
FiltroAutocomplete(opcion: string): void {
  let filterValue = '';
  switch (opcion) {
    case "solicita_desc":
      filterValue = this.solicita_desc.nativeElement.value.toLowerCase();
      this.OpcionesResponsables = this.EstructuraResponsables.filter(option => option.descrip.toLowerCase().includes(filterValue));
      this.solicita = this.OpcionesResponsables[0]?.codigo || 0;
      break;
    case "departam_desc":
      filterValue = this.departam_desc.nativeElement.value.toLowerCase();
      this.OpcionesDepartamentos = this.EstructuraDepartamentos.filter(option => option.descrip.toLowerCase().includes(filterValue));
      this.departam = this.OpcionesDepartamentos[0]?.codigo || 0;
      break;
  }
}

/**
 * Abre el selector de fecha de asignación.
 */
AbrirPickerFecAsi(): void {
  this.picker_fec_asi.open();
}

/**
 * Abre el selector de fecha de aprobación.
 */
AbrirPickerFecAprob(): void {
  this.picker_fec_aprob.open();
}


/**
 * Inicia el modo de edición para un elemento del grid.
 * @param element El elemento a editar.
 */
iniciaEditList(element: any): void {
  this.editedElement = element;
  this.isEditing = true; // Indicar que estamos en modo edición
}

/**
 * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
 * @param element El elemento editado.
 */
finEditList(element: any): void {
  element.val_sal = element.val_cre - element.val_deb; // Calcula el saldo
  this.editedElement = null; // Desactiva la edición
  this.isEditing = false; // Finaliza el modo edición
  // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
}

/**
 * Guarda la información ingresada en el grid.
 */
GuardarInformacion(): void {
  Swal.fire({
    title: "¿Está seguro de realizar los cambios?",
    showDenyButton: true,
    confirmButtonText: "Guardar",
    denyButtonText: "Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      let datosGuardar = this.FormularioDatos.getRawValue();

      const str_siglasnum = this.NoCompromiso;
      const parts_siglasnum = str_siglasnum.split(" ");

      // Reemplazo los valores del objeto inicial por los del formulario

      Object.keys(this.ModeloDatosCabecera).forEach(key => {
        if (key in datosGuardar) {
          (this.ModeloDatosCabecera as any)[key] = (datosGuardar as any)[key];
        }
      });
      this.ModeloDatosCabecera.departam = this.departam;
      this.ModeloDatosCabecera.solicita = this.solicita;
      this.ModeloDatosCabecera.tot_cre = this.TotalComprometido();
      this.ModeloDatosCabecera.tot_deb = this.TotalDevengado();
      this.ModeloDatosCabecera.sig_tip = parts_siglasnum[0];
      this.ModeloDatosCabecera.acu_tip = parseInt(parts_siglasnum[1]);
      this.ModeloDatosCabecera.fec_asi = this.datePipe.transform(datosGuardar.fec_asi, 'yyyy-MM-dd') ?? '';
      this.ModeloDatosCabecera.fec_apr = this.datePipe.transform(datosGuardar.fec_apr, 'yyyy-MM-dd') ?? '';


      this.GuardarCabecera();
    }
  });
}

/**
 * Guarda la cabecera en el servidor.
 */
GuardarCabecera(): void {
  this.ServicioClienteHttp.SeteoRuta("Compromiso/cabecera");
  this.ServicioClienteHttp.Insertar(this.ModeloDatosCabecera).subscribe({
    next: (data) => {
      if (data.success) {
        let retorno: any[] = JSON.parse(data.result);
        this.ModeloDatosCabecera.sig_tip = retorno[0].out_sig_tip;
        this.ModeloDatosCabecera.acu_tip = retorno[0].out_acu_tip;

        this.GuardarDetalle();

      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
}

/**
 * Guarda el detalle en el servidor.
 */
GuardarDetalle(): void {


  const ObjetoDetalle: CompromisoDetalleMo[] = this.resultado.map(element => {
    const str_siglasnumdet = element.certificacion;
    const parts_siglasnumdet = str_siglasnumdet.split(" ");
  
    let nuevoDetalle = new CompromisoDetalleMo(element); // Suponiendo que el constructor de CompromisoDetalleMo acepta un objeto como parámetro
  
    if (parts_siglasnumdet.length > 1) {
      nuevoDetalle.sig_tip = this.ModeloDatosCabecera.sig_tip;
      nuevoDetalle.acu_tip = this.ModeloDatosCabecera.acu_tip;
      nuevoDetalle.acu_tip_ce = parts_siglasnumdet[1];
    } else {
      console.error("La cadena str_siglasnumdet no contiene suficientes partes para dividir");
    }
  
    return nuevoDetalle;
  });

  this.ServicioClienteHttp.SeteoRuta("Compromiso/detalle");
  this.ServicioClienteHttp.Insertar(ObjetoDetalle).subscribe({
    next: (data) => {
      if (data.success) {
        let parametro = this.ServicioCrypt.encryptString("EDITAR||CO " + this.ModeloDatosCabecera.acu_tip)
        this.alertas.MensajeExito('/' + this.paginaA, 'Registro Guardado exitosamente', parametro)
      } else {
        this.alertas.MensajeError(data.message);
      }
    },
    error: (err) => {
      console.log(err.message);
    }
  });
  
}


/**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
ImprimirReporte(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let  DatosPdf: ObjetoPdf = new ObjetoPdf();
  DatosPdf.tipo_reporte="RPT205_COMPROMISO";
  DatosPdf.param1=parts_siglasnum[0];
  DatosPdf.param2=parts_siglasnum[1];

 

  const dialogRef = this.dialog.open(VisualizaPdfComponent, {
    data: {
      DatosPdf
    },
    width: '95%',
    height: '100%'
  });
}

/**
 * Función para cargar archivos.
 */
CargarArchivos(): void {
  const str_siglasnum = this.pk_identificador;
  const parts_siglasnum = str_siglasnum.split(" ");

  let DatosArchivo: CargaArchivoMo = {
    tipo_documento: parts_siglasnum[0],
    codigo_documento: parts_siglasnum[1],
    anio: this.anio,
    codsistema: 0,
    descripcion: ""
  };

  const dialogRef = this.dialog.open(CargarArchivosComponent, {
    data: {
      DatosArchivo
    },
    width: '95%',
    height: '100%'
  });
}

/**
 * Duplica el registro actual.
 */
DuplicarRegistro(): void {
  let parametro = this.ServicioCrypt.encryptString("DUPLICAR||" + this.pk_identificador)
  this.router.navigate(['/' + this.paginaA, parametro])
}


/**
 * Controla las acciones de los botones según el estado del registro.
 * @param estado El estado del registro.
 */
  AccionesBotones(estado: number) {
    switch (estado) {
      case 0:
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = true;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = true;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        break;
      case 2:
        this.OcultarBtnAprobar = false;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = false;
        break;
      case 3:
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = false;
        this.OcultarBtnAnular = false;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = false;
        this.OcultarBtnGuardarCancelar = true;

        this.accion = '';
        this.colorEstado = 'label-info';

        this.displayedColumns = [
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];

        break;

      case 991:
        this.OcultarBtnAprobar = false;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = false;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = false;
        this.OcultarBtnDistribuir = false;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        this.OcultarBtnGuardarCancelar = true;
        this.displayedColumns = [
          "certificacion",
          "cuenta",
          "nom_cue",
          "val_cre",
          "val_deb",
          "val_sal"];
        break;
        case 992:
          this.OcultarBtnAprobar = true;
          this.OcultarBtnDesaprobar = true;
          this.OcultarBtnImprimir = false;
          this.OcultarBtnAnular = true;
          this.OcultarBtnLiquidar = true;
          this.OcultarBtnDuplicar = false;
          this.OcultarBtnDistribuir = true;
          this.OcultarBtnVerSaldo = true;
          this.OcultarBtnCargarArchivos = false;
          this.OcultarBtnGuardarCancelar = true;
          this.colorEstado = 'label-info';
          this.displayedColumns = [
            "certificacion",
            "cuenta",
            "nom_cue",
            "val_cre",
            "val_deb",
            "val_sal"];
          break;
          
          case 993:
            this.OcultarBtnAprobar = true;
            this.OcultarBtnDesaprobar = true;
            this.OcultarBtnImprimir = false;
            this.OcultarBtnAnular = true;
            this.OcultarBtnLiquidar = true;
            this.OcultarBtnDuplicar = false;
            this.OcultarBtnDistribuir = true;
            this.OcultarBtnVerSaldo = true;
            this.OcultarBtnCargarArchivos = false;
            this.OcultarBtnGuardarCancelar = true;
            this.colorEstado = 'label-info';
            this.displayedColumns = [
              "certificacion",
              "cuenta",
              "nom_cue",
              "val_cre",
              "val_deb",
              "val_sal"];
            break;        
      default:
        this.OcultarBtnAprobar = true;
        this.OcultarBtnDesaprobar = true;
        this.OcultarBtnImprimir = true;
        this.OcultarBtnAnular = true;
        this.OcultarBtnLiquidar = true;
        this.OcultarBtnDuplicar = true;
        this.OcultarBtnDistribuir = true;
        this.OcultarBtnVerSaldo = true;
        this.OcultarBtnCargarArchivos = true;
        break;
    }
  }


/**
 * Método para mostrar un cuadro de diálogo de confirmación y aprobar el compromiso presupuestario.
 */
AprobarCompromiso(): void {
  Swal.fire({
    title: "¿Está seguro de aprobar el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Aprobar",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Aprobar");
      this.ServicioClienteHttp.Actualizar(this.NoCompromiso).subscribe({
        next: (data) => {
          if (data.success) {
            let respuestaAprobar = JSON.parse(data.result)[0];
            if (respuestaAprobar.ejecutado === true) {
              this.OcultarError = false;
              this.MensajeError = '<p><strong>NO SE PUEDE APROBAR EL COMPROMISO</strong><p>' + respuestaAprobar.mensaje;
            } else {
              let parametro = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
              this.alertas.MensajeExito('/' + this.paginaA, 'Registro aprobado exitosamente', parametro);
            }
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y desaprobar el compromiso presupuestario.
 */
DesAprobarCompromiso(): void {
  Swal.fire({
    title: "¿Está seguro de desaprobar el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Desaprobar",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Desaprobar");
      this.ServicioClienteHttp.Actualizar(this.NoCompromiso).subscribe({
        next: (data) => {
          if (data.success) {
            let parametro = this.ServicioCrypt.encryptString("EDITAR||" + this.NoCompromiso);
            this.alertas.MensajeExito('/' + this.paginaA, 'Registro desaprobado exitosamente', parametro);
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

/**
 * Método para mostrar un cuadro de diálogo de confirmación y anular el compromiso presupuestario.
 */
AnularCompromiso(): void {
  Swal.fire({
    title: "¿Está seguro de anular el Compromiso Presupuestario " + this.NoCompromiso + "?",
    showDenyButton: true,
    confirmButtonText: "Sí, Anular",
    denyButtonText: "No, Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      this.ServicioClienteHttp.SeteoRuta("Compromiso/Anular");
      this.ServicioClienteHttp.Actualizar(this.NoCompromiso).subscribe({
        next: (data) => {
          if (data.success) {
            let retorno: any[] = JSON.parse(data.result);
            let parametro = this.ServicioCrypt.encryptString("EDITAR||CO " + retorno[0].out_acu_tip);
            this.alertas.MensajeExito('/' + this.paginaA, 'Registro anulado exitosamente', parametro);
          } else {
            this.alertas.MensajeError(data.message);
          }
        },
        error: (err) => {
          console.log(err.message);
        }
      });
    }
  });
}

}

