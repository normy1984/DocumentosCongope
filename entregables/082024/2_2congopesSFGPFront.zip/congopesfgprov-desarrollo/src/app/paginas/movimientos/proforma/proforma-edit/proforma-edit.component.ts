import { Component, Input, OnInit, ViewChild, inject } from '@angular/core';
//import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { FormBuilder,  FormsModule,  UntypedFormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ListModule } from 'app/paginas/generico/list.module';
import { MatTableDataSource } from '@angular/material/table';
import { configapp } from '@config/configapp';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ProformaPresupuestariaUnicaMO } from 'app/models/params/proformapresupuestariaunica_mo';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { CompromisoCabeceraMo, CompromisoDetalleMo } from 'app/models/movimientos/compromiso-mo';
import { DatePipe } from '@angular/common';
import { DateAdapter, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { VersaldopartidaListComponent } from 'app/paginas/reportes/versaldopartida-list/versaldopartida-list.component';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
  selector: 'app-proforma-edit',
  templateUrl: './proforma-edit.component.html',
  standalone: true,
  imports: [EditModule, ListModule,
    MatAutocompleteModule, MatSlideToggleModule, MatDatepickerModule, FormsModule
  ],
  providers: [DatePipe,
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
    },],
})

export class ProformaEditComponent implements OnInit{
  @Input('param') param!: string;

  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  // Enlaces con las vistas
  @ViewChild('picker_fec_aprob') picker_fec_aprob!: MatDatepicker<Date>;

  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  public pageSizeOptions: number[] = configapp.pageSizeOptions;
  public dataSource !: MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = false;
  public isGPRD: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: number = 0;
  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;
  public NroDocumento: number = 0;
  public sCreadoPor : string = "";
  public sModificadoPor: string = '';
  public OcultarError: boolean = true;
  public MensajeError: string = '';
  public bAprobar: boolean = true;
  public bDesaprobar: boolean = false;
  public anio: number = 0;
  public editedElement: any | null = null;
  public editedElementG: any | null = null;
  public isEditing: boolean = false;
  public resultado: any[] = [];
  public nEstado = 0;
  public out_nombre_estado = "";
  public colorEstado: string = 'label-default';
  public creadoPor: string = '';

  objeto: unknown;

   /**COLUMNAS MOSTRADAS */
  public displayedColumns: string[] = [
    "accion",
    "out_cuenta",
    "out_nom_cue",
    "out_val_deb",
    "out_val_cre",
    "versaldo",
  ];
/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
  public pagina: string = "movimientos/proforma";
  public rutaapi: string = "ProformaPresupuestariaCab";
  public paginaA: string = "movimientos/proforma";
  public OptionsEstructura: any[] = [];

  // Modelos para los datos del formulario
  blankObject = {} as ProformaPresupuestariaUnicaMO;
  ModeloDatos: ProformaPresupuestariaUnicaMO = new ProformaPresupuestariaUnicaMO(this.blankObject);
  blankObjectCabecera = {} as CompromisoCabeceraMo;
  ModeloDatosCabecera: CompromisoCabeceraMo = new CompromisoCabeceraMo(this.blankObjectCabecera);
  blankObjectDetalle = {} as CompromisoDetalleMo;
  ModeloDatosDetalle: CompromisoDetalleMo = new CompromisoDetalleMo(this.blankObjectDetalle);

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
    private datePipe: DatePipe,
  ){
  }
  ngOnInit(): void {
    const datos = this.ServicioCrypt.decryptString(this.param);
    const arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = parseInt(arrayResultado[1]);
    this.codtab = parseInt(arrayResultado[2]);
    this.active_item = arrayResultado[3];
    this.CargarGrid();
    this.CargarForm();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      out_sig_acu_tip: [this.ModeloDatos.out_sig_acu_tip],
      out_fec_apr: [this.ModeloDatos.out_fec_apr],
      out_nombre_estado: [this.ModeloDatos.out_nombre_estado],
      out_des_cab: [this.ModeloDatos.out_des_cab],
      out_acu_tip: [this.ModeloDatos.out_acu_tip],
    });
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  CargarSelectEstructura()
  {
    this.ServicioClienteHttp.SeteoRuta("ProformaPresupuestariaCab?codemp=0004&anio=" + this.ParamSessiones.anio +"&sig_tip=PR&acu_tip="+this.pk_identificador+"");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.OptionsEstructura = data.result;
          //this.CargarAutocomplete();
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


    /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
    VolverPagina() {
      const parametro = this.ServicioCrypt.encryptString(this.codtab + "||" + this.active_item)
        this.router.navigate(['/' + this.pagina, parametro]);
    }

/**
 * Funcion que carga los valores iniciales del autocoomplete
 */
  /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion
   */


  /**
   * Funcion para cargar el filtro de informacion a partir de la estructyra de las partidas de gastos
   * @param filterValue
   * @returns
   */
    CargarDatosFiltrados(filterValue:string | null){
      return this.OptionsEstructura.filter(
        option =>
          {
            option.cuenta.toLowerCase().includes(filterValue)
            const valueMatch = option.cuenta.toLowerCase().includes(filterValue);
            const textMatch = option.nom_cue.toLowerCase().includes(filterValue);
            return valueMatch || textMatch;
          }
      );
    }

  /**
  * Funcion que genera la lista de datos para los grids de las pantallas
  */
  CargarForm():void {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi)
    this.evento = "EDITAR";

    if (this.evento == "EDITAR") {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO";
      this.ServicioClienteHttp.Obtener_x_Codigo("?codemp=0004&anio=" + this.ParamSessiones.anio +"&sig_tip=PR&acu_tip="+this.pk_identificador+" ").subscribe({
        next: (data) => {
          if (data.success) {
            const result: any = data.result;
            const datosForm: any = result[0];
            this.FormularioDatos.patchValue({
              out_sig_acu_tip: datosForm.out_sig_acu_tip,
              out_fec_apr: datosForm.out_fec_apr,
              out_nombre_estado: datosForm.out_nombre_estado,
              out_des_cab: datosForm.out_des_cab,
            });

            this.nEstado = datosForm.out_estado;
            this.out_nombre_estado = datosForm.out_nombre_estado ?? '';
            this.NroDocumento = datosForm.out_acu_tip ?? 0;
            this.sCreadoPor = datosForm.out_nomb_usu_crea ?? "";
            this.sModificadoPor = datosForm.out_nomb_usu_modifica ?? '';

            const fFechaApr = new Date(datosForm.out_fec_apr);

            this.anio = fFechaApr.getFullYear();

            this.bAprobar = true;
            this.bDesaprobar = false;
            if(datosForm.out_estado < "3"){
              this.isReadOnly = false;
              this.bAprobar = false;
              this.bDesaprobar = true;
            }

            if(this.sCreadoPor == "999"){
              this.bAprobar = true;
              this.bDesaprobar = true;
              this.isEditing = true;
            }
          }
          this.AccionesBotones(this.nEstado);
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
    this.FormularioDatos = this.CrearFormulario();

  }

  CargarGrid():void {
    this.ServicioClienteHttp.SeteoRuta("ProformaPresupuestariaDet");
    this.ServicioClienteHttp.Obtener_x_Codigo("?codemp=0004&anio=" + this.ParamSessiones.anio +"&sig_tip=PR&acu_tip="+this.pk_identificador+"").subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
        }
        this.dataSource = new MatTableDataSource(this.resultado);
        this.dataSource.sort = this.sort;
      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  /** Gets the total cost of all transactions. */
  TotalComprometido() {
    return this.resultado.map(t => t.out_val_deb).reduce((acc, value) => acc + value, 0);
  }

  TotalDevengado() {
    return this.resultado.map(t => t.out_val_cre).reduce((acc, value) => acc + value, 0);
  }


  AprobarDocumento(): void {
    Swal.fire({
      title: "¿Está seguro de aprobar la Proforma Presupuestaria " + this.NroDocumento + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Aprobar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta("ProformaPresupuestariaCab/Aprobar");
        this.ServicioClienteHttp.Actualizar(this.NroDocumento).subscribe({
          next: (data) => {
            if (data.success) {
              const respuestaAprobar = JSON.parse(data.result)[0];
              if (respuestaAprobar.ejecutado === true) {
                this.OcultarError = false;
                this.MensajeError = '<p><strong>NO SE PUEDE APROBAR LA PROFORMA PRESUPUESTARIA</strong><p>' + respuestaAprobar.mensaje;
                this.alertas.MensajeError(this.MensajeError);
              }
              else
              {
                const parametro = this.ServicioCrypt.encryptString("EDITAR||" + this.NroDocumento);
                this.alertas.MensajeExito('/' + this.paginaA, 'Registro aprobado exitosamente', parametro);
              }
            }
            else
            {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message);
          }
        });
      }
    });
  }

  DesaprobarDocumento(): void {
    Swal.fire({
      title: "¿Está seguro de desaprobar la Proforma Presupuestaria " + this.NroDocumento + "?",
      showDenyButton: true,
      confirmButtonText: "Sí, Desaprobar",
      denyButtonText: "No, Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        this.ServicioClienteHttp.SeteoRuta("ProformaPresupuestariaCab/Desaprobar");
        this.ServicioClienteHttp.Actualizar(this.NroDocumento).subscribe({
          next: (data) => {
            if (data.success) {
              const parametro = this.ServicioCrypt.encryptString("EDITAR||" + this.NroDocumento);
              this.alertas.MensajeExito('/' + this.paginaA, 'Registro desaprobado exitosamente', parametro);
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message);
          }
        });
      }
    });
  }

  /**
 * Función para enviar la impresión de los PDF.
 * @param row El registro seleccionado.
 */
  ImprimirReporte(): void {

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT227_PROFORMA";
    DatosPdf.param1 = "PR";
    DatosPdf.param2 = this.anio.toString();
    DatosPdf.param3 = this.NroDocumento.toString();
    DatosPdf.param4 = "";
    DatosPdf.param5 = "";

    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }

  AbrirPickerFecAprob(): void {
    this.picker_fec_aprob.open();
  }

  iniciaEditList(element: any): void {
    if(element.out_asociac == 2){
      this.editedElement = element;
    }
    if(element.out_asociac == 1){
      this.editedElementG = element;
    }
      this.isEditing = true; // Indicar que estamos en modo edición
  }

  /**
   * Finaliza el modo de edición para un elemento del grid y calcula el saldo.
   * @param element El elemento editado.
   */
  finEditList(element: any): void {
    element.val_sal = 0; // Calcula el saldo
    this.editedElement = null; // Desactiva la edición
    this.editedElementG = null; // Desactiva la edición
    this.isEditing = false; // Finaliza el modo edición
    // Aquí puedes realizar acciones adicionales, como guardar los cambios en una base de datos.
  }


  /**
 * Guarda la información ingresada en el grid.
 */

  GuardarInformacion(): void {
    Swal.fire({
      title: "¿Está seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      if (result.isConfirmed) {
        const datosGuardar = this.FormularioDatos.getRawValue();

        //const str_siglasnum = this.NroDocumento;
        //const parts_siglasnum = str_siglasnum.split(" ");

        this.ModeloDatosCabecera.sig_tip = "PR";
        this.ModeloDatosCabecera.acu_tip = this.NroDocumento;
        this.ModeloDatosCabecera.fec_apr = this.datePipe.transform(datosGuardar.out_fec_apr, 'yyyy-MM-dd') ?? '';
        this.ModeloDatosCabecera.des_cab = datosGuardar.out_des_cab;
        this.GuardarCabecera();

      }
    });
  }


/**
 * Guarda la cabecera en el servidor.
 */

  GuardarCabecera(): void {
    this.ServicioClienteHttp.SeteoRuta("Compromiso/cabecera");
    this.ServicioClienteHttp.Insertar(this.ModeloDatosCabecera).subscribe({
      next: (data) => {
        if (data.success) {
          //const retorno: any[] = JSON.parse(data.result);

          this.ModeloDatosCabecera.sig_tip = "PR";
          this.ModeloDatosCabecera.acu_tip = this.NroDocumento;

          this.GuardarDetalle();

        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }
/**
 * Guarda el detalle en el servidor.
 */

  GuardarDetalle(): void {
    const ObjetoDetalle: CompromisoDetalleMo[] = [];

    this.resultado.forEach(element => {
      this.ModeloDatosDetalle.sig_tip = this.ModeloDatosCabecera.sig_tip
      this.ModeloDatosDetalle.acu_tip = this.ModeloDatosCabecera.acu_tip;
      this.ModeloDatosDetalle.acu_tip_ce = 0;
      this.ModeloDatosDetalle.cuenta = element.out_cuenta;
      this.ModeloDatosDetalle.val_deb = element.out_val_deb;
      this.ModeloDatosDetalle.val_cre = element.out_val_cre;
      this.ModeloDatosDetalle.asociac = element.out_asociac;
      this.ModeloDatosDetalle.sec_det = element.out_sec_det;

      ObjetoDetalle.push({ ...this.ModeloDatosDetalle });
    });

    this.ServicioClienteHttp.SeteoRuta("ProformaPresupuestariaDet/detalle");

    this.ServicioClienteHttp.Insertar(ObjetoDetalle).subscribe({
      next: (data) => {
        if (data.success) {
          const parametro = this.ServicioCrypt.encryptString("EDITAR||PR " + this.ModeloDatosCabecera.acu_tip)
          this.alertas.MensajeExito('/' + this.paginaA, 'Registro Guardado exitosamente', parametro)
        }
        else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  VerSaldoPartida(fila: any) {
    const str_partida = fila.out_cuenta;
    const DatosArchivo: any = {
      tipo_reporte: "SALDO DE PARTIDA",
      partida: str_partida
    };

    this.dialog.open(VersaldopartidaListComponent, {
      data: {
        DatosArchivo
      },
      width: '90%',
      height: '80%'
    });
  }

  CargarArchivos(): void {
    /*
    const str_siglasnum = this.pk_identificador;
    const parts_siglasnum = str_siglasnum.split(" ");

    let DatosArchivo: CargaArchivoMo = {
      tipo_documento: parts_siglasnum[0],
      codigo_documento: parts_siglasnum[1],
      anio: this.anio,
      codsistema: 0,
      descripcion: ""
    };

    const dialogRef = this.dialog.open(CargarArchivosComponent, {
      data: {
        DatosArchivo
      },
      width: '95%',
      height: '100%'
    });
    */
  }

  AccionesBotones(estado: number) {

    this.colorEstado = 'label-default';
    if(estado == 2){
      this.colorEstado = 'label-danger';
    }
    if(estado == 3){
      this.colorEstado = 'label-info';
    }
    /*
    switch (estado) {
      case 2:
        this.colorEstado = 'label-danger';
        break;
      case 3:
        this.colorEstado = 'label-info';
        break;
      default:
          this.colorEstado = 'label-default';
          break;
    }
    */
  }

}

