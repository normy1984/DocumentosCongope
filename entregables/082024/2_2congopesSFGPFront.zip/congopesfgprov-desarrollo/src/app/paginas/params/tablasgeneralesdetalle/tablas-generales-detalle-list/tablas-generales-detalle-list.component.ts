import { Component, Input, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { TipoComprobanteMo } from 'app/models/params/tipo-comprobante-mo';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import Swal from 'sweetalert2';
import { TablasGeneralesMo } from 'app/models/params/tablas-generales-mo';


@Component({
  selector: 'app-tablas-generales-detalle-list',
  templateUrl: './tablas-generales-detalle-list.component.html',
  standalone:true,
  imports: [
ListModule
  ]
})

export class TablasGeneralesDetalleListComponent 
extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  @Input('param') param!: string;
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */  
public pagina:string = "Parametrizacion/TablasGenerales/tablasgenerales_edetalle";
public rutaapi:string = "TablasGenerales/DetalleSinDiccionario";
public active_item!: string;
public codtab!: number;


/**COLUMNAS MOSTRADAS */   
public displayedColumns:string[] = [
  "accion",
  "codigo","descrip"];

  constructor(
    private router: Router
  ) {
    super();
  }


  ngOnInit() {
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.active_item = arrayResultado[1];
    this.codtab = parseInt(arrayResultado[0]);
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.CargarGrid();
  }

  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */

  CargarGrid() {
   
    this.ServicioClienteHttp.Obtener_x_Codigo(this.codtab).subscribe({
      next: (data) => {
        if (data.success) {
          //let resultado: any[] = JSON.parse(data.result);
          let resultado: any = data.result;
          this.dataSource = new MatTableDataSource(resultado);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.paginator._intl.itemsPerPageLabel = configapp.mensajeItemsPagina;
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }

  /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
  NuevoRegistro() {
    let parametro = this.ServicioCrypt.encryptString("NUEVO||-1||"+this.codtab+"||"+this.active_item)
    this.router.navigate(['/' + this.pagina , parametro]);
  } 

  


  /**
   * Funcion que envia los datos para editar un registro
   * @param objeto 
   */

  EditarRegistro(objeto: TablasGeneralesMo) {
    let parametro = this.ServicioCrypt.encryptString("EDITAR||"+objeto.codigo+"||"+this.codtab+"||"+this.active_item)
    this.router.navigate(['/' + this.pagina, parametro]);
  }


/**
 * Funcion para eliminar un registro
 * @param objeto 
 */
  EliminarRegistro(objeto: TipoComprobanteMo) {

    let textoEliminar:string = objeto.descripcion;
    let codigo:string = objeto.sigla;

    Swal.fire({
      title: "Esta seguro de eliminar "+ textoEliminar + "?",
      showDenyButton: true,
      confirmButtonText: "Eliminar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {

        this.ServicioClienteHttp.Eliminar(codigo).subscribe({
          next: (data) => {
            if (data.success) {
              this.CargarGrid();
              this.alertas.MensajeExito(this.pagina, "Registro eliminado exitosamente!!");
            } else {
              this.alertas.MensajeError(data.message);
            }
          },
          error: (err) => {
            console.log(err.message)
          }
        })
      }
    });
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CODIGO': x.codigo,
        'DESCRIPCION': x.descrip,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }
 
  /**
   * 
   * @param event Funcion que realiza los fitrados de los grids
   */
  FiltrarRegistros(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
