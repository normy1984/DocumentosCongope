import { Component, ElementRef, Input, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormControl, FormsModule, ReactiveFormsModule, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { TablasGeneralesMo } from 'app/models/params/tablas-generales-mo';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-tablas-generales-detalle-edit',
  standalone: true,
  imports: [EditModule, 
    MatAutocompleteModule,MatSlideToggleModule
  ],
  templateUrl: './tablas-generales-detalle-edit.component.html'
})

export class TablasGeneralesDetalleEditComponent implements OnInit{
  

  @Input('param') param!: string;
  
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: number = 0;
  public active_item!: string;
  public codtab!: number;
  public ban_CargaEstructura: number = 0;

   objeto: any;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */  
  public pagina: string = "Parametrizacion/TablasGenerales/tablasgeneralesdetalle";
  public rutaapi: string = "TablasGenerales/Detalle";

  public OptionsEstructura: any[] = [];


  @ViewChild('cuenta_debito') cuenta_debito!: ElementRef<HTMLInputElement>;
  @ViewChild('cuenta_credito') cuenta_credito!: ElementRef<HTMLInputElement>;
  @ViewChild('cuenta_gastos') cuenta_gastos!: ElementRef<HTMLInputElement>;
  @ViewChild('cuenta_devolucion') cuenta_devolucion!: ElementRef<HTMLInputElement>;
  @ViewChild('cuenta_debito2') cuenta_debito2!: ElementRef<HTMLInputElement>;
  @ViewChild('cuenta_credito2') cuenta_credito2!: ElementRef<HTMLInputElement>;

  OpcionesCuentaDebito!: any[];
  OpcionesCuentaCredito!: any[];
  OpcionesCuentaGastos!: any[];
  OpcionesCuentaDevolucion!: any[];
  OpcionesCuentaDebito2!: any[];
  OpcionesCuentaCredito2!:any[];


  

  blankObject = {} as TablasGeneralesMo;
  ModeloDatos: TablasGeneralesMo = new TablasGeneralesMo(this.blankObject);

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService) {
      
  }
  ngOnInit(): void {

    
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = parseInt(arrayResultado[1]);
    this.codtab = parseInt(arrayResultado[2]);
    this.active_item = arrayResultado[3];
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+ "/"+this.codtab);

    if (this.evento == "EDITAR") {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO";
      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
        next: (data) => {
          if (data.success) {
            let result: any = data.result;
            let resultado: TablasGeneralesMo = result[0];
            let dato1 = '';


            switch (this.codtab) {
              case 80:
                dato1 = resultado.cedruc;
                break;
              default:
                dato1 = resultado.telefon1;
                break;
            }
                            
            this.FormularioDatos.patchValue({
              codigo: resultado.codigo,
              descrip: resultado.descrip,
              dato1: dato1,
              dato2: resultado.direcci,
              dato3: resultado.telefon2,
              dato4: resultado.fax1,
              cuenta_debito: resultado.cuentadb,
              cuenta_credito: resultado.cuentacr,
              cuenta_gastos: resultado.cuentagst,
              cuenta_devolucion: resultado.cuentadevol,
              cuenta_debito2: resultado.cuentaddb,
              cuenta_credito2: resultado.cuentadcr,
            });

          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
    this.FormularioDatos = this.CrearFormulario();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      codigo: [{value: this.ModeloDatos.codigo, disabled: true }],
      descrip: [this.ModeloDatos.descrip,[Validators.required]],
      dato1: [this.ModeloDatos.cedruc],
      dato2: [this.ModeloDatos.direcci],
      dato3: [this.ModeloDatos.telefon2],
      dato4: [this.ModeloDatos.fax1],
      cuenta_debito: [{value: this.ModeloDatos.cuentadb, disabled: true}],
      cuenta_credito: [{value: this.ModeloDatos.cuentacr, disabled: true}],
      cuenta_gastos: [{value: this.ModeloDatos.cuentagst, disabled: true}],
      cuenta_devolucion: [{value: this.ModeloDatos.cuentadevol, disabled: true}],
      cuenta_debito2: [{value: this.ModeloDatos.cuentaddb, disabled: true}],
      cuenta_credito2: [{value: this.ModeloDatos.cuentadcr, disabled: true}],
    });
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  GuardarInformacion() {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    Swal.fire({
      title: "Esta seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        let datosGuardar = this.FormularioDatos.getRawValue();

       

        switch (this.codtab) {
          case 80:
            this.ModeloDatos.cedruc = datosGuardar.dato1;
            break;
          default:
            this.ModeloDatos.telefon1 = datosGuardar.dato1;
            break;
        }

        this.ModeloDatos.codtab = this.codtab;
        this.ModeloDatos.codigo = datosGuardar.codigo;
        this.ModeloDatos.descrip = datosGuardar.descrip;
        this.ModeloDatos.direcci = datosGuardar.dato2;
        this.ModeloDatos.telefon2 = datosGuardar.dato3;
        this.ModeloDatos.fax1 = datosGuardar.dato4;
        this.ModeloDatos.cuentadb = datosGuardar.cuenta_debito;
        this.ModeloDatos.cuentacr = datosGuardar.cuenta_credito;
        this.ModeloDatos.cuentagst = datosGuardar.cuenta_gastos;
        this.ModeloDatos.cuentadevol = datosGuardar.cuenta_devolucion;
        this.ModeloDatos.cuentaddb = datosGuardar.cuenta_debito2;
        this.ModeloDatos.cuentadcr = datosGuardar.cuenta_credito2;

        const objeto = this.ModeloDatos;

        if (this.pk_identificador == -1) {
          this.ServicioClienteHttp.Insertar(objeto).subscribe({
            next: (data) => {
              if (data.success) {
                let parametro = this.ServicioCrypt.encryptString(objeto.codtab + "||" + this.active_item)
                this.alertas.MensajeExito('/' + this.pagina, "Registro Guardado Exitosamente", parametro);
                
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        } else {
          this.ServicioClienteHttp.Actualizar(this.pk_identificador, objeto).subscribe({
            next: (data) => {
              if (data.success) {
                let parametro = this.ServicioCrypt.encryptString(objeto.codtab + "||" + this.active_item)
                this.alertas.MensajeExito('/' + this.pagina, "Registro Guardado Exitosamente", parametro);
                
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        }

      }
    });
  }


  CargarSelectEstructura()
  {
    this.ServicioClienteHttp.SeteoRuta("CuentasContables?pag=0&reg=0");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          //let resultado: any[] = JSON.parse(data.result);
          //let resultado: any = data.result;
          //this.OptionsEstructura = JSON.parse(data.result);
          this.OptionsEstructura = data.result;
          this.CargarAutocomplete();
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


    /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
    VolverPagina() {
      let parametro = this.ServicioCrypt.encryptString(this.codtab + "||" + this.active_item)
        this.router.navigate(['/' + this.pagina, parametro]);
    } 

/**
 * Funcion que carga los valores iniciales del autocoomplete
 */

    CargarAutocomplete(){
      this.ban_CargaEstructura = 1;      
          this.OpcionesCuentaCredito = this.OptionsEstructura.slice();
          this.OpcionesCuentaDebito = this.OptionsEstructura.slice();
          this.OpcionesCuentaGastos = this.OptionsEstructura.slice();
          this.OpcionesCuentaDevolucion = this.OptionsEstructura.slice();
          this.OpcionesCuentaDebito2 = this.OptionsEstructura.slice();
          this.OpcionesCuentaCredito2 = this.OptionsEstructura.slice();
    }


  /**
   * Funcion que llama a un filtro de informacion para los campos autocomplete
   * @param opcion 
   */
  FiltroAutocomplete(opcion: string) {

    var filterValue = '';

    switch (opcion) {
      
      case "cuenta_debito":
        filterValue = this.cuenta_debito.nativeElement.value.toLowerCase();
        this.OpcionesCuentaDebito = this.CargarDatosFiltrados(filterValue);
        break;
      
      case "cuenta_credito":
        filterValue = this.cuenta_credito.nativeElement.value.toLowerCase();
        this.OpcionesCuentaCredito = this.CargarDatosFiltrados(filterValue);
        break;
     case "cuenta_gastos":
        filterValue = this.cuenta_gastos.nativeElement.value.toLowerCase();
        this.OpcionesCuentaGastos = this.CargarDatosFiltrados(filterValue);
        break;
      case "cuenta_devolucion":
        filterValue = this.cuenta_devolucion.nativeElement.value.toLowerCase();
        this.OpcionesCuentaDevolucion = this.CargarDatosFiltrados(filterValue);
        break;
     case "cuenta_credito2":
        filterValue = this.cuenta_credito2.nativeElement.value.toLowerCase();
        this.OpcionesCuentaCredito2 = this.CargarDatosFiltrados(filterValue);
        break;
      case "cuenta_debito2":
        filterValue = this.cuenta_debito2.nativeElement.value.toLowerCase();
        this.OpcionesCuentaDebito2 = this.CargarDatosFiltrados(filterValue);
        break;

    }

  }

  /**
   * Funcion para cargar el filtro de informacion a partir de la estructyra de las partidas de gastos
   * @param filterValue 
   * @returns 
   */
    CargarDatosFiltrados(filterValue:string | null){
      return this.OptionsEstructura.filter(
        option => 
          {
            option.cuenta.toLowerCase().includes(filterValue)
            const valueMatch = option.cuenta.toLowerCase().includes(filterValue);
            const textMatch = option.nom_cue.toLowerCase().includes(filterValue);
            return valueMatch || textMatch;
          }
      );
    }

    /**
     * Activa el Ingreso de Cuentas en tablas Generales
     */
    
    HabilitarIngresoCuentas(){
      this.FormularioDatos.get('cuenta_debito')?.disabled ? this.FormularioDatos.get('cuenta_debito')?.enable(): this.FormularioDatos.get('cuenta_debito')?.disable();
      this.FormularioDatos.get('cuenta_credito')?.disabled ? this.FormularioDatos.get('cuenta_credito')?.enable(): this.FormularioDatos.get('cuenta_credito')?.disable();
      this.FormularioDatos.get('cuenta_gastos')?.disabled ? this.FormularioDatos.get('cuenta_gastos')?.enable(): this.FormularioDatos.get('cuenta_gastos')?.disable();
      this.FormularioDatos.get('cuenta_devolucion')?.disabled ? this.FormularioDatos.get('cuenta_devolucion')?.enable(): this.FormularioDatos.get('cuenta_devolucion')?.disable();
      this.FormularioDatos.get('cuenta_debito2')?.disabled ? this.FormularioDatos.get('cuenta_debito2')?.enable(): this.FormularioDatos.get('cuenta_debito2')?.disable();
      this.FormularioDatos.get('cuenta_credito2')?.disabled ? this.FormularioDatos.get('cuenta_credito2')?.enable(): this.FormularioDatos.get('cuenta_credito2')?.disable();
      if(this.ban_CargaEstructura==0)this.CargarSelectEstructura();
    }

  
}
