import { Component, Input, OnInit, inject } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

import Swal from 'sweetalert2'
import { EditModule } from 'app/paginas/generico/edit.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { TablasGeneralesMo } from 'app/models/params/tablas-generales-mo';


@Component({
  selector: 'app-departamentos-edit',
  standalone: true,
  imports: [EditModule],
  templateUrl: './departamentos-edit.component.html'
})


export class DepartamentosEditComponent implements OnInit{
  @Input('param') param!: string;
  private ServicioClienteHttp = inject(ClienthttpCongopeService);
  public alertas = inject(AlertasSrvService);
  public formBuild = inject(FormBuilder);
  private ServicioCrypt = inject(CryptService);
  public isReadOnly: boolean = false;
  public FormularioDatos!: UntypedFormGroup;
  public accion: string = "NUEVO REGISTRO";
  public evento: string = "";
  public pk_identificador: number = 0;
  public active_item!: string;
  public codtab!: number;

  objeto: any;


/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */  
  public pagina: string = "Parametrizacion/TablasGenerales";
  public rutaapi: string = "TablasGenerales/Detalle";

  public OptionsEstructura: any[] = [];

  blankObject = {} as TablasGeneralesMo;
  ModeloDatos: TablasGeneralesMo = new TablasGeneralesMo(this.blankObject);

  constructor(
    private router: Router,
    public dialog: MatDialog) {
  }

  ngOnInit(): void {

    this.CargarSelectEstructura();
    
    let datos = this.ServicioCrypt.decryptString(this.param);
    let arrayResultado = datos.split('||');
    this.evento = arrayResultado[0];
    this.pk_identificador = parseInt(arrayResultado[1]);
    this.codtab = parseInt(arrayResultado[2]);
    this.active_item = arrayResultado[3];
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi+ "/"+this.codtab);

    if (this.evento == "EDITAR") {
      this.isReadOnly = true;
      this.accion = "MANTENIMIENTO";
      this.ServicioClienteHttp.Obtener_x_Codigo(this.pk_identificador).subscribe({
        next: (data) => {
          if (data.success) {
            let result: any = data.result;
            let resultado: TablasGeneralesMo = result[0];
            let tipo_bodega = 0;

            /** 
             * VALIDACION PARA EL TIPO DE BODEGA
             */
            if (resultado.telefon1 == "1" && resultado.tipocli == 1) {
              tipo_bodega = 3;
            }
            if (resultado.telefon1 == "1" && resultado.tipocli == 0) {
              tipo_bodega = 2;
            }
            if (resultado.telefon1 == "0" && resultado.tipocli == 1) {
              tipo_bodega = 1;
            }  
                            
            this.FormularioDatos.patchValue({
              codigo: resultado.codigo,
              descrip: resultado.descrip,
              tipo_bodega: tipo_bodega,
              estructura_organizacional: resultado.nrocta,
            });

          }
        },
        error: (err) => {
          console.log(err.message)
        }
      })
    }
    this.FormularioDatos = this.CrearFormulario();
  }


  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      codigo: [{value: this.ModeloDatos.codigo, disabled: this.isReadOnly },[Validators.required, Validators.pattern('[a-zA-Z]*'), Validators.maxLength(2)]],
      descrip: [this.ModeloDatos.descrip,[Validators.required]],
      estructura_organizacional: ["", [Validators.required]],
      tipo_bodega: [0, [Validators.required]],
    });
  }

/**
 * Funcion utilizada para guardar la informacion que se carga en el grid
 */
  GuardarInformacion() {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    Swal.fire({
      title: "Esta seguro de realizar los cambios?",
      showDenyButton: true,
      confirmButtonText: "Guardar",
      denyButtonText: "Cancelar"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        let datosGuardar = this.FormularioDatos.getRawValue();

        switch (datosGuardar.tipo_bodega) {
          case 1:
            this.ModeloDatos.telefon1 = "0";
            this.ModeloDatos.tipocli = 1;
            break;
          case 2:
            this.ModeloDatos.telefon1 = "1";
            this.ModeloDatos.tipocli = 0;
            break;
          case 3:
            this.ModeloDatos.telefon1 = "1";
            this.ModeloDatos.tipocli = 1;
            break;
          default:
            this.ModeloDatos.telefon1 = "0";
            this.ModeloDatos.tipocli = 0;
            break;
        }

        this.ModeloDatos.codigo = datosGuardar.codigo;
        this.ModeloDatos.descrip = datosGuardar.descrip;
        this.ModeloDatos.nrocta = datosGuardar.estructura_organizacional;
        this.ModeloDatos.codtab = this.codtab;
        
        const objeto = this.ModeloDatos;

        if (this.pk_identificador == -1) {
          this.ServicioClienteHttp.Insertar(objeto).subscribe({
            next: (data) => {
              if (data.success) {
                this.alertas.MensajeExito(this.pagina);
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        } else {
          this.ServicioClienteHttp.Actualizar(this.pk_identificador, objeto).subscribe({
            next: (data) => {
              if (data.success) {
                let parametro = this.ServicioCrypt.encryptString(objeto.codtab + "||" + this.active_item)
                this.alertas.MensajeExito('/' + this.pagina + '/tg_departamento', "Registro Guardado Exitosamente", parametro);
                
              } else {
                this.alertas.MensajeError(data.message);
              }
            },
            error: (err) => {
              console.log(err.message)
            }
          })
        }

      }
    });
  }


  CargarSelectEstructura()
  {
    this.ServicioClienteHttp.SeteoRuta("EstructuraOrganizacional");
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          //let resultado: any[] = JSON.parse(data.result);
          //let resultado: any = data.result;
          this.OptionsEstructura = JSON.parse(data.result);
        }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
  }


    /**
   * Funcion que dirige a la pantalla para el nuevo registro
   */
    VolverPagina() {
      let parametro = this.ServicioCrypt.encryptString(this.codtab + "||" + this.active_item)
        this.router.navigate(['/' + this.pagina + '/tg_departamento', parametro]);
    } 
  
}
