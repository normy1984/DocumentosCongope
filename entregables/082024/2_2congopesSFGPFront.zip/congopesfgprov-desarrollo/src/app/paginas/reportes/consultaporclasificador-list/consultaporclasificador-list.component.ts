import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table'
import { configapp } from '@config/configapp';
import { Router } from '@angular/router';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { ListModule } from 'app/paginas/generico/list.module';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { CryptService } from 'app/servicios/generico/crypt.service';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { EditModule } from 'app/paginas/generico/edit.module';
import { formatDate } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { VisualizaPdfComponent } from 'app/paginas/generico/visualiza-pdf/visualiza-pdf.component';

import {MatRadioModule} from '@angular/material/radio';
import { _isNumberValue } from '@angular/cdk/coercion';
import { ParamSessionMo } from 'app/models/param-session';

@Component({
  selector: 'app-consultaporclasificador-list',
  templateUrl: './consultaporclasificador-list.component.html',
  standalone:true,
  imports: [EditModule, ListModule, MatRadioModule
  ]
})


export class ConsultaporclasificadorListComponent extends UnsubscribeOnDestroyAdapter
implements OnInit
{
  public ParamSessiones:ParamSessionMo =  JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}')
  private ServicioCrypt = inject(CryptService);
  public alertas = inject(AlertasSrvService);
  public pageSizeOptions:number[] = configapp.pageSizeOptions;
  public dataSource !:  MatTableDataSource<any>;
  public FormularioDatos!: UntypedFormGroup;
  public formBuild = inject(FormBuilder);
  public fechaAct = formatDate(new Date(), 'yyyy-MM-dd', 'en-US')
  public sUltimoNivel = "";
  public nTipoPresupuesto = 1;
  public nTotalAsigIni = 0;
  public ntotalreformas = 0;
  public ntotalcodificado = 0;
  public ntotalcertificado = 0;
  public ntotalcomprometido = 0;
  public ntotaldevengado = 0;
  public ntotalpagado = 0;
  public ntotalpor_comprometer = 0;
  public ntotalpor_devengar = 0;
  public ntotalpor_pagar = 0;

  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

/**
 * PARAMETRIZACION DE LAS RUTAS DONDE SE REDIRIGE LA LAGINA Y DE DONDE SE CARGA EL API */
public pagina:string = "Reportes/ConsultaPorClasificador";
public rutaapi:string = "";

/**COLUMNAS MOSTRADAS */
public displayedColumns:string[] = [
  "clasificador",
  "categoria",
  "nom_cue",
  "asig_ini",
  "reformas",
  "codificado",
  "certificado",
  "comprometido",
  "devengado",
  "pagado",
  "por_comprometer",
  "por_devengar",
  "por_pagar",
  "porcen_eje",
];

public nivel: number = 0;
constructor(
    private router: Router,
    public dialog: MatDialog,
    private ServicioClienteHttp: ClienthttpCongopeService,
  ) {
    super();
  }

  ngOnInit() {
    const ffecha = new Date(this.fechaAct);
    if(this.ParamSessiones.anio < ffecha.getFullYear())
    {
      this.fechaAct = this.ParamSessiones.anio + "-12-31";
    }

    this.FormularioDatos = this.CrearFormulario();
    this.FiltrarAsociacion();
  }

  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      Txtfecha: this.fechaAct,
      TxtBuscar:"",
    });
  }
  /**
 * Funcion que genera la lista de datos para los grids de las pantallas
 */
  public resultado: any[] = [];
  CargarGrid() {
    this.ServicioClienteHttp.Obtener_Lista().subscribe({
      next: (data) => {
        if (data.success) {
          this.resultado = JSON.parse(data.result);
          this.nTotalAsigIni = this.resultado[0].totalasig_ini;

          this.ntotalreformas = this.resultado[0].totalreformas;
          this.ntotalcodificado = this.resultado[0].totalcodificado;
          this.ntotalcertificado = this.resultado[0].totalcertificado;
          this.ntotalcomprometido = this.resultado[0].totalcomprometido;
          this.ntotaldevengado = this.resultado[0].totaldevengado;
          this.ntotalpagado = this.resultado[0].totalapagado;
          this.ntotalpor_comprometer = this.resultado[0].totalpor_comprometer;
          this.ntotalpor_devengar = this.resultado[0].totalpor_devengar;
          this.ntotalpor_pagar = this.resultado[0].totalpor_pagar;



          this.dataSource = new MatTableDataSource(this.resultado);
          this.dataSource.sort = this.sort;
      }
        else {
          this.alertas.MensajeError(data.message);
        }

      },
      error: (err) => {
        console.log(err.message)
      }
    })
    //
  }

/**
 * Funcion llamada para la exportacion a excel del formulario
 */
  ExportarExcel() {
    // key name with space add in brackets
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'CLASIFICADOR': x.clasificador,
        'CATEGORÍA': x.categoria,
        'NOMBRE PARTIDA': x.nom_cue,
        'ASIG. INICIAL': x.asig_ini,
        'REFORMAS': x.reformas,
        'CODIFICADO': x.codificado,
        'CERTIFICADO': x.certificado,
        'COMPROMETIDO': x.comprometido,
        'DEVENGADO': x.devengado,
        'PAGADO': x.pagado,
        'POR COMPROM.': x.por_comprometer,
        'POR DEVENGAR': x.por_devengar,
        'POR PAGAR': x.por_pagar,
        'PORCEN. EJEC.': x.porcen_eje,
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

  /**
   *
   * @param event Funcion que realiza los fitrados de los grids
   */

  FiltrarRegistros(event: Event) {
    /*
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
      */
  }


  FiltrarAsociacion() {
    const nTipoPresu = this.nTipoPresupuesto;
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const sPartida = this.FormularioDatos.get('TxtBuscar')?.value;

    this.rutaapi = "ConsultaPorClasificador?sFechaHasta=" + sFechaHasta + "&nTipoPresu=" + nTipoPresu +"&sClasificador=" + sPartida +" ";
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    console.log(this.ServicioClienteHttp.SeteoRuta(this.rutaapi));
    this.CargarGrid();
  }

  FiltroAutocomplete(opcion: string): void {
    let filterValue = '';
  }


  //RERPORTE
  ImprimirReporte(): void {
    const sFechaHasta = this.FormularioDatos.get('Txtfecha')?.value;
    const sPartida = this.FormularioDatos.get('TxtBuscar')?.value;

    const DatosPdf: ObjetoPdf = new ObjetoPdf();
    DatosPdf.tipo_reporte = "RPT223_CLASIFICADOR";
    DatosPdf.param1 = sFechaHasta;
    DatosPdf.param2 = this.nTipoPresupuesto.toString();
    DatosPdf.param3 = sPartida;
    const dialogRef = this.dialog.open(VisualizaPdfComponent, {
      data: {
        DatosPdf
      },
      width: '95%',
      height: '100%'
    });

  }

  radioChangeHandler(value: any){
    this.nTipoPresupuesto = value;
    this.FormularioDatos.patchValue({
      TxtBuscar: "",
    });
 }



}


