import { Page404Component } from "app/authentication/page404/page404.component";
import { Route } from "@angular/router";
import { CedulapresupuestariaListComponent } from "./cedulapresupuestaria-list/cedulapresupuestaria-list.component";
import { VersaldopartidaListComponent } from "./versaldopartida-list/versaldopartida-list.component";
import { VerasociacioncontabilidadpresupuestoListComponent } from "./verasociacioncontabilidadpresupuesto-list/verasociacioncontabilidadpresupuesto-list.component";
import { EjecucionpresupuestariaListComponent } from "./ejecucionpresupuestaria-list/ejecucionpresupuestaria-list.component";
import { MovimientoporpartidaListComponent } from "./movimientoporpartida-list/movimientoporpartida-list.component";
import { MovimientosCompromisoListComponent } from "./movimientosCompromiso/movimientos-compromiso-list/movimientos-compromiso-list.component";
import { ConsultaporclasificadorListComponent } from "./consultaporclasificador-list/consultaporclasificador-list.component";
import { CertificacionCompromisoNoUtilizadosComponent } from "./certificacion-compromiso-no-utilizados/certificacion-compromiso-no-utilizados.component";
import { ReportePivotComponent } from "./reporte-pivot/reporte-pivot.component";
import { CedulagastosgrupoListComponent } from "./cedulagastosgrupo-list/cedulagastosgrupo-list.component";
import { CertificacionCompromisoArrastreComponent } from "./certificacion-compromiso-arrastre/certificacion-compromiso-arrastre.component";
export const REPORTES_ROUTE: Route[] = [
    {
      path: "",
      redirectTo: "dashboard1",
      pathMatch: "full",
    },
    {
      path: "CedulaPresupuestaria",
      component: CedulapresupuestariaListComponent,
    },
    {
      path: "VerSaldoPartida",
      component: VersaldopartidaListComponent,
    },
    {
      path: "VerAsociacionContabilidadPresupuesto",
      component: VerasociacioncontabilidadpresupuestoListComponent,
    },
    {
      path: "EjecucionPresupuestaria",
      component: EjecucionpresupuestariaListComponent,
    },
    {
      path: "MovimientosporPartida",
      component: MovimientoporpartidaListComponent,
    },
    {
      path: "MovimientosporCompromiso",
      component: MovimientosCompromisoListComponent,
    },
    {
      path: "ConsultaPorClasificador",
      component: ConsultaporclasificadorListComponent ,
    },
	{
      path: "Certificadossinutilizar",
      component: CertificacionCompromisoNoUtilizadosComponent,
    },
    {
      path: "Compromisossinutilizar",
      component: CertificacionCompromisoNoUtilizadosComponent,
    },
    {
      path: "ReporteGenerico",
      component: ReportePivotComponent,
    },
    {
      path: "CeduladeGastosporGrupo",
      component: CedulagastosgrupoListComponent,
    },
    {
      path: "Certificacionesdearrastre",
      component: CertificacionCompromisoArrastreComponent,
    },

    {
      path: "Compromisosdearrastre",
      component: CertificacionCompromisoArrastreComponent,
    },
    { path: "**", component: Page404Component },

  ];

