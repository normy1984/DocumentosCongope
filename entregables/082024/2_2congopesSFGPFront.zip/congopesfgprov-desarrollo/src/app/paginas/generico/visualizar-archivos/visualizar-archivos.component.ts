import { Component, Inject, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogClose, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { EditModule } from '../edit.module';

@Component({
  selector: 'app-visualizar-archivos',
  standalone: true,
  imports: [EditModule,MatIconModule,MatDialogClose],
  templateUrl: './visualizar-archivos.component.html'
})
export class VisualizarArchivosComponent {


  mostrarError: boolean = false;

  private ServicioClienteHttp = inject(ClienthttpCongopeService);

  public rutaapi: string = "Upload/VerArchivo";

  pdfSrc!: SafeResourceUrl;

  objetoArchivo!: any;

  titulo_reporte = "";

  blobUrl !: any;



  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<VisualizarArchivosComponent>,
    private sanitizer: DomSanitizer) {
      
    this.objetoArchivo = this.data.fila;
    this.titulo_reporte = this.objetoArchivo.dcm_archivo_ori;
    this.GenerarArchivo();
    
  }

/**
   * FUNCION QUE CREA EL OBJETO A PARTIR DEL OBJETO BASE 64 QUE RETORNA EL SERVICIO DE IMPRESION
   */
GenerarArchivo() { 

  /// ESTRUCTURA PARA ENVIO AL API
  interface DatosArchivo {
    codsistema: number;
    nombrearchivo: string;
  }

  // Ejemplo de uso:
  const datosArchivo: DatosArchivo = {
    codsistema: this.objetoArchivo.dcm_modulo,
    nombrearchivo: this.objetoArchivo.dcm_archivo
  };
 
  this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
  this.ServicioClienteHttp.Insertar(datosArchivo).subscribe({
    next: (data) => {
      if (data.success) {
        const base64Pdf = data.result;
        //const ContentType = data.ContentType;
        const blob = this.base64toBlob(base64Pdf, this.objetoArchivo.dcm_contenttype, this.objetoArchivo.dcm_archivo_ori);
        this.blobUrl = URL.createObjectURL(blob);
        this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(this.blobUrl);
        
      } else {
        console.log(data.message);
      }
    },
    error: (err) => {
      console.log(err.message)
    }
  })
}


  /**
   * Funcion que retorna un blob a partir de un string en base 64
   * @param base64String 
   * @param contentType 
   * @returns 
   */
  base64toBlob(base64String: string, contentType: string, fileName: string): Blob {
    const byteCharacters = atob(base64String);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    // Crear un Blob a partir de los bloques de bytes y asignarle el nombre del archivo
    return new Blob(byteArrays, { type: contentType });
  }

/**
 * Funcion creada para descargar un archivo
 */
  descargarArchivo(): void {
      const a = document.createElement('a');
      a.href = this.blobUrl;
      a.download = this.objetoArchivo.dcm_archivo_ori; // Nombre del archivo
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
  }
    

}