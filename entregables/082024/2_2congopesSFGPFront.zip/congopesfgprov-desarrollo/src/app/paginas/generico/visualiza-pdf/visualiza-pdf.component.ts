import { Component, Inject, inject } from '@angular/core';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { MAT_DIALOG_DATA, MatDialogClose, MatDialogRef } from '@angular/material/dialog';
import { ObjetoPdf } from 'app/models/objeto-pdf';
import { EditModule } from '../edit.module';

@Component({
  selector: 'app-visualiza-pdf',
  standalone: true,
  imports: [EditModule, MatIconModule, MatDialogClose],
  templateUrl: './visualiza-pdf.component.html'
})
export class VisualizaPdfComponent {

  private ServicioClienteHttp = inject(ClienthttpCongopeService);

  public rutaapi: string = "Pdf";

  pdfSrc!: SafeResourceUrl;

  objetoPdf!: any;

  blobUrl!: SafeResourceUrl;

  titulo_reporte = "";

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ObjetoPdf,
    public dialogRef: MatDialogRef<VisualizaPdfComponent>,
    private sanitizer: DomSanitizer) {

    this.objetoPdf = data;
    this.titulo_reporte = this.objetoPdf.DatosPdf.tipo_reporte;
    this.printPdf();
  }

  /**
   * FUNCION QUE CREA EL OBJETO A PARTIR DEL OBJETO BASE 64 QUE RETORNA EL SERVICIO DE IMPRESION
   */
  printPdf() {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);
    this.ServicioClienteHttp.Insertar(this.objetoPdf.DatosPdf, true).subscribe({
      next: (data) => {
        if (data.success) {
          const base64Pdf = data.result;
          const blob = this.base64toBlob(base64Pdf, 'application/pdf');
          const blobUrl = URL.createObjectURL(blob);
          this.pdfSrc = this.sanitizer.bypassSecurityTrustResourceUrl(blobUrl);
          this.blobUrl = this.sanitizer.bypassSecurityTrustUrl(blobUrl);
        } else {
          console.log(data.message);
        }
      },
      error: (err) => {
        console.log(err.message);
      }
    });
  }

  /**
   * Funcion que retorna un blob a partir de un string en base 64
   * @param base64String 
   * @param contentType 
   * @returns 
   */
  base64toBlob(base64String: string, contentType: string): Blob {
    const byteCharacters = atob(base64String);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);

      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, { type: contentType });
  }

  /**
   * Funcion creada para descargar los archivos adjuntos a un documento
   */
  descargarArchivo(): void {
    const a = document.createElement('a');
    a.href = this.blobUrl.toString();
    a.download = this.objetoPdf.DatosPdf.tipo_reporte+ ".pdf"; // Nombre del archivo
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}
