import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { MatButtonModule } from "@angular/material/button";
import { MatCardModule } from "@angular/material/card";
import { MatIconModule } from "@angular/material/icon";
import { MatFormField, MatInputModule, MatLabel } from "@angular/material/input";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort, MatSortModule } from "@angular/material/sort";
import { MatTableModule } from "@angular/material/table";
import { MatToolbarModule } from "@angular/material/toolbar";
import { BreadcrumbComponent } from "@shared/components/breadcrumb/breadcrumb.component";
import { MatTooltipModule } from '@angular/material/tooltip';

@NgModule({
  declarations: [],
  imports: [
    BreadcrumbComponent,
    CommonModule,
    MatInputModule,
    MatCardModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatPaginator,
    MatSort,
    MatToolbarModule,
    MatFormField,
    MatLabel,
    MatTooltipModule,
    MatSortModule
    
  ],
  exports:[
    BreadcrumbComponent,
    CommonModule,
    MatInputModule,
    MatCardModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatPaginator,
    MatSort,
    MatToolbarModule,
    MatFormField,
    MatLabel,
    MatTooltipModule,
    MatSortModule
    ]
})
export class ListModule { }
