import { Route } from "@angular/router";
import { Page404Component } from "../../authentication/page404/page404.component";
import { FuentesfinanciamientoListComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-list/fuentesfinanciamiento-list.component";
import { FuentesfinanciamientoEditComponent } from "./fuentesfinanciamiento/fuentesfinanciamiento-edit/fuentesfinanciamiento-edit.component";


export const CATALOGOS_ROUTE: Route[] = [
  {
    path: "",
    redirectTo: "dashboard1",
    pathMatch: "full",
  },
  {
    path: "FuentesFinanciamiento",
    component: FuentesfinanciamientoListComponent,
  },
    {
    path: "FuentesFinanciamiento/:ffn_id",
    component: FuentesfinanciamientoEditComponent,
  },
  
  { path: "**", component: Page404Component },
  
];

