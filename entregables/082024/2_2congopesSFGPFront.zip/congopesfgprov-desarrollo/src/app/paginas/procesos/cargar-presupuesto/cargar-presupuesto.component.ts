import { Component, OnInit } from '@angular/core';
import { FormBuilder, UntypedFormGroup } from '@angular/forms';
import { TableElement, TableExportUtil, UnsubscribeOnDestroyAdapter } from '@shared';
import { ListModule } from 'app/paginas/generico/list.module';
import { FileUploadComponent } from '@shared/components/file-upload/file-upload.component';
import { EditModule } from 'app/paginas/generico/edit.module';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import * as XLSX from 'xlsx';
import { ClienthttpCongopeService } from 'app/servicios/generico/clienthttp-congope.service';
import Swal from 'sweetalert2';
import { MatTableDataSource } from '@angular/material/table';
import { ParamSessionMo } from 'app/models/param-session';
import { CargarPresupuestoMo } from 'app/models/procesos/cargar-presupuesto-mo';


@Component({
  selector: 'app-cargar-presupuesto',
  standalone: true,
  imports: [ListModule, EditModule, FileUploadComponent],
  templateUrl: './cargar-presupuesto.component.html',
  styleUrl: './cargar-presupuesto.component.scss'
})
export class CargarPresupuestoComponent
  extends UnsubscribeOnDestroyAdapter
  implements OnInit {
  public FormularioDatos!: UntypedFormGroup;
  public VarSesion: ParamSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  public dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  public OcultarError: boolean = true;
  public OcultarOk: boolean = true;
  public OcultarAreaTrabajo: boolean = true;
  public OcultarMensajeImpedimento: boolean = true;
  
  ///CABECERA QUE DEBE TENER EL ARCHIVO EXCEL
  private CabeceraArchivo: string[] = ["PARTIDA PRESUPUESTARIA", "NOMBRE", "INGRESOS", "GASTOS", "TIPO"];
  public displayedColumns: string[] = [];

  private rutaapi = "CargarPresupuesto";
  private resultado: any[] = [];

  /*
    * COLUMNAS A MOSTRAR EN EL LISTADO PRINCIPAL
    */

  constructor(
    private formBuild: FormBuilder,
    private alertas: AlertasSrvService,
    private ServicioClienteHttp: ClienthttpCongopeService,

  ) {
    super();
    this.FormularioDatos = this.CrearFormulario();
  }



  ngOnInit() {
    this.ValidarCargaProforma();
  }

  /**
   * Funcion creada para la creacion del formulario de inicio
   * @returns 
   */
  CrearFormulario(): UntypedFormGroup {
    return this.formBuild.group({
      uploadFile: [''],
    });
  }

  /**
   * Valida que unicamente se cargue el archivo en formato excel
   * @param event 
   */

  onFileChange(event: any) {
    this.resultado = [];
    this.dataSource = new MatTableDataSource(this.resultado);
    this.OcultarError = true;
    this.OcultarOk = true;
    const file = event.target.files[0];
    if (file) {
      const validImageTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
      if (!validImageTypes.includes(file.type)) {
        this.alertas.MensajeAlerta('Por favor seleccione un archivo excel (.xlsx)');
        this.FormularioDatos.get('uploadFile')?.setValue(''); // Clear the form control value
        return;
      }

      const reader = new FileReader();
      reader.onload = (e: any) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const headers = this.ObtenerCabecerasExcel(worksheet);
        if (!this.ArreglosIguales(headers, this.CabeceraArchivo)) {
          this.alertas.MensajeAlerta('El archivo que esta cargando no tiene el formato adecuado. ' + this.CabeceraArchivo.toString());
          this.FormularioDatos.get('uploadFile')?.setValue(''); // Clear the form control value
          return;
        }
        // Aquí puedes hacer algo con las cabeceras, como almacenarlas en una variable o usarlas en tu aplicación
      };
      reader.readAsArrayBuffer(file);
    }
  }

  /**
   * Funcion para obtener las cabeceras del excel
   * @param sheet 
   * @returns 
   */
  ObtenerCabecerasExcel(sheet: XLSX.WorkSheet) {
    const headers: string[] = [];
    const range = XLSX.utils.decode_range(sheet['!ref'] as string);
    const firstRow = range.s.r; // Primera fila
    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = { c: col, r: firstRow };
      const cellRef = XLSX.utils.encode_cell(cellAddress);
      const cell = sheet[cellRef];
      const header = cell && cell.v ? cell.v : `UNKNOWN ${col}`;
      headers.push(header);
    }
    return headers;
  }

  /**
   * Compara si dos arreglos son iguales
   * @param arr1 
   * @param arr2 
   * @returns 
   */
  ArreglosIguales(arr1: string[], arr2: string[]): boolean {
    if (arr1.length !== arr2.length) return false;
    for (let i = 0; i < arr1.length; i++) {
      if (arr1[i] !== arr2[i]) return false;
    }
    return true;
  }


  /**
   * Funcion que realiza el procesamiento del archivo excel
   */

  ProcesarExcel(): void {

    this.ServicioClienteHttp.SeteoRuta(this.rutaapi);

    const datosGuardar = this.FormularioDatos.getRawValue();
    // Convierto toda la informacion en un formData ya que este modelo de datos tiene un file
    const formData = new FormData();
    formData.append('file', datosGuardar.uploadFile);
    formData.append('anio', this.VarSesion.anio.toString());
    formData.append('codemp', this.VarSesion.codemp);

    this.ServicioClienteHttp.Insertar(formData, true).subscribe({
      next: (data) => {

        if (data.success) {

          this.resultado = data.result.result;
          this.dataSource = new MatTableDataSource(this.resultado);

          if (data.result.validado && this.DiferenciaIngresosGastos() === 0) {
            this.OcultarError = true;
            this.OcultarOk = false;
            this.displayedColumns = [...this.CabeceraArchivo.filter(column => column !== "TIPO")];
          } else if (data.result.validado && this.DiferenciaIngresosGastos() != 0) {
            this.OcultarError = false;
            this.OcultarOk = true;
            this.displayedColumns = [...this.CabeceraArchivo.filter(column => column !== "TIPO")];
          }
          else {
            this.OcultarError = false;
            this.OcultarOk = true;
            this.displayedColumns = [...this.CabeceraArchivo.filter(column => column !== "TIPO"), "OBSERVACION"];
          }

          const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = Swal.stopTimer;
              toast.onmouseleave = Swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            title: "Registros procesados"
          });
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }

    });
  }

  /**
   * Funcion que suma el total de los ingresos del archivo de excel
   * @returns 
   */
  TotalIngresos(): number {
      return this.resultado
      .map(transaccion => {
        const valor = parseFloat(transaccion.INGRESOS);
        return isNaN(valor) ? 0 : valor;
      })
      .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
  }

  /**
   * Funcion que suma el total de gastos del archivo de excel
   * @returns 
   */
  TotalGastos(): number {
    return this.resultado
    .map(transaccion => {
      const valor = parseFloat(transaccion.GASTOS);
      return isNaN(valor) ? 0 : valor;
    })
    .reduce((acumulado, valorActual) => acumulado + valorActual, 0);
  }

  /**
   * Funcion que devuelve la diferencia absoluta entre el total de ingresos y el total de gastos
   * @returns La diferencia absoluta entre ingresos y gastos
   */
  DiferenciaIngresosGastos(): number {

    const totalIngresos = this.TotalIngresos();
    const totalGastos = this.TotalGastos();
    return parseFloat(Math.abs(totalIngresos - totalGastos).toFixed(2));
  }


  /**
     * Función llamada para la exportación a Excel del formulario.
     */

  ExportarExcel() {
    const exportData: Partial<TableElement>[] =
      this.dataSource.filteredData.map((x) => ({
        'PARTIDA PRESUPUESTARIA': x.PARTIDA_PRESUPUESTARIA,
        'NOMBRE': x.NOMBRE,
        'INGRESOS': x.INGRESOS,
        'GASTOS': x.GASTOS,
        'TIPO': x.TIPO,
        'OBSERVACION': x.OBSERVACION.replace(/<br\s*\/?>/gi, '\n'),
      }));

    TableExportUtil.exportToExcel(exportData, 'excel');
  }

/**
 * Funcion para cargar el presupuesto una vez que ya se ha subido la informacion
 */
  CargarPresupuesto() {

    /**AQUI SE CARGA EL OBJETO A ENVIAR A LA BASE DE DATOS */
    const ModeloDatos: CargarPresupuestoMo[] = this.resultado.map(data => new CargarPresupuestoMo(data));
   
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/SubirProforma")
    this.ServicioClienteHttp.Insertar(ModeloDatos, true).subscribe({
      next: (data) => {

        if (data.success) {

          const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.onmouseenter = Swal.stopTimer;
              toast.onmouseleave = Swal.resumeTimer;
            }
          });
          Toast.fire({
            icon: "success",
            title: "Proforma cargada exitosamente..."
          });
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }

    });


  }

/**
 * Funcion que valida si el ejercicio actual aun puede subier su proforma presuspuestaria
 */
  ValidarCargaProforma()
  {
    this.ServicioClienteHttp.SeteoRuta(this.rutaapi + "/ValidarCargaProforma")
    this.ServicioClienteHttp.Insertar(this.VarSesion).subscribe({
      next: (data) => {
        if (data.success) {

          const TotalMovimientos:number = data.result[0].longitud;
          this.OcultarAreaTrabajo = (TotalMovimientos === 0) ? false: true;
          this.OcultarMensajeImpedimento = (TotalMovimientos === 0) ? true: false;
       
        } else {
          this.alertas.MensajeError(data.message);
        }
      },
      error: (err) => {
        console.log(err.message)
      }

    });

  }

/**
 * Funcion que valida si lo que me envia es un numero
 * @param value 
 * @returns 
 */
  isNumber(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
  }

}
