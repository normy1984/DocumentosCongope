export class CargaArchivoMo {
        public anio: number;
        public tipo_documento: string;
        public codigo_documento: number;
        public descripcion: string;
        public codsistema: number;
        constructor(datos: CargaArchivoMo) {
            {
                this.anio = datos.anio || 0;
                this.tipo_documento = datos.tipo_documento || '';
                this.descripcion = datos.descripcion || '';
                this.codigo_documento = datos.codigo_documento || 0;
                this.codsistema =  datos.codsistema || 0;
            }
        }
}
