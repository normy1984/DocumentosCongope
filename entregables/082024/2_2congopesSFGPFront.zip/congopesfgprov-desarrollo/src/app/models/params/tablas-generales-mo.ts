export class TablasGeneralesMo {
    public codemp: string;
    public codtab: number;
    public codigo: number;
    public ucodemp: string;
    public cedruc: string;
    public secuenc: number;
    public descrip: string;
    public telefon1: string;
    public direcci: string;
    public telefon2: string;
    public fax1: string;
    public fax2: string;
    public email1: string;
    public email2: string;
    public fecemi: string;
    public fecval: string;
    public vendedor: number;
    public tipocli: number;
    public formpag: number;
    public contacto: string;
    public ciudad: number;
    public zona: number;
    public sector: number;
    public cupocre1: number;
    public cupocre2: number;
    public empresa: number;
    public placa1: string;
    public placa2: string;
    public placa3: string;
    public placa4: string;
    public placa5: string;
    public placa6: string;
    public placa7: string;
    public placa8: string;
    public nrocta: string;
    public banco: string;
    public tipocta: number;
    public cuentadb: string;
    public cuentacr: string;
    public cuentaddb: string;
    public cuentadcr: string;
    public cuentagst: string;
    public cuentadevol: string;
    constructor(datos: TablasGeneralesMo) {
        {
            this.codemp = datos.codemp || '';
            this.codtab = datos.codtab || 0
            this.codigo = datos.codigo || 0
            this.ucodemp = datos.ucodemp || '';
            this.cedruc = datos.cedruc || '';
            this.secuenc = datos.secuenc || 0
            this.descrip = datos.descrip || '';
            this.telefon1 = datos.telefon1 || '';
            this.direcci = datos.direcci || '';
            this.telefon2 = datos.telefon2 || '';
            this.fax1 = datos.fax1 || '';
            this.fax2 = datos.fax2 || '';
            this.email1 = datos.email1 || '';
            this.email2 = datos.email2 || '';
            this.fecemi = datos.fecemi || '';
            this.fecval = datos.fecval || '';
            this.vendedor = datos.vendedor || 0
            this.tipocli = datos.tipocli || 0
            this.formpag = datos.formpag || 0
            this.contacto = datos.contacto || '';
            this.ciudad = datos.ciudad || 0
            this.zona = datos.zona || 0
            this.sector = datos.sector || 0
            this.cupocre1 = datos.cupocre1 || 0
            this.cupocre2 = datos.cupocre2 || 0
            this.empresa = datos.empresa || 0
            this.placa1 = datos.placa1 || '';
            this.placa2 = datos.placa2 || '';
            this.placa3 = datos.placa3 || '';
            this.placa4 = datos.placa4 || '';
            this.placa5 = datos.placa5 || '';
            this.placa6 = datos.placa6 || '';
            this.placa7 = datos.placa7 || '';
            this.placa8 = datos.placa8 || '';
            this.nrocta = datos.nrocta || '';
            this.banco = datos.banco || '';
            this.tipocta = datos.tipocta || 0
            this.cuentadb = datos.cuentadb || '';
            this.cuentacr = datos.cuentacr || '';
            this.cuentaddb = datos.cuentaddb || '';
            this.cuentadcr = datos.cuentadcr || '';
            this.cuentagst = datos.cuentagst || '';
            this.cuentadevol = datos.cuentadevol || '';

        }
    }
}
