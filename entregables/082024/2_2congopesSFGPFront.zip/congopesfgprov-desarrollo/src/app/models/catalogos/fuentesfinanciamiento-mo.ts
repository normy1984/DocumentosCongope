export class FuentesFinanciamientoMo {
    
    ffn_id:string;
    ffn_nombre:string;
    ffn_ctapago:string;
   
    constructor(datos: FuentesFinanciamientoMo) {
        {
            this.ffn_id = datos.ffn_id || '';
            this.ffn_nombre = datos.ffn_nombre || '';
            this.ffn_ctapago = datos.ffn_ctapago || '';       
        }
    }
}
