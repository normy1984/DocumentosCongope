import { ParamSessionMo } from "../param-session";

export class CertificacionCompromisoArrastreMo {
    sig_tip: string;
    acu_tip: number;
    arrastre: number;
    observacion: string;
    paramSessionMo: ParamSessionMo;
    constructor(){
      this.sig_tip = "";
      this.acu_tip = 0;
      this.arrastre = 0;
      this.observacion = "";
      this.paramSessionMo = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
      }
}
