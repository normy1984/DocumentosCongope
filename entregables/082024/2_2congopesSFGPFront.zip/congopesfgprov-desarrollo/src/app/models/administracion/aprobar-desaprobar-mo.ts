import { ParamSessionMo } from "../param-session";

export class ConsultarAprobarDesaprobarMo {

    public SigTip:string;
    public VarSesion: ParamSessionMo; 
        constructor() {
            {
                this.SigTip = '';
                this.VarSesion = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
            }
        }
    }

    export class VariablesAprobarDesaprobarMo {
        aprobar:number;
        desaprobar:number;
        constructor() {
            {
                this.aprobar = 0;
                this.desaprobar = 0;
            }
        }
    }
        