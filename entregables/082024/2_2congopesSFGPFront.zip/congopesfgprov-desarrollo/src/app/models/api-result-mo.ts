export interface ApiResultMo {
    success:boolean,
    message:string,
    result:any
}
