import { ParamSessionMo } from "./param-session";

export class ObjetoPdf {
  tipo_reporte: string;
  param1: string;
  param2: string;
  param3: string;
  param4: string;
  param5: string;
  param6: string;
  VarSesion: ParamSessionMo;

  constructor(){
    this.tipo_reporte = "";
    this.param1 = "";
    this.param2 = "";
    this.param3 = "";
    this.param4 = "";
    this.param5 = "";
    this.param6 = "";
    this.VarSesion = JSON.parse(sessionStorage.getItem('ParamSesiones')?.toString() ?? '{}');
  }

}
