import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize, mergeMap } from 'rxjs/operators';
import { ApiResultMo } from 'app/models/api-result-mo';
import { configapp } from '@config/configapp';
import { AlertasSrvService } from 'app/servicios/generico/alertas-srv.service';
import { LoadingService } from '@core/service/loading.service';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./forgot-password.component.scss'],
    standalone: true,
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        MatButtonModule,
        RouterLink,
    ],
})
export class ForgotPasswordComponent implements OnInit {
  authForm!: UntypedFormGroup;
  error:string = "";
  submitted = false;
  returnUrl!: string;
  TipoLoginLdap:boolean = true;

  private apiUrl: string = configapp.UrlServicios + 'login/RecuperarContrasena';
  private apiUrlValidaTipoIngreso: string = configapp.UrlServicios + 'login/ValidarTipoIngreso';
  
  constructor(
    private formBuilder: UntypedFormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private alertas : AlertasSrvService,
    private loadingService : LoadingService// Inyectar el servicio de carga
  ) {}

  ngOnInit() {
    this.authForm = this.formBuilder.group({
      email: [
        '',
        [Validators.required, Validators.email, Validators.minLength(5)],
      ],
      username: [
        '',
        [Validators.required, Validators.minLength(10)],
      ],
    });
    // get return url from route parameters or default to '/'

    this.ValidarIngreso().subscribe({
      next: (res: any) => {
        if(res.body.result===true)
          {   
            this.error = `El ingreso al sistema debe realizarlo de la siguiente forma:</br>
                          <strong>Usuario:</strong> Correo Institucional</br>
                          <strong>Contraseña:</strong> Contraseña del correo institucional</br>
                          Si olvidó su contraseña contactese con soporte al usuario`;
          }
        this.TipoLoginLdap = res.body.result;
       },
      error: (error: any) => {
        
        this.error = error;
      }
    });
  


    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  get f() {
    return this.authForm.controls;
  }

  onSubmit() {
    this.error = '';
    this.submitted = true;
    // stop here if form is invalid
    if (this.authForm.invalid) {
      this.error = 'Usuario o Contraseña Inválido!';
      return;
    } else {
      this.login(this.f['username'].value, this.f['email'].value).subscribe({
        next: (res: any) => {
          if (res && res.body && res.body.success === true) {
            this.alertas.MensajeConTimer(res.body.message,true);
            this.router.navigate(['/authentication/signin']);
          } else {
            this.error = res.body.message;
          }
        },
        error: (error: any) => {
          
          this.error = error;
        }
      });
    }
  }

  /**
   * Funcion que realiza el envio de datos para resetear la contraseña
   * @param username 
   * @param email 
   * @returns 
   */
  login(username: string, email: string): Observable<HttpResponse<any>> {
    const credentials = { login: username, contrasena: email };
    this.loadingService.show(); // Mostrar el servicio de carga
    return this.http.post<ApiResultMo>(this.apiUrl, credentials).pipe(
      mergeMap((data) => {
        if (data.success) {
          return new Observable<HttpResponse<any>>(observer => {
            observer.next(new HttpResponse({ body: data }));
            observer.complete();
          });
        } else {
          return throwError(() => new Error(data.message));
        }
        
      }),
      catchError((error) => {
        console.error('Login error:', error.message);
        return throwError(() => new Error(error.message));
      }),
      finalize(() => this.loadingService.hide())
    );
  }


  ValidarIngreso(): Observable<HttpResponse<any>> {
    return this.http.get<ApiResultMo>(this.apiUrlValidaTipoIngreso).pipe(
      mergeMap((data) => {
        if (data.success) {
          return new Observable<HttpResponse<any>>(observer => {
            observer.next(new HttpResponse({ body: data }));
            observer.complete();
          });
        } else {
          return throwError(() => new Error(data.message));
        }
        
      }),
      catchError((error) => {
        console.error('Login error:', error.message);
        return throwError(() => new Error(error.message));
      })
    );
  }
}
