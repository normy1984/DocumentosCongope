import { Injectable } from '@angular/core';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AlertasSrvService {

  constructor(private router:Router) { }
/**
 * Funcion generica a traves de la cual se realiza la navegacion entre pantallas
 * @param ruta 
 */
PaginaNavegar(ruta:string){
  this.router.navigate(["/"+ruta]);
}

/**
 * Funcion para disparar un mensaje de error generico, recibe como parametro el error
 * @param error 
 */
MensajeError(error:string){
  Swal.fire({
    text: "Error: " + error,
    icon: "error"
  });
}


/**
 * Mensaje de exito 
 * @param ruta 
 * @param mensaje 
 */
MensajeExito(ruta:string, mensaje?:string, params?:string){
  
  let LabelMensaje = "Registro guardado exitosamente!";

  if(mensaje)
    {
      LabelMensaje = mensaje;
    }
  if(params)
      {
        this.router.navigate(["/"+ruta,params]);
      }  
  else{
    this.router.navigate(["/"+ruta]);
  }
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    }
  });
  Toast.fire({
    icon: "success",
    title: LabelMensaje
  });
}

/**
* 
* @param mensaje Mensaje de alert
*/
MensajeAlerta(mensaje:string)
{
  Swal.fire({
    text: mensaje,
    icon: "info"
  });
}


MensajeConTimer(mensaje:string, exito:boolean)
{

  const icono = exito ? 'success' : 'warning';
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    }
  });
  Toast.fire({
    icon: icono,
    title: mensaje
  });
}

}

