import { Injectable } from '@angular/core';
import { configapp } from '@config/configapp';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class CryptService extends UnsubscribeOnDestroyAdapter
{

  secretKey:string=configapp.secretKeyCrypt;

  encryptString(text: string): string {
    return CryptoJS.AES.encrypt(text, this.secretKey).toString();
  }

  decryptString(ciphertext: string): string {
    const bytes = CryptoJS.AES.decrypt(ciphertext, this.secretKey);
    return bytes.toString(CryptoJS.enc.Utf8);
  }
}
