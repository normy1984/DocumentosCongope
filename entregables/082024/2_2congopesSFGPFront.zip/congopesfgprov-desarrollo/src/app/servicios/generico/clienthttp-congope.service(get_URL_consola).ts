import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { UnsubscribeOnDestroyAdapter } from '@shared';
import { ApiResultMo } from 'app/models/api-result-mo';
import { configapp } from '@config/configapp';

import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ClienthttpCongopeService extends UnsubscribeOnDestroyAdapter {

  private http = inject(HttpClient);
  public apiUrl: string = configapp.apiUrl;

  constructor(private httpClient: HttpClient) {
    super();
  }

  SeteoRuta(rutaApi: string) {
    this.apiUrl = configapp.apiUrl + rutaApi;
  }

  private logUrl(url: string): void {
    console.log('URL de la solicitud:', url);
  }

  private interceptarSolicitud<T>(observable: Observable<T>): Observable<T> {
    return observable.pipe(
      tap(() => this.logUrl(this.apiUrl)) // Ignorar el parámetro _
    );
  }

  Obtener_Lista() {
    return this.interceptarSolicitud(this.http.get<ApiResultMo>(this.apiUrl));
  }

  Obtener_x_Codigo(parametro: any) {
    return this.interceptarSolicitud(this.http.get<ApiResultMo>(`${this.apiUrl}/${parametro}`));
  }

  Insertar(objeto: any) {
    return this.interceptarSolicitud(this.http.post<ApiResultMo>(this.apiUrl, objeto));
  }

  Actualizar(codigo: any, objeto: any) {
    return this.interceptarSolicitud(this.http.put<ApiResultMo>(`${this.apiUrl}/${codigo}`, objeto));
  }

  Eliminar(codigo: any) {
    return this.interceptarSolicitud(this.http.delete<ApiResultMo>(`${this.apiUrl}/${codigo}`));
  }
}