import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiResultMo } from 'app/models/api-result-mo';
import { configapp } from '@config/configapp';
import { Observable, finalize } from 'rxjs';
import { LoadingService } from '@core/service/loading.service';


@Injectable({
  providedIn: 'root'
})
export class ClienthttpCongopeService 
{

  private http = inject(HttpClient);
  private loadingService = inject(LoadingService); // Inyectar el servicio de carga
  public apiUrl: string = configapp.apiUrl;


  SeteoRuta(rutaApi: string)
  {
    this.apiUrl = configapp.apiUrl + rutaApi;
  }
  /**
   * 
   * @returns Funcion para obtener el listado de datos para la construccion de un DataGrid
   */
  Obtener_Lista(Cargando?: boolean): Observable<ApiResultMo> {
    if (Cargando) {
      this.loadingService.show(); // Mostrar el servicio de carga
      return this.http.get<ApiResultMo>(this.apiUrl).pipe(
        finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
      );
    } else {
      return this.http.get<ApiResultMo>(this.apiUrl);
    }
  }
/**
   * Funcion para obtener la informacion con un parametro especifico
   * @param sigla 
   * @returns 
   */
Obtener_x_Codigo(parametro: any, Cargando?: boolean): Observable<ApiResultMo> {
  if (Cargando) {
    this.loadingService.show(); // Mostrar el servicio de carga
    return this.http.get<ApiResultMo>(`${this.apiUrl}/${parametro}`).pipe(
      finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
    );
  } else {
    return this.http.get<ApiResultMo>(`${this.apiUrl}/${parametro}`);
  }
}
 
  /**
   * Funcion que envia los parametros para Insertar un nuevo registro
   * @param objeto 
   * @returns 
   */
  
  Insertar(objeto: any, Cargando?: boolean): Observable<ApiResultMo> {
    if (Cargando) {
      this.loadingService.show(); // Mostrar el servicio de carga
      return this.http.post<ApiResultMo>(this.apiUrl, objeto).pipe(
        finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
      );
    } else {
      return this.http.post<ApiResultMo>(this.apiUrl, objeto);
    }
  }

  /**
   * Funcion que actualiza los registros
   * @param sigla 
   * @param objeto 
   * @returns 
   */
  Actualizar(codigo: any, objeto?: any, Cargando?: boolean): Observable<ApiResultMo> {
    if (Cargando) {
      this.loadingService.show(); // Mostrar el servicio de carga
      const body = objeto || {}; // Proporcionar un cuerpo vacío si objeto no está definido
      return this.http.put<ApiResultMo>(`${this.apiUrl}/${codigo}`, body).pipe(
        finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
      );
    } else {
      const body = objeto || {}; // Proporcionar un cuerpo vacío si objeto no está definido
      return this.http.put<ApiResultMo>(`${this.apiUrl}/${codigo}`, body);
    }
  }

/**
 * Funcion para elminar los registros de la base
 * @param codigo 
 * @returns 
 */
Eliminar(codigo: any, Cargando?: boolean): Observable<ApiResultMo> {
    if (Cargando) {
      this.loadingService.show(); // Mostrar el servicio de carga
      return this.http.delete<ApiResultMo>(`${this.apiUrl}/${codigo}`).pipe(
        finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
      );
    } else {
      return this.http.delete<ApiResultMo>(`${this.apiUrl}/${codigo}`);
    }
  }

  /**
   * Funcion para eliminar el registro con un objeto que contiene datos
   * @param codigo 
   * @param objeto 
   * @returns 
   */
   

    EliminarParametros(codigo: any, objeto: any, Cargando?: boolean): Observable<ApiResultMo> {
      if (Cargando) {
        this.loadingService.show(); // Mostrar el servicio de carga
        return this.http.delete<ApiResultMo>(`${this.apiUrl}/${codigo}`, { body: objeto }).pipe(
          finalize(() => this.loadingService.hide()) // Ocultar el servicio de carga cuando la solicitud HTTP se complete
        );
      } else {
        return this.http.delete<ApiResultMo>(`${this.apiUrl}/${codigo}`, { body: objeto });
      }
    }
}
