﻿using Congope.Empresas.BussinessLogic.Administracion;
using Congope.Empresas.Models.Administracion;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Administracion
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AprobarDesaprobarController : Controller
    {
        /// <summary>
        /// Accion de aprobar o desaprobar los diferentes tipos de menu
        /// </summary>
        /// <param name="oAprobarDesaprobarMo"></param>
        /// <returns></returns>
        [HttpPost]
        public dynamic AprobarDesaprobar(AprobarDesaprobarMo oAprobarDesaprobarMo)
        {
            return AprobarDesaprobarBL.AprobarDesaprobar(oAprobarDesaprobarMo);
        }

    }
}
