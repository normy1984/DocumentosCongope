﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class CertificacionCompromisoNoUtilizadosController : Controller
    {
        [HttpPost]

        public dynamic CertificacionesCompromisosNoUtilizadas(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNoUtilizadosMo)
        {
            return CertificacionCompromisoNoUtilizadosBL.CertificacionesCompromisosNoUtilizadas(ingresoCertificacionCompromisoNoUtilizadosMo);
        }

    }
}
