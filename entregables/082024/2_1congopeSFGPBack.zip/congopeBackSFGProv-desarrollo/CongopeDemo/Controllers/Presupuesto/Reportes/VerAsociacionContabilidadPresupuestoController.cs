﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class AsociacionContabilidadPresupuestoController
    {
        [HttpGet]
        public dynamic Get(int nanio, int nTipo_Presupuesto)
        {
            return AsociacionContabilidadPresupuestoBL.Listar(nanio, nTipo_Presupuesto);
        }
    }
}
