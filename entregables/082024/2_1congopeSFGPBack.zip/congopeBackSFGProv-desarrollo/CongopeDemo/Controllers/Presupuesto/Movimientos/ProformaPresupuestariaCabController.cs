﻿using Congope.Empresas.BussinessLogic.Presupuesto;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProformaPresupuestariaCabController
    {
        [HttpGet]
        public dynamic Get(string codemp, int anio, string sig_tip, decimal acu_tip)
        {
            return ProformaPresupuestariaCabBL.Listar(codemp, anio, sig_tip, acu_tip);
        }

        [HttpPut("Desaprobar/{acu_tip}")]
        public dynamic DesaprobarProformaPresupuestaria(decimal acu_tip)
        {
            return ProformaPresupuestariaCabBL.DesaprobarProformaPresupuestaria(acu_tip);
        }

        [HttpPut("Aprobar/{acu_tip}")]
        public dynamic AprobarProformaPresupuestaria(decimal acu_tip)
        {
            return ProformaPresupuestariaCabBL.AprobarProformaPresupuestaria(acu_tip);
        }
        //revisar
    }
}
