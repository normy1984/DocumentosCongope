﻿using Congope.Empresas.BussinessLogic.Presupuesto;
using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System;
using System.Diagnostics;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReformaController : ControllerBase
    {

        /// <summary>
        /// Listar movimientos presupuestarios (Reformas)
        /// </summary>
        /// <returns>Lista de movimientos</returns>
        [HttpGet("{codemp}/{anio}")]
        public dynamic Get(string codemp, int anio)        
        {
            // Movimiento presupuestario (Reforma)
            string tipo = "RE";

            return ReformaBL.ListarMovimientosPresupuestariosRE(codemp, anio, tipo);
        }

        /*/// <summary>
        /// LLamada para insertar o actualizar los compromisos
        /// </summary>
        /// <param name="compromisoCabeceraMo"></param>
        /// <returns></returns>
        [HttpPost("cabecera")]
        public dynamic InsertUpdateCabecera([FromBody] CompromisoCabeceraMo compromisoCabeceraMo)
        {
            return CompromisoBL.InsertarActualizar_CabeceraCompromiso(compromisoCabeceraMo);
        }
        /// <summary>
        /// Llamada para actualizar o insertar los detalles
        /// </summary>
        /// <param name="compromisoDetalleMoList"></param>
        /// <returns></returns>

        [HttpPost("detalle")]
        public dynamic InsertUpdateDetalle([FromBody] List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            return CompromisoBL.InsertarActualizar_DetalleCompromisoList(compromisoDetalleMoList);
        }*/

        /// <summary>
        /// Llamada para listar los detalles por codigo
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpGet("CertDetalle/{acu_tip}")]
        public dynamic ListarDetalleCompromisoCertificadoCodigo(string acu_tip)
        {
            return CompromisoBL.ListarDetalleCompromisoCertificadoCodigo(acu_tip);
        }

        /// <summary>
        /// Funcion para listar las cabeceras de las reformas
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpGet("ReformaCabecera/{acu_tip}")]
        public dynamic ListarCabeceraReformaCodigo(string acu_tip)
        {
            return ReformaBL.ListarCabeceraReformaCodigo(acu_tip);
        }

       /* /// <summary>
        /// Llamada para aprobar el Compromiso Presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        [HttpPut("Aprobar/{acu_tip}")]
        public dynamic AprobarCompromisoPresupuestario(string acu_tip)
        {
            return CompromisoBL.AprobarCompromisoPresupuestario(acu_tip);
        }


        /// <summary>
        /// Lllamada para desaprobar el compromiso presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        [HttpPut("Desaprobar/{acu_tip}")]
        public dynamic DesAprobarCompromisoPresupuestario(string acu_tip)
        {
            return CompromisoBL.DesAprobarCompromisoPresupuestario(acu_tip);
        }


        /// <summary>
        /// Llamada para anular el compromiso presupuestario
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        [HttpPut("Anular/{acu_tip}")]
        public dynamic AnularCompromisoPresupuestario(string acu_tip)
        {
            return CompromisoBL.AnularCompromisoPresupuestario(acu_tip);
        }

        /// <summary>
        /// Llamada para mostrar las certificaciones presupuestarias habilitadas
        /// </summary>
        /// <param name="sig_tip"></param>
        /// <returns></returns>

        [HttpGet("ListCertificacion/{sig_tip}")]
        public dynamic ListCertificacionesPresupuestariasHabilitadas(string sig_tip)
        {
            return CompromisoBL.ListCertificacionesPresupuestariasHabilitadas(sig_tip);
        }*/
    }
}
