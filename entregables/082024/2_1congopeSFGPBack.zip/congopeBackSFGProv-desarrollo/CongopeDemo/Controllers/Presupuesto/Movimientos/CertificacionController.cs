﻿using Congope.Empresas.BussinessLogic.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Movimientos
{

    [Route("api/[controller]")]
    [ApiController]

    public class CertificacionController : ControllerBase
    {


        /// <summary>
        /// Actualización de movimientos
        /// </summary>
        /// <param name="mov">Objeto movimiento a actualizar</param>
        /// <returns>Movimiento actualizado</returns>
        [HttpPost]
        public dynamic Post([FromBody] MovimientosPresupuestariosMO mov)
        {
            string sTipoAccion = "INSERT";
            return MovimientosPresupuestariosBL.InsertarActualizar_MovimientosPresupuestarios(sTipoAccion, mov);

        }


        /// <summary>
        /// Servicio para liquidar Certificaciones presupuestarias
        /// </summary>
        /// <param name="opCertificacion">Información de certificación y partida</param>
        /// <returns>Infomación de la certificación eliminada</returns>
        [HttpPost("Liquidacion")]
        public dynamic LiquidarCertificacionesPresupuestarias([FromBody] PartidaPresupuestariaDetMO opCertificacion, string accion)
        {
            return CertificacionBL.LiquidarCertificacionesPresupuestarias(opCertificacion, accion);
        }
    }
}
