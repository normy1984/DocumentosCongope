﻿using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto.Reportes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ListaBuscarPartidaController
    {
        [HttpGet]
        public dynamic Get(int nanio, int nTipoPresu, string sPartida = "")
        {
            return ListaBuscarPartidaBL.Listar(nanio, nTipoPresu, sPartida);
        }
    }
}
