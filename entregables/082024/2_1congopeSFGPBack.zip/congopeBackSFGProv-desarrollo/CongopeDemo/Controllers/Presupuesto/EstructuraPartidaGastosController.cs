﻿using Congope.Empresas.BussinessLogic;
using Congope.Empresas.BussinessLogic.Presupuesto;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Presupuesto
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstructuraPartidaGastosController : ControllerBase
    {
        /// <summary>
        /// Mètodo para listar la estructura de Partida de Gastos
        /// </summary>
        /// <returns> Lista de estructuras de Partidas de Gastos</returns>
        [HttpGet]
        public List<EstructuraPartidaGastosMO> Get(int anio, int tipo_presu)
        {
            return EstructuraPartidaGastosBL.Listar(anio, tipo_presu);
        }

        [HttpGet("detalle")]
        public dynamic listar_J(int anio, int tipopresu)
        {
            return EstructuraPartidaGastosBL.Listar_J(anio, tipopresu);
        }

        /// <summary>
        /// Método para modificar la estructura de Partida de Gastos
        /// </summary>
        /// <param name="emp">Información de partida de Gastos</param>
        /// <returns>true o False segun se haya realizado o no la actualización</returns>
        // PUT api/<ValuesController>/5
        [HttpPut("{emp}")]
        public bool Put([FromBody] EstructuraPartidaGastosMO emp)
        {
            return EstructuraPartidaGastosBL.Modificar(emp);
        }

    }
}
