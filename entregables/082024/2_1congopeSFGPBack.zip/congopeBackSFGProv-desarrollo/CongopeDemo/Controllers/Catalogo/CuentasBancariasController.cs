﻿using Congope.Empresas.BussinessLogic.Catalogo;
using Congope.Empresas.BussinessLogic.Parametrizacion;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Congope.Empresas.Controllers.Catalogo
{
    [Route("api/[controller]")]
    [ApiController]
    public class CuentasBancariasController : Controller
    {
        /// <summary>
        /// Funcion Get que retorna la informacion de las cuentas bancarias habilitadas para la empresa y el año seleccionado
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public dynamic Get()
        {
            return CuentasBancariasBL.ListarCuentasBancarias();
        }
        /// <summary>
        /// Funcion que actualiza la cuenta bancaria a default para el sistema
        /// </summary>
        /// <param name="sCuentaBancaria"></param>
        /// <returns></returns>
        [HttpPut("{sCuentaBancaria}")]
        public dynamic Put(string sCuentaBancaria)
        {
            return CuentasBancariasBL.Default_CuentasBancarias(sCuentaBancaria);
        }

        
    }
}
