﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.BussinessLogic.Presupuesto.Reportes;
using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Congope.Empresas.Models.Reportes;
using Newtonsoft.Json;
using Npgsql;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Congope.Empresas.Reportes
{
    public class RPT238_DOC_ARRASTRE_DETALLE
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarReporte(VariablesPdfMO DatosReporte)
        {
            try
            {
                /* LA ESTRUCTURA DEL OBJETO PARA ESTE REPORTE ES:
                */

                var vReportes = new IngresoCertificacionCompromisoNoUtilizadosMo
                {
                    codemp = DatosReporte.VarSesion.CodEmp,
                    fecha_inicio = DatosReporte.param1,
                    fecha_final = DatosReporte.param2,
                    departamento = Convert.ToInt16(DatosReporte.param3),
                    tipo = DatosReporte.param4,
                    estado = 1
                };

                string codEmpresa = DatosReporte.VarSesion.CodEmp;
                NpgsqlCommand cmd = new NpgsqlCommand();

                /** CARGA LA ESTRUCTURA INICIAL DEL REPORTE **/

                var Nombre_Reporte = (DatosReporte.param5=="0")? "RPT238_DOC_ARRASTRE": "RPT238_DOC_ARRASTRE_DETALLE";

                string sql = @"
                                select * from piepagina p 
                                where trim(p.reporte)  like @nombreReporte
                                and p.codemp = @codEmpresa; 
                                ";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@nombreReporte", Nombre_Reporte);
                cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
                var DatosBase = Exec_sql.cargarDatosModel<PiePaginaMO>(cmd);

                /** CARGA EL CUERPO DEL REPORTE **/



                if (DatosBase.success)
                {
                    var oReporte = DatosBase.result[0];


                    /**
                     * ORIENTACION
                     * L: landscape/Horizontal
                     * P: portrait /Vertical 
                     * */
                    oReporte.orientacion = "L";

                    /*** CONTENIDO HTML DESDE BASE DE DATOS
                             * */
                    sql = @"
                                SELECT men_html from mensajes_html p 
                                where p.men_codigo  = 46; 
                                ";
                    cmd.CommandText = sql;
                    var DatosHtml = Exec_sql.cargarDatosJson(cmd);
                    DatosHtml = JsonConvert.DeserializeObject(DatosHtml.result);
                    string htmlContent = DatosHtml[0]["men_html"];


                    ////////////////////////////////////////////////////
                    ///DATOS DE LA CABECERA prcabmov ///////////////////
                    ////////////////////////////////////////////////////
                    var TipoReporte = (vReportes.tipo == "CE") ? "CERTIFICACIONES DE ARRASTRE" : "COMPROMISOS DE ARRASTRE";

                    oReporte.numero_documento = $"DESDE : {vReportes.fecha_inicio.Substring(0, 10)} HASTA: {vReportes.fecha_final.Substring(0, 10)}";

                    var filtros = string.Empty;
                    filtros += (vReportes.departamento != 0) ? "POR DEPARTAMENTO - " : string.Empty;
                    filtros = (filtros == string.Empty) ? "- TODOS -" : "FILTROS : - "+ filtros;

                    oReporte.numero_documento += $"\n{TipoReporte}\n{filtros}";

                    ////////////////////////////////////////////////////
                    ///DATOS DEL DETALLE prdetmov 
                    ///AQUI SE CONSTRUYE EL HTML RECURSIVO///////////////////
                    ////////////////////////////////////////////////////


                    var Datosprdetmov = CertificacionCompromisoArrastreBL.SqlCompromisoCertificacionesArrastre(vReportes);
                    StringBuilder htmlDetalle = new StringBuilder();

                    // Definir fragmentos HTML comunes
                    string plantillaFilaDepartamento = @"
                    <tr>
                        <td style=""font-size: 12px;"" colspan=""8""><strong>{0}</strong></td>
                    </tr>
                    <tr>
                        <td colspan=8><hr></td>
                    </tr>";

                    string plantillaFilaSubtotal = @"
                    <tr>
                        <td colspan=8><hr></td>
                    </tr>
                    <tr>
                        <td style=""font-size: 12px;text-align: right;"" colspan=5><strong>{0} Subtotal:</strong></td>
                        <td style=""font-size: 12px;text-align: right;""><strong>{1:N2}</strong></td>
                        <td style=""font-size: 12px;text-align: right;""><strong>{2:N2}</strong></td>
                        <td style=""font-size: 12px;text-align: right;""><strong>{3:N2}</strong></td>
                    </tr>";

                    string plantillaFilaDatos = @"
                    <tr>
                        <td style=""font-size: 10px;"">{0}</td>
                        <td style=""font-size: 10px;"">{1}</td>
                        <td style=""font-size: 10px;"">{2}</td>
                        <td style=""font-size: 10px;"">{3}</td>
                        <td style=""font-size: 10px;word-break: break-all;max-width: 15%;"">{4}</td>
                        <td style=""font-size: 10px;text-align: right;"">{5:N2}</td>
                        <td style=""font-size: 10px;text-align: right;"">{6:N2}</td>
                        <td style=""font-size: 10px;text-align: right;"">{7:N2}</td>
                    </tr>";

                    string CabeceraSubdetalle = @"
                    <tr>
                        <td colspan=""8"">
                            <hr style=""border-top: 1px dotted #000;"">
                        </td>
                    </tr>
                    <tr>
                        <td colspan=3><strong><i>Partida</i></strong></td>
                        <td colspan=2><strong><i>Nombre</i></strong></td>
                        <td colspan=3></td>
                    </tr>
                    <tr>
                        <td colspan=""8"">
                            <hr style=""border-top: 1px dotted #000;"">
                        </td>
                    </tr>
                    ";

                    string CuerpoSubdetalle = @"
                    
                    <tr>
                        <td style=""font-size: 10px;word-break: break-all;max-width: 23%;"" colspan=3><i>{0}</i></td>
                        <td colspan=2><i>{1}</i></td>
                        <td style=""font-size: 10px;text-align: right;""><i>{2:N2}</i></td>
                        <td style=""font-size: 10px;text-align: right;""><i>{3:N2}</i></td>
                        <td style=""font-size: 10px;text-align: right;""><i>{4:N2}</i></td>
                    </tr>";

                    string PieSubdetalle = @"
                    <tr>
                        <td colspan=""8"">
                            <hr style=""border-top: 1px dotted #000;"">
                        </td>
                    </tr>
                    ";

                    string departamento = string.Empty;
                    double Total_Comprometido = 0;
                    double Total_Devengado = 0;
                    double Total_Saldo = 0;



                    if (Datosprdetmov.success)
                    {
                        var certificaciones = Datosprdetmov.result as List<CertificacionCompromisoArrastreMo>;

                        foreach (var item in certificaciones)
                        {
                            if (departamento != item.departamento && string.IsNullOrEmpty(departamento))
                            {
                                htmlDetalle.AppendFormat(plantillaFilaDepartamento, item.departamento);
                                departamento = item.departamento;
                            }
                            else if (departamento != item.departamento)
                            {
                                htmlDetalle.AppendFormat(plantillaFilaSubtotal, departamento,  certificaciones.Where(x => x.departamento == departamento).Sum(x => x.comprometido),
                                    certificaciones.Where(x => x.departamento == departamento).Sum(x => x.devengado),
                                    certificaciones.Where(x => x.departamento == departamento).Sum(x => x.saldo));
                                htmlDetalle.AppendFormat(plantillaFilaDepartamento, item.departamento);
                                departamento = item.departamento;
                            }
                            Total_Comprometido += item.comprometido;
                            Total_Devengado += item.devengado;
                            Total_Saldo += item.saldo;


                            htmlDetalle.AppendFormat(plantillaFilaDatos, item.siglasnum, item.documento, item.fecha, item.concepto, item.cert_comp, item.comprometido, item.devengado, item.saldo);

                            /// AQUI SE AGREGA EL SUBDETALLE
                            /// 

                            if(DatosReporte.param5=="1")
                            { 

                            var vSubReportes = new EntradasDetalleCompromisoArrastreMo
                            {
                                acu_tip = item.acu_tip,
                                sig_tip = vReportes.tipo,
                                paramSessionMo = DatosReporte.VarSesion
                            };

                            var DatosSubdetalle = CertificacionCompromisoArrastreBL.DetalleCompromisoCertificacionesArrastre(vSubReportes);

                            var subdetalle = DatosSubdetalle.result as List<SalidaDetalleCompromisoArrastreMo>;
                            
                            htmlDetalle.AppendFormat(CabeceraSubdetalle);

                            foreach (var itemsub in subdetalle)
                            {
                                htmlDetalle.AppendFormat(CuerpoSubdetalle,itemsub.partida, itemsub.nombre, itemsub.comprometido, itemsub.devengado, itemsub.saldo);
                            }

                            htmlDetalle.AppendFormat(PieSubdetalle);
                            }


                        }

                        // Agregar la fila de subtotal final para el último departamento
                        htmlDetalle.AppendFormat(plantillaFilaSubtotal, departamento, certificaciones.Where(x => x.departamento == departamento).Sum(x => x.comprometido)
                            , certificaciones.Where(x => x.departamento == departamento).Sum(x => x.devengado)
                            , certificaciones.Where(x => x.departamento == departamento).Sum(x => x.saldo));
                    }

                    // Reemplazar el marcador en el contenido HTML
                    htmlContent = htmlContent.Replace("##DETALLE_RECURSIVO##", htmlDetalle.ToString());
                    htmlContent = htmlContent.Replace("##TOTAL_COMPROMETIDO##", string.Format("{0:N2}", Total_Comprometido));
                    htmlContent = htmlContent.Replace("##TOTAL_DEVENGADO##", string.Format("{0:N2}", Total_Devengado));
                    htmlContent = htmlContent.Replace("##TOTAL_SALDO##", string.Format("{0:N2}", Total_Saldo));

                    oReporte.cuerpo_reporte = htmlContent;

                    oReporte.VarSesion = DatosReporte.VarSesion;
                    return PdfBL.GenerarPDFBase64(oReporte);


                }
                else
                {
                    return DatosBase;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }


        }
    }
}
