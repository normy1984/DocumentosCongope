﻿namespace Congope.Empresas.Data
{
    /// <summary>
    /// CLASE QUE CONTIENE LAS REFERENCIAS PARA LA CONEXION A LOS DIFERENTES SERVICIOS
    /// </summary>
    public class Conexion
    {
        // VARIABLE QUE INDICA LA RUTA POR DEFECTO DONDE SE GUARDAN LOS ARCHIVOS
        public static string RutaDocumentos = Path.Combine(Environment.CurrentDirectory, "Uploads/");

        //Imagen que carga por defecto si la misma no ha sido cargada al server. sirve para la generacion de pdf y logos del sistema
        public static string NombreSistema = "Sistema Financiero de Gobiernos Provinciales";

        //VARIABLE DE AMBIENTE
        public static string VariableAmbiente = "Desarrollo"; //CAMBIAR A PRODUCCION PARA LA PUBLICACION

        //RUTA ARCHIVO ERRORES
        public static string ErrorlogFilePath = "error.log";

        //Imagen que carga por defecto si la misma no ha sido cargada al server. sirve para la generacion de pdf y logos del sistema
        public static string ErrorImagen = "error_imagen.png";

        /// <summary>
        /// VARIABLES PARA LAS CONEXIONES PARA CORREO ELECTRONICO
        /// </summary>
        public static dynamic CorreoConfiguracion = new
        {
            MailstrHost = "in-v3.mailjet.com",
            Mailport = 587,
            MailstrUserName = "d367bd2db8eb19e95e1992fe56fb77ee",
            MailstrFromPass = "9a7cd823338abe9699d5352f312eacda",
            MailFrom = "soporteuio@congope.gob.ec",
            MailNameFrom = "SFGProv Congope",
            MailEnableSsl = true
        };


        /// <summary>
        /// VARIABLES CONEXIONES HABILITANTES PARA EL TOKEN 
        /// JWTCADENA DE 32 CARACTERES QUE SIRVE PARA LA GENERACION DEL TOKEN DE AUTENTICACION DE LOS APIS
        /// </summary>
        public static dynamic JwtConfiguracion = new
        {
            JwtKey = "x6D711WpG6GekBcC5DBb5dUV6UavPPNR",   // ESTA CADENA DEBE REESMPLAZARSE POR UNA CADENA SEGURA 32 CARACTERES 
            JwtIssuer = "http://localhost:5142/",
            JwtAudience = "http://localhost:5142/",
            JwtSubject = "ApiCongope",
            JwtDuracionToken = 5,   //TIEMPO EN MINUTOS DEL TIEMPO DE VIDA DE UN TOKEN
            JwtTiempoMaximoRenovar = 30 //TIEMPO EN MINUTOS MAXIMO DESPUES DE LA CADUCIDAD DE UN TOKEN PARA RENOVARLO
        };

        
        /// <summary>
        /// VARIABLES DE CONEXION PARA LA BASE DE DATOS
        /// </summary>
        protected static dynamic PgSqlConfiguracion = new
        {
            servidor = "172.24.5.34",
            sPassword = "financiero",
            sUid = "postgres",
            sDatabase = "contabilidad",
            sPort = "5432"
        };

        public static string cadena = "server=" + PgSqlConfiguracion.servidor + ";port=" + PgSqlConfiguracion.sPort + ";user id=" +
            PgSqlConfiguracion.sUid + ";password=" + PgSqlConfiguracion.sPassword + ";database=" + PgSqlConfiguracion.sDatabase + ";";


        /// <summary>
        /// VARIABLES DE CONEXION PARA EL ACTIVE DIRECTORY
        /// </summary>
        public static bool ValidarLdap = false;

        public static dynamic ldapConfig = new
        {
            DomainControllers = new[] { "SRVDC-01.CONGOPE.LOCAL" },
            AccountSuffix = "@CONGOPE.LOCAL",
            BaseDn = "DC=CONGOPE,DC=LOCAL",
            DefaultEmailDomain = "congope.gob.ec",
            SaveDatabase = true
        };

    }
}
