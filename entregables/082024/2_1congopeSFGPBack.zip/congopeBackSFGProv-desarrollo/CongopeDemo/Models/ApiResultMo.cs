﻿using Congope.Empresas.Data;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.OpenApi.Any;

namespace Congope.Empresas.Models
{
    public class ApiResultMo<TResult>
    {
        public bool success { get; set; }
        public string message { get; set; }
        public TResult result { get; set; }

        // Constructor sin parámetros
        public ApiResultMo()
        {
            success = false;
            message = string.Empty;
            result = default(TResult);
        }
    }
}
