﻿namespace Congope.Empresas.Models.Genericas

{
    public class MenuMO
    {
        public int Nivel { get; set; }
        public string Codigo { get; set; }
        public string Path { get; set; }
        public string Title { get; set; }
        public string IconType { get; set; }
        public string Icon { get; set; }
        public string Class { get; set; }
        public bool GroupTitle { get; set; }
        public string Badge { get; set; }
        public string BadgeClass { get; set; }
        public List<MenuMO> Submenu { get; set; } = new List<MenuMO>();
    }

    public class NotificacionesMo
    {
        public string mensaje { get; set; }
        public string icono { get; set; }
        public string color { get; set; }
        public string componente { get; set; }
        public int notificaciones { get; set; }
    }


}
