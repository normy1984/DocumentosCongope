﻿namespace Congope.Empresas.Models.Genericas
{
    public class ParamSessionMo
    {
        public string CodEmp { get; set; }
        public int Anio { get; set; }
        public int Sistema { get; set; }
        public int codUsu { get; set; }
    }
}
