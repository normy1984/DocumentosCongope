﻿namespace Congope.Empresas.Models
{
    public class TipoComprobanteMO
    {
        public string sigla { get; set; }
        public float secuencia { get; set; }
        public string descripcion { get; set; }
        public float opcionPagado { get; set; }
        public string comprobanteRol { get; set; }
        public float reiniciaSecuencia { get; set; }
        public float comprobanteGarantia { get; set; }

    }

   
}
