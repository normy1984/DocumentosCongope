﻿namespace Congope.Empresas.Models.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaCabMO
    {
        public string out_acu_tip { get; set; }
        public string out_sig_acu_tip { get; set; }
        public string out_fec_apr { get; set; }
        public string out_des_cab { get; set; }
        public string out_tot_deb { get; set; }
        public string out_nombre_estado { get; set; }
        public string out_estado { get; set; }
        public string out_cre_por { get; set; }
        public string out_nomb_usu_crea { get; set; }
        public string out_mod_por { get; set; }
        public string out_nomb_usu_modifica { get; set; }

    }
}
