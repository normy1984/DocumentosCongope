﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class VerSaldoPartidaMO
    {
        public int codigo { get; set; }
        public string concepto { get; set; }
        public float monto { get; set; }
        public string partida { get; set; }
        public string nombre { get; set; }
    }
}
