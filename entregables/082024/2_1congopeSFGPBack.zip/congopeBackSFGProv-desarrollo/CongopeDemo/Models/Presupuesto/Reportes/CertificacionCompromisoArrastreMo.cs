﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{

    public class CertificacionCompromisoArrastreMo
    {
        public string departamento { get; set; }
        public string siglasnum { get; set; }
        public string documento { get; set; }
        public string observacion { get; set; }
        public string fecha { get; set; }
        public string concepto { get; set; }
        public int cod_departamento { get; set; }
        public int cod_arrastre { get; set; }
        public string cert_comp { get; set; }
        public int acu_tip { get; set; }
        public double comprometido { get; set; }
        public double devengado { get; set; }
        public double saldo { get; set; }
    }

    public class ActualizarCompromisoArrastreMo
    {
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }
        public int arrastre { get; set; }
        public string observacion { get; set; }
        public ParamSessionMo paramSessionMo { get; set; }
    }

    public class EntradasDetalleCompromisoArrastreMo
    {
        public string sig_tip { get; set; }
        public int acu_tip { get; set; }
        public ParamSessionMo paramSessionMo { get; set; }
    }

    public class SalidaDetalleCompromisoArrastreMo
    {
        public string partida { get; set; }
        public string nombre { get; set; }
        public float comprometido { get; set; }
        public float devengado { get; set; }
        public float saldo { get; set; }

    }

}
