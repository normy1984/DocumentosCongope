﻿using System;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class ConsultaPorClasificadorMO
    {
        public string clasificador { get; set; }
        public string categoria { get; set; }
        public string nom_cue { get; set; }
        public decimal asig_ini { get; set; }
        public decimal reformas { get; set; }
        public decimal codificado { get; set; }
        public decimal certificado { get; set; }
        public decimal comprometido { get; set; }
        public decimal devengado { get; set; }
        public decimal pagado { get; set; }
        public decimal por_comprometer { get; set; }
        public decimal por_devengar { get; set; }
        public decimal por_pagar { get; set; }
        public decimal porcen_eje { get; set; }
        public decimal totalasig_ini { get; set; }
        public decimal totalreformas { get; set; }
        public decimal totalcodificado { get; set; }
        public decimal totalcertificado { get; set; }
        public decimal totalcomprometido { get; set; }
        public decimal totaldevengado { get; set; }
        public decimal totalpagado { get; set; }
        public decimal totalpor_comprometer { get; set; }
        public decimal totalpor_devengar { get; set; }
        public decimal totalpor_pagar { get; set; }
    }
}
