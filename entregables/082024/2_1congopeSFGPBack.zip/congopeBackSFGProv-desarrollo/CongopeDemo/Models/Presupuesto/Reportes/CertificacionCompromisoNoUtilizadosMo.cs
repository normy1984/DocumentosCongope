﻿using Org.BouncyCastle.Utilities;

namespace Congope.Empresas.Models.Presupuesto.Reportes
{
    public class CertificacionCompromisoNoUtilizadosMo
    {
        public string siglasnum { get; set; }
        public string departamento { get; set; }
        public string documento { get; set; }
        public string estado { get; set; }
        public string fecha { get; set; }
        public string concepto { get; set; }
        public double valor{ get; set; }
        public int cod_departamento { get; set; }
        public int cod_estado { get; set; }
    }

    public class IngresoCertificacionCompromisoNoUtilizadosMo
    {
        public string fecha_inicio { get; set; }
        public string fecha_final { get; set; }
        public string codemp { get; set; }
        public int departamento { get; set; }
        public int estado { get; set; }
        public string tipo { get; set; }


    }

}
