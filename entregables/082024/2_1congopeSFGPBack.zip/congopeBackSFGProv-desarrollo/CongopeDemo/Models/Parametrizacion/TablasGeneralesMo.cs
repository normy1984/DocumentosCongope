﻿using System.Diagnostics.Contracts;
using System;

namespace Congope.Empresas.Models.Parametrizacion
{
    public class TablasGeneralesMo
    {
        public int codtab { get; set; }
        public string descrip { get; set; }
    }

    public class TablasGenerales_DetalleMo
    {
        public int codigo { get; set; }
        public string descrip { get; set; }
        public string direcci { get; set; }
        public string telefon1 { get; set; }
        public string telefon2 { get; set; }
        public string fax1 { get; set; }
        public string cuentadb { get; set; }
        public string cuentadevol { get; set; }
        public string cuentaddb { get; set; }
        public string cuentadcr { get; set; }
        public string cedruc { get; set; }
        public string placa3 { get; set; }
        public int codtab { get; set; }
        public string cuentacr { get; set; }
        public string cuentagst { get; set; }
        public int secuenc { get; set; }
    }

    public class TablasGeneralesDetalleDelete
    {
        public int codtab { get; set; }
        public int codigo { get; set; }

    }

    public class TablasGeneralesEstructuraMo
    {
        public string codemp { get; set; }
        public int codtab { get; set; }
        public int codigo { get; set; }
        public string ucodemp { get; set; }
        public string cedruc { get; set; }
        public int secuenc { get; set; }
        public string descrip { get; set; }
        public string telefon1 { get; set; }
        public string direcci { get; set; }
        public string telefon2 { get; set; }
        public string fax1 { get; set; }
        public string fax2 { get; set; }
        public string email1 { get; set; }
        public string email2 { get; set; }
        public int estado { get; set; }
        public string fecemi { get; set; }
        public string fecval { get; set; }
        public float vendedor { get; set; }
        public int tipocli { get; set; }
        public int formpag { get; set; }
        public string contacto { get; set; }
        public int ciudad { get; set; }
        public int zona { get; set; }
        public int sector { get; set; }
        public float cupocre1 { get; set; }
        public float cupocre2 { get; set; }
        public float empresa { get; set; }
        public string placa1 { get; set; }
        public string placa2 { get; set; }
        public string placa3 { get; set; }
        public string placa4 { get; set; }
        public string placa5 { get; set; }
        public string placa6 { get; set; }
        public string placa7 { get; set; }
        public string placa8 { get; set; }
        public string nrocta { get; set; }
        public string banco { get; set; }
        public int tipocta { get; set; }
        public string cuentadb { get; set; }
        public string cuentacr { get; set; }
        public string cuentaddb { get; set; }
        public string cuentadcr { get; set; }
        public string cuentagst { get; set; }
        public string cuentadevol { get; set; }
    }

}
