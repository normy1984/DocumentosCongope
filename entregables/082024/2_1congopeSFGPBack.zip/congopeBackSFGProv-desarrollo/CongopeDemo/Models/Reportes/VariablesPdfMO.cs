﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Genericas;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace Congope.Empresas.Models.Reportes
{
    public class VariablesPdfMO
    {
        public string tipo_reporte { get; set; }
        public string param1 { get; set; }
        public string param2 { get; set; }
        public string param3 { get; set; }
        public string param4 { get; set; }
        public string param5 { get; set; }
        public string param6 { get; set; }
        public ParamSessionMo VarSesion { get; set; }

    }
    public class DatosCabecera_Pdf_Mo
    {
        public string NombreReporte { get; set; }
        public string NombreUsuario { get; set; }
        public string NumeroDocumento { get; set; }
        public string NombreInstitucion_Pdf { get; set; }
        public string FilePath_LogoPdf { get; set; }
      
    }
    public class DatosPie_Pdf_Mo
    {
        public int MostrarFechaHora { get; set; }
        public string Direccion_Pdf { get; set; }
        public string Telefono_Pdf { get; set; }
        public string email_Pdf { get; set; }
        public string ciudad_Pdf { get; set; }
    }
}
