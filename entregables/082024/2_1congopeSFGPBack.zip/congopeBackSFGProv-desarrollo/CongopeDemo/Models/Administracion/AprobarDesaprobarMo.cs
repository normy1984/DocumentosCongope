﻿using Congope.Empresas.Models.Genericas;

namespace Congope.Empresas.Models.Administracion
{
    public class AprobarDesaprobarMo
    {
        public string SigTip { get; set; }
        public ParamSessionMo VarSesion { get; set; }
    }

    public class VariablesAprobarDesaprobarMo
    {
        public int Aprobar { get; set; }
        public int Desaprobar { get; set; }

    }
}
