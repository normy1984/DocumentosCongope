﻿namespace Congope.Empresas.Models
{
    public class EstructuraCodigoMO
    {
        public string nivel { get; set; }
        public string descripcion { get; set; }
        public string longitud { get; set; }
        public string item_aso { get; set; }
    }
}
