﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class AsociacionContabilidadPresupuestoBL
    {
        public static dynamic Listar(int nanio, int nTipo_presupuesto)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_ver_asociacion_contabilidad_presupuesto(" + nanio + ", " + nTipo_presupuesto  + ");";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
