﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    /// <summary>
    /// Funcion sql que permite obtener las certificaciones o compromisos no utilizados
    /// </summary>
    public class CertificacionCompromisoNoUtilizadosBL
    {
        public static dynamic SqlCompromisoCertificacionesNoUtilizadas(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNo)
        {
            string sql = @"
        SELECT * FROM public.sps_compromisoscertificacionessinutilizar
        (@fecha_inicio, @fecha_final, @codemp, @departamento, @estado, @tipo);
    ";

            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;

            cmd.Parameters.AddWithValue("@fecha_inicio", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.fecha_inicio);
            cmd.Parameters.AddWithValue("@fecha_final", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.fecha_final);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.codemp);
            cmd.Parameters.AddWithValue("@departamento", NpgsqlDbType.Integer, ingresoCertificacionCompromisoNo.departamento);
            cmd.Parameters.AddWithValue("@estado", NpgsqlDbType.Integer, ingresoCertificacionCompromisoNo.estado);
            cmd.Parameters.AddWithValue("@tipo", NpgsqlDbType.Text, ingresoCertificacionCompromisoNo.tipo);

            return Exec_sql.cargarDatosModel<CertificacionCompromisoNoUtilizadosMo>(cmd);
        }

        /// <summary>
        /// Funcion que permite organizar el objeto para mostrar en el list principal
        /// </summary>
        /// <param name="ingresoCertificacionCompromisoNo"></param>
        /// <returns></returns>
        public static dynamic CertificacionesCompromisosNoUtilizadas(IngresoCertificacionCompromisoNoUtilizadosMo ingresoCertificacionCompromisoNo)
        {
            var respuesta = new ApiResultMo<List<CertificacionCompromisoNoUtilizadosMo>>();
            var nuevoArreglo = new List<CertificacionCompromisoNoUtilizadosMo>();
            string departamento = string.Empty;

            var datosCertificaciones = SqlCompromisoCertificacionesNoUtilizadas(ingresoCertificacionCompromisoNo);

            if (datosCertificaciones.success)
            {
                var certificaciones = datosCertificaciones.result as List<CertificacionCompromisoNoUtilizadosMo>;

                foreach (var item in certificaciones)
                {
                    if (departamento != item.departamento)
                    {
                        nuevoArreglo.Add(new CertificacionCompromisoNoUtilizadosMo()
                        {
                            departamento = string.Empty,
                            concepto = item.departamento,
                            estado = string.Empty,
                            documento = string.Empty,
                            fecha = string.Empty,
                            siglasnum = string.Empty,
                            valor = certificaciones.Where(x => x.departamento == item.departamento).Sum(x => x.valor)
                        });

                        departamento = item.departamento;
                    }
                    nuevoArreglo.Add(item);
                }

                respuesta.success = true;
                respuesta.result = nuevoArreglo;
            }
            else
            {
                respuesta.success = false;
                respuesta.message = datosCertificaciones.message;
            }

            return respuesta;
        }

    }
}
