﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Congope.Empresas.Models.Presupuesto.Reportes;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class CedulaPresupuestariaBL
    {
        public static dynamic Listar(string codemp, string fecha_hasta, int ing_gas, int nTodas, int nNivel, string sOperador, string sPartida = "")
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_cedula_presupuestaria('" + codemp + "', '" + fecha_hasta + "', " + ing_gas + ", " + nTodas + ", " + nNivel + ", '"+ sOperador + "', '"+ sPartida + "');";
            cmd.CommandText = sql;
            //return Exec_sql.cargarDatosModel<CedulaPresupuestariaMO>(cmd);
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
