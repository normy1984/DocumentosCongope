﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class EjecucionPresupuestariaBL
    {
        public static dynamic Listar(string sFechaHasta)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_ejecucion_presupuestaria('" + sFechaHasta + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
