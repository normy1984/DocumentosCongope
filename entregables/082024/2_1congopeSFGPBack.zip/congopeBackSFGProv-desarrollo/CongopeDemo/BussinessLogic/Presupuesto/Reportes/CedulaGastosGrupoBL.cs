﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class CedulaGastosGrupoBL
    {
        public static dynamic Listar(string sFechaHasta)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_cedula_presupuetaria_gastos_grupo('" + sFechaHasta + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
