﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class MovimientoPorPartidaBL
    {
        public static dynamic Listar(string codemp, int anio, string sFechaDesde, string sFechaHasta, string sPartida)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_movimiento_por_partida('" + codemp + "', " + anio + ", '" + sFechaDesde + "', '" + sFechaHasta + "', '" + sPartida + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
