﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class VerSaldoPartidaBL
    {
        public static dynamic Listar(int nanio, string sPartida)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_ver_saldos_partida(" + nanio + ", '" + sPartida + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
