﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ConsultaPorClasificadorBL
    {
        public static dynamic Listar(string sFechaHasta, int nTipoPresu, string sclasificador = "")
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_consulta_por_clasificador_presupuestario('" + sFechaHasta + "', " + nTipoPresu + ", '" + sclasificador + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
