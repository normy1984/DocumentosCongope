﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto
{
    public class ProformaPresupuestariaCabBL
    {
        public static dynamic Listar(string codemp, int anio, string sig_tip, decimal acu_tip = 0)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_proforma_presupuestaria_cabecera('" + codemp + "', " + anio + ", '" + sig_tip + "', '"  + acu_tip + "' );";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<ProformaPresupuestariaCabMO>(cmd);
        }

        public static dynamic AprobarProformaPresupuestaria(decimal in_acu_tip)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_aprobar_proforma_presupuestaria(@in_codemp, @in_anio, @in_acu_tip);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(in_acu_tip));

            return Exec_sql.cargarDatosJson(cmd);

        }

        public static dynamic DesaprobarProformaPresupuestaria(decimal in_acu_tip)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select * FROM public.sp_desaprobar_proforma_presupuestaria(@in_codemp, @in_anio, @in_acu_tip);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(in_acu_tip));

            return Exec_sql.cargarDatosJson(cmd);

        }

    }

    



}
