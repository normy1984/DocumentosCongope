﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Presupuesto;
using Npgsql;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Presupuesto
{
    public class ProformaPresupuestariaBL
    {
        public static List<ProformaPresupuestariaMO> Listar()
        {
            List<ProformaPresupuestariaMO> oListaProformas = new List<ProformaPresupuestariaMO>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = "select * from sps_detalle_proforma_presupuestaria('0004', 2024, 'PR', 1) ";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaProformas.Add(new ProformaPresupuestariaMO()
                            {
                                anio = dr[0].ToString() ?? string.Empty,
                                sig_tip = dr[1].ToString() ?? string.Empty,
                                acu_tip = dr[2].ToString() ?? string.Empty,
                                fec_asi = dr[3].ToString() ?? string.Empty,
                                fec_apr = dr[4].ToString() ?? string.Empty,
                                num_com = dr[5].ToString() ?? string.Empty,
                                des_cab = dr[6].ToString() ?? string.Empty,
                                cre_por = dr[7].ToString() ?? string.Empty,
                                fec_cre = dr[8].ToString() ?? string.Empty,
                                mod_por = dr[9].ToString() ?? string.Empty,
                                fec_mod = dr[10].ToString() ?? string.Empty,
                                estado = dr[11].ToString() ?? string.Empty,
                                cuenta = dr[12].ToString() ?? string.Empty,
                                nom_cue = dr[13].ToString() ?? string.Empty,
                                val_deb = dr[14].ToString() ?? string.Empty,
                                val_cre = dr[15].ToString() ?? string.Empty,
                                asociac = dr[16].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return oListaProformas;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.StackTrace);
                    return oListaProformas;
                }
            }
        }

        ////
        ///

        public static bool Modificar(Proforma_Presupuestaria_DetalleMO datos)
        {
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand("spu_proforma_presupuestaria_detalle", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@varcodemp", datos.codemp);
                cmd.Parameters.AddWithValue("@varanio", datos.anio);
                cmd.Parameters.AddWithValue("@varsig_tip", datos.sig_tip);
                cmd.Parameters.AddWithValue("@varacu_tip", datos.acu_tip);
                cmd.Parameters.AddWithValue("@varsec_det", datos.sec_det);
                cmd.Parameters.AddWithValue("@varycodemp", datos.ycodemp);
                cmd.Parameters.AddWithValue("@varyanio", datos.yanio);
                cmd.Parameters.AddWithValue("@varysig_tip", datos.ysig_tip);
                cmd.Parameters.AddWithValue("@varyacu_tip", datos.yacu_tip);
                cmd.Parameters.AddWithValue("@varcuenta", datos.cuenta);
                cmd.Parameters.AddWithValue("@varval_deb", datos.val_deb);
                cmd.Parameters.AddWithValue("@varval_cre", datos.val_cre);
                cmd.Parameters.AddWithValue("@varfec_det", datos.fec_det);
                cmd.Parameters.AddWithValue("@varcod_cli", datos.cod_cli);
                cmd.Parameters.AddWithValue("@varfec_pos", datos.fec_pos);
                cmd.Parameters.AddWithValue("@varnroctac", datos.nroctac);
                cmd.Parameters.AddWithValue("@varnro_che", datos.nro_che);
                cmd.Parameters.AddWithValue("@vartip_com", datos.tip_com);
                cmd.Parameters.AddWithValue("@varcre_por", datos.cre_por);
                cmd.Parameters.AddWithValue("@varfec_cre", datos.fec_cre);
                cmd.Parameters.AddWithValue("@varmod_por", datos.mod_por);
                cmd.Parameters.AddWithValue("@varfec_mod", datos.fec_mod);
                cmd.Parameters.AddWithValue("@vardes_det", datos.des_det);
                cmd.Parameters.AddWithValue("@varestado", datos.estado);
                cmd.Parameters.AddWithValue("@varperiodo", datos.periodo);
                cmd.Parameters.AddWithValue("@varfactura", datos.factura);
                cmd.Parameters.AddWithValue("@varasociac", datos.asociac);
                cmd.Parameters.AddWithValue("@vardevengad", datos.devengad);
                cmd.Parameters.AddWithValue("@varsaldo", datos.saldo);
                cmd.Parameters.AddWithValue("@varpagado", datos.pagado);
                cmd.Parameters.AddWithValue("@varrecaudad", datos.recaudad);
                cmd.Parameters.AddWithValue("@varval_cert", datos.val_cert);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception e)
                {

                    Console.WriteLine("Explicitly specified:{0}{1}",
                      Environment.NewLine, e.StackTrace);
                    return false;
                }
            }
        }
    }
}
