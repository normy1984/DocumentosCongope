﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaDetBL
    {
        public static dynamic Listar(string codemp, int anio, string sig_tip, int acu_tip)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_proforma_presupuestaria_detalle('" + codemp + "', " + anio + ", '" + sig_tip + "', " + acu_tip + ");";
            cmd.CommandText = sql;
            //return Exec_sql.cargarDatosModel<ProformaPresupuestariaDetMO>(cmd);
            return Exec_sql.cargarDatosJson(cmd);
        }

        public static dynamic InsertarActualizar_DetalleMovimientosPresupuesto(List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            List<dynamic> respuestas = new List<dynamic>();
            bool success = true;

            try
            {
                foreach (var compromisoDetalleMo in compromisoDetalleMoList)
                {
                    try
                    {
                        dynamic respuesta = ProformaPresupuestariaDetBL.InsertarActualizar_DetalleMovimientosPrdetmov(compromisoDetalleMo);

                        respuestas.Add(respuesta);

                        // Verificar si la operación individual fue exitosa
                        if (!respuesta.success)
                        {
                            success = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        SeguridadBL.WriteErrorLog(ex);
                        respuestas.Add(new
                        {
                            success = false,
                            message = "Error: " + ex.Message,
                            result = ""
                        });
                    }
                }

                return new
                {
                    success = success,
                    message = success ? "Operaciones completadas exitosamente" : "Una o más operaciones fallaron",
                    result = respuestas
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        public static dynamic InsertarActualizar_DetalleMovimientosPrdetmov(CompromisoDetalleMo oCompromisoDetalleMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            * from
                            public.spiu_prdetmov
                                (@in_codemp,
                                @in_anio,
                                @in_sig_tip,
                                @in_acu_tip,
                                @in_sec_det,
                                @in_cuenta,
                                @in_val_deb,
                                @in_val_cre,
                                @in_fec_det,
                                @in_cod_cli,
                                @in_fec_pos,
                                @in_nroctac,
                                @in_nro_che,
                                @in_tip_com,
                                @in_cre_por,
                                @in_des_det,
                                @in_estado,
                                @in_periodo,
                                @in_factura,
                                @in_asociac,
                                @in_devengad,
                                @in_saldo,
                                @in_pagado,
                                @in_recaudad,
                                @in_val_cert,
                                @in_acu_tip_ce
                                );";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Constantes.General.codigoUsuario);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, oCompromisoDetalleMo.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip);
            cmd.Parameters.AddWithValue("@in_sec_det", NpgsqlDbType.Integer, oCompromisoDetalleMo.sec_det);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, oCompromisoDetalleMo.cuenta);
            cmd.Parameters.AddWithValue("@in_val_deb", NpgsqlDbType.Double, oCompromisoDetalleMo.val_deb);
            cmd.Parameters.AddWithValue("@in_val_cre", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cre);
            cmd.Parameters.AddWithValue("@in_fec_det", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_det);
            cmd.Parameters.AddWithValue("@in_cod_cli", NpgsqlDbType.Char, oCompromisoDetalleMo.cod_cli);
            cmd.Parameters.AddWithValue("@in_fec_pos", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_pos);
            cmd.Parameters.AddWithValue("@in_nroctac", NpgsqlDbType.Char, oCompromisoDetalleMo.nroctac);
            cmd.Parameters.AddWithValue("@in_nro_che", NpgsqlDbType.Integer, oCompromisoDetalleMo.nro_che);
            cmd.Parameters.AddWithValue("@in_tip_com", NpgsqlDbType.Smallint, oCompromisoDetalleMo.tip_com);
            cmd.Parameters.AddWithValue("@in_des_det", NpgsqlDbType.Char, oCompromisoDetalleMo.des_det);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, oCompromisoDetalleMo.estado);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, oCompromisoDetalleMo.periodo);
            cmd.Parameters.AddWithValue("@in_factura", NpgsqlDbType.Char, oCompromisoDetalleMo.factura);
            cmd.Parameters.AddWithValue("@in_asociac", NpgsqlDbType.Smallint, oCompromisoDetalleMo.asociac);
            cmd.Parameters.AddWithValue("@in_devengad", NpgsqlDbType.Integer, oCompromisoDetalleMo.devengad);
            cmd.Parameters.AddWithValue("@in_saldo", NpgsqlDbType.Numeric, oCompromisoDetalleMo.saldo);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, oCompromisoDetalleMo.pagado);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, oCompromisoDetalleMo.recaudad);
            cmd.Parameters.AddWithValue("@in_val_cert", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cert);
            cmd.Parameters.AddWithValue("@in_acu_tip_ce", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip_ce);

            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
