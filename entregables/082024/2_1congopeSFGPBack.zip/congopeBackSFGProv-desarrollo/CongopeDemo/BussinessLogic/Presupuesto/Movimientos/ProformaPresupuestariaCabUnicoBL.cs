﻿using Congope.Empresas.Data;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class ProformaPresupuestariaCabUnicoBL
    {
        public static dynamic Listar(string codemp, int anio, string sig_tip, int acu_tip)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sps_proforma_presupuestaria_cabecera_unico('" + codemp + "', " + anio + ", '" + sig_tip + "', " + acu_tip + ");";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<ProformaPresupuestariaCabUnicoMO>(cmd);
        }


    }
}
