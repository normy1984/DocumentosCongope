﻿using Congope.Empresas.BussinessLogic.Presupuesto.Catalogos;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Presupuesto.Catalogos;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;
using System.Data;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class CertificacionBL
    {

        /// <summary>
        /// Metodo para liquidar certificacion presupuestaria(Moviiento y detalle partida)
        /// </summary>
        /// <param name="pcertificacion">Detallle de partida presupuestaria</param>
        /// <returns>Estructura de certificacion</returns>
        public static dynamic LiquidarCertificacionesPresupuestarias(PartidaPresupuestariaDetMO pcertificacion,string accion)
        {
            ParamSessionMo VarSesion = pcertificacion.VarSesion;
            dynamic movimiento= InsertarActualizarCertificacionesPresupuestariasF(pcertificacion);
            
            var response = PartidasPresupuestariasBL.ListarDetallePartidasCE(pcertificacion.sig_tip + " " + pcertificacion.acu_tip);

            if (response.message == "Success")
            {       
                List<PartidaPresupuestariaDetMO> detpartidas = response.result;
                foreach (PartidaPresupuestariaDetMO p in detpartidas)
                {
                    p.VarSesion = VarSesion;
                    p.sig_tip = pcertificacion.sig_tip;
                    p.acu_tip = pcertificacion.acu_tip;
                    PartidasPresupuestariasBL.InsertarActualizar_CertificacionPartidasDet
                    (accion, p, movimiento.result[0].out_acu_tip);

                }

            }          
            return movimiento;
            //Analizar si se pue hacer para todos los tipos CE,CO,etc         
        }

        
        public static dynamic InsertarActualizarCertificacionesPresupuestariasF(PartidaPresupuestariaDetMO pcertificacion)
        {       
            //CambiarContrasenaMo el nombre del sp xq se esta insertando una certificacion, es parte del proceso de liquidacion
            string sql = @"select * from spiu_liquidar_certificado
                           (
                            @in_codemp,
                            @in_sigtip,
                            @in_acutip,
                            @in_anio,
                            @in_user
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", pcertificacion.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_sigtip", pcertificacion.sig_tip);
            cmd.Parameters.AddWithValue("@in_acutip", Convert.ToInt32(pcertificacion.acu_tip));
            cmd.Parameters.AddWithValue("@in_anio", pcertificacion.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_user", pcertificacion.VarSesion.codUsu.ToString());
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<CertificacionesPresupuestariasMO>(cmd);
        }     
    }
}
