﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Presupuesto.Movimientos;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Movimientos
{
    public class CompromisoBL
    {
        /// <summary>
        /// Funcion para listar los compromisos por codigo o un grupo de codigos concatenado por comas 
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>

        public static dynamic ListarDetalleCompromisoCertificadoCodigo(string acu_tip)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            out_cuenta as cuenta, 
                            out_certificacion as certificacion, 
                            out_nom_cue as nom_cue, 
                            out_val_cre as val_cre, 
                            out_val_deb as val_deb, 
                            out_val_sal as val_sal, 
                            out_asociac as asociac, 
                            out_estado as estado, 
                            out_periodo as periodo, 
                            out_sec_det as sec_det, 
                            out_valor_maximo as valor_maximo
                            from public.sps_prdetmovlistarcertificados
                            (
                             @codemp,
                             @anio,
                             @acu_tip
                            );";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@acu_tip", NpgsqlDbType.Varchar, acu_tip); // Asignar valores a los parámetros dinámicos
           
            return Exec_sql.cargarDatosJson(cmd);

        }
        /// <summary>
        /// Listar los elementos de la cabecera por codigos
        /// </summary>
        /// <param name="acu_tip"></param>
        /// <returns></returns>
        public static dynamic ListarCebeceraNuevoCompromisoCertificadoCodigo(string acu_tip)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();
            
            string sql = @"
                         SELECT  
                         'CO -1' as siglasnum,
                         current_date as fec_asi,
                         current_date as fec_apr,
                         0 as valor_contrato,
                         '' as cod_proceso,
                         'CE' as sig_tipce,
                         out_acu_tipce as acu_tipce,
                         out_descripcion as des_cab, 
                         out_comprobante as num_com, 
                         out_departamento as departam, 
                         out_responsable as solicita,
                         out_departamento_desc as departam_desc, 
                         out_responsable_desc as solicita_desc 
                         from public.sps_prdetmovnuevocompromisocertificacion(
                         @codemp, 
                         @anio, 
                         @acu_tip);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@anio", Int32.Parse(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@acu_tip", NpgsqlDbType.Varchar, acu_tip);

            return Exec_sql.cargarDatosJson(cmd);

        }



        /// <summary>
        /// Insertar y actualizar todos los registros de la cabecera prcabmov
        /// </summary>
        /// <param name="oCompromisoCabecera"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_CabeceraCompromiso(CompromisoCabeceraMo oCompromisoCabecera)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            *
                            from spiu_prcabmov
                            (
                             @in_codemp, 
                             @in_anio, 
                             @in_sig_tip,
                             @in_acu_tip, 
                             @in_num_com, 
                             @in_des_cab, 
                            @in_tot_deb, 
                            @in_tot_cre, 
                            @in_totinid, 
                            @in_totinic, 
                            @in_fec_asi, 
                            @in_fec_apr, 
                            @in_fec_anu, 
                            @in_cre_por, 
                            @in_estado, 
                            @in_periodo, 
                            @in_nropagos, 
                            @in_pagosre, 
                            @in_incremen, 
                            @in_comprom, 
                            @in_sig_tip1, 
                            @in_acu_tip1, 
                            @in_estadono, 
                            @in_liquida, 
                            @in_departam, 
                            @in_solicita, 
                            @in_cedruc, 
                            @in_tipopro, 
                            @in_retfte, 
                            @in_retiva, 
                            @in_cur, 
                            @in_pagado, 
                            @in_recaudad, 
                            @in_sig_tipce, 
                            @in_acu_tipce, 
                            @in_cod_proceso, 
                            @in_arrastre, 
                            @in_tipo_contrato, 
                            @in_admin_contrato, 
                            @in_valor_contrato, 
                            @in_observacion, 
                            @in_desagrupar);
                             ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Constantes.General.codigoUsuario);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, oCompromisoCabecera.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, oCompromisoCabecera.acu_tip);
            cmd.Parameters.AddWithValue("@in_num_com", NpgsqlDbType.Char, oCompromisoCabecera.num_com);
            cmd.Parameters.AddWithValue("@in_des_cab", NpgsqlDbType.Varchar, oCompromisoCabecera.des_cab);
            cmd.Parameters.AddWithValue("@in_tot_deb", NpgsqlDbType.Double, oCompromisoCabecera.tot_deb);
            cmd.Parameters.AddWithValue("@in_tot_cre", NpgsqlDbType.Double, oCompromisoCabecera.tot_cre);
            cmd.Parameters.AddWithValue("@in_totinid", NpgsqlDbType.Double, oCompromisoCabecera.totinid);
            cmd.Parameters.AddWithValue("@in_totinic", NpgsqlDbType.Double, oCompromisoCabecera.totinic);
            cmd.Parameters.AddWithValue("@in_fec_asi", NpgsqlDbType.Char, oCompromisoCabecera.fec_asi);
            cmd.Parameters.AddWithValue("@in_fec_apr", NpgsqlDbType.Char, oCompromisoCabecera.fec_apr);
            cmd.Parameters.AddWithValue("@in_fec_anu", NpgsqlDbType.Char, oCompromisoCabecera.fec_anu);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, oCompromisoCabecera.estado);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, oCompromisoCabecera.periodo);
            cmd.Parameters.AddWithValue("@in_nropagos", NpgsqlDbType.Smallint, oCompromisoCabecera.nropagos);
            cmd.Parameters.AddWithValue("@in_pagosre", NpgsqlDbType.Smallint, oCompromisoCabecera.pagosre);
            cmd.Parameters.AddWithValue("@in_incremen", NpgsqlDbType.Smallint, oCompromisoCabecera.incremen);
            cmd.Parameters.AddWithValue("@in_comprom", NpgsqlDbType.Double, oCompromisoCabecera.comprom);
            cmd.Parameters.AddWithValue("@in_sig_tip1", NpgsqlDbType.Char, oCompromisoCabecera.sig_tip1);
            cmd.Parameters.AddWithValue("@in_acu_tip1", NpgsqlDbType.Double, oCompromisoCabecera.acu_tip1);
            cmd.Parameters.AddWithValue("@in_estadono", NpgsqlDbType.Smallint, oCompromisoCabecera.estadono);
            cmd.Parameters.AddWithValue("@in_liquida", NpgsqlDbType.Smallint, oCompromisoCabecera.liquida);
            cmd.Parameters.AddWithValue("@in_departam", NpgsqlDbType.Smallint, oCompromisoCabecera.departam);
            cmd.Parameters.AddWithValue("@in_solicita", NpgsqlDbType.Smallint, oCompromisoCabecera.solicita);
            cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, oCompromisoCabecera.cedruc);
            cmd.Parameters.AddWithValue("@in_tipopro", NpgsqlDbType.Smallint, oCompromisoCabecera.tipopro);
            cmd.Parameters.AddWithValue("@in_retfte", NpgsqlDbType.Smallint, oCompromisoCabecera.retfte);
            cmd.Parameters.AddWithValue("@in_retiva", NpgsqlDbType.Smallint, oCompromisoCabecera.retiva);
            cmd.Parameters.AddWithValue("@in_cur", NpgsqlDbType.Char, oCompromisoCabecera.cur);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, oCompromisoCabecera.pagado);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, oCompromisoCabecera.recaudad);
            cmd.Parameters.AddWithValue("@in_sig_tipce", NpgsqlDbType.Char, oCompromisoCabecera.sig_tipce);
            cmd.Parameters.AddWithValue("@in_acu_tipce", NpgsqlDbType.Numeric, oCompromisoCabecera.acu_tipce);
            cmd.Parameters.AddWithValue("@in_cod_proceso", NpgsqlDbType.Char, oCompromisoCabecera.cod_proceso);
            cmd.Parameters.AddWithValue("@in_arrastre", NpgsqlDbType.Numeric, oCompromisoCabecera.arrastre);
            cmd.Parameters.AddWithValue("@in_tipo_contrato", NpgsqlDbType.Numeric, oCompromisoCabecera.tipo_contrato);
            cmd.Parameters.AddWithValue("@in_admin_contrato", NpgsqlDbType.Char, oCompromisoCabecera.admin_contrato);
            cmd.Parameters.AddWithValue("@in_valor_contrato", NpgsqlDbType.Numeric, oCompromisoCabecera.valor_contrato);
            cmd.Parameters.AddWithValue("@in_observacion", NpgsqlDbType.Varchar, oCompromisoCabecera.observacion);
            cmd.Parameters.AddWithValue("@in_desagrupar", NpgsqlDbType.Numeric, oCompromisoCabecera.desagrupar);


        
            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Insertar y actualizar los detalles prdetmov
        /// </summary>
        /// <param name="oCompromisoDetalleMo"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_DetalleCompromiso(CompromisoDetalleMo oCompromisoDetalleMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                            * from
                            public.spiu_prdetmovcompromiso
                                (@in_codemp,
                                @in_anio,
                                @in_sig_tip,
                                @in_acu_tip,
                                @in_sec_det,
                                @in_cuenta,
                                @in_val_deb,
                                @in_val_cre,
                                @in_fec_det,
                                @in_cod_cli,
                                @in_fec_pos,
                                @in_nroctac,
                                @in_nro_che,
                                @in_tip_com,
                                @in_cre_por,
                                @in_des_det,
                                @in_estado,
                                @in_periodo,
                                @in_factura,
                                @in_asociac,
                                @in_devengad,
                                @in_saldo,
                                @in_pagado,
                                @in_recaudad,
                                @in_val_cert,
                                @in_acu_tip_ce
                                );";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Constantes.General.codigoUsuario);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, oCompromisoDetalleMo.sig_tip);
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip);
            cmd.Parameters.AddWithValue("@in_sec_det", NpgsqlDbType.Integer, oCompromisoDetalleMo.sec_det);
            cmd.Parameters.AddWithValue("@in_cuenta", NpgsqlDbType.Char, oCompromisoDetalleMo.cuenta);
            cmd.Parameters.AddWithValue("@in_val_deb", NpgsqlDbType.Double, oCompromisoDetalleMo.val_deb);
            cmd.Parameters.AddWithValue("@in_val_cre", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cre);
            cmd.Parameters.AddWithValue("@in_fec_det", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_det);
            cmd.Parameters.AddWithValue("@in_cod_cli", NpgsqlDbType.Char, oCompromisoDetalleMo.cod_cli);
            cmd.Parameters.AddWithValue("@in_fec_pos", NpgsqlDbType.Char, oCompromisoDetalleMo.fec_pos);
            cmd.Parameters.AddWithValue("@in_nroctac", NpgsqlDbType.Char, oCompromisoDetalleMo.nroctac);
            cmd.Parameters.AddWithValue("@in_nro_che", NpgsqlDbType.Integer, oCompromisoDetalleMo.nro_che);
            cmd.Parameters.AddWithValue("@in_tip_com", NpgsqlDbType.Smallint, oCompromisoDetalleMo.tip_com);
            cmd.Parameters.AddWithValue("@in_des_det", NpgsqlDbType.Char, oCompromisoDetalleMo.des_det);
            cmd.Parameters.AddWithValue("@in_estado", NpgsqlDbType.Integer, oCompromisoDetalleMo.estado);
            cmd.Parameters.AddWithValue("@in_periodo", NpgsqlDbType.Smallint, oCompromisoDetalleMo.periodo);
            cmd.Parameters.AddWithValue("@in_factura", NpgsqlDbType.Char, oCompromisoDetalleMo.factura);
            cmd.Parameters.AddWithValue("@in_asociac", NpgsqlDbType.Smallint, oCompromisoDetalleMo.asociac);
            cmd.Parameters.AddWithValue("@in_devengad", NpgsqlDbType.Integer, oCompromisoDetalleMo.devengad);
            cmd.Parameters.AddWithValue("@in_saldo", NpgsqlDbType.Numeric, oCompromisoDetalleMo.saldo);
            cmd.Parameters.AddWithValue("@in_pagado", NpgsqlDbType.Double, oCompromisoDetalleMo.pagado);
            cmd.Parameters.AddWithValue("@in_recaudad", NpgsqlDbType.Double, oCompromisoDetalleMo.recaudad);
            cmd.Parameters.AddWithValue("@in_val_cert", NpgsqlDbType.Double, oCompromisoDetalleMo.val_cert);
            cmd.Parameters.AddWithValue("@in_acu_tip_ce", NpgsqlDbType.Double, oCompromisoDetalleMo.acu_tip_ce);

            return Exec_sql.cargarDatosJson(cmd);
        }



        /// <summary>
        /// Cuando se recibe una lista de detalles con esta funcion se hace recursiva la insercion
        /// </summary>
        /// <param name="compromisoDetalleMoList"></param>
        /// <returns></returns>

        public static dynamic InsertarActualizar_DetalleCompromisoList(List<CompromisoDetalleMo> compromisoDetalleMoList)
        {
            List<dynamic> respuestas = new List<dynamic>();
            bool success = true;

            try
            {
                foreach (var compromisoDetalleMo in compromisoDetalleMoList)
                {
                    try
                    {
                        dynamic respuesta = CompromisoBL.InsertarActualizar_DetalleCompromiso(compromisoDetalleMo);

                        respuestas.Add(respuesta);

                        // Verificar si la operación individual fue exitosa
                        if (!respuesta.success)
                        {
                            success = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        SeguridadBL.WriteErrorLog(ex);
                        respuestas.Add(new
                        {
                            success = false,
                            message = "Error: " + ex.Message,
                            result = ""
                        });
                    }
                }

                return new
                {
                    success = success,
                    message = success ? "Operaciones completadas exitosamente" : "Una o más operaciones fallaron",
                    result = respuestas
                };
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }



        /// <summary>
        /// Funcion para aprobar un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>

        public static dynamic AprobarCompromisoPresupuestario(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_aprobarcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip);
                          ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }


        /// <summary>
        /// Funcion para anular un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>

        public static dynamic AnularCompromisoPresupuestario(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_anularcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip, @in_cre_por);
                          ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(array[1]));
            cmd.Parameters.AddWithValue("@in_cre_por", NpgsqlDbType.Char, Constantes.General.codigoUsuario);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para desaprobar un compromiso presupuestario
        /// </summary>
        /// <param name="in_acu_tip"></param>
        /// <returns></returns>
        public static dynamic DesAprobarCompromisoPresupuestario(string in_acu_tip)
        {
            string[] array = in_acu_tip.Split(' ');

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = @"Select 
                           * 
                           FROM 
                           public.sp_desaprobarcompromiso(
                           @in_codemp, @in_anio, @in_acu_tip);
                          ";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Double, Convert.ToDouble(array[1]));

            return Exec_sql.cargarDatosJson(cmd);

        }


        /// <summary>
        /// Funcion para listar las certificaciones habilitadas para ingresar un nuevo compromiso
        /// </summary>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public static dynamic ListCertificacionesPresupuestariasHabilitadas(string tipo)
        {
            switch (tipo)
            {
                case Constantes.TipoMovimiento.Certificacion:
                    tipo = Constantes.TipoMovimiento.Certificacion;
                    break;
                default:
                    break;
            }

            string sql = @"select * from sps_movimiento_presupuestaria_habilitada
                           (
                            @in_codemp,
                            @in_anio,
                            @in_acu_tip
                            );
                            ";
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Integer, Convert.ToInt32(Constantes.General.anio));
            cmd.Parameters.AddWithValue("@in_acu_tip", NpgsqlDbType.Varchar, tipo);
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosModel<MovimientosPresupuestariosMO>(cmd);
        }

    }

    

}
