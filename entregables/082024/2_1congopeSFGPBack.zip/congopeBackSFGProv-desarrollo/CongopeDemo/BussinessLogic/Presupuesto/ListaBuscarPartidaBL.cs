﻿using Congope.Empresas.Data;
using Npgsql;

namespace Congope.Empresas.BussinessLogic.Presupuesto.Reportes
{
    public class ListaBuscarPartidaBL
    {
        public static dynamic Listar(int nanio, int nTipoPresu, string sPartida = "")
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = "select * from sp_lista_buscar_partida(" + nanio + ", " + nTipoPresu  + ", '" + sPartida + "');";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }
    }
}
