﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Catalogo;
using Congope.Empresas.Models.Parametrizacion;
using Npgsql;
using System.Numerics;

namespace Congope.Empresas.BussinessLogic.Catalogo
{
    public class CuentasBancariasBL
    {
        
        /// <summary>
        /// Funcion que retorna la cuentas bancarias habilitadas en el sistema para la empresa y el año en seleccionado
        /// </summary>
        /// <returns></returns>
        public static dynamic ListarCuentasBancarias()
        {
            string codEmpresa = Constantes.General.Empresa;
            string oAnio = Constantes.General.anio;

            List<CuentasBancariasMo> oCuentasBancariasMo = new List<CuentasBancariasMo>();

            string sql = @"select 
                        ctapag,
                        cuenta,
                        nom_cue,
                        nrocuent
                        from sps_cuentas_bancarias
                        ('" + codEmpresa + "'," + oAnio + ")";

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oCuentasBancariasMo.Add(new CuentasBancariasMo()
                            {
                                ctapag = Convert.ToInt32(dr["ctapag"].ToString()),
                                cuenta = dr["cuenta"].ToString() ?? string.Empty,
                                nombreCuenta = dr["nom_cue"].ToString() ?? string.Empty,
                                cuentaBancaria = dr["nrocuent"].ToString() ?? string.Empty,
                                
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oCuentasBancariasMo
                    };

                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.Message
                    };
                }

            }
        }
        /// <summary>
        /// Funcion que actualiza el valor de la cuenta bancaria por defecto que es utilizada en el sistema
        /// </summary>
        /// <param name="sCuenta"></param>
        /// <returns></returns>
        public static dynamic Default_CuentasBancarias(string sCuenta)
        {
            string codEmpresa = Constantes.General.Empresa;
            string oAnio = Constantes.General.anio;

            List<CuentasBancariasMo> oCuentasBancariasMo = new List<CuentasBancariasMo>();

            string sql = @"select 
                        ctapag,
                        cuenta,
                        nom_cue,
                        nrocuent
                        from spu_cuentas_bancarias
                        ('" + codEmpresa + "'," + oAnio + ",'" + sCuenta + "')";

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oCuentasBancariasMo.Add(new CuentasBancariasMo()
                            {
                                ctapag = Convert.ToInt32(dr["ctapag"].ToString()),
                                cuenta = dr["cuenta"].ToString() ?? string.Empty,
                                nombreCuenta = dr["nom_cue"].ToString() ?? string.Empty,
                                cuentaBancaria = dr["nrocuent"].ToString() ?? string.Empty,

                            });
                        }
                    }


                    if (oCuentasBancariasMo.Count == 0)
                    {
                        return new
                        {
                            success = false,
                            message = "No se actualizo ningún registro!!",
                            result = oCuentasBancariasMo
                        };
                    }
                    else
                    {
                        return new
                        {
                            success = true,
                            message = "Registro actualizado!!",
                            result = oCuentasBancariasMo
                        };

                    }

                    

                }
                catch (Exception e )
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.Message
                    };
                }

            }
        }
    }
}
