﻿using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.VisualBasic;
using Npgsql;
using System.Data;
using System.Numerics;
using System.Collections;
using static Npgsql.Replication.PgOutput.Messages.RelationMessage;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Diagnostics.CodeAnalysis;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Parametrizacion
{
    public class TablasGeneralesBL
    {
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre
        /// </summary>
        /// <returns></returns>
        public static dynamic ListarTablas()
        {
            string esAdministrador = Constantes.General.esAdministrador;
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGeneralesMo> oListaTablasGenerales = new List<TablasGeneralesMo>();

            string sql = "select out_codtab, out_descrip from select_tablas('" + codEmpresa + "','" + esAdministrador + "')";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGenerales.Add(new TablasGeneralesMo()
                            {
                                codtab = dr.GetInt32(dr.GetOrdinal("out_codtab")),
                                descrip = dr["out_descrip"].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oListaTablasGenerales
                    };
                   
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }
        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre por Padre
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarTablas_Codigo(int in_codtab)
        {
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGeneralesMo> oListaTablasGenerales = new List<TablasGeneralesMo>();

            string sql = @"select 
                        out_codtab, 
                        out_descrip 
                        from select_tablas_codigo
                        ('" + codEmpresa + "'," + in_codtab + ")";
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                    oConexion.Open();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oListaTablasGenerales.Add(new TablasGeneralesMo()
                            {
                                codtab = dr.GetInt32(dr.GetOrdinal("out_codtab")),
                                descrip = dr["out_descrip"].ToString() ?? string.Empty,
                            });
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = oListaTablasGenerales
                    };
                 
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }
        /// <summary>
        /// Listar Detalle Sin Diccionario
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarDetalleSinDiccionario(int in_codtab)
        {
            if ((int)in_codtab < 0)
            {
                return new
                {
                    success = true,
                    message = "No existe la tabla buscada",
                    result = "error"
                };
            }
            var cmd = new NpgsqlCommand();
            string sql = "";
            string codEmpresa = Constantes.General.Empresa;

        sql = @"select 
                        out_codigo as codigo,
                        out_descrip as descrip,
                        out_direcci as direcci,
                        out_telefon1 as telefon1,
                        out_telefon2 as telefon2,
                        out_fax1 as fax1,
                        out_cuentadb as cuentadb,
                        out_cuentacr as cuentacr,
                        out_cuentagst as cuentagst,
                        out_cuentadevol as cuentadevol,
                        out_cuentaddb as cuentaddb,
                        out_cuentadcr as cuentadcr,
                        out_cedruc as cedruc,
                        out_placa3 as placa3,
                        @in_codtab as codtab
                        from select_tablas_detalle
                        (@codEmpresa,@in_codtab)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codEmpresa", codEmpresa.ToString());
            cmd.Parameters.AddWithValue("@in_codtab",NpgsqlDbType.Integer, in_codtab);

            return  Exec_sql.cargarDatosModel<TablasGenerales_DetalleMo>(cmd);
          
        }

        /// <summary>
        /// Listar Detalle Departamentos
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarDetalleDepartamentos(int in_codtab)
        {
            if ((int)in_codtab < 0)
            {
                return new
                {
                    success = true,
                    message = "No existe la tabla buscada",
                    result = "error"
                };
            }
            var cmd = new NpgsqlCommand();
            string codEmpresa = Constantes.General.Empresa;
            int anio = Convert.ToInt32(Constantes.General.anio);

            string sql = @"select 
	                codigo, 
	                descrip, 
	                case 
	                when (telefon1 = '1' and tipocli = '1') then 'PRINCIPAL Y BAJAS'
	                when (telefon1 = '1' and tipocli = '0') then 'BAJAS'
	                when (telefon1 = '0' and tipocli = '1') then 'PRINCIPAL'
	                else ''
	                end as tipo_bodega,
	                (select nom_cue from roplacta b where b.codemp = tb.codemp and tb.nrocta = b.cuenta and b.anio = @anio)
                    as ugestion 
	                from tablas tb
	                where tb.codemp = @codemp
	                and tb.codigo <> 0 
	                and tb.codtab = @codtab;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", codEmpresa.ToString());
            cmd.Parameters.AddWithValue("@codtab", NpgsqlDbType.Integer, in_codtab);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, anio);
 
            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion para obtener la informacion CatalogoHijo por Padre
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <returns></returns>
        public static dynamic ListarDetalle(BigInteger in_codtab)
        {
            if((int)in_codtab<0){
                    return new
                    {
                        success = true,
                        message = "No existe la tabla buscada",
                        result = "error"
                    };
            }
            string codEmpresa = Constantes.General.Empresa;

            List<TablasGenerales_DetalleMo> oListaTablasGeneralesDetalle = new List<TablasGenerales_DetalleMo>();

            string sql = @"select 
                        out_codigo,
                        out_descrip,
                        out_direcci,
                        out_telefon1,
                        out_telefon2,
                        out_fax1,
                        out_cuentadb,
                        out_cuentacr,
                        out_cuentagst,
                        out_cuentadevol,
                        out_cuentaddb,
                        out_cuentadcr,
                        out_cedruc,
                        out_placa3
                        from select_tablas_detalle
                        ('" + codEmpresa + "'," + in_codtab + ")";

            var sqlDiccionarioTabla="select diccionario from diccionario_tabla where codtab="+in_codtab;

            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))

            {
                var comandoDiccionarioTabla= new NpgsqlCommand(sqlDiccionarioTabla, oConexion);
                NpgsqlCommand cmd = new NpgsqlCommand(sql, oConexion);

                try
                {
                   

                    oConexion.Open();

                    var registroDiccionario =(string) comandoDiccionarioTabla.ExecuteScalar(); 
                    var tablaDiccionario=ConversorTabla.convertir(registroDiccionario.Trim());
                    var columnasDiccionario=tablaDiccionario.Keys;
                    var prefijo="out_";
                    var diccionario = new List<object>();


                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                                             
                            var registro= new Hashtable();
                            foreach(var columna in columnasDiccionario){
                                var campo=tablaDiccionario[columna];                            
                    
                                var valor=dr[prefijo+columna];
                                valor=valor.ToString().Trim();
                                registro.Add(campo,valor);
                            }
                             
                            diccionario.Add(registro); 
                        }
                    }
                    return new
                    {
                        success = true,
                        message = "Lectura exitosa",
                        result = diccionario
                    };
                  
                }
                catch (Exception e)
                {
                    Console.WriteLine("Explicitly specified:{0}{1}",
                    Environment.NewLine, e.StackTrace);
                    return new
                    {
                        success = false,
                        message = "Lectura fallida",
                        result = e.StackTrace
                    };
                }

            }
        }

        /// <summary>
        /// Funcion para obtener la informacion CatalogoPadre por Padre y por codigo
        /// </summary>
        /// <param name="in_codtab"></param>
        /// <param name="in_codigo"></param>
        /// <returns></returns>
        public static dynamic ListarDetalle_Codigo(int in_codtab, int in_codigo)
        {

            var cmd = new NpgsqlCommand();

            string sql = @"select 
	                        *
                            from tablas a
	                        where a.codemp = @codemp 
	                        and a.codigo <> 0 
	                        and a.codtab = @in_codtab
	                        and a.codigo = @in_codigo;";
            
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codemp", Constantes.General.Empresa);
            cmd.Parameters.AddWithValue("@in_codtab", NpgsqlDbType.Integer, in_codtab);
            cmd.Parameters.AddWithValue("@in_codigo", NpgsqlDbType.Integer, in_codigo);

            return Exec_sql.cargarDatosModel<TablasGeneralesEstructuraMo>(cmd);
        
        }

        /// <summary>
        /// Funcion para insertar y actualizar la informacion del CatalogoHijo por Padre y codigo
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        public static dynamic InsertUpdate_Detalle(TablasGeneralesEstructuraMo DetalleMo)
        {
            string codEmpresa = Constantes.General.Empresa;
            var cmd = new NpgsqlCommand();
            cmd.CommandText = "spiu_tabla_detalle";
                cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, codEmpresa);
            cmd.Parameters.AddWithValue("@in_codtab", NpgsqlDbType.Integer, DetalleMo.codtab);
            cmd.Parameters.AddWithValue("@in_codigo", NpgsqlDbType.Integer, DetalleMo.codigo);
            cmd.Parameters.AddWithValue("@in_ucodemp", NpgsqlDbType.Char, DetalleMo.ucodemp);
            cmd.Parameters.AddWithValue("@in_cedruc", NpgsqlDbType.Char, DetalleMo.cedruc);
            cmd.Parameters.AddWithValue("@in_secuenc", NpgsqlDbType.Smallint, DetalleMo.secuenc);
            cmd.Parameters.AddWithValue("@in_descrip", NpgsqlDbType.Char, DetalleMo.descrip);
            cmd.Parameters.AddWithValue("@in_telefon1", NpgsqlDbType.Char, DetalleMo.telefon1);
            cmd.Parameters.AddWithValue("@in_direcci", NpgsqlDbType.Char, DetalleMo.direcci);
            cmd.Parameters.AddWithValue("@in_telefon2", NpgsqlDbType.Char, DetalleMo.telefon2);
            cmd.Parameters.AddWithValue("@in_fax1", NpgsqlDbType.Char, DetalleMo.fax1);
            cmd.Parameters.AddWithValue("@in_fax2", NpgsqlDbType.Char, DetalleMo.fax2);
            cmd.Parameters.AddWithValue("@in_email1", NpgsqlDbType.Char, DetalleMo.email1);
            cmd.Parameters.AddWithValue("@in_email2", NpgsqlDbType.Char, DetalleMo.email2);
            cmd.Parameters.AddWithValue("@in_fecemi", NpgsqlDbType.Char, DetalleMo.fecemi);
            cmd.Parameters.AddWithValue("@in_fecval", NpgsqlDbType.Char, DetalleMo.fecval);
            cmd.Parameters.AddWithValue("@in_vendedor", NpgsqlDbType.Double, DetalleMo.vendedor);
            cmd.Parameters.AddWithValue("@in_tipocli", NpgsqlDbType.Smallint, DetalleMo.tipocli);
            cmd.Parameters.AddWithValue("@in_formpag", NpgsqlDbType.Smallint, DetalleMo.formpag);
            cmd.Parameters.AddWithValue("@in_contacto", NpgsqlDbType.Char, DetalleMo.contacto);
            cmd.Parameters.AddWithValue("@in_ciudad", NpgsqlDbType.Smallint, DetalleMo.ciudad);
            cmd.Parameters.AddWithValue("@in_zona", NpgsqlDbType.Smallint, DetalleMo.zona);
            cmd.Parameters.AddWithValue("@in_sector", NpgsqlDbType.Smallint, DetalleMo.sector);
            cmd.Parameters.AddWithValue("@in_cupocre1", NpgsqlDbType.Double, DetalleMo.cupocre1);
            cmd.Parameters.AddWithValue("@in_cupocre2", NpgsqlDbType.Double, DetalleMo.cupocre2);
            cmd.Parameters.AddWithValue("@in_empresa", NpgsqlDbType.Double, DetalleMo.empresa);
            cmd.Parameters.AddWithValue("@in_placa1", NpgsqlDbType.Char, DetalleMo.placa1);
            cmd.Parameters.AddWithValue("@in_placa2", NpgsqlDbType.Char, DetalleMo.placa2);
            cmd.Parameters.AddWithValue("@in_placa3", NpgsqlDbType.Char, DetalleMo.placa3);
            cmd.Parameters.AddWithValue("@in_placa4", NpgsqlDbType.Char, DetalleMo.placa4);
            cmd.Parameters.AddWithValue("@in_placa5", NpgsqlDbType.Char, DetalleMo.placa5);
            cmd.Parameters.AddWithValue("@in_placa6", NpgsqlDbType.Char, DetalleMo.placa6);
            cmd.Parameters.AddWithValue("@in_placa7", NpgsqlDbType.Char, DetalleMo.placa7);
            cmd.Parameters.AddWithValue("@in_placa8", NpgsqlDbType.Char, DetalleMo.placa8);
            cmd.Parameters.AddWithValue("@in_nrocta", NpgsqlDbType.Varchar, DetalleMo.nrocta);
            cmd.Parameters.AddWithValue("@in_banco", NpgsqlDbType.Varchar, DetalleMo.banco);
            cmd.Parameters.AddWithValue("@in_tipocta", NpgsqlDbType.Integer, DetalleMo.tipocta);
            cmd.Parameters.AddWithValue("@in_cuentadb", NpgsqlDbType.Varchar, DetalleMo.cuentadb);
            cmd.Parameters.AddWithValue("@in_cuentacr", NpgsqlDbType.Varchar, DetalleMo.cuentacr);
            cmd.Parameters.AddWithValue("@in_cuentaddb", NpgsqlDbType.Varchar, DetalleMo.cuentaddb);
            cmd.Parameters.AddWithValue("@in_cuentadcr", NpgsqlDbType.Varchar, DetalleMo.cuentadcr);
            cmd.Parameters.AddWithValue("@in_cuentagst", NpgsqlDbType.Varchar, DetalleMo.cuentagst);
            cmd.Parameters.AddWithValue("@in_cuentadevol", NpgsqlDbType.Varchar, DetalleMo.cuentadevol);

            return Exec_sql.EjecutarQuerySP(cmd);
        }

        /// <summary>
        /// Funcion para inactivar el registro de CatalogoHijo
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>
        public static dynamic Delete_Detalle(TablasGeneralesDetalleDelete DetalleMo)
        {
            string codEmpresa = Constantes.General.Empresa;
            var cmd = new NpgsqlCommand();
            string sql = "";

            sql = "spd_tabla_detalle";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_codemp", codEmpresa);
            cmd.Parameters.AddWithValue("@in_codtab", DetalleMo.codtab);
            cmd.Parameters.AddWithValue("@in_codigo", DetalleMo.codigo);

            return Exec_sql.EjecutarQuerySP(cmd);

        }
    }
}
