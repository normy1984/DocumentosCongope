﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Microsoft.AspNetCore.Mvc;
using Npgsql;

namespace Congope.Empresas.BussinessLogic
{
    /// <summary>
    /// Clase que contiene operaciones Crud
    /// </summary>
    public class InventarioInicialBl
    {

        /// <summary>
        /// Método para ver la lista de Invetario Inicial
        /// </summary>
        /// <returns>Lista de Inventarios</returns>
        public static List<InventarioInicialMo> ListarInventarioInicial()
        {

            List<InventarioInicialMo> oInventarioInicialMo = new List<InventarioInicialMo>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = @"select 
                                    a.cuenta, b.nom_cue, cantidb, a.costo103, 
                                    (a.cantidb * a.costo103) as total, a.sec_det 
                                    from indetmov a 
                                    left join inplacta b on a.codemp = b.codemp and a.anio = b.anio and a.cuenta = b.cuenta
                                    limit 100
";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oInventarioInicialMo.Add(new InventarioInicialMo()
                            {
                                cuenta = dr[0].ToString(),
                                nom_cue = dr[1].ToString(),
                                cantidb = Convert.ToInt32(dr[2].ToString()),
                                costo103 = Convert.ToSingle(dr[3].ToString()),
                                total = Convert.ToSingle(dr[4].ToString()),
                                sec_det = Convert.ToInt32(dr[5].ToString()),
                            });
                        }
                    }
                    return oInventarioInicialMo;
                }
                catch (Exception e)
                {
                    throw e;
                    return oInventarioInicialMo;
                }

            }

        }

        /// <summary>
        /// Método para ver la lista de Invetario Inicial - Documento
        /// </summary>
        /// <returns>Lista de Inventarios</returns>
        public static List<InventarioInicialMo_Documento> ListarInventarioInicial_Documento()
        {

            List<InventarioInicialMo_Documento> oInventarioInicialMo_Documento = new List<InventarioInicialMo_Documento>();
            using (NpgsqlConnection oConexion = new NpgsqlConnection(Conexion.cadena))
            {
                NpgsqlCommand cmd = new NpgsqlCommand();
                cmd.CommandText = @"select b.descrip as departamento, c.descrip as responsable, d.descrip as n_estado,
                                    a.sig_tip , a.acu_tip , a.fec_asi, a.bodrec02 
                                    from incabmov  a  
                                    left join tablas b on a.codemp = b.codemp and b.codtab = 19 and b.codigo > 0 and a.bodrec02 = b.codigo  
                                    left join tablas c on a.codemp = c.codemp and c.codtab = 54 and c.codigo > 0 and a.codrec02 = c.codigo  
                                    left join tablas d on a.codemp = d.codemp and d.codtab = 2 and d.codigo > 0 and a.estado = d.codigo  
                                    Where -- & Funciones.GetEmp(a) &   and 
                                    a.sig_tip = 'IN' 
                                    -- and a.anio = 2024 
                                    order by a.acu_tip desc
                                    ";
                cmd.Connection = oConexion;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            // Se realiza un cast de la variable de fecha para evitar errores en registros null
                            DateOnly? esFecha; DateOnly varFecha;
                            esFecha = DateOnly.TryParse(dr[5].ToString(), out varFecha) ? varFecha : (DateOnly?)null;

                            oInventarioInicialMo_Documento.Add(new InventarioInicialMo_Documento()
                            {

                                departamento = dr[0].ToString(),
                                responsable = dr[1].ToString(),
                                n_estado = dr[2].ToString(),
                                sig_tip = dr[3].ToString(),
                                acu_tip = Convert.ToInt32(dr[4].ToString()),
                                fec_asi = varFecha,
                                bodrec02 = Convert.ToInt32(dr[6].ToString()),

                            });
                        }
                    }
                    return oInventarioInicialMo_Documento;
                }
                catch (Exception e)
                {
                    throw e;
                    return oInventarioInicialMo_Documento;
                }

            }

        }


    }
}
