﻿using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Genericas;
using Microsoft.IdentityModel.Tokens;
using Npgsql;
using System.DirectoryServices.Protocols;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
using static iText.Kernel.Pdf.Colorspace.PdfSpecialCs;
using System.Text.RegularExpressions;
using Congope.Empresas.BussinessLogic.Administracion;
using Newtonsoft.Json;


namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class LoginBL
    {
        /// <summary>
        /// Funcion que trae la informacion de un usuario con el atributo de usuario y contraseña
        /// </summary>
        /// <param name="oCredencialesLogo"></param>
        /// <returns></returns>
        public static dynamic GetUsuario(CredencialesLogo oCredencialesLogo)
        {
            var respuesta = new ApiResultMo<List<LoginMo>>(); // Cambiar a List<LoginMo>
            var validaLogin = new ApiResultMo<string>();


            try
            {

                switch ((Conexion.ValidarLdap, Regex.IsMatch(oCredencialesLogo.login, @"^\d+$")))
                {
                    case (true, true):
                        // CUANDO ES VALIDACION CON LDAP Y ME ENVIA SOLO NUMEROS
                        respuesta.message = "No existe el usuario";

                        break;
                    case (false, false):
                        // CUANDO ES VALIDACION SIN LDAP Y ME ENVIA LETRAS
                        respuesta.message = "No existe el usuario";
                        break;

                    default:
                        // En caso de que no haya un caso que coincida (esto debería ser imposible en este caso)
                        using (var cmd = new NpgsqlCommand())
                        {
                            string sql = @"select * from public.sp_selectusuarioinfologin(@usuario);";
                            cmd.Parameters.AddWithValue("@usuario", oCredencialesLogo.login.ToString());
                            cmd.CommandText = sql;

                            var oLoginMo = Exec_sql.cargarDatosModel<LoginMo>(cmd);  // Retornar List<LoginMo>

                            if (oLoginMo.success)
                            {
                                var ContrasenaBase = SeguridadBL.DecryptStringFromBytes_Aes(
                                    oLoginMo.result[0].contrasena.Trim(),
                                    oLoginMo.result[0].llave.Trim()
                                );


                                if (Conexion.ValidarLdap)
                                {
                                    validaLogin = AutenticaActiveDirectory(
                                    oCredencialesLogo.login,
                                    oCredencialesLogo.contrasena

                                    );

                                }
                                else
                                {

                                    validaLogin = AutenticaTablaSistema(
                                    oLoginMo.result[0].contrasena.Trim(),
                                    oLoginMo.result[0].llave.Trim(),
                                    oCredencialesLogo.contrasena
                                    );
                                }

                                if (validaLogin.success)
                                {
                                    respuesta.success = true;
                                    respuesta.message = "Lectura exitosa";
                                    respuesta.result = oLoginMo.result;  // Asignar List<LoginMo>
                                }
                                else
                                {
                                    respuesta.message = validaLogin.message;
                                }
                            }
                            else
                            {
                                respuesta.message = "No existe el usuario";
                            }
                        }
                        break;
                }



            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                respuesta.message = "Ocurrió un error al procesar la solicitud.";
            }

            return respuesta;
        }

        /// <summary>
        /// Funcion que genera el token de autorizacion de los servicios
        /// </summary>
        /// <param name="oCredenciales"></param>
        /// <returns></returns>
        public static dynamic ObtenerToken(CredencialesLogo oCredenciales)
        {
            var respuesta = GetUsuario(oCredenciales);
            try
            {
                if (respuesta.success == true)
                {
                    var oLoginMo = respuesta.result;

                    var token = GenerarToken(
                        oLoginMo[0].CodigoUsu,
                        oLoginMo[0].login
                        );

                    oLoginMo[0].llave = token;
                    oLoginMo[0].contrasena = "";

                    respuesta.message = "Token Generado Exitosamente";
                    respuesta.result = oLoginMo;
                }
            }
            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                respuesta.message = "Error de generación de token";
                respuesta.success = false;
            }
            return respuesta;
        }

        /// <summary>
        /// Funcion que realiza la autenticacion a traves de la tabla del sistema
        /// </summary>
        /// <param name="password"></param>
        /// <param name="llave"></param>
        /// <param name="oContrasena"></param>
        /// <returns></returns>

        protected static dynamic AutenticaTablaSistema(string password, string llave, string oContrasena)
        {

            var respuesta = new ApiResultMo<string>();

            try
            {

                /** 
                ESTA FUNCION HAY QUE ACTIVAR SI SE DESEA LOGEARSE CON LA FUNCION DE DESENCRIPCION DEL VB6
                ACTUALIZAR LA FUNCION  PARA RECIBIR LOS VALORES DE password y llave
                * public.sp_selectusuarioinfologin
                var ContrasenaBase = SeguridadSFGv6BL.Desencriptar(
                                password.Trim(),
                                llave.Trim()
                            );
                **/

                var ContrasenaBase = SeguridadBL.DecryptStringFromBytes_Aes(
                            password.Trim(),
                            llave.Trim()
                        );

                if (ContrasenaBase == oContrasena)
                {
                    respuesta.success = true;
                }
                else
                {
                    respuesta.success = false;
                    respuesta.message = "Contraseña Incorrecta";
                }

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                respuesta.message = "Contraseña Incorrecta";

            }

            return respuesta;

        }


        /// <summary>
        /// Funcion que realiza la autenticacion de usuario con el Directorio Activo institucional
        /// </summary>
        /// <param name="correo"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        protected static dynamic AutenticaActiveDirectory(string correo, string password)
        {

            var respuesta = new ApiResultMo<string>();

            try
            {
                var _ldapConfig = Conexion.ldapConfig;

                int indiceArroba = correo.IndexOf('@');

                string username = correo.Substring(0, indiceArroba);


                string domainController = _ldapConfig.DomainControllers[0]; // Assuming there's only one domain controller
                string userDn = $"{username}{_ldapConfig.AccountSuffix}";

                using (var ldapConnection = new LdapConnection(new LdapDirectoryIdentifier(domainController)))
                {
                    ldapConnection.AuthType = AuthType.Basic; // Use Basic authentication

                    ldapConnection.Bind(new NetworkCredential(userDn, password));

                    // If Bind succeeds, authentication is successful
                    respuesta.success = true;

                }
            }
            catch (LdapException ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                respuesta.message = ex.Message;

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                respuesta.message = ex.Message;
            }
            return respuesta;
        }

        /// <summary>
        /// Esta funcion regenera el token si es que ya caduco, con esta funcion se evita crear muchos tokens antiguos
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public static dynamic RenovarToken(string token)
        {
            var respuesta = new ApiResultMo<string>();

            try
            {
                var jwt = new JwtMo();
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
                // Valida el token
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = key,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = jwt.Issuer,
                    ValidAudience = jwt.Audience,
                    ValidateLifetime = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var usuario = jwtToken.Claims.FirstOrDefault(x => x.Type == "usuario")?.Value;
                var id = jwtToken.Claims.FirstOrDefault(x => x.Type == "id")?.Value;

                // Verificar la fecha de expiración
                var expirationDate = jwtToken.ValidTo;

                // Verificar si el token ha expirado hace más de una hora
                if (DateTime.UtcNow.Subtract(expirationDate).TotalMinutes > jwt.TiempoMaximoRenovar)
                {
                    throw new Exception("El token expiró hace mas de " + jwt.TiempoMaximoRenovar + " minutos y no puede renovarse.");
                }

                respuesta.result = GenerarToken(Int32.Parse(id), usuario);
                respuesta.success = true;

            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                respuesta.success = false;
                respuesta.message = ex.Message;
            }

            return respuesta;
        }


        /// <summary>
        /// Funcion que genera el token con el que se valida el acceso a los servicios 
        /// </summary>
        /// <param name="codigoUsuario"></param>
        /// <param name="NombreUsuario"></param>
        /// <returns></returns>
        protected static string GenerarToken(int codigoUsuario, string NombreUsuario)
        {

            var jwt = new JwtMo();
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key));
            var singIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                                new Claim(JwtRegisteredClaimNames.Sub, jwt.Subject),
                                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                                new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()),
                                new Claim("id", codigoUsuario.ToString()),
                                new Claim("usuario", NombreUsuario),
                            };

            var token = new JwtSecurityToken(
                 jwt.Issuer,
                 jwt.Audience,
                 claims,
                 expires: DateTime.Now.AddMinutes(jwt.DuracionToken), /*VALIDAR EL TIEMPO O ALGUN SERVICIO PARA RENOVAR EL TOKEN AUTOMATICAMENTE*/
                 signingCredentials: singIn
                 );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        /// <summary>
        /// Funcion que recibe las credenciales usuario y correo para recuperar la contraseña
        /// </summary>
        /// <param name="oCredencialesLogo"></param>
        /// <returns></returns>
        public static dynamic RecuperarContrasena(CredencialesLogo oCredencialesLogo)
        {
            var respuesta = new ApiResultMo<string>();
            using (var cmd = new NpgsqlCommand())
            {
                string sql = @"select * from public.sps_validarUsuarioRecupera(@in_cedruc,@in_email1);";
                cmd.Parameters.AddWithValue("@in_cedruc", oCredencialesLogo.login.ToString());
                cmd.Parameters.AddWithValue("@in_email1", oCredencialesLogo.contrasena.ToString());
                cmd.CommandText = sql;
                var DatosUsuario = Exec_sql.cargarDatosJson(cmd);

                if (DatosUsuario.success)
                {
                    DatosUsuario = JsonConvert.DeserializeObject(DatosUsuario.result.ToString());
                    var cod_usu = Int32.Parse(DatosUsuario[0]["cod_usu"].Value.ToString());
                    var EnviarCorreo = UsuariosBL.ResetearContrasena(cod_usu);
                    respuesta.message = EnviarCorreo.message;
                    if (EnviarCorreo.success)
                    {
                        respuesta.success = EnviarCorreo.success;
                        respuesta.message = EnviarCorreo.message;

                    }

                }
                else
                {
                    respuesta.message = "La credenciales ingresadas son erroneas, por favor verifique!!";
                }
            }
            return respuesta;
        }

    }


}
