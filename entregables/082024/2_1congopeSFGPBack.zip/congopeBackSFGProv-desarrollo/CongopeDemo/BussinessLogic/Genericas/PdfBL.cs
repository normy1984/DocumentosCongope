﻿using System;
using System.IO;
using iText.IO.Font.Constants;
using iText.Kernel.Colors;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Html2pdf;
using iText.IO.Image;
using Congope.Empresas.Data;
using iText.Layout.Font;
using Congope.Empresas.Models.Reportes;
using Congope.Empresas.BussinessLogic.Administracion;
using Microsoft.AspNetCore.Mvc.RazorPages;
using iText.Layout.Layout;
using iText.Layout.Renderer;
using System.Runtime.CompilerServices;



namespace Congope.Empresas.BussinessLogic.Genericas
{

    public class PdfBL
    {
        private static string? NombreUsuario; 
        /// <summary>
        /// Funcion para construir el string base 64 que se retorna para la construccion del PDF
        /// </summary>
        /// <param name="CuerpoReporte"></param>
        /// <returns></returns>
        public static dynamic GenerarPDFBase64(PiePaginaMO CuerpoReporte)
        {
            var DatosUsuario = UsuariosBL.CargarUsuarioCodigo(CuerpoReporte.VarSesion.codUsu);
            var DatosEmpresa = EmpresaDataBL.ObtenerEmpresaCodigo(CuerpoReporte.VarSesion.CodEmp);

            var correo = DatosUsuario.result[0].correo;
            int indiceArroba = correo.IndexOf('@');
            string username = correo.Substring(0, indiceArroba);

            PdfBL.NombreUsuario = DatosUsuario.result[0].NombresCompletos;

            var imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + DatosEmpresa.result[0].pathlogo);
            if (!System.IO.File.Exists(imagen))
            {
                imagen = System.IO.Path.Combine(Environment.CurrentDirectory, "assets/images/" + Conexion.ErrorImagen);
            }

            var DatosCabeceraPdf = new DatosCabecera_Pdf_Mo
            {
                NombreReporte = CuerpoReporte.descrip,
                NombreUsuario = username.ToUpper(),
                NumeroDocumento = CuerpoReporte.numero_documento,
                FilePath_LogoPdf = imagen,
                NombreInstitucion_Pdf = DatosEmpresa.result[0].nom_emp
            };

            var DatosPiePdf = new DatosPie_Pdf_Mo
            {
                MostrarFechaHora = CuerpoReporte.imp_fecha,
                Direccion_Pdf = DatosEmpresa.result[0].dir_emp,
                Telefono_Pdf = "Telf: " + DatosEmpresa.result[0].tel1_emp,
                ciudad_Pdf = DatosEmpresa.result[0].ciudad.ToUpper() + "-ECUADOR",
                email_Pdf = "Email: " + DatosEmpresa.result[0].email1
            };

            FontProvider fontProvider = new FontProvider();
            fontProvider.AddSystemFonts();
            fontProvider.AddFont(StandardFonts.HELVETICA);
            ConverterProperties properties = new ConverterProperties();
            properties.SetFontProvider(fontProvider);

            PdfFont font = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);
            float fontSize = 10;
            var Orientacion = CuerpoReporte.orientacion == "L" ? PageSize.A4.Rotate() : PageSize.A4;

            try
            {
                // Primera pasada: Generar el documento y calcular el número total de páginas
                byte[] pdfBytes;
                using (MemoryStream ms = new MemoryStream())
                {
                    using (PdfWriter writer = new PdfWriter(ms))
                    using (PdfDocument pdf = new PdfDocument(writer))
                    {
                        Document document = new Document(pdf, Orientacion);
                        // LLAMADA A LAS CLASES DE LA CABECERA Y PIE DE PAGINA
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new CabeceraEventHandler(DatosCabeceraPdf));
                        pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new PieEventHandler(DatosPiePdf));

                        document.SetFont(font).SetFontSize(fontSize);
                        document.SetMargins(125, 20, 80, 20);

                        if (!string.IsNullOrEmpty(CuerpoReporte.cabecera))
                        {
                            document.Add(new Paragraph(CuerpoReporte.cabecera).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }

                        var _html = $"<div style=\"font-family: Arial, sans-serif;font-size: 12px;\">{CuerpoReporte.cuerpo_reporte}</div>";
                        using (MemoryStream htmlStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(_html)))
                        {
                            IList<IElement> elements = HtmlConverter.ConvertToElements(htmlStream, properties);
                            foreach (IElement element in elements)
                            {
                                document.Add((IBlockElement)element);
                            }
                        }

                         if (!string.IsNullOrEmpty(CuerpoReporte.pie))
                        {
                            document.Add(new Paragraph(CuerpoReporte.pie).SetTextAlignment(TextAlignment.JUSTIFIED));
                        }

                        

                        float[] cellWidth = { 33f, 34f, 33f };
                        Table TablaFirmas = new Table(UnitValue.CreatePercentArray(cellWidth)).UseAllAvailableWidth();
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma1);
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma2);
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma3);
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma4);
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma5);
                        AddFirmaToTable(TablaFirmas, CuerpoReporte.firma6);
                        
                        if (!TieneEspacioSuficiente(document, TablaFirmas))
                        {
                            document.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                        }

                        document.Add(TablaFirmas);

                        document.Close();

                        pdfBytes = ms.ToArray();
                    }
                }

                // Segunda pasada: Reabrir el documento y actualizar el pie de página con el número total de páginas

                string pdfBase64 = GenerarDocumentoBase64(pdfBytes);


                return new
                {
                    success = true,
                    message = "",
                    result = pdfBase64
                };
            }
            catch (NullReferenceException ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
            catch (Exception ex)
            {
                SeguridadBL.WriteErrorLog(ex);
                return new
                {
                    success = false,
                    message = "Error: " + ex.Message,
                    result = ""
                };
            }
        }

        public static bool TieneEspacioSuficiente(Document document, Table table)
        {
            // Obtener el área actual de la página
            Rectangle currentPageArea = document.GetRenderer().GetCurrentArea().GetBBox();

            // Crear un renderer temporal para calcular la altura de la tabla
            IRenderer renderer = table.CreateRendererSubTree().SetParent(document.GetRenderer());
            LayoutResult result = renderer.Layout(new LayoutContext(new LayoutArea(1, new Rectangle(0, 0, currentPageArea.GetWidth(), float.MaxValue))));

            // Calcular la altura requerida por la tabla
            float requiredHeight = result.GetOccupiedArea().GetBBox().GetHeight();

            // Calcular la altura disponible considerando el contenido existente
            float availableHeight = currentPageArea.GetHeight() - document.GetBottomMargin();

            return availableHeight >= requiredHeight;
        }


        public static void AddFirmaToTable(Table table, string firma)
        {
            firma = firma.Replace("&", PdfBL.NombreUsuario);

            Cell cell = new Cell()
                .Add(new Paragraph("\n\n" + firma).SetBold())
                .SetBorder(Border.NO_BORDER)
                .SetTextAlignment(TextAlignment.CENTER);
            table.AddCell(cell);

        }


        public static string GenerarDocumentoBase64(byte[] pdfBytes)
        {
            using (MemoryStream msInput = new MemoryStream(pdfBytes))
            using (MemoryStream msOutput = new MemoryStream())
            using (PdfReader reader = new PdfReader(msInput))
            using (PdfWriter writer = new PdfWriter(msOutput))
            using (PdfDocument pdf = new PdfDocument(reader, writer))
            {
                Document document = new Document(pdf);
                for (int i = 1; i <= pdf.GetNumberOfPages(); i++)
                {
                    Paragraph header = new Paragraph($"PÁGINA: {i}/{pdf.GetNumberOfPages()}").
                        SetTextAlignment(TextAlignment.CENTER).SetFontSize(8f);
                    
                    Rectangle pageSize = new Rectangle(20, pdf.GetPage(i).GetPageSize().GetTop() - 105, pdf.GetPage(i).GetPageSize().GetWidth() - 40, 80);
                    float x = pdf.GetPage(i).GetPageSize().GetWidth() - pageSize.GetWidth()/4 + pageSize.GetWidth() / 8 - 20;
                    float y = pageSize.GetTop() - (pageSize.GetHeight() / 2) + 7;
                    document.ShowTextAligned(header, x, y, i, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 0);
                }
                document.Close();
                pdfBytes = msOutput.ToArray();
            }

            return Convert.ToBase64String(pdfBytes);
        }

       
    }


    public class CabeceraEventHandler : IEventHandler
    {
        private DatosCabecera_Pdf_Mo DatosReporte;
        /// <summary>
        /// CONSTRUCTOR PARA LA CABECERA
        /// </summary>
        /// <param name="NombreReporte"></param>
        /// <param name="nombreUsuario"></param>
        /// <param name="numeroDocumento"></param>
        public CabeceraEventHandler(DatosCabecera_Pdf_Mo oDatosCabecera_Pdf_Mo)
        {
            this.DatosReporte = new DatosCabecera_Pdf_Mo();
            this.DatosReporte.NombreUsuario = oDatosCabecera_Pdf_Mo.NombreUsuario;
            this.DatosReporte.FilePath_LogoPdf = oDatosCabecera_Pdf_Mo.FilePath_LogoPdf;
            this.DatosReporte.NombreReporte = oDatosCabecera_Pdf_Mo.NombreReporte;
            this.DatosReporte.NumeroDocumento = oDatosCabecera_Pdf_Mo.NumeroDocumento;
            this.DatosReporte.NombreInstitucion_Pdf = oDatosCabecera_Pdf_Mo.NombreInstitucion_Pdf;
    
        }
        /// <summary>
        /// FUNCION PARA LA SOBRECARGA DE LA CABECERA 
        /// </summary>
        /// <param name="event"></param>
        public void HandleEvent(Event @event)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)@event;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();

            PdfCanvas canvas1 = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);
            Rectangle rootArea = new Rectangle(20, page.GetPageSize().GetTop() - 105, page.GetPageSize().GetWidth() - 40, 80);

            new Canvas(canvas1, rootArea)
                .Add(getTable(docEvent));
        }

        /// <summary>
        /// CONSTRUCCION DE LA TABLA CON LOS ELEMENTOS PARA LA CABECERA
        /// </summary>
        /// <param name="docEvent"></param>
        /// <returns></returns>
        public Table getTable(PdfDocumentEvent docEvent)
        {
            float[] cellWidth = { 25f, 50f, 25f };
            Table tableEvent = new Table(UnitValue.CreatePercentArray(cellWidth)).UseAllAvailableWidth();
            PdfFont bold = PdfFontFactory.CreateFont(StandardFonts.TIMES_BOLD);


            // Construir la ruta completa del archivo PDF
            Image logoCongope = new Image(ImageDataFactory.Create(this.DatosReporte.FilePath_LogoPdf));

            // PARAMETROS PARA OBTENER EL NUMERO DE PAGINAS
            PdfPage page = docEvent.GetPage();
            int pageNum = docEvent.GetDocument().GetPageNumber(page);
            int pageNumPages = docEvent.GetDocument().GetNumberOfPages();

            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER);
            Style styleText = new Style()
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(10f);
            Style styleText_Pagina = new Style()
                .SetTextAlignment(TextAlignment.CENTER).SetFontSize(8f);

            //new SolidBorder(ColorConstants.BLACK, 1)

            // CELDA QUE SE AGREGA PARA EL ENCABEZADO

            Cell cell = new Cell()
                .Add(logoCongope.SetAutoScale(true).SetHorizontalAlignment(HorizontalAlignment.CENTER))
                .SetVerticalAlignment(VerticalAlignment.MIDDLE)
                .SetTextAlignment(TextAlignment.CENTER)
                .AddStyle(styleCell);

            tableEvent.AddCell(cell);


            // CELDA PARA LA PARTE CENTRAL DEL ENCABEZADO
            cell = new Cell()
                .Add(new Paragraph(this.DatosReporte.NombreInstitucion_Pdf).SetBold())
                .Add(new Paragraph(this.DatosReporte.NombreReporte))
                .Add(new Paragraph($"\n{this.DatosReporte.NumeroDocumento}").SetBold())
                .SetVerticalAlignment(VerticalAlignment.MIDDLE)
                .AddStyle(styleText)
                .AddStyle(styleCell);

            tableEvent.AddCell(cell);

            Paragraph LineaUsuario = new Paragraph();
            LineaUsuario.Add("USUARIO:");
            LineaUsuario.Add(new Text(this.DatosReporte.NombreUsuario).SetBold());

            cell = new Cell()
                .Add(new Paragraph($"\n"))
                .Add(LineaUsuario)
                .SetVerticalAlignment(VerticalAlignment.MIDDLE)
                .AddStyle(styleText_Pagina).AddStyle(styleCell);

            tableEvent.AddCell(cell);

            return tableEvent;
        }

      

    }

    /// <summary>
    /// CLASE PARA LA CONSTRUCCION DEL PIE DE PAGINA GENERICO PARA EL PDF
    /// </summary>
    public class PieEventHandler : IEventHandler
    {
        private DatosPie_Pdf_Mo PiePagina;
        /// <summary>
        /// CONSTRUCTOR DE LA CLASE PARA EL PIE DE PAGINA
        /// </summary>
        /// <param name="MostrarFechaHora"></param>
        public PieEventHandler(DatosPie_Pdf_Mo inPiePagina)
        {
            this.PiePagina = new DatosPie_Pdf_Mo();
            this.PiePagina.email_Pdf = inPiePagina.email_Pdf;
            this.PiePagina.Telefono_Pdf = inPiePagina.Telefono_Pdf;
            this.PiePagina.Direccion_Pdf = inPiePagina.Direccion_Pdf;
            this.PiePagina.ciudad_Pdf = inPiePagina.ciudad_Pdf;
            this.PiePagina.MostrarFechaHora = inPiePagina.MostrarFechaHora;
        }
        /// <summary>
        /// SOBRECARGA DE LA CLASE PARA SOBRESCRIBIR EL PIE DE PAGINA
        /// </summary>
        /// <param name="event"></param>
        public void HandleEvent(Event @event)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)@event;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();

            PdfCanvas canvas1 = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);
            Rectangle rootArea = new Rectangle(20, 20, page.GetPageSize().GetWidth() - 40, 60);

            new Canvas(canvas1, rootArea)
                .Add(getTable(docEvent));
        }
        /// <summary>
        /// TABLA PARA EL PIE DE PAGINA
        /// </summary>
        /// <param name="docEvent"></param>
        /// <returns></returns>
        public Table getTable(PdfDocumentEvent docEvent)
        {
            float[] cellWidth = { 50f, 50f };
            Table tableEvent = new Table(UnitValue.CreatePercentArray(cellWidth)).UseAllAvailableWidth();

            Style styleText = new Style()
                .SetTextAlignment(TextAlignment.RIGHT).SetFontSize(8f);

            Style styleCell = new Style()
                .SetBorder(Border.NO_BORDER)
                .SetBorderTop(new SolidBorder(ColorConstants.BLACK, 1));

            Cell cell = new Cell()
                 .Add(new Paragraph(this.PiePagina.Direccion_Pdf)).SetMarginBottom(5)
                 .Add(new Paragraph(this.PiePagina.Telefono_Pdf))
                 .Add(new Paragraph(this.PiePagina.email_Pdf))
                 .Add(new Paragraph(this.PiePagina.ciudad_Pdf))
                 .AddStyle(styleText)
                 .AddStyle(styleCell);

            tableEvent.AddCell(cell
                 .AddStyle(styleCell)
                 .SetTextAlignment(TextAlignment.LEFT));


            if (this.PiePagina.MostrarFechaHora == 1)
            {
                cell = new Cell()
                   .Add(new Paragraph($"{Conexion.NombreSistema}\n Ambiente:{Conexion.VariableAmbiente}"))
                   .Add(new Paragraph($"{DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")}"))
                   .AddStyle(styleText)
                   .AddStyle(styleCell);
            }
            else
            {
                cell = new Cell()
       .Add(new Paragraph($"{Conexion.NombreSistema}\n Ambiente:{Conexion.VariableAmbiente}"))
       .AddStyle(styleText)
       .AddStyle(styleCell);
            }

            tableEvent.AddCell(cell);

            return tableEvent;
        }
    }
}

