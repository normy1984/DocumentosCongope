﻿using Congope.Empresas.BussinessLogic.Parametrizacion;
using Congope.Empresas.Data;
using Congope.Empresas.General;
using Congope.Empresas.Models.Genericas;
using Congope.Empresas.Models.Parametrizacion;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.VisualBasic;
using Npgsql;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;


namespace Congope.Empresas.BussinessLogic.Genericas
{
    public class SeguridadBL
    {
        /// <summary>
        /// Funcion que genera una llave de 256Bits para la encriptacion de la contraseña
        /// </summary>
        /// <returns></returns>
        private static string Generate256BitKey()
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.KeySize = 256; // Set the key size to 256 bits
                aesAlg.GenerateKey(); // Generate a random 256-bit key
                return Convert.ToBase64String(aesAlg.Key);
            }
        }

        /// <summary>
        /// Funcion que encripta un string y devuelve el string encriptado y la llave 
        /// </summary>
        /// <param name="plainText"></param>
        /// <returns></returns>
        public static dynamic EncryptStringToBytes_Aes(string plainText)
        {
            string key = Generate256BitKey();

            byte[] encrypted;

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Convert.FromBase64String(key);
                aesAlg.IV = new byte[aesAlg.BlockSize / 8]; // IV should be the same size as the block size
                aesAlg.Mode = CipherMode.CBC; // Set the mode to CBC
                aesAlg.Padding = PaddingMode.PKCS7; // Use PKCS7 padding

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        swEncrypt.Write(plainText);
                    }
                    encrypted = msEncrypt.ToArray();
                }

               
            }

            return new
            {
                success = true,
                contrasenaEncriptada = Convert.ToBase64String(encrypted),
                llave = key
            };
        }

        /// <summary>
        /// Funcion que desencripta un string
        /// </summary>
        /// <param name="textToDecrypt"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string DecryptStringFromBytes_Aes(string textToDecrypt, string key)
        {
            string plaintext = null;
            byte[] cipherText = new byte[textToDecrypt.Replace(" ", "+").Length];
            cipherText = Convert.FromBase64String(textToDecrypt.Replace(" ", "+"));

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Convert.FromBase64String(key);
                aesAlg.IV = new byte[aesAlg.BlockSize / 8]; // IV should be the same size as the block size
                aesAlg.Mode = CipherMode.CBC; // Set the mode to CBC
                aesAlg.Padding = PaddingMode.PKCS7; // Use PKCS7 padding

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                {
                    plaintext = srDecrypt.ReadToEnd();
                }
            }
            return plaintext;
        }

        /// <summary>
        /// Generador de CodigoAleatorio puede generar un codigo con el numero de caracteres necesarios
        /// </summary>
        /// <param name="p_CodeLength"></param>
        /// <returns></returns>
        public string GeneraCodigo(int p_CodeLength)
        {
            string result = "";
            // Nuestro patrón de caracteres para formar el código
            string pattern = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            // Creamos una instancia del generador de números aleatorios
            // cogemos como semilla los Ticks de reloj de esta forma nos 
            // aseguramos de no generar códigos con la misma semilla.
            Random myRndGenerator = new Random((int)DateTime.Now.Ticks);
            // Procedemos a conformar el código
            for (int i = 0; i < p_CodeLength; i++)
            {
                // Obtenemos un número aleatorio que se corresponde con una
                // posición dentro del pattern.
                int mIndex = myRndGenerator.Next(pattern.Length);
                // Vamos formando el código
                result += pattern[mIndex];
            }

            return result;
        }


        /// <summary>
        /// Funcion que valida si un string es un email valido
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Normalize the domain
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Examines the domain part of the email and normalizes it.
                string DomainMapper(Match match)
                {
                    // Use IdnMapping class to convert Unicode domain names.
                    var idn = new IdnMapping();

                    // Pull out and process domain name (throws ArgumentException on invalid)
                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                SeguridadBL.WriteErrorLog(e);
                return false;
            }
            catch (ArgumentException e)
            {
                SeguridadBL.WriteErrorLog(e);
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException e)
            {
                SeguridadBL.WriteErrorLog(e);
                return false;
            }
        }

        /// <summary>
        /// Funcion para escribir los errores
        /// </summary>
        /// <param name="ex"></param>
        public static void WriteErrorLog(Exception ex)
        {
            // Ruta del archivo de registro de errores
            string logFilePath = Conexion.ErrorlogFilePath;

            // Abre el archivo de registro en modo de anexión
            using (StreamWriter writer = new StreamWriter(logFilePath, true))
            {
                // Escribe el mensaje de error y la pila de llamadas en el archivo de registro
                writer.WriteLine($"[DateTime: {DateTime.Now}] Error Message: {ex.Message}");
                writer.WriteLine($"StackTrace: {ex.StackTrace}");
                writer.WriteLine(); // Añade una línea en blanco para separar los registros de errores
            }
        }

    }
}
