﻿using System.Numerics;
using System.Text;

namespace Congope.Empresas.BussinessLogic.Genericas
{
    /// <summary>
    /// Esta clase se migro desde VB6. para poder mantener la relacion con la generacion de claves para el sistema anterior
    /// </summary>
    public class SeguridadSFGv6BL
    {
        public static string Mask;
        public static string tempmask;
        public static string MemoryMask;
        public static string Relleno;

        /// <summary>
        /// Funcion para encriptar la clave
        /// </summary>
        /// <param name="mensaje"></param>
        /// <returns></returns>
        public static dynamic Encriptar(string mensaje)
        {
            mensaje = Desordenar(mensaje);
            GenerarMascara();
            Mask = MemoryMask;
            tempmask = Mask;
            Relleno = "A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0%$#t!()[]{}¿=/+-.,abcdhe";
            mensaje = mensaje.Trim();
            byte a;
            int p1, p2, cont = 0, lon = mensaje.Length;

            if (lon < 63)
            {
                mensaje = mensaje.Trim() + Relleno.Substring(0, 63 - lon);
            }

            lon += 48;
            mensaje += (char)lon;

            string[,] matriz = new string[8, 8];
            cont = 0;

            do
            {
                tempmask = Mask;
                for (int i = 0; i < 16; i++)
                {
                    a = byte.Parse(Mask.Substring(0, 1));
                    Mask = Mask.Substring(1);
                    p1 = Xcuadrant(i + 1, a);
                    p2 = Ycuadrant(i + 1, a);
                    matriz[p1, p2] = "*";
                }

                for (int j = 0; j < 8; j++)
                {
                    for (int k = 0; k < 8; k++)
                    {
                        if (matriz[j, k] == "*")
                        {
                            matriz[j, k] = mensaje[0].ToString();
                            mensaje = mensaje.Substring(1);
                            cont++;
                            if (cont == 64)
                            {
                                goto fin;
                            }
                        }
                    }
                }

                Mask = RotarCuadrante(tempmask);
            } while (true);

        fin:
            mensaje = "";
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    mensaje += matriz[i, j];
                }
            }

            return new
            {
                contrasenaEncriptada = mensaje.Trim(),
                llave = MemoryMask
            };
        }
        /// <summary>
        /// Funcion para desencriptar la contraseña
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string Desencriptar(string mensaje, string key)
        {
            string Mask = key;
            string tempmask = Mask;
            string[,] matriz = new string[8, 8];
            string[,] lineal = new string[8, 8];
            byte a;
            int p1, p2, cont;

            int mensajeIndex = 0;

            // Inicialización de lineal con los caracteres de mensaje
            for (int i = 0; i <= 7; i++)
            {
                for (int j = 0; j <= 7; j++)
                {
                    if (mensajeIndex < mensaje.Length)
                    {
                        lineal[i, j] = mensaje[mensajeIndex].ToString();
                        mensajeIndex++;
                    }
                }
            }

            mensaje = "";
            cont = 0;

            while (true)
            {
                tempmask = Mask;

                for (int i = 0; i <= 15; i++)
                {
                    a = byte.Parse(Mask.Substring(0, 1));
                    Mask = Mask.Substring(1);
                    p1 = Xcuadrant(i + 1, a);
                    p2 = Ycuadrant(i + 1, a);
                    matriz[p1, p2] = "*";
                }

                for (int j = 0; j <= 7; j++)
                {
                    for (int k = 0; k <= 7; k++)
                    {
                        if (matriz[j, k] == "*")
                        {
                            matriz[j, k] = "@";
                            mensaje += lineal[j, k];
                            cont++;
                            if (cont == 64)
                                goto fin;
                        }
                    }
                }

                Mask = RotarCuadrante(tempmask);
            }

        fin:
            cont = (int)mensaje[mensaje.Length - 1];

            if (cont >= 48)
            {
                mensaje = mensaje.Substring(0, cont - 48);
            }
            else
            {
                mensaje = mensaje.Substring(0, cont - mensaje.Length);
            }

            return Ordenar(mensaje.Trim());
        }


        public static int Xcuadrant(int p, byte pos)
        {
            switch (pos)
            {
                case 1:
                    switch (p)
                    {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            return 0;
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                            return 1;
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                            return 2;
                        case 13:
                        case 14:
                        case 15:
                        case 16:
                            return 3;
                    }
                    break;
                case 2:
                    switch (p)
                    {
                        case 1:
                        case 5:
                        case 9:
                        case 13:
                            return 0;
                        case 2:
                        case 6:
                        case 10:
                        case 14:
                            return 1;
                        case 3:
                        case 7:
                        case 11:
                        case 15:
                            return 2;
                        case 4:
                        case 8:
                        case 12:
                        case 16:
                            return 3;
                    }
                    break;
                case 3:
                    switch (p)
                    {
                        case 13:
                        case 14:
                        case 15:
                        case 16:
                            return 4;
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                            return 5;
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                            return 6;
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            return 7;
                    }
                    break;
                case 4:
                    switch (p)
                    {
                        case 4:
                        case 8:
                        case 12:
                        case 16:
                            return 4;
                        case 3:
                        case 7:
                        case 11:
                        case 15:
                            return 5;
                        case 2:
                        case 6:
                        case 10:
                        case 14:
                            return 6;
                        case 1:
                        case 5:
                        case 9:
                        case 13:
                            return 7;
                    }
                    break;
            }

            return -1; // Default case if no match found
        }
        public static int Ycuadrant(int p, byte pos)
        {
            switch (pos)
            {
                case 4:
                    switch (p)
                    {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            return 0;
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                            return 1;
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                            return 2;
                        case 13:
                        case 14:
                        case 15:
                        case 16:
                            return 3;
                    }
                    break;
                case 1:
                    switch (p)
                    {
                        case 1:
                        case 5:
                        case 9:
                        case 13:
                            return 0;
                        case 2:
                        case 6:
                        case 10:
                        case 14:
                            return 1;
                        case 3:
                        case 7:
                        case 11:
                        case 15:
                            return 2;
                        case 4:
                        case 8:
                        case 12:
                        case 16:
                            return 3;
                    }
                    break;
                case 2:
                    switch (p)
                    {
                        case 13:
                        case 14:
                        case 15:
                        case 16:
                            return 4;
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                            return 5;
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                            return 6;
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            return 7;
                    }
                    break;
                case 3:
                    switch (p)
                    {
                        case 4:
                        case 8:
                        case 12:
                        case 16:
                            return 4;
                        case 3:
                        case 7:
                        case 11:
                        case 15:
                            return 5;
                        case 2:
                        case 6:
                        case 10:
                        case 14:
                            return 6;
                        case 1:
                        case 5:
                        case 9:
                        case 13:
                            return 7;
                    }
                    break;
            }

            return -1; // Default case if no match found
        }
        public static string RotarCuadrante(string mascara)
        {
            int v;
            string newmask = "";

            for (int i = 0; i < 16; i++)
            {
                v = (int)char.GetNumericValue(mascara[0]);
                mascara = mascara.Substring(1);

                if (v == 1)
                {
                    v = 4;
                }
                else
                {
                    v = v - 1;
                }

                newmask += v.ToString();
            }

            return newmask.Trim();
        }
        public static void GenerarMascara()
        {
            string strmask = "";
            Random rand = new Random();

            for (int i = 1; i <= 16; i++)
            {
                strmask += rand.Next(1, 5).ToString().Trim();
            }

            MemoryMask = strmask.Trim();
        }
        public static string Desordenar(string mensaje)
        {
            string nuevom = "";
            int despl;
            char a;
            Random rand = new Random();

            int basu = rand.Next(21) + 1;
            despl = rand.Next(5) + 1;
            nuevom = ((char)(64 + basu)).ToString() + ((char)(64 + despl)).ToString();

            foreach (char ch in mensaje)
            {
                a = ch;
                nuevom += (char)(a + despl);
            }

            return nuevom;
        }
        public static string Ordenar(string mensaje)
        {
            string nuevom = "";
            int despl;
            char c;
            string a = "";

            if (!string.IsNullOrWhiteSpace(mensaje))
            {
                nuevom = mensaje.Substring(2);
                a = mensaje.Substring(0, 2);
                c = a[1];
                despl = (int)c - 64;
                a = "";

                foreach (char ch in nuevom)
                {
                    a += (char)(ch - despl);
                }
            }

            return a;
        }


    }
}
