﻿using Congope.Empresas.BussinessLogic.Genericas;
using Congope.Empresas.Data;
using Congope.Empresas.Models;
using Congope.Empresas.Models.Administracion;
using Congope.Empresas.Models.Genericas;
using Newtonsoft.Json;
using Npgsql;
using NpgsqlTypes;

namespace Congope.Empresas.BussinessLogic.Administracion
{
    public class UsuariosBL
    {
        /// <summary>
        /// Funcion que retorna el listado de usuario existentes en el sistema
        /// </summary>
        /// <returns></returns>
        public static dynamic ListarUsuarios()
        {
            var cmd = new NpgsqlCommand();
            var sql = @"
                    SELECT 
                       * from public.sps_listarUsuarios();";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Funcion que retorna el listado de funcionarios activos necesarios para crear un usuario
        /// </summary>
        /// <returns></returns>
        public static dynamic ListarFuncionarios()
        {
            var cmd = new NpgsqlCommand();
            var sql = @"
                    SELECT * FROM
                    public.sps_seleccionarFuncionarios()
                    ;";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);
        }

        /// <summary>
        /// Funcion que retorna la informacion de los usuarios de acuerdo al codigo
        /// </summary>
        /// <param name="iCodigoUsuario"></param>
        /// <returns></returns>
        public static dynamic CargarUsuarioCodigo(int iCodigoUsuario)
        {
            var cmd = new NpgsqlCommand();
            var sql = @"SELECT
                          * FROM
                          public.sps_usuarioCodigo(@usuario)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@usuario", iCodigoUsuario);
            return Exec_sql.cargarDatosModel<LoginMo>(cmd);
        }
        
        /// <summary>
        /// Funcion que permite resetear la contraseña depende del codigo ingresado, genera una contraseña aleatoria de 8 digitos
        /// </summary>
        /// <param name="iCodigoUsuario"></param>
        /// <returns></returns>

        public static dynamic ResetearContrasena(int iCodigoUsuario)
        {
            dynamic respuesta, result = "";
            var cmd = new NpgsqlCommand();
            List<LoginMo> oLoginMo = new List<LoginMo>();
            string message = "Error: ";
            string sql = "";
            bool success = false;

            try
            {
                /// SE VALIDA EL USUARIO AL QUE SE DESEA RESETEAR LA CONTRASEÑA

                respuesta = CargarUsuarioCodigo(iCodigoUsuario);

                if (respuesta.success == true)
                {
                    oLoginMo = respuesta.result;

                    switch (oLoginMo.Count)
                    {
                        case 0:
                            message += "No existe el usuario";
                            break;
                        case 1:
                            message += "El correo electronico <" + oLoginMo[0].correo.Trim() + "> es invalido!!";

                            var CorreoValido = SeguridadBL.IsValidEmail(oLoginMo[0].correo.Trim());

                            if (CorreoValido == true)
                            {
                                // SI TIENE UN CORREO VALIDO PARA ACTUALIZAR REALIZO EL PROCESO DE ACTUALIZACION
                                string _html = string.Empty;
                                sql = @"select *
                                           from mensajes_html
                                           where men_codigo = @men_codigo;";
                                cmd.CommandText = sql;
                                cmd.Parameters.AddWithValue("@men_codigo", 1);

                                respuesta = Exec_sql.cargarDatosJson(cmd);
                                respuesta = JsonConvert.DeserializeObject(respuesta.result);
                                _html = respuesta[0]["men_html"];

                                var nuevaContrasena = new SeguridadBL().GeneraCodigo(8);

                                respuesta = ActualizarContrasena(oLoginMo[0].CodigoUsu, nuevaContrasena);

                                // SI LOS REGISTROS SE EJECUTARON CORRECTAMENTE SE ENVIA EL CORREO ELECTRONICO
                                if (respuesta.success == true)
                                {
                                    _html = _html.Replace("##USUARIO_NOMBRE##", oLoginMo[0].NombresCompletos.ToUpper());
                                    _html = _html.Replace("##USUARIO##", oLoginMo[0].login);
                                    _html = _html.Replace("##CONTRASENA##", nuevaContrasena);


                                    // ENVIAR CORREO PARA RECUPERACION DE CONTRASEÑA 
                                    var oCorreo = new CorreoMo();
                                    oCorreo.Para = new String[] { oLoginMo[0].correo };
                                    oCorreo.Asunto = "RESETEO DE CONTRASEÑA SFGProv";
                                    oCorreo.isHtml = true;
                                    oCorreo.Body = _html;

                                    var oEnviarCorreo = new CorreoBL().Enviar(oCorreo);

                                    success = oEnviarCorreo.success;
                                    message = oEnviarCorreo.message;
                                    result = oEnviarCorreo.result;
                                }
                                else
                                {
                                    success = respuesta.success;
                                    message = respuesta.message;
                                    result = respuesta.result;
                                }
                            }

                            break;
                        default:
                            message += "No existe el usuario";
                            break;
                    }
                }


                return new
                {
                    success = success,
                    message = message,
                    result = result
                };
            }

            catch (Exception e)
            {
                SeguridadBL.WriteErrorLog(e);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }

        }

        /// <summary>
        /// Funcion para cambiar la contraseña
        /// </summary>
        /// <param name="oCambiarContrasenaMo"></param>
        /// <returns></returns>

        public static dynamic CambiarContrasena(CambiarContrasenaMo oCambiarContrasenaMo)
        {
            dynamic respuesta, result = "";
            var cmd = new NpgsqlCommand();
            string message = "Error: ";
            bool success = false;

            try
            {
                string sql = @" select 
                             TRIM(u.password_nv) as password,
                             TRIM(u.llave_nv) as llave
                             from usuarios u
                             where  
                             u.cod_usu = @usuario";

                cmd.Parameters.AddWithValue("@usuario", oCambiarContrasenaMo.CodUsu);
                cmd.CommandText = sql;

                var usuario = Exec_sql.cargarDatosJson(cmd);
                usuario = JsonConvert.DeserializeObject(usuario.result);



                switch (usuario.Count)
                {
                    case 0:
                        message += "No existe el usuario!!";
                        break;
                    case 1:
                        message += "La contraseña actual es erronea!!";

                        string llave = usuario[0]["llave"];
                        string contrasena = usuario[0]["password"];

                        /*
                        var ContrasenaBase = SeguridadSFGv6BL.Desencriptar(contrasena, llave);
                        */
                        var ContrasenaBase = SeguridadBL.DecryptStringFromBytes_Aes(contrasena, llave);
                        

                        if (ContrasenaBase == oCambiarContrasenaMo.contrasenaAnterior)
                        {

                            respuesta = ActualizarContrasena(oCambiarContrasenaMo.CodUsu, oCambiarContrasenaMo.contrasenaNueva);
                            success = respuesta.success;
                            message = respuesta.message;
                            result = respuesta.result;

                        }


                        break;
                    default:
                        message += "No existe el usuario";
                        break;
                }


                return new
                {
                    success = success,
                    message = message,
                    result = result
                };
            }

            catch (Exception e)
            {
                Console.WriteLine("Explicitly specified:{0}{1}",
                Environment.NewLine, e.StackTrace);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion que realiza la actualizacion de los usuarios, recibe como parametros el codigo del usuario y la contraseña
        /// </summary>
        /// <param name="CodigoUsuario"></param>
        /// <param name="nuevaContrasena"></param>
        /// <returns></returns>
        private static dynamic ActualizarContrasena(int CodigoUsuario, string nuevaContrasena)
        {
            var cmd = new NpgsqlCommand();
            var ClaveEncriptada = SeguridadBL.EncryptStringToBytes_Aes(nuevaContrasena);
            var ClaveEncriptadaV6 = SeguridadSFGv6BL.Encriptar(nuevaContrasena);

            var sql = @"UPDATE
                                           usuarios
                                           set 
                                           password = @passwordV6,
                                           llave = @llaveV6,
                                           password_nv = @password,
                                           llave_nv = @llave,
                                           clave = md5(@nuevaContrasena)
                                           where cod_usu = @cod_usu;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@cod_usu", CodigoUsuario);
            cmd.Parameters.AddWithValue("@password", ClaveEncriptada.contrasenaEncriptada);
            cmd.Parameters.AddWithValue("@llave", ClaveEncriptada.llave);
            cmd.Parameters.AddWithValue("@passwordV6", ClaveEncriptadaV6.contrasenaEncriptada);
            cmd.Parameters.AddWithValue("@llaveV6", ClaveEncriptadaV6.llave);
            cmd.Parameters.AddWithValue("@nuevaContrasena", nuevaContrasena);

            return Exec_sql.EjecutarQuery(cmd);

        }

        /// <summary>
        /// Funcion que inactiva o inactiva usuarios del sistema
        /// </summary>
        /// <param name="CodigoUsuario"></param>
        /// <param name="EstadoUsuario"></param>
        /// <returns></returns>
        public static dynamic ActivarInactivarUsuario(int CodigoUsuario, int EstadoUsuario)
        {
            var cmd = new NpgsqlCommand();
            var sql = @"UPDATE
                        usuarios
                        set 
                        estado = @estado_usuario
                        where cod_usu = @cod_usu;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@cod_usu", CodigoUsuario);
            cmd.Parameters.AddWithValue("@estado_usuario", EstadoUsuario);
            return Exec_sql.EjecutarQuery(cmd);

        }

        /// <summary>
        /// Funcion que carga el menu del sistema es una funcion recursiva
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        private static List<UsuarioMenuPerfilMO> CargarMenuPerfilRecursivo(int codUsu, int nivel, string codigo)
        {
            var menu = new List<UsuarioMenuPerfilMO>();
            var respuesta = SqlCargarMenuPerfil(codUsu, nivel, codigo);

            if (respuesta.success)
            {
                var objetoMenu = respuesta.result; // Suponiendo que respuesta.result es de tipo List<MenuMO> o MenuMO[]
                foreach (var item in objetoMenu)
                {
                    if (item.TotalHijos > 0)
                    {
                        item.Submenu = CargarMenuPerfilRecursivo(codUsu, nivel + 1, item.Codigo); // Llamada recursiva para el siguiente nivel
                    }
                    else
                    {
                        item.Submenu = new List<UsuarioMenuPerfilMO>(); // Inicializar Submenu si es null
                    }
                    menu.Add(item); // Agregar cada ítem de objetoMenu a la lista menu
                }
            }
            return menu;
        }

        /// <summary>
        /// Funcion que carga los diferentes menus a los que tendra acceso el usuario
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        public static dynamic CargarMenuPerfil(int codUsu, int nivel, string codigo)

        {

            var menu = CargarMenuPerfilRecursivo(codUsu, nivel, codigo);

            return new
            {
                success = true,
                message = "",
                result = menu
            };
        }

        /// <summary>
        /// Consulta Sql que permite obtener los permisos de acceso a los que tiene acceso un usuario
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="nivel"></param>
        /// <param name="codigo"></param>
        /// <returns></returns>
        protected static dynamic SqlCargarMenuPerfil(int codUsu, int nivel, string codigo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.sps_generar_menu_perfil
                            (@codUsu, @nivel, @codigo);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Numeric, codUsu);
            cmd.Parameters.AddWithValue("@nivel", NpgsqlDbType.Numeric, nivel);
            cmd.Parameters.AddWithValue("@codigo", codigo);

            return Exec_sql.cargarDatosModel<UsuarioMenuPerfilMO>(cmd);

        }

        /// <summary>
        /// Funcion Sql para actualizar los datos especificos de un usuario
        /// </summary>
        /// <param name="oUsuariosMO"></param>
        /// <returns></returns>

        public static dynamic ActualizarUsuario(UsuariosMO oUsuariosMO)
        {

            try
            {

                var retorno = new ApiResultMo<string>();

                // ENVIAR LA CREACION O ACTUALIZACION DEL USUARIO
                var usuario = SqlInsertUpdateUsuario(oUsuariosMO.CodUsu, oUsuariosMO.Cedruc, oUsuariosMO.EsAdministrador, oUsuariosMO.UsuarioConsulta);

                if (usuario.success)
                {
                    usuario = JsonConvert.DeserializeObject(usuario.result);
                    int vusuario = Convert.ToInt32(usuario[0]["codusu"].ToString());

                    foreach (var item in oUsuariosMO.PerfilesMenu)
                    {

                       
                        var PerfilUsuario = SqlPerfilUsuario(vusuario, item.ToString());
                        if (!PerfilUsuario.success)
                        {
                            return usuario;
                        }
                    }

                    //*** SI TODO ES CORRECTO CAMBIO LA CONTRASEÑA SI HAY CREACION DE USUARIO**/

                    if (oUsuariosMO.CodUsu == -1 && Conexion.ValidarLdap)
                    {
                        return ResetearContrasena(vusuario);
                    }

                    retorno.success = true;
                    retorno.message = "Proceso generado exitosamente";

                }
                else
                {
                    return usuario;
                }


                return retorno;
               

            }

            catch (Exception e)
            {
                Console.WriteLine("Explicitly specified:{0}{1}",
                Environment.NewLine, e.StackTrace);
                return new
                {
                    success = false,
                    message = "Error: " + e.Message,
                    result = ""
                };
            }
        }

        /// <summary>
        /// Funcion insert / update para la creacion de usuarios en el sistema
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="CedRuc"></param>
        /// <param name="EsAdmin"></param>
        /// <param name="UsuarioConsulta"></param>
        /// <returns></returns>
        protected static dynamic SqlInsertUpdateUsuario(int codUsu, string CedRuc , int EsAdmin, bool UsuarioConsulta)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.spiu_usuario
                            (@codUsu, @CedRuc, @EsAdmin, @UsuarioConsulta);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Numeric, codUsu);
            cmd.Parameters.AddWithValue("@CedRuc", NpgsqlDbType.Varchar, CedRuc);
            cmd.Parameters.AddWithValue("@EsAdmin", NpgsqlDbType.Numeric, EsAdmin);
            cmd.Parameters.AddWithValue("@UsuarioConsulta", NpgsqlDbType.Boolean, UsuarioConsulta);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion que carga los permisos de un usuario especifico
        /// </summary>
        /// <param name="codUsu"></param>
        /// <param name="Codigo"></param>
        /// <returns></returns>
        protected static dynamic SqlPerfilUsuario(int codUsu, string Codigo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                           SELECT 
                            *
                            from
                            public.spiu_menuusuario
                            (@codUsu,  @codigo);";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Numeric, codUsu);
            cmd.Parameters.AddWithValue("@codigo", NpgsqlDbType.Varchar, Codigo);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Menu principal que carga los botones de los menus
        /// </summary>
        /// <returns></returns>
        public static dynamic CargarMenusAprobarDesaprobar()
        {

            NpgsqlCommand cmd = new NpgsqlCommand();
            string sql = $@"
                           select
                            * FROM
                            public.sps_menuAprobarDesaprobar();";
            cmd.CommandText = sql;
            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Opciones Aprobar o Desaprobar
        /// </summary>
        /// <param name="vConsultaAprobarDocumentosMo"></param>
        /// <returns></returns>
        public static dynamic CargarOpcionesAprobarDesaprobar(ConsultaAprobarDocumentosMo vConsultaAprobarDocumentosMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                        SELECT 
                           *   
                        FROM 
                        public.sps_opcionesAprobarDesaprobar 
                        (
                          @codUsu
                          ,@codemp
                         ,@anio
                         ,@CodSistema)
                         ;";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@codUsu", NpgsqlDbType.Numeric, vConsultaAprobarDocumentosMo.CodUsu);
            cmd.Parameters.AddWithValue("@codemp", NpgsqlDbType.Varchar, vConsultaAprobarDocumentosMo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@anio", NpgsqlDbType.Integer, vConsultaAprobarDocumentosMo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@CodSistema", NpgsqlDbType.Numeric, vConsultaAprobarDocumentosMo.CodSistema);

            return Exec_sql.cargarDatosJson(cmd);

        }

        /// <summary>
        /// Funcion que realiza el select de aprobacion o desaprobacion de los sistemas
        /// </summary>
        /// <param name="DetalleMo"></param>
        /// <returns></returns>

        public static dynamic ApruebaDesapruebaDocumentos(AprobarDesaprobarDocumentosMo DetalleMo)
        {

            NpgsqlCommand cmd = new NpgsqlCommand();

            string sql = $@"
                        SELECT 
                            *
                        FROM 
                            public.spiu_ApruebaDesapruebaDocumentos
                       (
                        @in_cod_usu,
                        @in_anio,
                        @in_sistema,
                        @in_aprueba,
                        @in_desaprueba,
                        @in_codemp,
                        @in_sig_tip
                        )";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@in_cod_usu", NpgsqlDbType.Integer, DetalleMo.CodUsu);
            cmd.Parameters.AddWithValue("@in_anio", NpgsqlDbType.Numeric, DetalleMo.VarSesion.Anio);
            cmd.Parameters.AddWithValue("@in_sistema", NpgsqlDbType.Smallint, DetalleMo.CodSistema);
            cmd.Parameters.AddWithValue("@in_aprueba", NpgsqlDbType.Numeric, DetalleMo.Aprueba);
            cmd.Parameters.AddWithValue("@in_desaprueba", NpgsqlDbType.Numeric, DetalleMo.Desaprueba);
            cmd.Parameters.AddWithValue("@in_codemp", NpgsqlDbType.Char, DetalleMo.VarSesion.CodEmp);
            cmd.Parameters.AddWithValue("@in_sig_tip", NpgsqlDbType.Char, DetalleMo.SigTip);

            return Exec_sql.cargarDatosJson(cmd);

        }



    }
}
