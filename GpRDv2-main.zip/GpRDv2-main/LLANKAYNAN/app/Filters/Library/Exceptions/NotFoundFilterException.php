<?php

namespace App\Filters\Library\Exceptions;

use Exception;

class NotFoundFilterException extends Exception
{

}